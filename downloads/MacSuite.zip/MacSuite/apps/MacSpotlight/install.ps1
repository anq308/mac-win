﻿# Установка поиска MacSpotlight: копирует программу, включает автозапуск, добавляет ярлык в «Пуск»
# .\install.ps1             — установить
# .\install.ps1 -Uninstall  — удалить
param([switch]$Uninstall)

$dir = Join-Path $env:LOCALAPPDATA "Programs\MacSpotlight"
$exe = Join-Path $dir "mac-spotlight.exe"
$run = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$lnk = Join-Path ([Environment]::GetFolderPath("Programs")) "Поиск (MacSpotlight).lnk"

Get-Process mac-spotlight -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 400

if ($Uninstall) {
    Remove-ItemProperty $run -Name MacSpotlight -ErrorAction SilentlyContinue
    Remove-Item $lnk -Force -ErrorAction SilentlyContinue
    Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "MacSpotlight удалён. Win+Пробел снова переключает раскладку."
    return
}

New-Item -ItemType Directory -Force $dir | Out-Null
Copy-Item (Join-Path $PSScriptRoot "mac-spotlight.exe") $exe -Force
Unblock-File $exe -ErrorAction SilentlyContinue
Set-ItemProperty $run -Name MacSpotlight -Value "`"$exe`""

$sh = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
$sh.TargetPath = $exe
$sh.IconLocation = "$exe,0"
$sh.Description = "Поиск приложений, файлов и папок"
$sh.Save()

Start-Process $exe
Write-Host "Готово! Поиск запущен и будет стартовать вместе с Windows."
Write-Host ""
Write-Host "  Win+Пробел — открыть поиск"
Write-Host "  ↑ ↓ — выбрать, Enter — открыть, Ctrl+Enter — показать в папке, Esc — закрыть"
Write-Host "  Ctrl+1…4 — приложения, файлы, действия, история буфера обмена"
Write-Host "  Pause или Shift дважды — исправить раскладку («ghbdtn» → «привет»)"
Write-Host "  Пробел в Проводнике — быстрый просмотр файла"
