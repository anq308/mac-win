﻿# Установка MacMirror: копирует программу, ярлыки «Экран iPhone» в «Пуск» и на рабочий стол,
# разрешает входящие подключения от iPhone в брандмауэре (только для домашней/частной сети)
# .\install.ps1             — установить или обновить
# .\install.ps1 -Uninstall  — удалить
param([switch]$Uninstall)

$dir = Join-Path $env:LOCALAPPDATA "Programs\MacMirror"
$exe = Join-Path $dir "mac-mirror.exe"
$links = @(
    (Join-Path ([Environment]::GetFolderPath("Programs")) "Экран iPhone.lnk"),
    (Join-Path ([Environment]::GetFolderPath("Desktop")) "Экран iPhone.lnk")
)
$rule = "MacMirror (экран iPhone)"

# правило брандмауэра меняется только с правами администратора — отдельным окном с запросом
function Set-Firewall([bool]$on) {
    $cmd = "Remove-NetFirewallRule -DisplayName '$rule' -ErrorAction SilentlyContinue;"
    if ($on) {
        $cmd += "New-NetFirewallRule -DisplayName '$rule' -Direction Inbound -Action Allow -Program '$exe' -Profile Private,Domain | Out-Null"
    }
    $enc = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($cmd))
    try {
        Start-Process powershell -Verb RunAs -Wait -WindowStyle Hidden -ArgumentList "-NoProfile -EncodedCommand $enc"
        return $true
    } catch {
        return $false
    }
}

Get-Process mac-mirror -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 400

if ($Uninstall) {
    $null = Set-Firewall $false
    $links | ForEach-Object { Remove-Item $_ -Force -ErrorAction SilentlyContinue }
    Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "MacMirror удалён. Снимки и записи остались в папке «Изображения\iPhone»."
    return
}

New-Item -ItemType Directory -Force $dir | Out-Null
Copy-Item (Join-Path $PSScriptRoot "mac-mirror.exe") $exe -Force
Unblock-File $exe -ErrorAction SilentlyContinue

$shell = New-Object -ComObject WScript.Shell
foreach ($lnk in $links) {
    $sh = $shell.CreateShortcut($lnk)
    $sh.TargetPath = $exe
    $sh.IconLocation = "$exe,0"
    $sh.Description = "Экран iPhone на компьютере по Wi-Fi"
    $sh.Save()
}

Write-Host "Брандмауэр: разрешаю iPhone подключаться к программе — подтвердите запрос администратора..."
if (-not (Set-Firewall $true)) {
    Write-Host "Правило не добавлено. При первом запуске Windows сама спросит — отметьте «Частные сети» и нажмите «Разрешить»."
}

Start-Process $exe
Write-Host ""
Write-Host "Готово! Ярлык «Экран iPhone» — на рабочем столе и в меню «Пуск»."
Write-Host ""
Write-Host "  На iPhone: Пункт управления → «Повтор экрана» → выберите $env:COMPUTERNAME"
Write-Host "  Ctrl+S — снимок, Ctrl+R — запись, Ctrl+T — поверх окон, F11 — во весь экран"
Write-Host "  Снимки и записи: «Изображения\iPhone»"
Write-Host "  Ctrl+F — файлы с iPhone и на iPhone по QR-коду"
