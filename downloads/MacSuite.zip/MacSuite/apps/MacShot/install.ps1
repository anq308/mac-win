﻿# Установка MacShot: копирует программу, включает автозапуск, добавляет ярлык в «Пуск»
# .\install.ps1             — установить
# .\install.ps1 -Uninstall  — удалить
param([switch]$Uninstall)

$dir = Join-Path $env:LOCALAPPDATA "Programs\MacShot"
$exe = Join-Path $dir "mac-shot.exe"
$run = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$lnk = Join-Path ([Environment]::GetFolderPath("Programs")) "Хранилище снимков (MacShot).lnk"

Get-Process mac-shot -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 400

if ($Uninstall) {
    Remove-ItemProperty $run -Name MacShot -ErrorAction SilentlyContinue
    Remove-Item $lnk -Force -ErrorAction SilentlyContinue
    Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "MacShot удалён. Win+Shift+S снова открывает стандартные «Ножницы»."
    return
}

New-Item -ItemType Directory -Force $dir | Out-Null
Copy-Item (Join-Path $PSScriptRoot "mac-shot.exe") $exe -Force
Unblock-File $exe -ErrorAction SilentlyContinue
Set-ItemProperty $run -Name MacShot -Value "`"$exe`""

$sh = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
$sh.TargetPath = $exe
$sh.Arguments = "--library"
$sh.Save()

Start-Process $exe
Write-Host "Готово! MacShot запущен и будет стартовать вместе с Windows."
Write-Host ""
Write-Host "  Win+Shift+S  — панель: окно / область / весь экран"
Write-Host "  Win+Shift+4  — сразу область (Пробел — переключиться на окно)"
Write-Host "  Win+Shift+3  — весь экран"
Write-Host "  Win+Shift+2  — хранилище всех снимков (перетаскивай их прямо в чаты)"
Write-Host "  Win+Shift+1  — выделить участок и скопировать с него текст"
Write-Host ""
Write-Host "Снимки: папка «Изображения\Снимки экрана» + сразу в буфере обмена."
