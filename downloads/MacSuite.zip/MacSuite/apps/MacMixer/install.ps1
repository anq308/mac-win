﻿# Установка MacMixer: копирует программу, включает автозапуск, добавляет ярлык в «Пуск»
# .\install.ps1             — установить
# .\install.ps1 -Uninstall  — удалить
param([switch]$Uninstall)

$dir = Join-Path $env:LOCALAPPDATA "Programs\MacMixer"
$exe = Join-Path $dir "mac-mixer.exe"
$run = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$lnk = Join-Path ([Environment]::GetFolderPath("Programs")) "Микшер громкости (MacMixer).lnk"

Get-Process mac-mixer -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 400

if ($Uninstall) {
    # стандартные баннеры уведомлений возвращаются, даже если программу закрыли не из меню
    if (Test-Path $exe) { Start-Process $exe -ArgumentList "--restore-banners" -Wait }
    Remove-ItemProperty $run -Name MacMixer -ErrorAction SilentlyContinue
    Remove-Item $lnk -Force -ErrorAction SilentlyContinue
    Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "MacMixer удалён."
    return
}

New-Item -ItemType Directory -Force $dir | Out-Null
Copy-Item (Join-Path $PSScriptRoot "mac-mixer.exe") $exe -Force
Unblock-File $exe -ErrorAction SilentlyContinue
Set-ItemProperty $run -Name MacMixer -Value "`"$exe`""

$sh = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk)
$sh.TargetPath = $exe
$sh.Save()

Start-Process $exe
Write-Host "Готово! MacMixer запущен и будет стартовать вместе с Windows."
Write-Host ""
Write-Host "  Клик по значку динамика в трее — панель громкости"
Write-Host "  Правый клик — параметры звука, автозапуск, выход"
Write-Host ""
Write-Host "Стандартный значок громкости можно спрятать: Параметры → Персонализация →"
Write-Host "Панель задач → Включение и выключение системных значков → Громкость."
