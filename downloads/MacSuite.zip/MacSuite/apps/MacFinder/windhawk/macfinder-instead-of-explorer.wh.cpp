// ==WindhawkMod==
// @id              macfinder-instead-of-explorer
// @name            MacFinder вместо Проводника
// @description     Обычные папки открываются в MacFinder: «Показать в папке», explorer.exe путь и /select, значок Проводника
// @version         1.0
// @author          kulem
// @include         explorer.exe
// @architecture    x86-64
// @compilerOptions -lole32 -loleaut32 -lshell32 -lshlwapi -luuid
// ==/WindhawkMod==

// ==WindhawkModReadme==
/*
# MacFinder вместо Проводника

Папки на диске открываются в MacFinder, а не в Проводнике:

- `explorer.exe C:\папка` и `explorer.exe /select,файл` — сразу MacFinder, Проводник даже не запускается;
- «Показать в папке» из браузеров, Telegram, Steam и т. д., значок Проводника на панели задач,
  «Открыть расположение файла» в «Пуске» — новое окно Проводника прячется и закрывается,
  вместо него открывается MacFinder с тем же файлом.

Панель управления, корзина, сеть, телефоны, zip-архивы и прочие «не-папки» остаются в Проводнике.

Обычный Проводник: зажать **Shift** (меняется в настройках) или «Открыть в Проводнике» в меню MacFinder.

Win+E и двойной клик по папкам на рабочем столе переключает установщик MacFinder (реестр),
этот мод ловит всё остальное.
*/
// ==/WindhawkModReadme==

// ==WindhawkModSettings==
/*
- finderPath: ""
  $name: Путь к mac-finder.exe
  $description: Пусто — %LOCALAPPDATA%\Programs\MacFinder\mac-finder.exe
- keepWindows: false
  $name: Не трогать новые окна Проводника
  $description: Перехватывать только запуски explorer.exe с путём
- bypassKey: shift
  $name: Клавиша для обычного Проводника
  $options:
  - shift: Shift
  - ctrl: Ctrl
  - none: Нет
*/
// ==/WindhawkModSettings==

#include <windows.h>
#include <exdisp.h>
#include <shlobj.h>
#include <shlwapi.h>
#include <shobjidl.h>

#include <string>
#include <vector>

static const wchar_t kThisPc[] = L"::{20D04FE0-3AEA-1069-A2D8-08002B30309D}";
static const wchar_t kHome[] = L"::{F874310E-B6B7-47DC-BC84-B9E6B38F5903}";
// MacFinder держит это событие пару секунд, когда сам открывает Проводник
static const wchar_t kBypassEvent[] = L"Local\\MacFinder.OpenExplorer";

static std::wstring g_finder;
static bool g_keepWindows = false;
static int g_bypassKey = VK_SHIFT;

static void LoadSettings() {
    PCWSTR p = Wh_GetStringSetting(L"finderPath");
    g_finder = p ? p : L"";
    Wh_FreeStringSetting(p);
    if (g_finder.empty()) {
        wchar_t buf[MAX_PATH];
        if (ExpandEnvironmentStringsW(L"%LOCALAPPDATA%\\Programs\\MacFinder\\mac-finder.exe", buf, MAX_PATH)) {
            g_finder = buf;
        }
    }
    g_keepWindows = Wh_GetIntSetting(L"keepWindows") != 0;
    PCWSTR k = Wh_GetStringSetting(L"bypassKey");
    g_bypassKey = !k || !*k || !wcscmp(k, L"shift") ? VK_SHIFT : !wcscmp(k, L"ctrl") ? VK_CONTROL : 0;
    Wh_FreeStringSetting(k);
}

static bool Bypass() {
    if (g_bypassKey && (GetAsyncKeyState(g_bypassKey) & 0x8000)) {
        return true;
    }
    if (HANDLE h = OpenEventW(SYNCHRONIZE, FALSE, kBypassEvent)) {
        CloseHandle(h);
        return true;
    }
    return GetFileAttributesW(g_finder.c_str()) == INVALID_FILE_ATTRIBUTES;
}

static bool IsDir(const std::wstring& p) {
    DWORD a = GetFileAttributesW(p.c_str());
    return a != INVALID_FILE_ATTRIBUTES && (a & FILE_ATTRIBUTE_DIRECTORY);
}

// Аргумент в кавычках так, чтобы «C:\» не превратился в «C:"» при разборе
static std::wstring Quote(const std::wstring& s) {
    std::wstring q = L"\"" + s;
    if (!s.empty() && s.back() == L'\\') {
        q += L'\\';
    }
    return q + L"\"";
}

static bool LaunchFinder(const std::wstring& args) {
    std::wstring cmd = Quote(g_finder) + L" " + args;
    STARTUPINFOW si = {sizeof(si)};
    PROCESS_INFORMATION pi = {};
    if (!CreateProcessW(g_finder.c_str(), cmd.data(), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {
        Wh_Log(L"CreateProcess failed: %u", GetLastError());
        return false;
    }
    AllowSetForegroundWindow(pi.dwProcessId);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    Wh_Log(L"MacFinder %s", args.c_str());
    return true;
}

// shell:Downloads, ::{CLSID}, file:/// — в путь на диске; computer — это «Этот компьютер»
static std::wstring Resolve(const std::wstring& target, bool* computer) {
    *computer = false;
    PIDLIST_ABSOLUTE pidl = nullptr;
    if (FAILED(SHParseDisplayName(target.c_str(), nullptr, &pidl, 0, nullptr)) || !pidl) {
        return L"";
    }
    std::wstring out;
    wchar_t buf[MAX_PATH * 4];
    if (SHGetPathFromIDListEx(pidl, buf, ARRAYSIZE(buf), GPFIDL_DEFAULT)) {
        out = buf;
    } else {
        PWSTR name = nullptr;
        if (SUCCEEDED(SHGetNameFromIDList(pidl, SIGDN_DESKTOPABSOLUTEPARSING, &name)) && name) {
            *computer = !_wcsicmp(name, kThisPc);
            CoTaskMemFree(name);
        }
    }
    CoTaskMemFree(pidl);
    return out;
}

// ---------- explorer.exe путь / explorer.exe /select,файл ----------

static std::vector<std::wstring> Tokens(PCWSTR s) {
    std::vector<std::wstring> out;
    std::wstring cur;
    bool quoted = false, any = false;
    for (; *s; s++) {
        wchar_t c = *s;
        if (c == L'"') {
            quoted = !quoted;
            any = true;
        } else if (!quoted && (c == L',' || c == L' ' || c == L'\t')) {
            if (any) {
                out.push_back(cur);
            }
            cur.clear();
            any = false;
        } else {
            cur += c;
            any = true;
        }
    }
    if (any) {
        out.push_back(cur);
    }
    // "/select,C:\a b" целиком в кавычках — ключ и путь всё равно отдельно
    std::vector<std::wstring> split;
    for (auto& t : out) {
        size_t comma = t.find(L',');
        if (!t.empty() && t[0] == L'/' && comma != std::wstring::npos) {
            split.push_back(t.substr(0, comma));
            if (comma + 1 < t.size()) {
                split.push_back(t.substr(comma + 1));
            }
        } else {
            split.push_back(t);
        }
    }
    return split;
}

static bool OwnsWindow() {
    bool found = false;
    EnumWindows(
        [](HWND h, LPARAM lp) -> BOOL {
            DWORD pid = 0;
            GetWindowThreadProcessId(h, &pid);
            if (pid == GetCurrentProcessId()) {
                *(bool*)lp = true;
                return FALSE;
            }
            return TRUE;
        },
        (LPARAM)&found);
    return found;
}

// true — запрос отдан MacFinder, этот explorer.exe больше не нужен
static bool HandleCommandLine() {
    PCWSTR args = PathGetArgsW(GetCommandLineW());
    if (!args || !*args) {
        return false;
    }
    bool select = false;
    std::wstring target;
    for (auto& t : Tokens(args)) {
        if (!_wcsicmp(t.c_str(), L"/select")) {
            select = true;
        } else if (!_wcsicmp(t.c_str(), L"/n") || !_wcsicmp(t.c_str(), L"/e") || !_wcsicmp(t.c_str(), L"/root") ||
                   !_wcsicmp(t.c_str(), L"/separate")) {
            continue;
        } else if (t[0] == L'/' || t[0] == L'-' || !target.empty()) {
            // /factory, -Embedding, /idlist и прочее служебное — не наше
            return false;
        } else {
            target = t;
        }
    }
    if (target.empty() || !FindWindowW(L"Shell_TrayWnd", nullptr) || OwnsWindow() || Bypass()) {
        return false;
    }
    bool computer = false;
    std::wstring path;
    if (target.rfind(L"shell:", 0) == 0 || target.rfind(L"::", 0) == 0 || target.rfind(L"file:", 0) == 0) {
        HRESULT co = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
        path = Resolve(target, &computer);
        if (SUCCEEDED(co)) {
            CoUninitialize();
        }
    } else {
        wchar_t full[MAX_PATH * 4];
        if (GetFullPathNameW(target.c_str(), ARRAYSIZE(full), full, nullptr)) {
            path = full;
        }
    }
    if (computer) {
        return LaunchFinder(Quote(kThisPc));
    }
    if (path.empty() || GetFileAttributesW(path.c_str()) == INVALID_FILE_ATTRIBUTES) {
        return false;
    }
    if (select) {
        return LaunchFinder(L"--select " + Quote(path));
    }
    // файл без /select проводник открывает программой — это не к нам
    return IsDir(path) && LaunchFinder(Quote(path));
}

// ---------- новые окна Проводника ----------

static const LONG kHideEx = WS_EX_LAYERED | WS_EX_TOOLWINDOW;

static void Restore(HWND h) {
    if (!IsWindow(h)) {
        return;
    }
    LONG ex = GetWindowLongW(h, GWL_EXSTYLE);
    bool visible = IsWindowVisible(h);
    // кнопка на панели задач появляется только при показе окна
    if (visible) {
        ShowWindow(h, SW_HIDE);
    }
    SetWindowLongW(h, GWL_EXSTYLE, ex & ~kHideEx);
    SetWindowPos(h, nullptr, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
    if (visible) {
        ShowWindow(h, SW_SHOW);
    }
    SetForegroundWindow(h);
}

enum Place { kWait, kFolder, kComputer, kHomeFolder, kOther };

// Куда смотрит окно; selection — выделенный файл, если окно открыли «Показать в папке»
static Place Probe(HWND hwnd, std::wstring& path, std::wstring* selection) {
    IShellWindows* sw = nullptr;
    if (FAILED(CoCreateInstance(CLSID_ShellWindows, nullptr, CLSCTX_ALL, IID_PPV_ARGS(&sw)))) {
        return kWait;
    }
    Place out = kWait;
    long count = 0;
    sw->get_Count(&count);
    for (long i = 0; i < count && out == kWait; i++) {
        VARIANT v;
        VariantInit(&v);
        v.vt = VT_I4;
        v.lVal = i;
        IDispatch* disp = nullptr;
        if (sw->Item(v, &disp) != S_OK || !disp) {
            continue;
        }
        IWebBrowserApp* app = nullptr;
        SHANDLE_PTR h = 0;
        if (SUCCEEDED(disp->QueryInterface(IID_PPV_ARGS(&app)))) {
            app->get_HWND(&h);
            app->Release();
        }
        IServiceProvider* sp = nullptr;
        IShellBrowser* sb = nullptr;
        IShellView* view = nullptr;
        IFolderView2* fv = nullptr;
        if ((HWND)h == hwnd && SUCCEEDED(disp->QueryInterface(IID_PPV_ARGS(&sp))) &&
            SUCCEEDED(sp->QueryService(SID_STopLevelBrowser, IID_PPV_ARGS(&sb))) && SUCCEEDED(sb->QueryActiveShellView(&view)) &&
            SUCCEEDED(view->QueryInterface(IID_PPV_ARGS(&fv)))) {
            IPersistFolder2* pf = nullptr;
            PIDLIST_ABSOLUTE pidl = nullptr;
            if (SUCCEEDED(fv->GetFolder(IID_PPV_ARGS(&pf))) && SUCCEEDED(pf->GetCurFolder(&pidl)) && pidl) {
                wchar_t buf[MAX_PATH * 4];
                PWSTR name = nullptr;
                if (SHGetPathFromIDListEx(pidl, buf, ARRAYSIZE(buf), GPFIDL_DEFAULT)) {
                    path = buf;
                    // zip-архив тоже «папка» с путём, но MacFinder его не откроет
                    out = IsDir(path) ? kFolder : kOther;
                } else if (SUCCEEDED(SHGetNameFromIDList(pidl, SIGDN_DESKTOPABSOLUTEPARSING, &name)) && name) {
                    out = !_wcsicmp(name, kThisPc) ? kComputer : !_wcsicmp(name, kHome) ? kHomeFolder : kOther;
                    CoTaskMemFree(name);
                } else {
                    out = kOther;
                }
                CoTaskMemFree(pidl);
            }
            if (pf) {
                pf->Release();
            }
            IShellItemArray* items = nullptr;
            if (out == kFolder && selection && SUCCEEDED(fv->GetSelection(FALSE, &items)) && items) {
                IShellItem* first = nullptr;
                PWSTR name = nullptr;
                if (SUCCEEDED(items->GetItemAt(0, &first)) && SUCCEEDED(first->GetDisplayName(SIGDN_FILESYSPATH, &name)) && name) {
                    *selection = name;
                    CoTaskMemFree(name);
                }
                if (first) {
                    first->Release();
                }
                items->Release();
            }
        }
        if (fv) {
            fv->Release();
        }
        if (view) {
            view->Release();
        }
        if (sb) {
            sb->Release();
        }
        if (sp) {
            sp->Release();
        }
        disp->Release();
    }
    sw->Release();
    return out;
}

static DWORD WINAPI Redirect(LPVOID param) {
    HWND hwnd = (HWND)param;
    if (FAILED(CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED))) {
        Restore(hwnd);
        return 0;
    }
    std::wstring path, sel;
    Place place = kWait;
    for (int i = 0; i < 120 && place == kWait && IsWindow(hwnd); i++) {
        place = Probe(hwnd, path, nullptr);
        if (place == kWait) {
            Sleep(25);
        }
    }
    if (place == kFolder) {
        // «Показать в папке» выделяет файл чуть позже, чем открывается папка
        for (int i = 0; i < 8 && sel.empty() && IsWindow(hwnd); i++) {
            Sleep(40);
            std::wstring again;
            if (Probe(hwnd, again, &sel) == kFolder && again != path) {
                path = again;
            }
        }
    }
    bool done = false;
    switch (place) {
        case kFolder:
            done = LaunchFinder(sel.empty() ? Quote(path) : L"--select " + Quote(sel));
            break;
        case kComputer:
            done = LaunchFinder(Quote(kThisPc));
            break;
        case kHomeFolder:
            done = LaunchFinder(L"");
            break;
        default:
            break;
    }
    if (done) {
        PostMessageW(hwnd, WM_CLOSE, 0, 0);
    } else {
        Restore(hwnd);
    }
    CoUninitialize();
    return 0;
}

using CreateWindowExW_t = decltype(&CreateWindowExW);
static CreateWindowExW_t CreateWindowExW_Original;

static HWND WINAPI CreateWindowExW_Hook(DWORD ex, LPCWSTR cls, LPCWSTR name, DWORD style, int x, int y, int w, int h, HWND parent, HMENU menu,
                                        HINSTANCE inst, LPVOID param) {
    bool cabinet = cls && !IS_INTRESOURCE(cls) && !_wcsicmp(cls, L"CabinetWClass") && !parent;
    if (!cabinet || g_keepWindows || Bypass()) {
        return CreateWindowExW_Original(ex, cls, name, style, x, y, w, h, parent, menu, inst, param);
    }
    // окно живёт как обычно (иначе Проводник не скажет, что в нём открыто), но его не видно и на панели задач его нет
    HWND hwnd = CreateWindowExW_Original(ex | kHideEx, cls, name, style, x, y, w, h, parent, menu, inst, param);
    if (hwnd) {
        SetLayeredWindowAttributes(hwnd, 0, 0, LWA_ALPHA);
        if (HANDLE t = CreateThread(nullptr, 0, Redirect, hwnd, 0, nullptr)) {
            CloseHandle(t);
        } else {
            Restore(hwnd);
        }
    }
    return hwnd;
}

BOOL Wh_ModInit() {
    LoadSettings();
    if (HandleCommandLine()) {
        ExitProcess(0);
    }
    Wh_SetFunctionHook((void*)CreateWindowExW, (void*)CreateWindowExW_Hook, (void**)&CreateWindowExW_Original);
    return TRUE;
}

void Wh_ModSettingsChanged() {
    LoadSettings();
}
