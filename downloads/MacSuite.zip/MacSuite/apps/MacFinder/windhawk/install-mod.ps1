﻿# Мод Windhawk «MacFinder вместо Проводника»: компилирует его компилятором самого Windhawk и регистрирует
# так же, как это делает редактор модов. Нужны права администратора: Windhawk хранит моды в HKLM и ProgramData.
# .\install-mod.ps1             — поставить или обновить
# .\install-mod.ps1 -Uninstall  — убрать
param([switch]$Uninstall)
$ErrorActionPreference = 'Stop'
# окно администратора закроется сразу — ошибку надо успеть прочитать
trap {
    Write-Host $_ -ForegroundColor Red
    Read-Host 'Enter — закрыть'
    exit 1
}

$id = 'local@macfinder-instead-of-explorer'
$src = Join-Path $PSScriptRoot 'macfinder-instead-of-explorer.wh.cpp'
$wh = Join-Path $env:ProgramFiles 'Windhawk'
$iniPath = Join-Path $wh 'windhawk.ini'
if (-not (Test-Path $iniPath)) {
    Write-Host 'Windhawk не установлен — мод пропущен.'
    return
}
# windhawk.ini в UTF-16, ReadAllText определяет это сам
$ini = [IO.File]::ReadAllText($iniPath)
function IniValue($name) { if ($ini -match "(?m)^$name=(.*)$") { $Matches[1].Trim() } }
if ((IniValue 'Portable') -eq '1') {
    Write-Host 'Переносной Windhawk — добавьте мод вручную: Windhawk → «Создать новый мод», вставьте текст из' $src
    return
}
$engine = Join-Path $wh (IniValue 'EnginePath')
$data = [Environment]::ExpandEnvironmentVariables((IniValue 'AppDataPath'))
$regKey = 'HKLM:\' + ((IniValue 'RegistryKey') -replace '^HKLM\\', '') + '\Engine\Mods\' + $id
$mods = Join-Path $data 'Engine\Mods\64'
$source = Join-Path $data "ModsSource\$id.wh.cpp"

if ($Uninstall) {
    if (Test-Path $regKey) {
        $old = (Get-ItemProperty $regKey).LibraryFileName
        # движок сам выгружает мод, как только ключ пропадает
        Remove-Item $regKey -Recurse -Force
        if ($old) {
            Start-Sleep -Milliseconds 500
            Remove-Item (Join-Path $mods $old) -Force -ErrorAction SilentlyContinue
        }
    }
    Remove-Item $source -Force -ErrorAction SilentlyContinue
    Write-Host 'Мод «MacFinder вместо Проводника» убран из Windhawk.'
    return
}

$code = [IO.File]::ReadAllText($src)
$version = if ($code -match '(?m)^//\s*@version\s+(\S+)') { $Matches[1] } else { '1.0' }
$options = if ($code -match '(?m)^//\s*@compilerOptions\s+(.+)$') { $Matches[1].Trim() -split '\s+' } else { @() }

# исходник туда же, где Windhawk держит свои: так мод видно и можно править в его редакторе
New-Item -ItemType Directory -Force (Split-Path $source), $mods | Out-Null
[IO.File]::WriteAllText($source, $code, (New-Object Text.UTF8Encoding $false))

# рантайм C++, который Windhawk кладёт рядом с модами при первой своей компиляции
$compiler = Join-Path $wh 'Compiler'
foreach ($pair in @(@('libc++.dll', 'libc++.whl'), @('libunwind.dll', 'libunwind.whl'), @('windhawk-mod-shim.dll', 'windhawk-mod-shim.dll'))) {
    $to = Join-Path $mods $pair[1]
    $from = Join-Path $compiler "x86_64-w64-mingw32\bin\$($pair[0])"
    if (-not (Test-Path $to) -and (Test-Path $from)) { Copy-Item $from $to }
}

$dll = '{0}_{1}_{2}.dll' -f $id, $version, (Get-Random -Minimum 100000 -Maximum 999999)
# те же ключи, что у редактора модов Windhawk
$flags = @('-std=c++23', '-O2', '-shared', '-DUNICODE', '-D_UNICODE', '-DWINVER=0x0A00', '-D_WIN32_WINNT=0x0A00', '-D_WIN32_IE=0x0A00',
    '-DNTDDI_VERSION=0x0A000008', '-D__USE_MINGW_ANSI_STDIO=0', '-DWH_MOD', "-DWH_MOD_ID=L`"$id`"", "-DWH_MOD_VERSION=L`"$version`"",
    (Join-Path $engine '64\windhawk.lib'), '-x', 'c++', $source, '-include', 'windhawk_api.h', '-target', 'x86_64-w64-mingw32',
    '-Wl,--export-all-symbols', '-o', (Join-Path $mods $dll)) + $options
# PowerShell 5 теряет кавычки внутри аргументов — собираем командную строку сами
$line = ($flags | ForEach-Object { $a = $_ -replace '"', '\"'; if ($a -match '\s') { "`"$a`"" } else { $a } }) -join ' '
$psi = New-Object Diagnostics.ProcessStartInfo (Join-Path $compiler 'bin\clang++.exe'), $line
$psi.WorkingDirectory = $compiler
$psi.UseShellExecute = $false
$psi.RedirectStandardError = $true
$p = [Diagnostics.Process]::Start($psi)
$err = $p.StandardError.ReadToEnd()
$p.WaitForExit()
if ($p.ExitCode -ne 0) {
    Write-Host $err
    throw 'Мод не скомпилировался'
}

$old = if (Test-Path $regKey) { (Get-ItemProperty $regKey).LibraryFileName }
if (-not (Test-Path $regKey)) { New-Item $regKey -Force | Out-Null }
if (-not (Test-Path "$regKey\Settings")) {
    New-Item "$regKey\Settings" -Force | Out-Null
    New-ItemProperty "$regKey\Settings" -Name finderPath -Value '' -PropertyType String | Out-Null
    New-ItemProperty "$regKey\Settings" -Name keepWindows -Value 0 -PropertyType DWord | Out-Null
    New-ItemProperty "$regKey\Settings" -Name bypassKey -Value 'shift' -PropertyType String | Out-Null
}
$now = [int][DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$values = [ordered]@{
    Disabled = @(0, 'DWord'); LoggingEnabled = @(0, 'DWord'); DebugLoggingEnabled = @(0, 'DWord')
    Include = @('explorer.exe', 'String'); Exclude = @('', 'String'); Architecture = @('x86-64', 'String')
    Version = @($version, 'String'); SettingsChangeTime = @($now, 'DWord')
    # последним: по нему движок понимает, что мод готов, и загружает новую библиотеку
    LibraryFileName = @($dll, 'String')
}
foreach ($k in $values.Keys) { New-ItemProperty $regKey -Name $k -Value $values[$k][0] -PropertyType $values[$k][1] -Force | Out-Null }
if ($old -and $old -ne $dll) {
    Start-Sleep -Milliseconds 500
    Remove-Item (Join-Path $mods $old) -Force -ErrorAction SilentlyContinue
}
Write-Host "Мод «MacFinder вместо Проводника» $version включён в Windhawk."
