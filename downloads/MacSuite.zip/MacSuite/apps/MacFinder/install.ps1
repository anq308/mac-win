﻿# Установка MacFinder: копирует программу, кладёт ярлык «Finder» в «Пуск» и на рабочий стол
# и ставит его вместо Проводника: Win+E — через реестр, папки, диски и «Показать в папке» —
# через мод Windhawk (если Windhawk стоит)
# .\install.ps1               — установить или обновить
# .\install.ps1 -KeepExplorer — установить, но папки пусть открывает Проводник
# .\install.ps1 -Uninstall    — удалить
param([switch]$Uninstall, [switch]$KeepExplorer)

$dir = Join-Path $env:LOCALAPPDATA "Programs\MacFinder"
$exe = Join-Path $dir "mac-finder.exe"
$links = @(
    (Join-Path ([Environment]::GetFolderPath("Programs")) "Finder.lnk"),
    (Join-Path ([Environment]::GetFolderPath("Desktop")) "Finder.lnk")
)
$classes = "HKCU:\Software\Classes"
# Win+E: «открыть новое окно» у самого Проводника
$winE = "$classes\CLSID\{52205fd8-5dfb-447d-801a-d0b52f2e83e1}"
$mod = Join-Path $PSScriptRoot "windhawk\install-mod.ps1"
$modSource = Join-Path $PSScriptRoot "windhawk\macfinder-instead-of-explorer.wh.cpp"

function Ensure-Key($path) {
    # New-Item -Force по существующему ключу стёр бы его содержимое (там бывают чужие пункты меню)
    if (-not (Test-Path $path)) { New-Item -Path $path -Force | Out-Null }
}

function Set-Explorer([bool]$on) {
    # Действие папок по умолчанию больше не подменяем: «Показать в папке» запускает его, а потом
    # 20 секунд ждёт окно Проводника, чтобы выделить файл, — программа висит, файл не выделен.
    # Папки отдаёт Finder мод Windhawk. Здесь только убираем то, что ставили прошлые версии
    foreach ($cls in "Directory", "Drive") {
        Remove-Item "$classes\$cls\shell\MacFinder" -Recurse -Force -ErrorAction SilentlyContinue
        # значение «по умолчанию» Remove-ItemProperty в PowerShell 5 не удаляет
        $k = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey("Software\Classes\$cls\shell", $true)
        if ($k) {
            if ($k.GetValue("") -eq "MacFinder") { $k.DeleteValue("") }
            $k.Close()
        }
    }
    if ($on) {
        Ensure-Key "$winE\shell\opennewwindow\command"
        Set-ItemProperty "$winE\shell\opennewwindow\command" -Name "(default)" -Value "`"$exe`""
        # пустой DelegateExecute — иначе Проводник открывает окно сам, не глядя на команду
        Set-ItemProperty "$winE\shell\opennewwindow\command" -Name "DelegateExecute" -Value ""
    } else {
        Remove-Item "$winE\shell\opennewwindow" -Recurse -Force -ErrorAction SilentlyContinue
    }
    # сообщаем оболочке, что сопоставления поменялись
    Add-Type -Namespace MacFinder -Name Shell -MemberDefinition '[DllImport("shell32.dll")] public static extern void SHChangeNotify(int e, int f, System.IntPtr a, System.IntPtr b);'
    [MacFinder.Shell]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)
}

# мод Windhawk живёт в HKLM и ProgramData — его ставим с правами администратора
function Set-WindhawkMod([bool]$on) {
    if (-not (Test-Path (Join-Path $env:ProgramFiles "Windhawk\windhawk.ini"))) { return }
    $installed = Join-Path $env:ProgramData "Windhawk\ModsSource\local@macfinder-instead-of-explorer.wh.cpp"
    if ($on -and (Test-Path $installed) -and ((Get-FileHash $installed).Hash -eq (Get-FileHash $modSource).Hash)) { return }
    if (-not $on -and -not (Test-Path $installed)) { return }
    Write-Host "Windhawk: $(if ($on) { 'ставлю' } else { 'убираю' }) мод «MacFinder вместо Проводника» — подтвердите запрос администратора..."
    $argLine = "-NoProfile -ExecutionPolicy Bypass -File `"$mod`"" + $(if ($on) { "" } else { " -Uninstall" })
    try {
        Start-Process powershell -Verb RunAs -Wait -ArgumentList $argLine
    } catch {
        Write-Host "Мод Windhawk не поставлен: нет прав администратора. Запустите install.cmd ещё раз и нажмите «Да»."
    }
}

Get-Process mac-finder -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300

if ($Uninstall) {
    Set-Explorer $false
    Set-WindhawkMod $false
    $links | ForEach-Object { Remove-Item $_ -Force -ErrorAction SilentlyContinue }
    Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host "MacFinder удалён, папки снова открывает Проводник."
    return
}

New-Item -ItemType Directory -Force $dir | Out-Null
Copy-Item (Join-Path $PSScriptRoot "mac-finder.exe") $exe -Force
Unblock-File $exe -ErrorAction SilentlyContinue

$shell = New-Object -ComObject WScript.Shell
foreach ($lnk in $links) {
    $sh = $shell.CreateShortcut($lnk)
    $sh.TargetPath = $exe
    # значок вшит в exe — ярлык берёт его оттуда
    $sh.IconLocation = "$exe,0"
    $sh.Description = "Файлы и папки"
    $sh.Save()
}

Set-Explorer (-not $KeepExplorer)
Set-WindhawkMod (-not $KeepExplorer)

if (-not $KeepExplorer) { Start-Process $exe }
Write-Host "Готово! Ярлык Finder — на рабочем столе и в меню «Пуск»."
if ($KeepExplorer) {
    Write-Host "Папки открывает Проводник, как раньше."
} elseif (Test-Path (Join-Path $env:ProgramFiles "Windhawk\windhawk.ini")) {
    Write-Host "Папки, диски, Win+E и «Показать в папке» теперь открываются в Finder. Обычный Проводник —"
    Write-Host "с зажатым Shift или «Открыть в Проводнике» в меню Finder. Вернуть: «Вернуть Проводник.cmd»."
} else {
    Write-Host "Win+E теперь открывает Finder. Чтобы в нём открывались и папки, и «Показать в папке»,"
    Write-Host "поставьте Windhawk (windhawk.net) и запустите install.cmd ещё раз."
}
Write-Host "Закрепить на панели задач: правый клик по значку запущенного Finder → «Закрепить на панели задач»."
