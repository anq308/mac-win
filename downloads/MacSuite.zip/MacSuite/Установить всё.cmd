@chcp 65001 >nul
@powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-all.ps1"
@pause
