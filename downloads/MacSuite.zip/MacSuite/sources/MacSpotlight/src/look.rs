//! Быстрый просмотр, как Quick Look в macOS: Пробел в проводнике или на рабочем столе показывает выделенный файл.
//! Окно не забирает фокус — стрелками в проводнике можно листать файлы, просмотр идёт следом.
//! Картинки и текст рисуем сами, видео, PDF, документы и шрифты показывают обработчики просмотра Windows —
//! те же, что в области просмотра проводника.

use std::cell::RefCell;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicIsize, AtomicU32, AtomicU64, Ordering};
use std::sync::mpsc::{channel, Sender};
use std::sync::Mutex;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use ab_glyph::FontVec;
use tiny_skia::PixmapMut;
use windows::core::{w, Interface, GUID, PCWSTR, PWSTR};
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Dwm::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::Com::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::System::SystemServices::SFGAO_FOLDER;
use windows::Win32::System::Variant::*;
use windows::Win32::UI::Controls::MARGINS;
use windows::Win32::UI::HiDpi::GetDpiForWindow;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::Shell::PropertiesSystem::{IInitializeWithFile, IInitializeWithStream};
use windows::Win32::UI::Shell::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::gfx::{self, Img};
use crate::win::{self, pcwstr, wide, wide_path, Surface};

pub const WM_LOOK: u32 = WM_APP + 7;
const WM_LOOK_IMG: u32 = WM_APP + 8;
const TIMER_FOLLOW: usize = 1;
const TIMER_SHOW: usize = 2;
/// перерисовать позже: сообщение WM_PAINT пришло, пока состояние было занято
const WM_LOOK_REDRAW: u32 = WM_APP + 9;
const HEAD: f32 = 44.0;
const FOOT: f32 = 32.0;
const CLOSE_W: f32 = 46.0;

/// Включён ли просмотр (меню в трее)
pub static ON: AtomicBool = AtomicBool::new(true);
static OPEN: AtomicBool = AtomicBool::new(false);
static SOURCE: AtomicIsize = AtomicIsize::new(0);
static WINDOW: AtomicIsize = AtomicIsize::new(0);
static TARGET: AtomicIsize = AtomicIsize::new(0);
/// пробел или Esc, нажатие которых мы съели: их отпускание и автоповтор тоже не пропускаем
static EATEN: AtomicU32 = AtomicU32::new(0);
/// окно и время последней буквы: в проводнике можно начать набирать имя файла, и пробел тогда — часть имени
static TYPING: Mutex<(isize, Option<Instant>)> = Mutex::new((0, None));

fn held(vk: VIRTUAL_KEY) -> bool {
    unsafe { GetAsyncKeyState(vk.0 as i32) < 0 }
}

fn class_of(h: HWND) -> String {
    let mut buf = [0u16; 64];
    let n = unsafe { GetClassNameW(h, &mut buf) } as usize;
    String::from_utf16_lossy(&buf[..n])
}

fn is_desktop(h: HWND) -> bool {
    matches!(class_of(h).as_str(), "Progman" | "WorkerW")
}

/// Фокус в списке файлов проводника или рабочего стола (а не в адресной строке, поиске или переименовании)
fn view_focused(fg: HWND) -> bool {
    if fg.is_invalid() || !matches!(class_of(fg).as_str(), "CabinetWClass" | "ExploreWClass" | "Progman" | "WorkerW") {
        return false;
    }
    unsafe {
        let mut gti = GUITHREADINFO { cbSize: std::mem::size_of::<GUITHREADINFO>() as u32, ..Default::default() };
        if GetGUIThreadInfo(GetWindowThreadProcessId(fg, None), &mut gti).is_err() || gti.hwndFocus.is_invalid() {
            return false;
        }
        if gti.flags.0 & (GUI_INMENUMODE.0 | GUI_POPUPMENUMODE.0) != 0 {
            return false;
        }
        let focus = class_of(gti.hwndFocus);
        let parent = GetParent(gti.hwndFocus).map(class_of).unwrap_or_default();
        parent == "SHELLDLL_DefView" && (focus == "DirectUIHWND" || focus == "SysListView32")
    }
}

fn same_source(fg: HWND) -> bool {
    let src = HWND(SOURCE.load(Ordering::Relaxed) as *mut _);
    let mine = WINDOW.load(Ordering::Relaxed);
    if fg.0 as isize == mine && mine != 0 {
        return true;
    }
    fg == src || (is_desktop(src) && is_desktop(fg))
}

/// Из хука клавиатуры, на каждое настоящее нажатие. true — клавишу съесть
pub fn on_key(vk: u32, down: bool) -> bool {
    if !down {
        if EATEN.load(Ordering::Relaxed) == vk {
            EATEN.store(0, Ordering::Relaxed);
            return true;
        }
        return false;
    }
    if EATEN.load(Ordering::Relaxed) == vk {
        return true; // автоповтор
    }
    if !ON.load(Ordering::Relaxed) {
        return false;
    }
    let fg = unsafe { GetForegroundWindow() };
    let post = |wp: usize| unsafe {
        let _ = PostMessageW(Some(HWND(TARGET.load(Ordering::Relaxed) as *mut _)), WM_LOOK, WPARAM(wp), LPARAM(fg.0 as isize));
    };
    let mods = held(VK_CONTROL) || held(VK_MENU) || held(VK_SHIFT) || held(VK_LWIN) || held(VK_RWIN);
    let open = OPEN.load(Ordering::Relaxed);
    if vk == VK_SPACE.0 as u32 && !mods {
        if open && same_source(fg) {
            EATEN.store(vk, Ordering::Relaxed);
            post(2);
            return true;
        }
        let typing = TYPING.lock().is_ok_and(|t| t.0 == fg.0 as isize && t.1.is_some_and(|at| at.elapsed() < Duration::from_millis(1200)));
        if !typing && view_focused(fg) {
            EATEN.store(vk, Ordering::Relaxed);
            post(1);
            return true;
        }
        return false;
    }
    if vk == VK_ESCAPE.0 as u32 && open && same_source(fg) {
        EATEN.store(vk, Ordering::Relaxed);
        post(2);
        return true;
    }
    if matches!(vk, 0x30..=0x39 | 0x41..=0x5A | 0xBA..=0xC0 | 0xDB..=0xDF) && !mods {
        if let Ok(mut t) = TYPING.lock() {
            *t = (fg.0 as isize, Some(Instant::now()));
        }
    } else if let Ok(mut t) = TYPING.lock() {
        t.1 = None;
    }
    false
}

// ---------- выделение в проводнике ----------

fn var_i4(v: i32) -> VARIANT {
    let mut x = VARIANT::default();
    unsafe {
        let inner = &mut *x.Anonymous.Anonymous;
        inner.vt = VT_I4;
        inner.Anonymous.lVal = v;
    }
    x
}

/// Окно проводника → его «браузер»: из него в любой момент можно спросить текущую папку и выделение
fn browser_for(fg: HWND) -> Option<IShellBrowser> {
    unsafe {
        let sw: IShellWindows = CoCreateInstance(&ShellWindows, None, CLSCTX_ALL).ok()?;
        if is_desktop(fg) {
            let mut h = 0i32;
            let disp = sw.FindWindowSW(&var_i4(0), &VARIANT::default(), SWC_DESKTOP, &mut h, SWFO_NEEDDISPATCH).ok()?;
            let sp: IServiceProvider = disp.cast().ok()?;
            return sp.QueryService(&SID_STopLevelBrowser).ok();
        }
        let mut fallback = None;
        for i in 0..sw.Count().unwrap_or(0) {
            let Ok(d) = sw.Item(&var_i4(i)) else { continue };
            let Ok(wb) = d.cast::<IWebBrowser2>() else { continue };
            if wb.HWND().map(|h| h.0) != Ok(fg.0 as isize) {
                continue;
            }
            let Ok(sp) = wb.cast::<IServiceProvider>() else { continue };
            let Ok(b) = sp.QueryService::<IShellBrowser>(&SID_STopLevelBrowser) else { continue };
            // вкладки Windows 11: у всех одно окно, видим только вид активной вкладки
            let visible = b.QueryActiveShellView().and_then(|v| v.GetWindow()).is_ok_and(|h| IsWindowVisible(h).as_bool());
            if visible {
                return Some(b);
            }
            fallback = Some(b);
        }
        fallback
    }
}

fn selected(b: &IShellBrowser) -> Option<IShellItem> {
    unsafe {
        let v: IFolderView2 = b.QueryActiveShellView().ok()?.cast().ok()?;
        let arr = v.GetSelection(false).ok()?;
        let n = arr.GetCount().ok()?;
        if n == 0 {
            return None;
        }
        if n > 1 {
            // выделено несколько — показываем тот, на котором рамка фокуса (по нему ходят стрелки)
            if let Ok(item) = v.GetFocusedItem().and_then(|i| v.GetItem::<IShellItem>(i)) {
                return Some(item);
            }
        }
        arr.GetItemAt(0).ok()
    }
}

fn display(item: &IShellItem, kind: SIGDN) -> Option<String> {
    unsafe {
        let p: PWSTR = item.GetDisplayName(kind).ok()?;
        let s = p.to_string().ok();
        CoTaskMemFree(Some(p.0 as *const _));
        s
    }
}

// ---------- что показывать ----------

#[derive(Clone, Copy, PartialEq)]
enum Kind {
    Folder,
    Text,
    Image,
    Handler(GUID),
    Other,
}

const TEXT_EXT: [&str; 44] = [
    "txt", "md", "log", "json", "rs", "py", "js", "ts", "tsx", "jsx", "css", "xml", "ini", "cfg", "toml", "yaml", "yml", "csv", "bat", "cmd",
    "ps1", "c", "cpp", "h", "hpp", "cs", "java", "go", "sql", "sh", "lua", "conf", "kt", "swift", "php", "rb", "vue", "svelte", "gitignore",
    "env", "srt", "nfo", "reg", "properties",
];
const IMAGE_EXT: [&str; 15] = ["jpg", "jpeg", "jfif", "png", "gif", "bmp", "tif", "tiff", "webp", "heic", "heif", "avif", "ico", "dng", "jxr"];
const VIDEO_EXT: [&str; 12] = ["mp4", "m4v", "mov", "mkv", "avi", "wmv", "webm", "mpg", "mpeg", "3gp", "ts", "m2ts"];
/// Windows Media Player Rich Preview Handler — играет и видео, даже если к расширению он не привязан
const WMP_PREVIEW: GUID = GUID::from_u128(0x031ee060_67bc_460d_8847_e4a7c5e45a27);

fn ext_of(name: &str) -> String {
    Path::new(name).extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default()
}

/// Обработчик просмотра, зарегистрированный для расширения (как у области просмотра проводника)
fn handler_for(ext: &str) -> Option<GUID> {
    let dot = wide(&format!(".{ext}"));
    let mut buf = [0u16; 64];
    let mut len = buf.len() as u32;
    unsafe {
        AssocQueryStringW(
            ASSOCF_INIT_DEFAULTTOSTAR,
            ASSOCSTR_SHELLEXTENSION,
            pcwstr(&dot),
            w!("{8895b1c6-b41f-4c1c-a562-0d564250836f}"),
            Some(PWSTR(buf.as_mut_ptr())),
            &mut len,
        )
        .ok()
        .ok()?;
        CLSIDFromString(PCWSTR(buf.as_ptr())).ok()
    }
}

fn registered(clsid: &GUID) -> bool {
    let key = wide(&format!("CLSID\\{{{clsid:?}}}"));
    unsafe {
        let mut h = windows::Win32::System::Registry::HKEY::default();
        let ok = windows::Win32::System::Registry::RegOpenKeyExW(
            windows::Win32::System::Registry::HKEY_CLASSES_ROOT,
            pcwstr(&key),
            Some(0),
            windows::Win32::System::Registry::KEY_READ,
            &mut h,
        )
        .is_ok();
        if ok {
            let _ = windows::Win32::System::Registry::RegCloseKey(h);
        }
        ok
    }
}

fn classify(name: &str, folder: bool, path: Option<&Path>) -> Kind {
    if folder {
        return Kind::Folder;
    }
    let ext = ext_of(name);
    if path.is_some() && TEXT_EXT.contains(&ext.as_str()) {
        return Kind::Text;
    }
    if path.is_some() && IMAGE_EXT.contains(&ext.as_str()) {
        return Kind::Image;
    }
    if let Some(h) = handler_for(&ext) {
        return Kind::Handler(h);
    }
    if VIDEO_EXT.contains(&ext.as_str()) && registered(&WMP_PREVIEW) {
        return Kind::Handler(WMP_PREVIEW);
    }
    Kind::Other
}

fn text_lines(p: &Path) -> Option<Vec<String>> {
    use std::io::Read;
    let mut buf = vec![0u8; 256 * 1024];
    let n = std::fs::File::open(p).ok()?.read(&mut buf).ok()?;
    buf.truncate(n);
    let s = if buf.starts_with(&[0xFF, 0xFE]) {
        let u: Vec<u16> = buf[2..].chunks_exact(2).map(|c| u16::from_le_bytes([c[0], c[1]])).collect();
        String::from_utf16_lossy(&u)
    } else {
        String::from_utf8_lossy(buf.strip_prefix(&[0xEF, 0xBB, 0xBF]).unwrap_or(&buf)).to_string()
    };
    Some(s.lines().take(5000).map(|l| l.replace('\t', "    ")).collect())
}

fn size_text(n: u64) -> String {
    let f = n as f64;
    let s = if n < 1024 {
        format!("{n} байт")
    } else if f < 1024.0 * 1024.0 {
        format!("{:.0} КБ", f / 1024.0)
    } else if f < 1024.0 * 1024.0 * 1024.0 {
        format!("{:.1} МБ", f / 1048576.0)
    } else {
        format!("{:.2} ГБ", f / 1073741824.0)
    };
    s.replace('.', ",")
}

fn date_text(t: SystemTime) -> Option<String> {
    use windows::Win32::System::Time::{FileTimeToSystemTime, SystemTimeToTzSpecificLocalTime};
    let d = t.duration_since(UNIX_EPOCH).ok()?;
    let ft = (d.as_nanos() / 100) as u64 + 116_444_736_000_000_000;
    let ft = FILETIME { dwLowDateTime: ft as u32, dwHighDateTime: (ft >> 32) as u32 };
    let (mut st, mut lt) = (SYSTEMTIME::default(), SYSTEMTIME::default());
    unsafe {
        FileTimeToSystemTime(&ft, &mut st).ok()?;
        SystemTimeToTzSpecificLocalTime(None, &st, &mut lt).ok()?;
    }
    Some(format!("{:02}.{:02}.{} {:02}:{:02}", lt.wDay, lt.wMonth, lt.wYear, lt.wHour, lt.wMinute))
}

fn type_name(path: &Path) -> String {
    let p = wide_path(path);
    let mut info = SHFILEINFOW::default();
    unsafe {
        SHGetFileInfoW(
            pcwstr(&p),
            windows::Win32::Storage::FileSystem::FILE_FLAGS_AND_ATTRIBUTES(0),
            Some(&mut info),
            std::mem::size_of::<SHFILEINFOW>() as u32,
            SHGFI_TYPENAME,
        );
    }
    let n = info.szTypeName.iter().position(|c| *c == 0).unwrap_or(0);
    String::from_utf16_lossy(&info.szTypeName[..n])
}

/// Подпись снизу: тип · размер · дата
fn info_for(path: Option<&Path>, kind: Kind) -> String {
    let Some(p) = path else { return String::new() };
    let meta = std::fs::metadata(p).ok();
    let mut parts = Vec::new();
    if kind == Kind::Folder {
        let n = std::fs::read_dir(p).map(|r| r.take(100_000).count()).unwrap_or(0);
        parts.push(format!("Папка · {}", items_text(n)));
    } else {
        let t = type_name(p);
        if !t.is_empty() {
            parts.push(t);
        }
        if let Some(m) = &meta {
            parts.push(size_text(m.len()));
        }
    }
    if let Some(d) = meta.and_then(|m| m.modified().ok()).and_then(date_text) {
        parts.push(format!("изменён {d}"));
    }
    parts.join("   ·   ")
}

fn items_text(n: usize) -> String {
    let word = match (n % 10, n % 100) {
        (1, x) if x != 11 => "элемент",
        (2..=4, x) if !(12..=14).contains(&x) => "элемента",
        _ => "элементов",
    };
    format!("{n} {word}")
}

/// «Открыть в «Фотографии»» — программа по умолчанию для этого типа
fn open_label(name: &str, kind: Kind) -> String {
    if kind == Kind::Folder {
        return "Открыть".into();
    }
    let dot = wide(&format!(".{}", ext_of(name)));
    let mut buf = [0u16; 128];
    let mut len = buf.len() as u32;
    let app = unsafe {
        AssocQueryStringW(ASSOCF_INIT_IGNOREUNKNOWN, ASSOCSTR_FRIENDLYAPPNAME, pcwstr(&dot), None, Some(PWSTR(buf.as_mut_ptr())), &mut len)
            .ok()
            .ok()
            .map(|_| String::from_utf16_lossy(&buf[..buf.iter().position(|c| *c == 0).unwrap_or(0)]))
    };
    match app {
        Some(a) if !a.is_empty() && a.chars().count() <= 28 => format!("Открыть в «{a}»"),
        _ => "Открыть".into(),
    }
}

// ---------- окно ----------

enum Body {
    Empty,
    Image(Img),
    Text(Vec<String>),
    Handler(IPreviewHandler),
    Icon(Option<Img>),
}

#[derive(Clone, Copy, PartialEq)]
enum Hit {
    None,
    Close,
    Open,
}

struct Fonts {
    regular: FontVec,
    semibold: FontVec,
    mono: FontVec,
}

impl Fonts {
    fn load() -> Option<Fonts> {
        let dir = std::env::var("WINDIR").unwrap_or_else(|_| "C:\\Windows".into()) + "\\Fonts";
        let file = |name: &str| std::fs::read(format!("{dir}\\{name}")).ok().and_then(|v| FontVec::try_from_vec(v).ok());
        Some(Fonts {
            regular: gfx::variable_font(400.0).or_else(|| file("segoeui.ttf"))?,
            semibold: gfx::variable_font(600.0).or_else(|| file("seguisb.ttf")).or_else(|| file("segoeui.ttf"))?,
            mono: file("consola.ttf").or_else(|| file("cour.ttf"))?,
        })
    }
}

struct Look {
    hwnd: HWND,
    /// дочернее окно под обработчик просмотра: некоторые (Word) занимают всё окно-родитель целиком
    host: HWND,
    fonts: Fonts,
    browser: Option<IShellBrowser>,
    key: String,
    path: Option<PathBuf>,
    name: String,
    kind: Kind,
    info: String,
    open: String,
    icon: Option<Img>,
    body: Body,
    /// ждём картинку из фонового потока с этим номером
    waiting: u64,
    scroll: f32,
    hover: Hit,
    /// окно двигали или растягивали — дальше размер и место не трогаем
    user_rect: bool,
    frame: Option<Surface>,
}

thread_local! {
    static LOOK: RefCell<Option<Look>> = const { RefCell::new(None) };
}

struct Job {
    gen: u64,
    path: PathBuf,
    px: u32,
    icon_only: bool,
}

static GEN: AtomicU64 = AtomicU64::new(0);
static JOBS: Mutex<Option<Sender<Job>>> = Mutex::new(None);
static DONE: Mutex<Option<(u64, Option<Img>)>> = Mutex::new(None);

/// Окно просмотра и поток, который грузит картинки (большие фото и кадры видео — не мгновенно)
pub fn init(target: HWND) {
    TARGET.store(target.0 as isize, Ordering::Relaxed);
    let (tx, rx) = channel::<Job>();
    if let Ok(mut j) = JOBS.lock() {
        *j = Some(tx);
    }
    std::thread::spawn(move || {
        unsafe {
            let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
        }
        while let Ok(mut job) = rx.recv() {
            // пока грузили прошлую, могли пролистать дальше — берём только последнюю
            while let Ok(next) = rx.try_recv() {
                job = next;
            }
            if job.gen != GEN.load(Ordering::Relaxed) {
                continue;
            }
            let img = win::shell_image(&job.path, job.px, job.icon_only);
            if let Ok(mut d) = DONE.lock() {
                *d = Some((job.gen, img));
            }
            let h = WINDOW.load(Ordering::Relaxed);
            unsafe {
                let _ = PostMessageW(Some(HWND(h as *mut _)), WM_LOOK_IMG, WPARAM(0), LPARAM(0));
            }
        }
    });
}

unsafe extern "system" fn host_proc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_MOUSEACTIVATE => LRESULT(MA_NOACTIVATE as isize),
        WM_ERASEBKGND => {
            let mut r = RECT::default();
            let _ = GetClientRect(hwnd, &mut r);
            let brush = CreateSolidBrush(colorref(bg_rgb()));
            FillRect(HDC(wp.0 as *mut _), &r, brush);
            let _ = DeleteObject(brush.into());
            LRESULT(1)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

fn create_window() -> Option<(HWND, HWND)> {
    unsafe {
        let inst = GetModuleHandleW(None).ok()?;
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacSpotlight.Look"),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            style: CS_DBLCLKS,
            ..Default::default()
        };
        RegisterClassW(&wc);
        let hc = WNDCLASSW {
            lpfnWndProc: Some(host_proc),
            hInstance: inst.into(),
            lpszClassName: w!("MacSpotlight.LookBody"),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            ..Default::default()
        };
        RegisterClassW(&hc);
        let hwnd = CreateWindowExW(
            WS_EX_TOPMOST | WS_EX_NOACTIVATE | WS_EX_TOOLWINDOW,
            w!("MacSpotlight.Look"),
            w!("Быстрый просмотр"),
            WS_POPUP | WS_THICKFRAME | WS_CLIPCHILDREN,
            0,
            0,
            600,
            400,
            None,
            None,
            Some(inst.into()),
            None,
        )
        .ok()?;
        // рамки нет (WM_NCCALCSIZE), а тень и скругление Windows 11 — от DWM
        let m = MARGINS { cxLeftWidth: 0, cxRightWidth: 0, cyTopHeight: 1, cyBottomHeight: 0 };
        let _ = DwmExtendFrameIntoClientArea(hwnd, &m);
        let round: u32 = 2; // DWMWCP_ROUND
        let _ = DwmSetWindowAttribute(hwnd, DWMWINDOWATTRIBUTE(33), &round as *const u32 as *const _, 4);
        WINDOW.store(hwnd.0 as isize, Ordering::Relaxed);
        let host = CreateWindowExW(
            WINDOW_EX_STYLE(0),
            w!("MacSpotlight.LookBody"),
            None,
            WS_CHILD | WS_CLIPCHILDREN,
            0,
            0,
            10,
            10,
            Some(hwnd),
            None,
            Some(inst.into()),
            None,
        )
        .ok()?;
        Some((hwnd, host))
    }
}

/// Доступ к состоянию окна. Вызовы Windows внутри могут вложенно прислать сообщение этому же окну —
/// тогда состояние уже занято, и вложенный вызов просто ничего не делает (None)
fn with<R>(f: impl FnOnce(&mut Look) -> R) -> Option<R> {
    LOOK.with(|l| l.try_borrow_mut().ok()?.as_mut().map(f))
}

/// Из главного окна: 1 — Пробел в проводнике (lp — окно), 2 — закрыть
pub fn command(wp: usize, lp: isize) {
    match wp {
        1 => open_from(HWND(lp as *mut _)),
        _ => close(),
    }
}

fn ensure() -> bool {
    let exists = LOOK.with(|l| l.borrow().is_some());
    if exists {
        return true;
    }
    let Some(fonts) = Fonts::load() else { return false };
    let Some((hwnd, host)) = create_window() else { return false };
    LOOK.with(|l| {
        *l.borrow_mut() = Some(Look {
            hwnd,
            host,
            fonts,
            browser: None,
            key: String::new(),
            path: None,
            name: String::new(),
            kind: Kind::Other,
            info: String::new(),
            open: String::new(),
            icon: None,
            body: Body::Empty,
            waiting: 0,
            scroll: 0.0,
            hover: Hit::None,
            user_rect: false,
            frame: None,
        })
    });
    true
}

fn open_from(fg: HWND) {
    let Some(browser) = browser_for(fg) else { return };
    let Some(item) = selected(&browser) else { return };
    if !ensure() {
        return;
    }
    SOURCE.store(fg.0 as isize, Ordering::Relaxed);
    with(|l| {
        l.browser = Some(browser);
        l.key.clear();
        l.user_rect = false;
    });
    show_item(&item);
}

/// Для проверки без проводника: показать файл по пути
pub fn open_path(p: &Path) -> bool {
    // оболочка понимает только обратные косые черты
    let wp = wide(&p.to_string_lossy().replace('/', "\\"));
    let Ok(item) = (unsafe { SHCreateItemFromParsingName::<_, _, IShellItem>(pcwstr(&wp), None) }) else { return false };
    if !ensure() {
        return false;
    }
    SOURCE.store(0, Ordering::Relaxed);
    with(|l| {
        l.browser = None;
        l.key.clear();
    });
    show_item(&item);
    true
}

fn unload(l: &mut Look) {
    if let Body::Handler(h) = std::mem::replace(&mut l.body, Body::Empty) {
        unsafe {
            let _ = h.Unload();
            let _ = ShowWindow(l.host, SW_HIDE);
        }
    }
}

pub fn close() {
    OPEN.store(false, Ordering::Relaxed);
    GEN.fetch_add(1, Ordering::Relaxed);
    let Some((hwnd, host, body)) = with(|l| {
        l.browser = None;
        l.key.clear();
        l.icon = None;
        (l.hwnd, l.host, std::mem::replace(&mut l.body, Body::Empty))
    }) else {
        return;
    };
    unsafe {
        let _ = ShowWindow(host, SW_HIDE);
        let _ = KillTimer(Some(hwnd), TIMER_FOLLOW);
        let _ = KillTimer(Some(hwnd), TIMER_SHOW);
        let _ = ShowWindow(hwnd, SW_HIDE);
        if let Body::Handler(h) = body {
            let _ = h.Unload();
        }
    }
}

fn scale(hwnd: HWND) -> f32 {
    unsafe { GetDpiForWindow(hwnd).max(96) as f32 / 96.0 }
}

fn show_item(item: &IShellItem) {
    let path = display(item, SIGDN_FILESYSPATH).map(PathBuf::from);
    let Some(key) = path.as_ref().map(|p| p.to_string_lossy().to_string()).or_else(|| display(item, SIGDN_DESKTOPABSOLUTEPARSING)) else {
        return;
    };
    let same = with(|l| l.key == key).unwrap_or(false);
    if same {
        return;
    }
    let name = display(item, SIGDN_NORMALDISPLAY).unwrap_or_else(|| key.clone());
    let folder = unsafe { item.GetAttributes(SFGAO_FOLDER) }.is_ok_and(|a| a.0 & SFGAO_FOLDER.0 != 0)
        && path.as_ref().is_none_or(|p| p.is_dir());
    // имя для показа может быть без расширения (если их скрывают) — тип берём из настоящего имени
    let real = display(item, SIGDN_PARENTRELATIVEPARSING).unwrap_or_else(|| name.clone());
    let kind = classify(&real, folder, path.as_deref());
    let gen = GEN.fetch_add(1, Ordering::Relaxed) + 1;
    let info = info_for(path.as_deref(), kind);
    let open = open_label(&real, kind);
    with(|l| {
        let s = scale(l.hwnd);
        l.key = key;
        l.name = name;
        l.kind = kind;
        l.info = info;
        l.open = open;
        l.scroll = 0.0;
        l.icon = path.as_ref().and_then(|p| win::small_icon(p, (16.0 * s).round() as u32));
        l.path = path.clone();
    });
    let request = |px: u32, icon_only: bool| {
        if let (Some(p), Ok(j)) = (path.clone(), JOBS.lock()) {
            if let Some(tx) = j.as_ref() {
                let _ = tx.send(Job { gen, path: p, px, icon_only });
            }
        }
    };
    match kind {
        Kind::Image => {
            // размер окна зависит от пропорций — показываем, когда картинка готова (но не дольше 0,4 с)
            let px = with(|l| {
                let m = win::monitor_at(center_of(l.hwnd));
                let (w, h) = (m.work.right - m.work.left, m.work.bottom - m.work.top);
                (w.max(h) as f32 * 0.8).min(2560.0) as u32
            })
            .unwrap_or(1600);
            with(|l| {
                l.waiting = gen;
                unsafe {
                    SetTimer(Some(l.hwnd), TIMER_SHOW, 400, None);
                }
            });
            request(px, false);
        }
        Kind::Text => {
            let lines = path.as_deref().and_then(text_lines).unwrap_or_default();
            with(|l| {
                unload(l);
                l.body = Body::Text(lines);
            });
            present();
        }
        Kind::Handler(clsid) => {
            with(|l| unload(l));
            present();
            let ok = with(|l| attach_handler(l, clsid, item)).unwrap_or(false);
            redraw();
            if !ok {
                // обработчик не справился — хотя бы миниатюра или значок
                with(|l| {
                    l.body = Body::Icon(None);
                    l.waiting = gen;
                });
                request(256, false);
                redraw();
            }
        }
        Kind::Folder | Kind::Other => {
            with(|l| {
                unload(l);
                l.body = Body::Icon(None);
                l.waiting = gen;
            });
            request(256, kind == Kind::Folder);
            present();
        }
    }
}

fn center_of(hwnd: HWND) -> POINT {
    let src = HWND(SOURCE.load(Ordering::Relaxed) as *mut _);
    let h = if src.is_invalid() { hwnd } else { src };
    let mut r = RECT::default();
    unsafe {
        let _ = GetWindowRect(h, &mut r);
    }
    if src.is_invalid() && !OPEN.load(Ordering::Relaxed) {
        return win::cursor();
    }
    POINT { x: (r.left + r.right) / 2, y: (r.top + r.bottom) / 2 }
}

/// Размер окна под содержимое (в пикселях экрана)
fn desired(l: &Look) -> (i32, i32) {
    let m = win::monitor_at(center_of(l.hwnd));
    let s = m.scale;
    let (ww, wh) = ((m.work.right - m.work.left) as f32, (m.work.bottom - m.work.top) as f32);
    let chrome = (HEAD + FOOT) * s;
    match &l.body {
        Body::Image(img) => {
            let (mw, mh) = (ww * 0.72, wh * 0.82 - chrome);
            let k = (mw / img.w as f32).min(mh / img.h as f32).min(s);
            let (w, h) = (img.w as f32 * k, img.h as f32 * k);
            let pad = 24.0 * s;
            ((w + pad).max(420.0 * s) as i32, ((h + pad).max(240.0 * s) + chrome) as i32)
        }
        Body::Text(_) | Body::Handler(_) => ((ww * 0.55).min(1000.0 * s) as i32, (wh * 0.78).min(820.0 * s) as i32),
        _ if matches!(l.kind, Kind::Handler(_) | Kind::Text) => ((ww * 0.55).min(1000.0 * s) as i32, (wh * 0.78).min(820.0 * s) as i32),
        Body::Icon(_) | Body::Empty => ((520.0 * s) as i32, (420.0 * s) as i32),
    }
}

/// Показать окно (или подогнать под новый файл) — без активации: фокус остаётся в проводнике
fn present() {
    let Some((hwnd, place, follow)) = with(|l| {
        let place = (!l.user_rect || !OPEN.load(Ordering::Relaxed)).then(|| {
            let (w, h) = desired(l);
            let m = win::monitor_at(center_of(l.hwnd));
            ((m.work.left + m.work.right - w) / 2, (m.work.top + m.work.bottom - h) / 2, w, h)
        });
        (l.hwnd, place, l.browser.is_some())
    }) else {
        return;
    };
    unsafe {
        let _ = KillTimer(Some(hwnd), TIMER_SHOW);
        if let Some((x, y, w, h)) = place {
            let _ = SetWindowPos(hwnd, Some(HWND_TOPMOST), x, y, w, h, SWP_NOACTIVATE);
        }
        if !OPEN.swap(true, Ordering::Relaxed) {
            let _ = ShowWindow(hwnd, SW_SHOWNOACTIVATE);
            if follow {
                SetTimer(Some(hwnd), TIMER_FOLLOW, 150, None);
            }
        }
        let _ = InvalidateRect(Some(hwnd), None, false);
    }
}

fn redraw() {
    with(|l| unsafe {
        let _ = InvalidateRect(Some(l.hwnd), None, false);
    });
}

fn body_rect(l: &Look) -> RECT {
    let mut r = RECT::default();
    unsafe {
        let _ = GetClientRect(l.hwnd, &mut r);
    }
    let s = scale(l.hwnd);
    RECT { left: 0, top: (HEAD * s) as i32 + 1, right: r.right, bottom: r.bottom - (FOOT * s) as i32 }
}

fn colorref(c: (u8, u8, u8)) -> COLORREF {
    COLORREF(c.0 as u32 | (c.1 as u32) << 8 | (c.2 as u32) << 16)
}

fn bg_rgb() -> (u8, u8, u8) {
    match (gfx::theme().dark, gfx::win11()) {
        (true, true) => (0x20, 0x20, 0x20),
        (true, false) => (0x19, 0x19, 0x19),
        (false, _) => (0xFF, 0xFF, 0xFF),
    }
}

fn attach_handler(l: &mut Look, clsid: GUID, item: &IShellItem) -> bool {
    let Some(path) = l.path.clone() else { return false };
    unsafe {
        let ph: IPreviewHandler = match CoCreateInstance(&clsid, None, CLSCTX_LOCAL_SERVER) {
            Ok(p) => p,
            Err(_) => match CoCreateInstance(&clsid, None, CLSCTX_INPROC_SERVER) {
                Ok(p) => p,
                Err(_) => return false,
            },
        };
        let wp = wide_path(&path);
        let init = if let Ok(i) = ph.cast::<IInitializeWithStream>() {
            SHCreateStreamOnFileEx(pcwstr(&wp), (STGM_READ | STGM_SHARE_DENY_NONE).0, 0, false, None).and_then(|s| i.Initialize(&s, STGM_READ.0))
        } else if let Ok(i) = ph.cast::<IInitializeWithFile>() {
            i.Initialize(pcwstr(&wp), STGM_READ.0)
        } else if let Ok(i) = ph.cast::<IInitializeWithItem>() {
            i.Initialize(item, STGM_READ.0)
        } else {
            return false;
        };
        if init.is_err() {
            return false;
        }
        gfx::use_theme(true);
        if let Ok(v) = ph.cast::<IPreviewHandlerVisuals>() {
            let _ = v.SetBackgroundColor(colorref(bg_rgb()));
            let ink = if gfx::theme().dark { (0xFF, 0xFF, 0xFF) } else { (0, 0, 0) };
            let _ = v.SetTextColor(colorref(ink));
        }
        let r = body_rect(l);
        let _ = SetWindowPos(l.host, None, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE | SWP_SHOWWINDOW);
        let inner = RECT { left: 0, top: 0, right: r.right - r.left, bottom: r.bottom - r.top };
        if ph.SetWindow(l.host, &inner).is_err() || ph.DoPreview().is_err() {
            let _ = ShowWindow(l.host, SW_HIDE);
            let _ = ph.Unload();
            return false;
        }
        l.body = Body::Handler(ph);
        true
    }
}

fn image_ready() {
    let Some((gen, img)) = DONE.lock().ok().and_then(|mut d| d.take()) else { return };
    let waiting = with(|l| l.waiting).unwrap_or(0);
    if gen != waiting || gen != GEN.load(Ordering::Relaxed) {
        return;
    }
    let kind = with(|l| l.kind).unwrap_or(Kind::Other);
    with(|l| {
        l.waiting = 0;
        if matches!(l.body, Body::Handler(_)) {
            return;
        }
        unload(l);
        l.body = match (kind, img) {
            (Kind::Image, Some(i)) => Body::Image(i),
            (_, img) => Body::Icon(img),
        };
    });
    present();
}

/// Каждые 150 мс: проводник закрыли или ушли в другое окно — закрываемся; выделение сменилось — показываем новый файл
fn follow() {
    let fg = unsafe { GetForegroundWindow() };
    let src = HWND(SOURCE.load(Ordering::Relaxed) as *mut _);
    if !unsafe { IsWindow(Some(src)) }.as_bool() {
        close();
        return;
    }
    let mine = with(|l| unsafe { GetAncestor(fg, GA_ROOTOWNER) } == l.hwnd || fg == l.hwnd).unwrap_or(false);
    if !fg.is_invalid() && !mine && !same_source(fg) {
        close();
        return;
    }
    let Some(browser) = with(|l| l.browser.clone()).flatten() else { return };
    match selected(&browser) {
        Some(item) => show_item(&item),
        None => close(),
    }
}

fn open_item() {
    let path = with(|l| l.path.clone()).flatten();
    close();
    if let Some(p) = path {
        let wp = wide_path(&p);
        unsafe {
            ShellExecuteW(None, w!("open"), pcwstr(&wp), None, None, SW_SHOWNORMAL);
        }
    }
}

// ---------- рисование ----------

fn hit_at(l: &Look, x: i32, y: i32) -> Hit {
    let s = scale(l.hwnd);
    let mut r = RECT::default();
    unsafe {
        let _ = GetClientRect(l.hwnd, &mut r);
    }
    let (x, y, w) = (x as f32 / s, y as f32 / s, r.right as f32 / s);
    if y >= HEAD {
        return Hit::None;
    }
    if x >= w - CLOSE_W {
        return Hit::Close;
    }
    let ow = open_width(l, s) / s;
    if x >= w - CLOSE_W - 8.0 - ow && x < w - CLOSE_W - 8.0 && (8.0..HEAD - 8.0).contains(&y) {
        return Hit::Open;
    }
    Hit::None
}

fn open_width(l: &Look, s: f32) -> f32 {
    gfx::measure(&l.fonts.regular, &l.open, 13.0 * s) + 28.0 * s
}

fn compose(l: &Look, pm: &mut PixmapMut, cw: f32, ch: f32, s: f32) {
    gfx::use_theme(true);
    let p = |v: f32| v * s;
    let (br, bgc, bb) = bg_rgb();
    pm.fill(tiny_skia::Color::from_rgba8(bb, bgc, br, 255));
    let dark = gfx::theme().dark;
    let head = p(HEAD);
    let foot_y = ch - p(FOOT);
    // содержимое
    let (bx, by, bw, bh) = (0.0, head + 1.0, cw, foot_y - head - 1.0);
    match &l.body {
        Body::Image(img) => {
            let pad = p(12.0);
            let k = ((bw - 2.0 * pad) / img.w as f32).min((bh - 2.0 * pad) / img.h as f32).min(s.max(1.0));
            let (w, h) = ((img.w as f32 * k).round(), (img.h as f32 * k).round());
            gfx::image(pm, img, (bx + (bw - w) / 2.0).round(), (by + (bh - h) / 2.0).round(), w, h, 0.0, 1.0);
        }
        Body::Text(lines) => {
            let lh = p(19.0);
            let first = (l.scroll / 19.0) as usize;
            let rows = (bh / lh) as usize + 1;
            let gutter = p(16.0);
            for (k, line) in lines.iter().skip(first).take(rows).enumerate() {
                let t = gfx::fit(&l.fonts.mono, line, p(13.0), bw - 2.0 * gutter);
                gfx::text(pm, &l.fonts.mono, &t, gutter, by + p(12.0) + lh * (k as f32 + 0.75), p(13.0), gfx::white(0.88));
            }
            if lines.is_empty() {
                let t = "Файл пуст";
                let tw = gfx::measure(&l.fonts.regular, t, p(14.0));
                gfx::text(pm, &l.fonts.regular, t, (cw - tw) / 2.0, by + bh / 2.0, p(14.0), gfx::white(0.5));
            }
        }
        Body::Icon(img) => {
            let size = p(128.0).min(bh * 0.5);
            let cy = by + bh / 2.0 - p(24.0);
            match img {
                Some(i) => {
                    let k = (size / i.w as f32).min(size / i.h as f32);
                    let (w, h) = (i.w as f32 * k, i.h as f32 * k);
                    gfx::image(pm, i, (cw - w) / 2.0, cy - h / 2.0, w, h, 0.0, 1.0);
                }
                None => {
                    if let Some(i) = &l.icon {
                        gfx::image(pm, i, (cw - p(32.0)) / 2.0, cy - p(16.0), p(32.0), p(32.0), 0.0, 0.5);
                    }
                }
            }
            let name = gfx::fit_middle(&l.fonts.semibold, &l.name, p(15.0), cw - p(60.0));
            let nw = gfx::measure(&l.fonts.semibold, &name, p(15.0));
            gfx::text(pm, &l.fonts.semibold, &name, (cw - nw) / 2.0, cy + size / 2.0 + p(34.0), p(15.0), gfx::white(0.9));
        }
        Body::Handler(_) | Body::Empty => {}
    }
    // шапка и подвал поверх: длинный текст под ними обрезается
    // шапка как у окон Windows: значок и имя слева, кнопка «Открыть в …» и крестик справа
    let bar = if dark { gfx::rgb(0x2B, 0x2B, 0x2B, 1.0) } else { gfx::rgb(0xF3, 0xF3, 0xF3, 1.0) };
    gfx::fill_rrect(pm, 0.0, 0.0, cw, head, 0.0, bar);
    gfx::fill_rrect(pm, 0.0, head, cw, 1.0, 0.0, gfx::white(0.08));
    let mut x = p(14.0);
    if let Some(icon) = &l.icon {
        let sz = p(16.0);
        gfx::image(pm, icon, x, (head - sz) / 2.0, sz, sz, 0.0, 1.0);
        x += sz + p(10.0);
    }
    let ow = open_width(l, s);
    let close_x = cw - p(CLOSE_W);
    let open_x = close_x - p(8.0) - ow;
    let name = gfx::fit_middle(&l.fonts.semibold, &l.name, p(13.0), open_x - x - p(12.0));
    gfx::text(pm, &l.fonts.semibold, &name, x, head / 2.0 + p(4.5), p(13.0), gfx::white(0.92));
    if !l.open.is_empty() {
        let (oy, oh) = (p(8.0), head - p(16.0));
        let fill = match (l.hover == Hit::Open, dark) {
            (true, true) => gfx::white(0.12),
            (false, true) => gfx::white(0.07),
            (true, false) => gfx::rgb(0xE5, 0xE5, 0xE5, 1.0),
            (false, false) => gfx::rgb(0xFB, 0xFB, 0xFB, 1.0),
        };
        gfx::fill_rrect(pm, open_x, oy, ow, oh, p(4.0), fill);
        gfx::stroke_rrect(pm, open_x + 0.5, oy + 0.5, ow - 1.0, oh - 1.0, p(4.0), 1.0, gfx::white(if dark { 0.09 } else { 0.12 }));
        gfx::text(pm, &l.fonts.regular, &l.open, open_x + p(14.0), oy + oh / 2.0 + p(4.5), p(13.0), gfx::white(0.9));
    }
    if l.hover == Hit::Close {
        gfx::fill_rrect(pm, close_x, 0.0, p(CLOSE_W), head, 0.0, gfx::rgb(0xC4, 0x2B, 0x1C, 1.0));
    }
    let xc = if l.hover == Hit::Close { gfx::rgb(0xFF, 0xFF, 0xFF, 1.0) } else { gfx::white(0.85) };
    gfx::glyph(pm, '\u{E8BB}', close_x + p(CLOSE_W) / 2.0, head / 2.0, p(10.0), xc);
    // подвал
    gfx::fill_rrect(pm, 0.0, foot_y, cw, p(FOOT), 0.0, bar);
    gfx::fill_rrect(pm, 0.0, foot_y, cw, 1.0, 0.0, gfx::white(0.08));
    let info = gfx::fit(&l.fonts.regular, &l.info, p(12.0), cw - p(28.0));
    gfx::text(pm, &l.fonts.regular, &info, p(14.0), foot_y + p(FOOT) / 2.0 + p(4.0), p(12.0), gfx::white(0.6));
}

fn paint(l: &mut Look, hdc: HDC) {
    let mut r = RECT::default();
    unsafe {
        let _ = GetClientRect(l.hwnd, &mut r);
    }
    let (cw, ch) = (r.right, r.bottom);
    if cw <= 0 || ch <= 0 {
        return;
    }
    if l.frame.as_ref().is_none_or(|f| f.w != cw || f.h != ch) {
        l.frame = Surface::new(cw, ch);
    }
    let s = scale(l.hwnd);
    let Some(frame) = l.frame.as_ref() else { return };
    let data = unsafe { frame.pixels() };
    if let Some(mut pm) = PixmapMut::from_bytes(data, cw as u32, ch as u32) {
        compose(l, &mut pm, cw as f32, ch as f32, s);
    }
    unsafe {
        let _ = BitBlt(hdc, 0, 0, cw, ch, Some(frame.dc), 0, 0, SRCCOPY);
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        // вся площадь окна — наша: рамку не рисуем, но растягивать за края можно
        WM_NCCALCSIZE if wp.0 != 0 => LRESULT(0),
        WM_NCHITTEST => {
            let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, (lp.0 >> 16 & 0xFFFF) as i16 as i32);
            let mut r = RECT::default();
            let _ = GetWindowRect(hwnd, &mut r);
            let b = (6.0 * scale(hwnd)) as i32;
            let (l, t, rr, bb) = (x < r.left + b, y < r.top + b, x >= r.right - b, y >= r.bottom - b);
            let edge = match (l, t, rr, bb) {
                (true, true, _, _) => HTTOPLEFT,
                (_, true, true, _) => HTTOPRIGHT,
                (true, _, _, true) => HTBOTTOMLEFT,
                (_, _, true, true) => HTBOTTOMRIGHT,
                (true, _, _, _) => HTLEFT,
                (_, _, true, _) => HTRIGHT,
                (_, true, _, _) => HTTOP,
                (_, _, _, true) => HTBOTTOM,
                _ => 0,
            };
            if edge != 0 {
                return LRESULT(edge as isize);
            }
            let hit = with(|lk| hit_at(lk, x - r.left, y - r.top)).unwrap_or(Hit::None);
            let head = y - r.top < (HEAD * scale(hwnd)) as i32;
            LRESULT(if head && hit == Hit::None { HTCAPTION } else { HTCLIENT } as isize)
        }
        WM_MOUSEACTIVATE => LRESULT(MA_NOACTIVATE as isize),
        WM_MOUSEMOVE => {
            let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, (lp.0 >> 16 & 0xFFFF) as i16 as i32);
            let changed = with(|l| {
                let h = hit_at(l, x, y);
                std::mem::replace(&mut l.hover, h) != h
            })
            .unwrap_or(false);
            let mut tme = TRACKMOUSEEVENT { cbSize: std::mem::size_of::<TRACKMOUSEEVENT>() as u32, dwFlags: TME_LEAVE, hwndTrack: hwnd, dwHoverTime: 0 };
            let _ = TrackMouseEvent(&mut tme);
            if changed {
                redraw();
            }
            LRESULT(0)
        }
        0x02A3 => {
            // WM_MOUSELEAVE
            with(|l| l.hover = Hit::None);
            redraw();
            LRESULT(0)
        }
        WM_LBUTTONUP => {
            let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, (lp.0 >> 16 & 0xFFFF) as i16 as i32);
            match with(|l| hit_at(l, x, y)).unwrap_or(Hit::None) {
                Hit::Close => close(),
                Hit::Open => open_item(),
                Hit::None => {}
            }
            LRESULT(0)
        }
        WM_LBUTTONDBLCLK => {
            open_item();
            LRESULT(0)
        }
        WM_MOUSEWHEEL => {
            let delta = (wp.0 >> 16 & 0xFFFF) as i16 as f32 / 120.0;
            with(|l| {
                if let Body::Text(lines) = &l.body {
                    let s = scale(l.hwnd);
                    let r = body_rect(l);
                    let visible = (r.bottom - r.top) as f32 / s - 24.0;
                    let max = (lines.len() as f32 * 19.0 - visible).max(0.0);
                    l.scroll = (l.scroll - delta * 3.0 * 19.0).clamp(0.0, max);
                }
            });
            redraw();
            LRESULT(0)
        }
        WM_SIZE => {
            with(|l| {
                if let Body::Handler(h) = &l.body {
                    let r = body_rect(l);
                    let _ = SetWindowPos(l.host, None, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE);
                    let _ = h.SetRect(&RECT { left: 0, top: 0, right: r.right - r.left, bottom: r.bottom - r.top });
                }
            });
            redraw();
            LRESULT(0)
        }
        WM_EXITSIZEMOVE => {
            with(|l| l.user_rect = true);
            LRESULT(0)
        }
        WM_DPICHANGED => {
            let r = &*(lp.0 as *const RECT);
            let _ = SetWindowPos(hwnd, None, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE);
            LRESULT(0)
        }
        WM_TIMER => {
            match wp.0 {
                TIMER_FOLLOW => follow(),
                TIMER_SHOW => {
                    let _ = KillTimer(Some(hwnd), TIMER_SHOW);
                    // картинка грузится долго — показываем окно со значком, она подставится сама
                    with(|l| {
                        if !matches!(l.body, Body::Image(_)) {
                            unload(l);
                            l.body = Body::Icon(None);
                        }
                    });
                    present();
                }
                _ => {}
            }
            LRESULT(0)
        }
        WM_LOOK_REDRAW => {
            let _ = InvalidateRect(Some(hwnd), None, false);
            LRESULT(0)
        }
        WM_LOOK_IMG => {
            image_ready();
            LRESULT(0)
        }
        WM_ERASEBKGND => LRESULT(1),
        WM_PAINT => {
            let mut ps = PAINTSTRUCT::default();
            let hdc = BeginPaint(hwnd, &mut ps);
            let done = with(|l| paint(l, hdc)).is_some();
            let _ = EndPaint(hwnd, &ps);
            if !done {
                let _ = PostMessageW(Some(hwnd), WM_LOOK_REDRAW, WPARAM(0), LPARAM(0));
            }
            LRESULT(0)
        }
        WM_CLOSE => {
            close();
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

// ---------- проверка ----------

/// --look-test файл out.png: открыть просмотр файла, через пару секунд снять окно с экрана и закрыть
pub fn self_test(path: &Path, out: &Path) -> String {
    init(HWND::default());
    let wp = wide(&path.to_string_lossy().replace('/', "\\"));
    if let Err(e) = unsafe { SHCreateItemFromParsingName::<_, _, IShellItem>(pcwstr(&wp), None) } {
        return format!("оболочка не знает файл: {e}");
    }
    if Fonts::load().is_none() {
        return "нет шрифтов".into();
    }
    if !open_path(path) {
        return "не открылся".into();
    }
    let start = Instant::now();
    let mut msg = MSG::default();
    unsafe {
        let _ = SetTimer(None, 0, 50, None);
        while start.elapsed() < Duration::from_millis(3000) && GetMessageW(&mut msg, None, 0, 0).as_bool() {
            let _ = TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
    let report = with(|l| {
        let body = match &l.body {
            Body::Empty => "пусто".to_string(),
            Body::Image(i) => format!("картинка {}×{}", i.w, i.h),
            Body::Text(t) => format!("текст, строк: {}", t.len()),
            Body::Handler(_) => "обработчик Windows".into(),
            Body::Icon(i) => format!("значок {}", i.is_some()),
        };
        let mut r = RECT::default();
        unsafe {
            let _ = GetWindowRect(l.hwnd, &mut r);
        }
        if out.to_str() == Some("-") {
            // чужие файлы на снимок не берём — только отчёт
        } else if let Some(png) = capture(RECT { left: r.left - 24, top: r.top - 24, right: r.right + 24, bottom: r.bottom + 24 }) {
            let _ = std::fs::write(out, png);
        }
        format!("{body}\nподпись: {}\nкнопка: {}\nокно: {}×{}", l.info, l.open, r.right - r.left, r.bottom - r.top)
    })
    .unwrap_or_default();
    close();
    report
}

/// Снимок участка экрана (окно поверх всех — значит, видно его и тень)
fn capture(r: RECT) -> Option<Vec<u8>> {
    let (w, h) = (r.right - r.left, r.bottom - r.top);
    let surf = Surface::new(w, h)?;
    unsafe {
        let screen = GetDC(None);
        let _ = BitBlt(surf.dc, 0, 0, w, h, Some(screen), r.left, r.top, SRCCOPY);
        ReleaseDC(None, screen);
        let mut img = Img::new(w as u32, h as u32);
        img.px.copy_from_slice(surf.pixels());
        for p in img.px.chunks_exact_mut(4) {
            p[3] = 255;
        }
        win::encode_png(&img)
    }
}

/// --look-probe: доходим ли до проводника и рабочего стола (только счётчики, без имён файлов)
pub fn probe() -> String {
    let mut out = String::new();
    unsafe {
        let desk = GetShellWindow();
        let b = browser_for(desk);
        let n = b.as_ref().and_then(|b| {
            let v: IFolderView2 = b.QueryActiveShellView().ok()?.cast().ok()?;
            let all = v.ItemCount(SVGIO_ALLVIEW).ok()?;
            let sel = v.GetSelection(false).ok().and_then(|a| a.GetCount().ok()).unwrap_or(0);
            Some((all, sel))
        });
        out += &format!("рабочий стол ({}): найден {}, элементов/выделено {:?}
", class_of(desk), b.is_some(), n);
        let mut wins = Vec::new();
        let _ = EnumWindows(Some(collect), LPARAM(&mut wins as *mut Vec<HWND> as isize));
        out += &format!("окон проводника: {}
", wins.len());
        for w in wins {
            let b = browser_for(w);
            let sel = b.as_ref().and_then(|b| {
                let v: IFolderView2 = b.QueryActiveShellView().ok()?.cast().ok()?;
                v.GetSelection(false).ok()?.GetCount().ok()
            });
            out += &format!("  окно: найден {}, выделено {:?}
", b.is_some(), sel);
        }
    }
    out
}

unsafe extern "system" fn collect(h: HWND, lp: LPARAM) -> windows::core::BOOL {
    if class_of(h) == "CabinetWClass" {
        (*(lp.0 as *mut Vec<HWND>)).push(h);
    }
    TRUE
}
