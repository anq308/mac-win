//! Что находит поиск: приложения из «Пуска», файлы и папки, разделы параметров Windows,
//! а ещё считает примеры. Индекс строится в фоне и обновляется раз в 15 минут.

use std::collections::HashMap;
use std::ffi::c_void;
use std::os::windows::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

use windows::core::PWSTR;
use windows::Win32::Storage::FileSystem::{GetDriveTypeW, GetLogicalDrives, FILE_ATTRIBUTE_HIDDEN, FILE_ATTRIBUTE_SYSTEM};
use windows::Win32::System::Com::{CoInitializeEx, CoTaskMemFree, COINIT_MULTITHREADED};
use windows::Win32::UI::Shell::*;

use crate::win::{self, pcwstr, wide};

#[derive(Clone, Copy, PartialEq)]
pub enum Kind {
    App,
    Folder,
    File,
    Setting,
    Calc,
    Web,
    /// команда: заблокировать, сон, перезагрузка…
    Action,
    /// запись из истории буфера обмена
    Clip,
}

/// Режимы поиска — кнопки справа в строке, как в новом Spotlight
#[derive(Clone, Copy, PartialEq)]
pub enum Mode {
    All,
    Apps,
    Files,
    Actions,
    Clipboard,
}

impl Mode {
    pub const LIST: [Mode; 4] = [Mode::Apps, Mode::Files, Mode::Actions, Mode::Clipboard];

    fn takes(self, k: Kind) -> bool {
        match self {
            Mode::All => true,
            Mode::Apps => k == Kind::App,
            Mode::Files => matches!(k, Kind::Folder | Kind::File),
            Mode::Actions => matches!(k, Kind::Setting | Kind::Action),
            Mode::Clipboard => false,
        }
    }
}

#[derive(Clone)]
pub struct Hit {
    pub kind: Kind,
    pub title: String,
    pub sub: String,
    /// что открывать: путь, «shell:AppsFolder\…», адрес параметров, ссылка или результат примера
    pub target: String,
    /// откуда брать значок (у приложений — shell:AppsFolder\…)
    pub icon: Option<PathBuf>,
    pub score: i32,
}

pub struct Item {
    name: String,
    lower: String,
    target: String,
    kind: Kind,
}

pub type Shared = Arc<Mutex<Vec<Item>>>;

/// больше файлов в памяти не держим — хватает с запасом, а память и время поиска ограничены
const MAX_FILES: usize = 150_000;
const SKIP: [&str; 18] = [
    "node_modules",
    "target",
    "appdata",
    "windows",
    "program files",
    "program files (x86)",
    "programdata",
    "$recycle.bin",
    "system volume information",
    "steamapps",
    "__pycache__",
    "venv",
    ".git",
    "msocache",
    "recovery",
    "perflogs",
    "$windows.~ws",
    "windowsapps",
];

/// Запустить построение индекса в фоне: сразу и затем раз в 15 минут
pub fn start(shared: Shared) {
    std::thread::spawn(move || {
        unsafe {
            let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
        }
        loop {
            let items = build();
            if let Ok(mut s) = shared.lock() {
                *s = items;
            }
            std::thread::sleep(std::time::Duration::from_secs(15 * 60));
        }
    });
}

/// Построить индекс прямо сейчас (для превью)
pub fn build_now() -> Vec<Item> {
    build()
}

/// Перестроить индекс в фоне, не дожидаясь 15 минут
pub fn rebuild_now(shared: Shared) {
    std::thread::spawn(move || {
        unsafe {
            let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
        }
        let items = build();
        if let Ok(mut s) = shared.lock() {
            *s = items;
        }
    });
}

fn build() -> Vec<Item> {
    let mut out = apps();
    out.extend(actions());
    out.extend(settings());
    let mut budget = MAX_FILES;
    let known = [&FOLDERID_Desktop, &FOLDERID_Documents, &FOLDERID_Downloads, &FOLDERID_Pictures, &FOLDERID_Videos, &FOLDERID_Music];
    for id in known {
        if let Some(p) = win::known_folder(id) {
            crawl(&p, 6, &mut out, &mut budget);
        }
    }
    // папки в домашнем каталоге и корни остальных дисков — неглубоко
    if let Some(home) = win::known_folder(&FOLDERID_Profile) {
        crawl(&home, 1, &mut out, &mut budget);
    }
    for root in drives() {
        crawl(&root, 3, &mut out, &mut budget);
    }
    // одна и та же папка могла попасть дважды (Загрузки внутри домашней и т. п.)
    let mut seen = std::collections::HashSet::new();
    out.retain(|i| seen.insert(i.target.to_lowercase()));
    out
}

fn take(p: PWSTR) -> String {
    unsafe {
        let s = p.to_string().unwrap_or_default();
        CoTaskMemFree(Some(p.0 as *const c_void));
        s
    }
}

/// Все приложения из «Пуска» — и обычные, и из Microsoft Store
fn apps() -> Vec<Item> {
    let mut out = Vec::new();
    unsafe {
        let Ok(folder) = SHGetKnownFolderItem::<IShellItem>(&FOLDERID_AppsFolder, KF_FLAG_DEFAULT, None) else { return out };
        let Ok(en) = folder.BindToHandler::<_, IEnumShellItems>(None, &BHID_EnumItems) else { return out };
        loop {
            let mut buf = [None];
            let mut n = 0u32;
            if en.Next(&mut buf, Some(&mut n)).is_err() || n == 0 {
                break;
            }
            let Some(it) = buf[0].take() else { break };
            let name = it.GetDisplayName(SIGDN_NORMALDISPLAY).map(take).unwrap_or_default();
            let id = it.GetDisplayName(SIGDN_PARENTRELATIVEPARSING).map(take).unwrap_or_default();
            let low = name.to_lowercase();
            // деинсталляторы и справки в поиске только мешают
            if name.is_empty() || id.is_empty() || ["uninstall", "удален", "удалит", "readme", "help", "справк"].iter().any(|w| low.contains(w))
            {
                continue;
            }
            out.push(Item { lower: low, name, target: format!("shell:AppsFolder\\{id}"), kind: Kind::App });
        }
    }
    out
}

/// Команды Windows; опасные (перезагрузка, выключение, выход) окно спросит перед выполнением
fn actions() -> Vec<Item> {
    [
        ("Заблокировать компьютер", "action:lock"),
        ("Спящий режим", "action:sleep"),
        ("Перезагрузить компьютер", "action:restart"),
        ("Выключить компьютер", "action:shutdown"),
        ("Выйти из учётной записи", "action:signout"),
        ("Очистить корзину", "action:emptybin"),
        ("Открыть Finder", "action:finder"),
    ]
    .iter()
    .map(|(n, t)| Item { name: n.to_string(), lower: n.to_lowercase(), target: t.to_string(), kind: Kind::Action })
    .collect()
}

fn settings() -> Vec<Item> {
    [
        ("Параметры", "ms-settings:"),
        ("Параметры звука", "ms-settings:sound"),
        ("Параметры экрана", "ms-settings:display"),
        ("Bluetooth и другие устройства", "ms-settings:bluetooth"),
        ("Сеть и Интернет, Wi-Fi", "ms-settings:network"),
        ("Центр обновления Windows", "ms-settings:windowsupdate"),
        ("Приложения и возможности", "ms-settings:appsfeatures"),
        ("Автозагрузка приложений", "ms-settings:startupapps"),
        ("Персонализация", "ms-settings:personalization"),
        ("Фон рабочего стола", "ms-settings:personalization-background"),
        ("Цвета и тёмная тема", "ms-settings:colors"),
        ("Мышь", "ms-settings:mousetouchpad"),
        ("Питание и спящий режим", "ms-settings:powersleep"),
        ("Память устройства", "ms-settings:storagesense"),
        ("Язык и раскладка клавиатуры", "ms-settings:regionlanguage"),
        ("Дата и время", "ms-settings:dateandtime"),
        ("Принтеры и сканеры", "ms-settings:printers"),
        ("Панель управления", "control"),
        ("Диспетчер задач", "taskmgr"),
        ("Диспетчер устройств", "devmgmt.msc"),
        ("Корзина", "shell:RecycleBinFolder"),
    ]
    .iter()
    .map(|(n, t)| Item { name: n.to_string(), lower: n.to_lowercase(), target: t.to_string(), kind: Kind::Setting })
    .collect()
}

/// Корни дисков, кроме системного (его папки уже обойдены через домашний каталог)
fn drives() -> Vec<PathBuf> {
    let mut out = Vec::new();
    let mask = unsafe { GetLogicalDrives() };
    for i in 0..26 {
        if mask & (1 << i) == 0 {
            continue;
        }
        let root = format!("{}:\\", (b'A' + i as u8) as char);
        let w = wide(&root);
        // только обычные диски: флешки и сетевые бывают медленными
        if unsafe { GetDriveTypeW(pcwstr(&w)) } == 3 && !root.starts_with('C') {
            out.push(PathBuf::from(root));
        }
    }
    out
}

fn crawl(dir: &Path, depth: u32, out: &mut Vec<Item>, budget: &mut usize) {
    let Ok(rd) = std::fs::read_dir(dir) else { return };
    let mut subdirs = Vec::new();
    for e in rd.flatten() {
        if *budget == 0 {
            return;
        }
        let Ok(md) = e.metadata() else { continue };
        let attr = md.file_attributes();
        let name = e.file_name().to_string_lossy().to_string();
        if attr & (FILE_ATTRIBUTE_HIDDEN.0 | FILE_ATTRIBUTE_SYSTEM.0) != 0 || name.starts_with('.') || name.starts_with('$') {
            continue;
        }
        let lower = name.to_lowercase();
        let is_dir = md.is_dir();
        if is_dir && SKIP.contains(&lower.as_str()) {
            continue;
        }
        // desktop.ini и прочие служебные — мимо
        if !is_dir && (lower == "desktop.ini" || lower.ends_with(".tmp") || lower.ends_with(".lnk~")) {
            continue;
        }
        let path = e.path();
        out.push(Item { name, lower, target: path.to_string_lossy().to_string(), kind: if is_dir { Kind::Folder } else { Kind::File } });
        *budget -= 1;
        if is_dir && depth > 1 && attr & 0x400 == 0 {
            subdirs.push(path);
        }
    }
    for d in subdirs {
        crawl(&d, depth - 1, out, budget);
    }
}

/// Насколько имя подходит под запрос; None — не подходит
fn score(name: &str, q: &str) -> Option<i32> {
    if name == q {
        return Some(1000);
    }
    if name.starts_with(q) {
        return Some(800);
    }
    // с начала любого слова: «стим» найдёт «Клиент Steam» не хуже, чем «Steam»
    let mut prev = ' ';
    for (i, c) in name.char_indices() {
        if matches!(prev, ' ' | '-' | '_' | '.' | '(' | '[') && name[i..].starts_with(q) {
            return Some(650);
        }
        prev = c;
    }
    if name.contains(q) {
        return Some(450);
    }
    let words: Vec<&str> = q.split_whitespace().collect();
    if words.len() > 1 && words.iter().all(|w| name.contains(w)) {
        return Some(350);
    }
    None
}

fn parent_text(target: &str) -> String {
    Path::new(target).parent().map(|p| p.display().to_string()).unwrap_or_default()
}

fn hit_of(item: &Item, score: i32) -> Hit {
    let (sub, icon) = match item.kind {
        Kind::App => ("Приложение".to_string(), Some(PathBuf::from(&item.target))),
        Kind::Setting => ("Параметры Windows".to_string(), None),
        Kind::Action => ("Действие".to_string(), None),
        Kind::Folder => (format!("Папка · {}", parent_text(&item.target)), Some(PathBuf::from(&item.target))),
        _ => (parent_text(&item.target), Some(PathBuf::from(&item.target))),
    };
    // у ярлыков расширение не показываем — «Steam», а не «Steam.lnk», как в проводнике
    let low = item.lower.as_str();
    let title = if item.kind == Kind::File && (low.ends_with(".lnk") || low.ends_with(".url")) {
        item.name[..item.name.len() - 4].to_string()
    } else {
        item.name.clone()
    };
    Hit { kind: item.kind, title, sub, target: item.target.clone(), icon, score }
}

/// Результаты для запроса в выбранном режиме: пример, лучшие совпадения, в конце — поиск в интернете
pub fn search(items: &[Item], history: &HashMap<String, u32>, query: &str, limit: usize, mode: Mode) -> Vec<Hit> {
    let q = query.trim().to_lowercase();
    let mut out = Vec::new();
    if q.is_empty() {
        let mut list: Vec<(&Item, u32)> = items
            .iter()
            .filter(|i| mode.takes(i.kind))
            .filter_map(|i| {
                let n = history.get(&i.target).copied().unwrap_or(0);
                // во «всём» пустой запрос — только частое; в режиме — частое сверху, дальше всё по алфавиту
                (n > 0 || mode != Mode::All).then_some((i, n))
            })
            .collect();
        // частое сверху, затем команды раньше параметров, внутри — по алфавиту
        list.sort_by(|a, b| {
            b.1.cmp(&a.1).then_with(|| (a.0.kind != Kind::Action).cmp(&(b.0.kind != Kind::Action))).then_with(|| a.0.lower.cmp(&b.0.lower))
        });
        // в «Файлах» без запроса — только то, что открывали: весь диск по алфавиту бесполезен
        if mode == Mode::Files {
            list.retain(|(_, n)| *n > 0);
        }
        return list.into_iter().take(limit).map(|(i, n)| hit_of(i, n as i32)).collect();
    }
    if mode == Mode::All {
        if let Some(v) = calc(&q) {
            out.push(Hit {
                kind: Kind::Calc,
                title: format!("= {v}"),
                sub: "Enter — скопировать результат".into(),
                target: v,
                icon: None,
                score: i32::MAX,
            });
        }
    }
    let mut found: Vec<Hit> = items
        .iter()
        .filter(|i| mode.takes(i.kind))
        .filter_map(|i| {
            let base = score(&i.lower, &q)?;
            let bonus = match i.kind {
                Kind::App => 300,
                Kind::Setting | Kind::Action => 150,
                Kind::Folder => 40,
                _ => 0,
            };
            let used = history.get(&i.target).map_or(0, |n| (*n as i32 * 60).min(400));
            Some(hit_of(i, base + bonus + used - i.name.chars().count() as i32 / 3))
        })
        .collect();
    found.sort_by(|a, b| b.score.cmp(&a.score));
    let web = mode == Mode::All;
    out.extend(found.into_iter().take(limit.saturating_sub(out.len() + web as usize)));
    if web {
        out.push(Hit {
            kind: Kind::Web,
            title: format!("Искать «{}» в интернете", query.trim()),
            sub: "Откроется браузер".into(),
            target: format!("https://www.google.com/search?q={}", url_encode(query.trim())),
            icon: None,
            score: 0,
        });
    }
    out
}

fn url_encode(s: &str) -> String {
    let mut out = String::new();
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => out.push(b as char),
            b' ' => out.push('+'),
            _ => out.push_str(&format!("%{b:02X}")),
        }
    }
    out
}

// ---------- калькулятор ----------

/// «2+2*3», «(10-4)/3», «2^10», «15%» — только если это и правда пример
fn calc(q: &str) -> Option<String> {
    let s: String = q.chars().filter(|c| !c.is_whitespace()).collect::<String>().replace(',', ".");
    if s.is_empty() || !s.chars().all(|c| c.is_ascii_digit() || "+-*/^%().".contains(c)) {
        return None;
    }
    if !s.chars().any(|c| "+-*/^%".contains(c)) || !s.chars().any(|c| c.is_ascii_digit()) {
        return None;
    }
    let chars: Vec<char> = s.chars().collect();
    let mut p = Parser { s: &chars, i: 0 };
    let v = p.expr()?;
    if p.i != chars.len() || !v.is_finite() {
        return None;
    }
    let text = if (v - v.round()).abs() < 1e-9 && v.abs() < 1e15 {
        format!("{}", v.round() as i64)
    } else {
        let t = format!("{v:.10}");
        t.trim_end_matches('0').trim_end_matches('.').to_string()
    };
    Some(text.replace('.', ","))
}

struct Parser<'a> {
    s: &'a [char],
    i: usize,
}

impl Parser<'_> {
    fn peek(&self) -> Option<char> {
        self.s.get(self.i).copied()
    }
    fn expr(&mut self) -> Option<f64> {
        let mut v = self.term()?;
        while let Some(c @ ('+' | '-')) = self.peek() {
            self.i += 1;
            let r = self.term()?;
            v = if c == '+' { v + r } else { v - r };
        }
        Some(v)
    }
    fn term(&mut self) -> Option<f64> {
        let mut v = self.power()?;
        while let Some(c @ ('*' | '/')) = self.peek() {
            self.i += 1;
            let r = self.power()?;
            v = if c == '*' { v * r } else { v / r };
        }
        Some(v)
    }
    fn power(&mut self) -> Option<f64> {
        let base = self.unary()?;
        if self.peek() == Some('^') {
            self.i += 1;
            return Some(base.powf(self.power()?));
        }
        Some(base)
    }
    fn unary(&mut self) -> Option<f64> {
        if self.peek() == Some('-') {
            self.i += 1;
            return Some(-self.unary()?);
        }
        self.atom()
    }
    fn atom(&mut self) -> Option<f64> {
        let mut v = if self.peek() == Some('(') {
            self.i += 1;
            let v = self.expr()?;
            if self.peek() != Some(')') {
                return None;
            }
            self.i += 1;
            v
        } else {
            let start = self.i;
            while self.peek().is_some_and(|c| c.is_ascii_digit() || c == '.') {
                self.i += 1;
            }
            self.s[start..self.i].iter().collect::<String>().parse().ok()?
        };
        if self.peek() == Some('%') {
            self.i += 1;
            v /= 100.0;
        }
        Some(v)
    }
}

// ---------- что открывали ----------

fn history_file() -> Option<PathBuf> {
    Some(PathBuf::from(std::env::var_os("APPDATA")?).join("MacSpotlight").join("history.txt"))
}

pub fn load_history() -> HashMap<String, u32> {
    let mut out = HashMap::new();
    if let Some(text) = history_file().and_then(|f| std::fs::read_to_string(f).ok()) {
        for line in text.lines() {
            if let Some((n, t)) = line.split_once('\t') {
                out.insert(t.to_string(), n.parse().unwrap_or(1));
            }
        }
    }
    out
}

pub fn save_history(h: &HashMap<String, u32>) {
    let Some(f) = history_file() else { return };
    if let Some(d) = f.parent() {
        let _ = std::fs::create_dir_all(d);
    }
    let text: String = h.iter().map(|(t, n)| format!("{n}\t{t}\n")).collect();
    let _ = std::fs::write(f, text);
}
