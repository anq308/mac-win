//! Все окна плитками, как Mission Control: Ctrl+Win+↑ раскладывает открытые окна по каждому монитору
//! живыми миниатюрами (их рисует сам DWM), щелчок — открыть окно, Esc или пустое место — назад

use std::cell::RefCell;
use std::time::Instant;

use tiny_skia::PixmapMut;
use windows::core::w;
use windows::core::BOOL;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Dwm::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::gfx::{self, Img};
use crate::win::{self, Surface};

pub const WM_MISSION: u32 = WM_APP + 11;
pub static ON: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(true);
const TIMER_ANIM: usize = 1;
const ANIM_MS: f32 = 230.0;

struct Item {
    hwnd: HWND,
    title: String,
    icon: Option<Img>,
    minimized: bool,
    /// где окно на самом деле (относительно монитора) и где его плитка
    from: RECT,
    to: RECT,
    thumb: isize,
    /// часть исходного окна без невидимых краёв
    source: RECT,
}

struct Screen {
    hwnd: HWND,
    origin: POINT,
    size: (i32, i32),
    back: Option<Surface>,
    items: Vec<Item>,
}

struct Mission {
    screens: Vec<Screen>,
    start: Instant,
    closing: Option<HWND>,
    leaving: bool,
    hover: Option<(usize, usize)>,
    fonts: ab_glyph::FontVec,
}

thread_local! {
    static M: RefCell<Option<Mission>> = const { RefCell::new(None) };
}

fn with<R>(f: impl FnOnce(&mut Mission) -> R) -> Option<R> {
    M.with(|m| m.try_borrow_mut().ok()?.as_mut().map(f))
}

pub fn is_open() -> bool {
    M.with(|m| m.try_borrow().map(|m| m.is_some()).unwrap_or(true))
}

pub fn toggle() {
    if is_open() {
        close(None);
    } else {
        open();
    }
}

fn class_of(h: HWND) -> String {
    let mut buf = [0u16; 128];
    let n = unsafe { GetClassNameW(h, &mut buf) } as usize;
    String::from_utf16_lossy(&buf[..n])
}

fn title_of(h: HWND) -> String {
    let mut buf = [0u16; 256];
    let n = unsafe { GetWindowTextW(h, &mut buf) } as usize;
    String::from_utf16_lossy(&buf[..n])
}

/// Окна, которые видит человек: как в Alt+Tab
fn windows_list() -> Vec<HWND> {
    unsafe extern "system" fn each(h: HWND, lp: LPARAM) -> BOOL {
        let v = &mut *(lp.0 as *mut Vec<HWND>);
        if !IsWindowVisible(h).as_bool() || GetWindowTextLengthW(h) == 0 {
            return TRUE;
        }
        let ex = GetWindowLongW(h, GWL_EXSTYLE) as u32;
        let app = ex & WS_EX_APPWINDOW.0 != 0;
        if !app && (ex & WS_EX_TOOLWINDOW.0 != 0 || ex & WS_EX_NOACTIVATE.0 != 0 || GetWindow(h, GW_OWNER).is_ok_and(|o| !o.is_invalid())) {
            return TRUE;
        }
        let mut cloaked = 0u32;
        let _ = DwmGetWindowAttribute(h, DWMWA_CLOAKED, &mut cloaked as *mut _ as *mut _, 4);
        if cloaked != 0 {
            return TRUE;
        }
        let cls = class_of(h);
        if matches!(cls.as_str(), "Progman" | "WorkerW" | "Shell_TrayWnd" | "Shell_SecondaryTrayWnd" | "Windows.UI.Core.CoreWindow") || cls.starts_with("MacSpotlight.") {
            return TRUE;
        }
        v.push(h);
        TRUE
    }
    let mut v = Vec::new();
    unsafe {
        let _ = EnumWindows(Some(each), LPARAM(&mut v as *mut _ as isize));
    }
    v
}

fn icon_of(h: HWND) -> Option<Img> {
    unsafe {
        let mut r = 0usize;
        let _ = SendMessageTimeoutW(h, WM_GETICON, WPARAM(ICON_BIG as usize), LPARAM(0), SMTO_ABORTIFHUNG, 50, Some(&mut r));
        if r == 0 {
            let _ = SendMessageTimeoutW(h, WM_GETICON, WPARAM(ICON_SMALL2 as usize), LPARAM(0), SMTO_ABORTIFHUNG, 50, Some(&mut r));
        }
        if r == 0 {
            r = GetClassLongPtrW(h, GCLP_HICON);
        }
        if r == 0 {
            return None;
        }
        win::icon_img(HICON(r as *mut _))
    }
}

fn frame(h: HWND) -> (RECT, RECT) {
    let mut wr = RECT::default();
    let mut ext = RECT::default();
    unsafe {
        let _ = GetWindowRect(h, &mut wr);
        if DwmGetWindowAttribute(h, DWMWA_EXTENDED_FRAME_BOUNDS, &mut ext as *mut _ as *mut _, std::mem::size_of::<RECT>() as u32).is_err() {
            ext = wr;
        }
    }
    (wr, ext)
}

struct Mon {
    handle: HMONITOR,
    rect: RECT,
}

fn monitors() -> Vec<Mon> {
    unsafe extern "system" fn each(m: HMONITOR, _: HDC, _: *mut RECT, lp: LPARAM) -> BOOL {
        let mut mi = MONITORINFO { cbSize: std::mem::size_of::<MONITORINFO>() as u32, ..Default::default() };
        let _ = GetMonitorInfoW(m, &mut mi);
        (*(lp.0 as *mut Vec<Mon>)).push(Mon { handle: m, rect: mi.rcMonitor });
        TRUE
    }
    let mut v = Vec::new();
    unsafe {
        let _ = EnumDisplayMonitors(None, None, Some(each), LPARAM(&mut v as *mut _ as isize));
    }
    v
}

/// Снимок монитора — затемнённый и размытый фон под плитками
fn backdrop(r: RECT) -> Option<Surface> {
    let (w, h) = (r.right - r.left, r.bottom - r.top);
    let shot = Surface::new(w, h)?;
    unsafe {
        let screen = GetDC(None);
        let _ = BitBlt(shot.dc, 0, 0, w, h, Some(screen), r.left, r.top, SRCCOPY);
        ReleaseDC(None, screen);
    }
    // размытие: уменьшаем в 16 раз усреднением, растягиваем обратно с фильтром
    let k = 16;
    let (sw, sh) = ((w / k).max(1), (h / k).max(1));
    let src = unsafe { shot.pixels() };
    let mut small = Img::new(sw as u32, sh as u32);
    for y in 0..sh {
        for x in 0..sw {
            let mut acc = [0u32; 3];
            for yy in 0..k {
                for xx in 0..k {
                    let i = (((y * k + yy) * w + x * k + xx) * 4) as usize;
                    acc[0] += src[i] as u32;
                    acc[1] += src[i + 1] as u32;
                    acc[2] += src[i + 2] as u32;
                }
            }
            let n = (k * k) as u32;
            let o = ((y * sw + x) * 4) as usize;
            small.px[o] = (acc[0] / n) as u8;
            small.px[o + 1] = (acc[1] / n) as u8;
            small.px[o + 2] = (acc[2] / n) as u8;
            small.px[o + 3] = 255;
        }
    }
    if let Some(mut pm) = PixmapMut::from_bytes(unsafe { shot.pixels() }, w as u32, h as u32) {
        if let Some(sp) = small.pixmap() {
            let paint = tiny_skia::Paint {
                shader: tiny_skia::Pattern::new(
                    sp,
                    tiny_skia::SpreadMode::Pad,
                    tiny_skia::FilterQuality::Bilinear,
                    1.0,
                    tiny_skia::Transform::from_scale(w as f32 / sw as f32, h as f32 / sh as f32),
                ),
                ..Default::default()
            };
            if let Some(rr) = tiny_skia::Rect::from_xywh(0.0, 0.0, w as f32, h as f32) {
                pm.fill_rect(rr, &paint, tiny_skia::Transform::identity(), None);
                pm.fill_rect(rr, &gfx::solid(gfx::rgb(0, 0, 0, 0.42)), tiny_skia::Transform::identity(), None);
            }
        }
        for p in pm.data_mut().chunks_exact_mut(4) {
            p[3] = 255;
        }
    }
    Some(shot)
}

/// Сетка плиток: число рядов, при котором окна выходят крупнее всего
fn layout(items: &mut [Item], w: i32, h: i32, scale: f32) {
    let n = items.len();
    if n == 0 {
        return;
    }
    // по месту на экране: сверху вниз, слева направо
    items.sort_by_key(|i| ((i.from.top + i.from.bottom) / 2 / 200, (i.from.left + i.from.right) / 2));
    let (mx, my) = (w as f32 * 0.05, h as f32 * 0.07);
    let (aw, ah) = (w as f32 - 2.0 * mx, h as f32 - 2.0 * my);
    let title = 34.0 * scale;
    let gap = 28.0 * scale;
    let size = |i: &Item| {
        let (fw, fh) = ((i.from.right - i.from.left).max(200) as f32, (i.from.bottom - i.from.top).max(150) as f32);
        if i.minimized {
            (fw.min(800.0), fh.min(500.0))
        } else {
            (fw, fh)
        }
    };
    let mut best = (1usize, 0.0f32);
    for rows in 1..=n {
        let cols = n.div_ceil(rows);
        let (cw, ch) = (aw / cols as f32, ah / rows as f32);
        let total: f32 = items
            .iter()
            .map(|i| {
                let (fw, fh) = size(i);
                let k = ((cw - gap) / fw).min((ch - gap - title) / fh).min(1.0);
                fw * fh * k * k
            })
            .sum();
        if total > best.1 {
            best = (rows, total);
        }
    }
    let rows = best.0;
    let cols = n.div_ceil(rows);
    let (cw, ch) = (aw / cols as f32, ah / rows as f32);
    for (k, it) in items.iter_mut().enumerate() {
        let (r, c) = (k / cols, k % cols);
        let in_row = if r == rows - 1 { n - r * cols } else { cols };
        let shift = (cols - in_row) as f32 * cw / 2.0;
        let (fw, fh) = size(it);
        let s = ((cw - gap) / fw).min((ch - gap - title) / fh).min(1.0);
        let (tw, th) = (fw * s, fh * s);
        let x = mx + shift + c as f32 * cw + (cw - tw) / 2.0;
        let y = my + r as f32 * ch + title + (ch - title - th) / 2.0;
        it.to = RECT { left: x as i32, top: y as i32, right: (x + tw) as i32, bottom: (y + th) as i32 };
    }
}

fn open() {
    if !ON.load(std::sync::atomic::Ordering::Relaxed) {
        return;
    }
    let list = windows_list();
    let mons = monitors();
    let Some(fonts) = gfx::variable_font(600.0).or_else(|| {
        let dir = std::env::var("WINDIR").unwrap_or_else(|_| "C:\\Windows".into());
        std::fs::read(format!("{dir}\\Fonts\\seguisb.ttf")).ok().and_then(|v| ab_glyph::FontVec::try_from_vec(v).ok())
    }) else {
        return;
    };
    // фон снимаем до того, как появятся наши окна
    let backs: Vec<Option<Surface>> = mons.iter().map(|m| backdrop(m.rect)).collect();
    let inst = unsafe { GetModuleHandleW(None).unwrap_or_default() };
    unsafe {
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacSpotlight.Mission"),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            ..Default::default()
        };
        RegisterClassW(&wc);
    }
    let mut screens = Vec::new();
    for (mi, (m, back)) in mons.iter().zip(backs).enumerate() {
        let (w, h) = (m.rect.right - m.rect.left, m.rect.bottom - m.rect.top);
        let Ok(hwnd) = (unsafe {
            CreateWindowExW(
                WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
                w!("MacSpotlight.Mission"),
                w!("Все окна"),
                WS_POPUP,
                m.rect.left,
                m.rect.top,
                w,
                h,
                None,
                None,
                Some(inst.into()),
                None,
            )
        }) else {
            continue;
        };
        let scale = win::monitor_at(POINT { x: m.rect.left + 1, y: m.rect.top + 1 }).scale;
        let mut items = Vec::new();
        for &win in &list {
            let minimized = unsafe { IsIconic(win).as_bool() };
            let (wr, ext) = if minimized {
                let mut wp = WINDOWPLACEMENT { length: std::mem::size_of::<WINDOWPLACEMENT>() as u32, ..Default::default() };
                unsafe {
                    let _ = GetWindowPlacement(win, &mut wp);
                }
                (wp.rcNormalPosition, wp.rcNormalPosition)
            } else {
                frame(win)
            };
            let on = unsafe { MonitorFromRect(&ext, MONITOR_DEFAULTTONEAREST) };
            if on != m.handle {
                continue;
            }
            let from = RECT { left: ext.left - m.rect.left, top: ext.top - m.rect.top, right: ext.right - m.rect.left, bottom: ext.bottom - m.rect.top };
            let source = RECT { left: ext.left - wr.left, top: ext.top - wr.top, right: ext.right - wr.left, bottom: ext.bottom - wr.top };
            let mut thumb = 0isize;
            if !minimized {
                if let Ok(t) = unsafe { DwmRegisterThumbnail(hwnd, win) } {
                    thumb = t;
                }
            }
            items.push(Item { hwnd: win, title: title_of(win), icon: icon_of(win), minimized, from, to: from, thumb, source });
        }
        layout(&mut items, w, h, scale);
        let _ = mi;
        screens.push(Screen { hwnd, origin: POINT { x: m.rect.left, y: m.rect.top }, size: (w, h), back, items });
    }
    if screens.is_empty() {
        return;
    }
    M.with(|m| *m.borrow_mut() = Some(Mission { screens, start: Instant::now(), closing: None, leaving: false, hover: None, fonts }));
    let (hwnds, cursor_screen) = with(|m| {
        let c = win::cursor();
        let hs: Vec<HWND> = m.screens.iter().map(|s| s.hwnd).collect();
        let cs = m
            .screens
            .iter()
            .find(|s| c.x >= s.origin.x && c.x < s.origin.x + s.size.0 && c.y >= s.origin.y && c.y < s.origin.y + s.size.1)
            .map(|s| s.hwnd)
            .unwrap_or(hs[0]);
        (hs, cs)
    })
    .unwrap_or_default();
    update_thumbs(0.0);
    unsafe {
        for h in &hwnds {
            let _ = ShowWindow(*h, SW_SHOW);
        }
        let _ = SetForegroundWindow(cursor_screen);
        SetTimer(Some(hwnds[0]), TIMER_ANIM, 15, None);
    }
}

fn ease(p: f32) -> f32 {
    1.0 - (1.0 - p).powi(3)
}

fn lerp(a: RECT, b: RECT, k: f32) -> RECT {
    let f = |x: i32, y: i32| (x as f32 + (y - x) as f32 * k).round() as i32;
    RECT { left: f(a.left, b.left), top: f(a.top, b.top), right: f(a.right, b.right), bottom: f(a.bottom, b.bottom) }
}

/// Положение миниатюр на этом шаге анимации (0 — окна на своих местах, 1 — плитки)
fn update_thumbs(k: f32) {
    with(|m| {
        for s in &m.screens {
            for it in &s.items {
                if it.thumb == 0 {
                    continue;
                }
                let props = DWM_THUMBNAIL_PROPERTIES {
                    dwFlags: DWM_TNP_RECTDESTINATION | DWM_TNP_RECTSOURCE | DWM_TNP_VISIBLE | DWM_TNP_OPACITY | DWM_TNP_SOURCECLIENTAREAONLY,
                    rcDestination: lerp(it.from, it.to, k),
                    rcSource: it.source,
                    opacity: 255,
                    fVisible: true.into(),
                    fSourceClientAreaOnly: false.into(),
                };
                unsafe {
                    let _ = DwmUpdateThumbnailProperties(it.thumb, &props);
                }
            }
        }
    });
}

/// Закрыть: плитки летят обратно, затем открывается выбранное окно (если выбрали)
pub fn close(activate: Option<HWND>) {
    let first = with(|m| {
        if m.leaving {
            return None;
        }
        m.leaving = true;
        m.closing = activate;
        m.start = Instant::now();
        m.screens.first().map(|s| s.hwnd)
    })
    .flatten();
    if let Some(h) = first {
        unsafe {
            SetTimer(Some(h), TIMER_ANIM, 15, None);
        }
        for h in with(|m| m.screens.iter().map(|s| s.hwnd).collect::<Vec<_>>()).unwrap_or_default() {
            unsafe {
                let _ = InvalidateRect(Some(h), None, false);
            }
        }
    }
}

fn finish() {
    let Some(m) = M.with(|m| m.borrow_mut().take()) else { return };
    for s in &m.screens {
        for it in &s.items {
            if it.thumb != 0 {
                unsafe {
                    let _ = DwmUnregisterThumbnail(it.thumb);
                }
            }
        }
        unsafe {
            let _ = DestroyWindow(s.hwnd);
        }
    }
    if let Some(h) = m.closing {
        unsafe {
            if IsIconic(h).as_bool() {
                let _ = ShowWindow(h, SW_RESTORE);
            }
            let _ = SetForegroundWindow(h);
        }
    }
}

fn tick() {
    let Some((p, leaving)) = with(|m| ((m.start.elapsed().as_millis() as f32 / ANIM_MS).min(1.0), m.leaving)) else { return };
    let k = ease(p);
    update_thumbs(if leaving { 1.0 - k } else { k });
    if p >= 1.0 {
        if leaving {
            finish();
        } else if let Some(h) = with(|m| m.screens.first().map(|s| s.hwnd)).flatten() {
            unsafe {
                let _ = KillTimer(Some(h), TIMER_ANIM);
            }
            for h in with(|m| m.screens.iter().map(|s| s.hwnd).collect::<Vec<_>>()).unwrap_or_default() {
                unsafe {
                    let _ = InvalidateRect(Some(h), None, false);
                }
            }
        }
    }
}

fn screen_index(m: &Mission, hwnd: HWND) -> Option<usize> {
    m.screens.iter().position(|s| s.hwnd == hwnd)
}

fn hit(m: &Mission, si: usize, x: i32, y: i32) -> Option<usize> {
    let s = &m.screens[si];
    s.items.iter().position(|it| x >= it.to.left - 6 && x < it.to.right + 6 && y >= it.to.top - 34 && y < it.to.bottom + 6)
}

fn paint(m: &Mission, si: usize, hdc: HDC) {
    let s = &m.screens[si];
    let (w, h) = s.size;
    let Some(frame) = Surface::new(w, h) else { return };
    unsafe {
        if let Some(b) = &s.back {
            let _ = BitBlt(frame.dc, 0, 0, w, h, Some(b.dc), 0, 0, SRCCOPY);
        }
    }
    // подписи и рамки рисуем, только когда плитки встали
    let settled = !m.leaving && m.start.elapsed().as_millis() as f32 >= ANIM_MS;
    if settled {
        let scale = win::monitor_at(POINT { x: s.origin.x + 1, y: s.origin.y + 1 }).scale;
        if let Some(mut pm) = PixmapMut::from_bytes(unsafe { frame.pixels() }, w as u32, h as u32) {
            for (i, it) in s.items.iter().enumerate() {
                let r = it.to;
                let hot = m.hover == Some((si, i));
                let (x, y, tw, th) = (r.left as f32, r.top as f32, (r.right - r.left) as f32, (r.bottom - r.top) as f32);
                if hot {
                    let pad = 5.0 * scale;
                    gfx::fill_rrect(&mut pm, x - pad, y - pad, tw + 2.0 * pad, th + 2.0 * pad, 8.0 * scale, gfx::accent(1.0));
                }
                if it.minimized {
                    gfx::fill_rrect(&mut pm, x, y, tw, th, 6.0 * scale, gfx::rgb(0x2B, 0x2B, 0x2B, 0.92));
                    if let Some(ic) = &it.icon {
                        let sz = (64.0 * scale).min(th * 0.5);
                        gfx::image(&mut pm, ic, x + (tw - sz) / 2.0, y + (th - sz) / 2.0, sz, sz, 0.0, 1.0);
                    }
                    let t = "Свёрнуто";
                    let px = 12.0 * scale;
                    let lw = gfx::measure(&m.fonts, t, px);
                    gfx::text(&mut pm, &m.fonts, t, x + (tw - lw) / 2.0, y + th - 14.0 * scale, px, gfx::rgb(0xFF, 0xFF, 0xFF, 0.6));
                }
                // значок и имя над плиткой
                let px = 13.0 * scale;
                let isz = 18.0 * scale;
                let name = gfx::fit(&m.fonts, &it.title, px, tw - isz - 8.0 * scale);
                let nw = gfx::measure(&m.fonts, &name, px) + isz + 8.0 * scale;
                let lx = x + (tw - nw) / 2.0;
                let ly = y - 12.0 * scale;
                if let Some(ic) = &it.icon {
                    gfx::image(&mut pm, ic, lx, ly - isz + 3.0 * scale, isz, isz, 0.0, 1.0);
                }
                gfx::text(&mut pm, &m.fonts, &name, lx + isz + 8.0 * scale, ly, px, gfx::rgb(0xFF, 0xFF, 0xFF, if hot { 1.0 } else { 0.85 }));
            }
            for p in pm.data_mut().chunks_exact_mut(4) {
                p[3] = 255;
            }
        }
    }
    unsafe {
        let _ = BitBlt(hdc, 0, 0, w, h, Some(frame.dc), 0, 0, SRCCOPY);
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_PAINT => {
            let mut ps = PAINTSTRUCT::default();
            let hdc = BeginPaint(hwnd, &mut ps);
            with(|m| {
                if let Some(si) = screen_index(m, hwnd) {
                    paint(m, si, hdc);
                }
            });
            let _ = EndPaint(hwnd, &ps);
            LRESULT(0)
        }
        WM_ERASEBKGND => LRESULT(1),
        WM_TIMER if wp.0 == TIMER_ANIM => {
            tick();
            LRESULT(0)
        }
        WM_MOUSEMOVE => {
            let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, (lp.0 >> 16 & 0xFFFF) as i16 as i32);
            let changed = with(|m| {
                let h = screen_index(m, hwnd).and_then(|si| hit(m, si, x, y).map(|i| (si, i)));
                std::mem::replace(&mut m.hover, h) != h
            })
            .unwrap_or(false);
            if changed {
                for h in with(|m| m.screens.iter().map(|s| s.hwnd).collect::<Vec<_>>()).unwrap_or_default() {
                    let _ = InvalidateRect(Some(h), None, false);
                }
            }
            LRESULT(0)
        }
        WM_LBUTTONUP => {
            let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, (lp.0 >> 16 & 0xFFFF) as i16 as i32);
            let target = with(|m| screen_index(m, hwnd).and_then(|si| hit(m, si, x, y).map(|i| m.screens[si].items[i].hwnd))).flatten();
            close(target);
            LRESULT(0)
        }
        WM_RBUTTONUP => {
            close(None);
            LRESULT(0)
        }
        WM_KEYDOWN => {
            if wp.0 == VK_ESCAPE.0 as usize {
                close(None);
            }
            LRESULT(0)
        }
        WM_ACTIVATEAPP if wp.0 == 0 => {
            // ушли в другую программу (Alt+Tab) — убираем плитки
            close(None);
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

/// --preview mission-test: сколько окон видно и ровно ли встают плитки (без показа и без снимков)
pub fn self_test() -> String {
    let list = windows_list();
    let mut out = format!("окон: {}\n", list.len());
    for (mi, m) in monitors().iter().enumerate() {
        let (w, h) = (m.rect.right - m.rect.left, m.rect.bottom - m.rect.top);
        let mut items: Vec<Item> = list
            .iter()
            .filter_map(|&win| {
                let (_, ext) = frame(win);
                (unsafe { MonitorFromRect(&ext, MONITOR_DEFAULTTONEAREST) } == m.handle).then(|| {
                    let from = RECT { left: ext.left - m.rect.left, top: ext.top - m.rect.top, right: ext.right - m.rect.left, bottom: ext.bottom - m.rect.top };
                    Item { hwnd: win, title: String::new(), icon: None, minimized: unsafe { IsIconic(win).as_bool() }, from, to: from, thumb: 0, source: from }
                })
            })
            .collect();
        layout(&mut items, w, h, 1.0);
        let inside = items.iter().all(|i| i.to.left >= 0 && i.to.top >= 0 && i.to.right <= w && i.to.bottom <= h && i.to.right > i.to.left);
        let mut overlap = false;
        for a in 0..items.len() {
            for b in a + 1..items.len() {
                let (x, y) = (items[a].to, items[b].to);
                if x.left < y.right && y.left < x.right && x.top < y.bottom && y.top < x.bottom {
                    overlap = true;
                }
            }
        }
        let min = items.iter().map(|i| (i.to.right - i.to.left) * 100 / (i.from.right - i.from.left).max(1)).min().unwrap_or(0);
        out += &format!("монитор {mi} {w}×{h}: плиток {}, в границах {inside}, наложений {overlap}, самая мелкая {min}% от окна\n", items.len());
    }
    out
}
