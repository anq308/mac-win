#![windows_subsystem = "windows"]

mod clip;
mod daylight;
mod mission;
mod snap;
mod gfx;
mod hook;
mod index;
mod layout;
mod look;
mod panel;
mod scenery;
mod sun;
mod thumbs;
mod win;

use std::ffi::c_void;
use std::mem::size_of;
use std::sync::atomic::Ordering::Relaxed;

use windows::core::{w, PCWSTR};
use windows::Win32::Foundation::*;
use windows::Win32::System::Com::{CoInitializeEx, COINIT_APARTMENTTHREADED};
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::System::Registry::*;
use windows::Win32::System::Threading::CreateMutexW;
use windows::Win32::UI::HiDpi::{SetProcessDpiAwarenessContext, DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2};
use windows::Win32::UI::Shell::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use win::wide;

const WM_TRAY: u32 = WM_APP + 2;
const MENU_OPEN: usize = 1;
const MENU_REINDEX: usize = 2;
const MENU_AUTOSTART: usize = 3;
const MENU_EXIT: usize = 4;
const MENU_LAYOUT: usize = 5;
const TIMER_DAY: usize = 77;
const TIMER_DAY_FIRST: usize = 78;
const MENU_LOOK: usize = 6;

static mut TASKBAR_CREATED: u32 = 0;

/// Короткий журнал в %LOCALAPPDATA%\\MacSpotlight\\debug.log — чтобы понять, где теряется Win+S
pub fn log(msg: &str) {
    let Some(dir) = std::env::var_os("LOCALAPPDATA").map(|d| std::path::PathBuf::from(d).join("MacSpotlight")) else { return };
    let _ = std::fs::create_dir_all(&dir);
    let file = dir.join("debug.log");
    // журнал не растёт бесконечно: больше 100 КБ — начинаем заново
    if std::fs::metadata(&file).is_ok_and(|m| m.len() > 100_000) {
        let _ = std::fs::remove_file(&file);
    }
    let t = unsafe { windows::Win32::System::SystemInformation::GetLocalTime() };
    let line = format!("{:02}.{:02} {:02}:{:02}:{:02}.{:03}  {msg}\n", t.wDay, t.wMonth, t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    let _ = std::fs::OpenOptions::new().create(true).append(true).open(file).and_then(|mut f| std::io::Write::write_all(&mut f, line.as_bytes()));
}

fn main() {
    // panic = "abort" не оставляет следов — пишем причину в лог рядом с exe
    std::panic::set_hook(Box::new(|info| {
        if let Ok(exe) = std::env::current_exe() {
            let line = format!("{:?}: {info}\n", std::time::SystemTime::now());
            let _ = std::fs::OpenOptions::new()
                .create(true)
                .append(true)
                .open(exe.with_file_name("crash.log"))
                .and_then(|mut f| std::io::Write::write_all(&mut f, line.as_bytes()));
        }
    }));
    unsafe {
        let _ = SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
        let _ = CoInitializeEx(None, COINIT_APARTMENTTHREADED);
    }
    gfx::load_themes();
    gfx::use_theme(false);
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.first().map(String::as_str) == Some("--preview") && args.get(1).map(String::as_str) == Some("layout-test") {
        let out = args.get(2).cloned().unwrap_or_else(|| "layout.txt".into());
        let _ = std::fs::write(out, layout::self_test());
        return;
    }
    if args.first().map(String::as_str) == Some("--preview") && args.get(1).map(String::as_str) == Some("scenery-frames") {
        // четыре отдельных кадра 1920×1080: утро, день, вечер, ночь
        let dir = std::path::PathBuf::from(args.get(2).cloned().unwrap_or_else(|| ".".into()));
        for (name, e, evening, x) in [("morning", 2.5f32, false, 0.06f32), ("day", 28.0, false, 0.5), ("evening", 3.0, true, 0.94), ("night", -22.0, false, 0.5)] {
            if let Some(png) = win::encode_png(&scenery::render(1920, 1080, e, evening, x)) {
                let _ = std::fs::write(dir.join(format!("{name}.png")), png);
            }
        }
        return;
    }
    if args.first().map(String::as_str) == Some("--preview") && args.get(1).map(String::as_str) == Some("scenery") {
        // утро, день, вечер, ночь — четыре кадра в одной картинке
        let out = args.get(2).cloned().unwrap_or_else(|| "scenery.png".into());
        let (w, h) = (640u32, 360u32);
        let mut all = gfx::Img::new(w * 2, h * 2);
        for (k, (e, evening, x)) in [(2.0f32, false, 0.05f32), (28.0, false, 0.5), (3.0, true, 0.95), (-22.0, false, 0.5)].iter().enumerate() {
            let one = scenery::render(w, h, *e, *evening, *x);
            let (ox, oy) = ((k as u32 % 2) * w, (k as u32 / 2) * h);
            for y in 0..h {
                let src = (y * w * 4) as usize;
                let dst = (((oy + y) * w * 2 + ox) * 4) as usize;
                all.px[dst..dst + (w * 4) as usize].copy_from_slice(&one.px[src..src + (w * 4) as usize]);
            }
        }
        if let Some(png) = win::encode_png(&all) {
            let _ = std::fs::write(out, png);
        }
        return;
    }
    if args.first().map(String::as_str) == Some("--preview") && matches!(args.get(1).map(String::as_str), Some("snap-test" | "mission-test" | "day-test")) {
        let out = args.get(2).cloned().unwrap_or_else(|| "test.txt".into());
        let report = match args[1].as_str() {
            "snap-test" => snap::self_test(),
            "mission-test" => mission::self_test(),
            _ => daylight::self_test(args.get(3).map(std::path::Path::new)),
        };
        let _ = std::fs::write(out, report);
        return;
    }
    if args.first().map(String::as_str) == Some("--look-probe") {
        let _ = std::fs::write(args.get(1).cloned().unwrap_or_else(|| "probe.txt".into()), look::probe());
        return;
    }
    if args.first().map(String::as_str) == Some("--look-test") {
        let file = std::path::PathBuf::from(args.get(1).cloned().unwrap_or_default());
        let out = std::path::PathBuf::from(args.get(2).cloned().unwrap_or_else(|| "look.png".into()));
        let report = look::self_test(&file, &out);
        let _ = std::fs::write(out.with_extension("txt"), report);
        return;
    }
    if args.first().map(String::as_str) == Some("--preview") {
        let q = args.get(1).cloned().unwrap_or_default();
        let out = args.get(2).cloned().unwrap_or_else(|| "preview.png".into());
        if let Some(png) = panel::preview(&q).as_ref().and_then(win::encode_png) {
            let _ = std::fs::write(out, png);
        }
        return;
    }
    unsafe {
        let _ = CreateMutexW(None, true, w!("Local\\MacSpotlight.Instance"));
        if GetLastError() == ERROR_ALREADY_EXISTS {
            // повторный запуск (ярлык) — открыть поиск в уже работающей копии
            if let Ok(main) = FindWindowW(w!("MacSpotlight.Main"), None) {
                let _ = AllowSetForegroundWindow(ASFW_ANY);
                let _ = PostMessageW(Some(main), hook::WM_SEARCH, WPARAM(0), LPARAM(0));
            }
            return;
        }
    }
    let Some(fonts) = gfx::Fonts::load() else { return };
    let shared: index::Shared = Default::default();
    index::start(shared.clone());
    panel::init(fonts, shared);

    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW { lpfnWndProc: Some(wndproc), hInstance: inst.into(), lpszClassName: w!("MacSpotlight.Main"), ..Default::default() };
        RegisterClassW(&wc);
        let Ok(hwnd) =
            CreateWindowExW(WS_EX_TOOLWINDOW, w!("MacSpotlight.Main"), w!("MacSpotlight"), WS_POPUP, 0, 0, 0, 0, None, None, Some(inst.into()), None)
        else {
            return;
        };
        TASKBAR_CREATED = RegisterWindowMessageW(w!("TaskbarCreated"));
        tray(hwnd, NIM_ADD);
        load_settings();
        look::init(hwnd);
        // тема и обои по времени суток: сразу и потом раз в минуту
        SetTimer(Some(hwnd), TIMER_DAY, 60_000, None);
        SetTimer(Some(hwnd), TIMER_DAY_FIRST, 4_000, None);
        hook::start(hwnd);
        // история буфера обмена для режима «Буфер»
        clip::listen(hwnd);
        log("запуск");
        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).as_bool() {
            let _ = TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        let nid = NOTIFYICONDATAW { cbSize: size_of::<NOTIFYICONDATAW>() as u32, hWnd: hwnd, uID: 1, ..Default::default() };
        let _ = Shell_NotifyIconW(NIM_DELETE, &nid);
    }
}

/// Значок в трее — лупа Windows в цвете панели задач
fn tray_icon() -> HICON {
    gfx::use_theme(false);
    let size = unsafe { GetSystemMetrics(SM_CXSMICON) }.max(16) as u32 * 2;
    let mut img = gfx::Img::new(size, size);
    if let Some(mut pm) = img.pixmap_mut() {
        let k = size as f32;
        gfx::glyph(&mut pm, '\u{E721}', k / 2.0, k / 2.0, k * 0.8, gfx::white(1.0));
    }
    // иконкам нужна непремультиплицированная альфа
    for p in img.px.chunks_exact_mut(4) {
        let a = p[3] as u32;
        if a > 0 {
            for c in &mut p[..3] {
                *c = ((*c as u32 * 255 + a / 2) / a).min(255) as u8;
            }
        }
    }
    unsafe {
        let color = windows::Win32::Graphics::Gdi::CreateBitmap(size as i32, size as i32, 1, 32, Some(img.px.as_ptr() as *const c_void));
        let mask = windows::Win32::Graphics::Gdi::CreateBitmap(size as i32, size as i32, 1, 1, None);
        let info = ICONINFO { fIcon: true.into(), hbmColor: color, hbmMask: mask, ..Default::default() };
        let icon = CreateIconIndirect(&info).unwrap_or_default();
        let _ = windows::Win32::Graphics::Gdi::DeleteObject(color.into());
        let _ = windows::Win32::Graphics::Gdi::DeleteObject(mask.into());
        icon
    }
}

fn tray(hwnd: HWND, action: NOTIFY_ICON_MESSAGE) {
    let mut nid = NOTIFYICONDATAW {
        cbSize: size_of::<NOTIFYICONDATAW>() as u32,
        hWnd: hwnd,
        uID: 1,
        uFlags: NIF_ICON | NIF_MESSAGE | NIF_TIP,
        uCallbackMessage: WM_TRAY,
        hIcon: tray_icon(),
        ..Default::default()
    };
    let tip = wide("Поиск — Win+Пробел");
    nid.szTip[..tip.len()].copy_from_slice(&tip);
    unsafe {
        let _ = Shell_NotifyIconW(action, &nid);
        let _ = DestroyIcon(nid.hIcon);
    }
}

fn settings_file() -> Option<std::path::PathBuf> {
    std::env::var_os("LOCALAPPDATA").map(|d| std::path::PathBuf::from(d).join("MacSpotlight").join("settings.txt"))
}

/// Включены ли исправление раскладки и быстрый просмотр — по строке «имя=0/1»
fn load_settings() {
    let Some(text) = settings_file().and_then(|f| std::fs::read_to_string(f).ok()) else { return };
    for line in text.lines() {
        match line.trim().split_once('=') {
            Some(("layout", v)) => layout::ON.store(v.trim() != "0", Relaxed),
            Some(("look", v)) => look::ON.store(v.trim() != "0", Relaxed),
            Some(("snap", v)) => snap::ON.store(v.trim() != "0", Relaxed),
            Some(("mission", v)) => mission::ON.store(v.trim() != "0", Relaxed),
            _ => {}
        }
    }
}

fn save_settings() {
    daylight::set("layout", Some(if layout::ON.load(Relaxed) { "1" } else { "0" }));
    daylight::set("look", Some(if look::ON.load(Relaxed) { "1" } else { "0" }));
    daylight::set("snap", Some(if snap::ON.load(Relaxed) { "1" } else { "0" }));
    daylight::set("mission", Some(if mission::ON.load(Relaxed) { "1" } else { "0" }));
}

const RUN_KEY: PCWSTR = w!("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
const RUN_VALUE: PCWSTR = w!("MacSpotlight");

fn autostart_enabled() -> bool {
    let mut size = 0u32;
    unsafe { RegGetValueW(HKEY_CURRENT_USER, RUN_KEY, RUN_VALUE, RRF_RT_REG_SZ, None, None, Some(&mut size)) == ERROR_SUCCESS }
}

fn set_autostart(on: bool) {
    unsafe {
        if on {
            let Ok(exe) = std::env::current_exe() else { return };
            let cmd = wide(&format!("\"{}\"", exe.display()));
            let _ = RegSetKeyValueW(HKEY_CURRENT_USER, RUN_KEY, RUN_VALUE, REG_SZ.0, Some(cmd.as_ptr() as *const c_void), (cmd.len() * 2) as u32);
        } else {
            let _ = RegDeleteKeyValueW(HKEY_CURRENT_USER, RUN_KEY, RUN_VALUE);
        }
    }
}

fn tray_menu(hwnd: HWND) {
    unsafe {
        let Ok(m) = CreatePopupMenu() else { return };
        let _ = AppendMenuW(m, MF_STRING, MENU_OPEN, w!("Поиск\tWin+Пробел"));
        let _ = SetMenuDefaultItem(m, MENU_OPEN as u32, 0);
        let _ = AppendMenuW(m, MF_STRING, MENU_REINDEX, w!("Обновить список файлов"));
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        let check = |on: bool| if on { MF_STRING | MF_CHECKED } else { MF_STRING };
        let _ = AppendMenuW(m, check(layout::ON.load(Relaxed)), MENU_LAYOUT, w!("Исправлять раскладку	Pause или Shift дважды"));
        let _ = AppendMenuW(m, check(look::ON.load(Relaxed)), MENU_LOOK, w!("Быстрый просмотр	Пробел в проводнике"));
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        let flags = if autostart_enabled() { MF_STRING | MF_CHECKED } else { MF_STRING };
        let _ = AppendMenuW(m, flags, MENU_AUTOSTART, w!("Запускать вместе с Windows"));
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        let _ = AppendMenuW(m, MF_STRING, MENU_EXIT, w!("Выход"));
        let p = win::cursor();
        let _ = SetForegroundWindow(hwnd);
        let cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, p.x, p.y, Some(0), hwnd, None).0 as usize;
        let _ = DestroyMenu(m);
        match cmd {
            MENU_OPEN => panel::toggle(),
            MENU_REINDEX => panel::reindex(),
            MENU_AUTOSTART => set_autostart(!autostart_enabled()),
            MENU_LAYOUT => {
                layout::ON.fetch_xor(true, Relaxed);
                save_settings();
            }
            MENU_LOOK => {
                if look::ON.fetch_xor(true, Relaxed) {
                    look::close();
                }
                save_settings();
            }
            MENU_EXIT => PostQuitMessage(0),
            _ => {}
        }
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        hook::WM_SEARCH => {
            log(if wp.0 == 1 { "Win+Пробел пойман хуком" } else { "открыть поиск (повторный запуск)" });
            panel::toggle();
            LRESULT(0)
        }
        layout::WM_FIX => {
            layout::fix(wp.0 == 1);
            LRESULT(0)
        }
        look::WM_LOOK => {
            look::command(wp.0, lp.0);
            LRESULT(0)
        }
        WM_TRAY => {
            match (lp.0 & 0xFFFF) as u32 {
                WM_LBUTTONUP => panel::toggle(),
                WM_RBUTTONUP => tray_menu(hwnd),
                _ => {}
            }
            LRESULT(0)
        }
        WM_CLIPBOARDUPDATE => {
            clip::on_update(hwnd);
            LRESULT(0)
        }
        snap::WM_SNAP => {
            snap::apply(wp.0);
            LRESULT(0)
        }
        mission::WM_MISSION => {
            mission::toggle();
            LRESULT(0)
        }
        WM_TIMER if wp.0 == TIMER_DAY || wp.0 == TIMER_DAY_FIRST => {
            if wp.0 == TIMER_DAY_FIRST {
                let _ = KillTimer(Some(hwnd), TIMER_DAY_FIRST);
            }
            daylight::tick();
            LRESULT(0)
        }
        WM_SETTINGCHANGE => {
            // сменили тему или цвет акцента
            gfx::load_themes();
            gfx::use_theme(false);
            tray(hwnd, NIM_MODIFY);
            LRESULT(0)
        }
        m if m == TASKBAR_CREATED && m != 0 => {
            tray(hwnd, NIM_ADD);
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}
