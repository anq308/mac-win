//! История буфера обмена, как в новом Spotlight: текст и файлы, последние 50 штук.
//! Хранится только в памяти — на диск не пишется, чтобы там не оседали пароли.

use std::cell::{Cell, RefCell};
use std::path::PathBuf;
use std::time::SystemTime;

use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::System::DataExchange::*;
use windows::Win32::System::Memory::{GlobalAlloc, GlobalLock, GlobalUnlock, GMEM_MOVEABLE};
use windows::Win32::UI::Shell::{DragQueryFileW, HDROP};

const LIMIT: usize = 50;
const CF_UNICODETEXT: u32 = 13;
const CF_HDROP: u32 = 15;

#[derive(Clone, PartialEq)]
pub enum Data {
    Text(String),
    Files(Vec<PathBuf>),
}

#[derive(Clone)]
pub struct Clip {
    pub data: Data,
    pub at: SystemTime,
}

thread_local! {
    static CLIPS: RefCell<Vec<Clip>> = const { RefCell::new(Vec::new()) };
    /// буфер только что заполнили мы сами — это не новая запись
    static OURS: Cell<bool> = const { Cell::new(false) };
}

/// До какого момента изменения буфера не записывать: исправление раскладки берёт выделенное через него
static QUIET: std::sync::Mutex<Option<std::time::Instant>> = std::sync::Mutex::new(None);

pub fn quiet(d: std::time::Duration) {
    if let Ok(mut q) = QUIET.lock() {
        *q = Some(std::time::Instant::now() + d);
    }
}

/// Подписаться на изменения буфера: окно будет получать WM_CLIPBOARDUPDATE
pub fn listen(hwnd: HWND) {
    unsafe {
        let _ = AddClipboardFormatListener(hwnd);
    }
}

pub fn all() -> Vec<Clip> {
    CLIPS.with(|c| c.borrow().clone())
}

/// Буфер изменился — запоминаем текст или список файлов
pub fn on_update(hwnd: HWND) {
    if OURS.with(|o| o.replace(false)) {
        return;
    }
    if QUIET.lock().is_ok_and(|q| q.is_some_and(|until| std::time::Instant::now() < until)) {
        return;
    }
    unsafe {
        // менеджеры паролей помечают свои данные этим форматом — их в историю не берём
        let private = RegisterClipboardFormatW(w!("ExcludeClipboardContentFromMonitorProcessing"));
        if private != 0 && IsClipboardFormatAvailable(private).is_ok() {
            return;
        }
        if OpenClipboard(Some(hwnd)).is_err() {
            return;
        }
        let data = read_files().or_else(|| read_text());
        let _ = CloseClipboard();
        if let Some(data) = data {
            CLIPS.with(|c| {
                let mut c = c.borrow_mut();
                c.retain(|x| x.data != data);
                c.insert(0, Clip { data, at: SystemTime::now() });
                c.truncate(LIMIT);
            });
        }
    }
}

unsafe fn read_text() -> Option<Data> {
    let h = GetClipboardData(CF_UNICODETEXT).ok()?;
    let g = HGLOBAL(h.0);
    let ptr = GlobalLock(g) as *const u16;
    if ptr.is_null() {
        return None;
    }
    let mut n = 0;
    while *ptr.add(n) != 0 {
        n += 1;
    }
    let s = String::from_utf16_lossy(std::slice::from_raw_parts(ptr, n));
    let _ = GlobalUnlock(g);
    (!s.trim().is_empty()).then_some(Data::Text(s))
}

unsafe fn read_files() -> Option<Data> {
    let h = GetClipboardData(CF_HDROP).ok()?;
    let drop = HDROP(h.0);
    let n = DragQueryFileW(drop, u32::MAX, None);
    let mut out = Vec::new();
    for i in 0..n {
        let len = DragQueryFileW(drop, i, None) as usize;
        let mut buf = vec![0u16; len + 1];
        DragQueryFileW(drop, i, Some(&mut buf));
        out.push(PathBuf::from(String::from_utf16_lossy(&buf[..len])));
    }
    (!out.is_empty()).then_some(Data::Files(out))
}

/// Положить запись обратно в буфер и поднять её наверх истории
pub fn restore(hwnd: HWND, i: usize) -> bool {
    let Some(clip) = CLIPS.with(|c| c.borrow().get(i).cloned()) else { return false };
    let bytes: Vec<u8> = match &clip.data {
        Data::Text(t) => t.encode_utf16().chain(Some(0)).flat_map(u16::to_le_bytes).collect(),
        Data::Files(files) => {
            // DROPFILES: смещение списка (20), точка (0,0), fNC = 0, fWide = 1; дальше пути через \0 и ещё \0
            let mut b = Vec::new();
            for v in [20u32, 0, 0, 0, 1] {
                b.extend(v.to_le_bytes());
            }
            for f in files {
                b.extend(f.to_string_lossy().encode_utf16().chain(Some(0)).flat_map(u16::to_le_bytes));
            }
            b.extend([0, 0]);
            b
        }
    };
    let format = if matches!(clip.data, Data::Text(_)) { CF_UNICODETEXT } else { CF_HDROP };
    unsafe {
        if OpenClipboard(Some(hwnd)).is_err() {
            return false;
        }
        let _ = EmptyClipboard();
        let mut ok = false;
        if let Ok(g) = GlobalAlloc(GMEM_MOVEABLE, bytes.len()) {
            let p = GlobalLock(g) as *mut u8;
            if !p.is_null() {
                std::ptr::copy_nonoverlapping(bytes.as_ptr(), p, bytes.len());
                let _ = GlobalUnlock(g);
                OURS.with(|o| o.set(true));
                ok = SetClipboardData(format, Some(HANDLE(g.0))).is_ok();
            }
        }
        let _ = CloseClipboard();
        if ok {
            CLIPS.with(|c| {
                let mut c = c.borrow_mut();
                let item = c.remove(i);
                c.insert(0, Clip { data: item.data, at: SystemTime::now() });
            });
        }
        ok
    }
}

/// «только что», «5 мин назад», «2 ч назад»
pub fn ago(t: SystemTime) -> String {
    let s = t.elapsed().map(|d| d.as_secs()).unwrap_or(0);
    match s {
        0..=59 => "только что".into(),
        60..=3599 => format!("{} мин назад", s / 60),
        3600..=86399 => format!("{} ч назад", s / 3600),
        _ => format!("{} дн назад", s / 86400),
    }
}
