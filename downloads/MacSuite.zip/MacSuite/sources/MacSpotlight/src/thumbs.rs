//! Миниатюры и иконки файлов в фоновых потоках: окно не подвисает даже в папке с тысячами фото

use std::path::PathBuf;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Mutex};

use windows::Win32::Foundation::{HWND, LPARAM, WPARAM};
use windows::Win32::System::Com::{CoInitializeEx, COINIT_MULTITHREADED};
use windows::Win32::UI::WindowsAndMessaging::PostMessageW;

use crate::gfx::Img;
use crate::win;

pub const WM_THUMB: u32 = windows::Win32::UI::WindowsAndMessaging::WM_APP + 20;
const WORKERS: usize = 3;

struct Job {
    path: PathBuf,
    px: u32,
    gen: u64,
}

pub struct Done {
    pub path: PathBuf,
    pub px: u32,
    pub img: Option<Img>,
}

pub struct Pool {
    jobs: Sender<Job>,
    pub done: Receiver<Done>,
    /// номер «поколения»: при переходе в другую папку старые задания пропускаются
    gen: Arc<AtomicU64>,
}

impl Pool {
    pub fn new(hwnd: HWND) -> Pool {
        let (jtx, jrx) = channel::<Job>();
        let (dtx, drx) = channel::<Done>();
        let jrx = Arc::new(Mutex::new(jrx));
        let gen = Arc::new(AtomicU64::new(0));
        let h = hwnd.0 as isize;
        for _ in 0..WORKERS {
            let (jrx, dtx, gen) = (jrx.clone(), dtx.clone(), gen.clone());
            std::thread::spawn(move || {
                unsafe {
                    let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
                }
                loop {
                    let job = match jrx.lock() {
                        Ok(rx) => match rx.recv() {
                            Ok(j) => j,
                            Err(_) => break,
                        },
                        Err(_) => break,
                    };
                    if job.gen != gen.load(Ordering::Relaxed) {
                        continue;
                    }
                    // мелкие значки (список, боковая панель) — именно значки, как в проводнике, а не эскизы
                    let img = if job.px <= 40 {
                        win::small_icon(&job.path, job.px).or_else(|| win::shell_image(&job.path, job.px, true))
                    } else {
                        win::shell_image(&job.path, job.px, false)
                    };
                    if dtx.send(Done { path: job.path, px: job.px, img }).is_err() {
                        break;
                    }
                    unsafe {
                        let _ = PostMessageW(Some(HWND(h as *mut _)), WM_THUMB, WPARAM(0), LPARAM(0));
                    }
                }
            });
        }
        Pool { jobs: jtx, done: drx, gen }
    }

    pub fn request(&self, path: PathBuf, px: u32) {
        let gen = self.gen.load(Ordering::Relaxed);
        let _ = self.jobs.send(Job { path, px, gen });
    }
}
