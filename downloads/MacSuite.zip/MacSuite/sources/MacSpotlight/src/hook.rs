//! Win+Пробел — поиск, Pause — исправить раскладку, Пробел в проводнике — быстрый просмотр.
//! Win+Пробел: сочетание занято Windows (смена раскладки), RegisterHotKey его не получит,
//! а низкоуровневый хук клавиатуры успевает «съесть» нажатие раньше системы (как в MacShot)

use std::sync::atomic::{AtomicBool, AtomicIsize, AtomicU32, Ordering};

use windows::Win32::Foundation::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::WindowsAndMessaging::*;

pub const WM_SEARCH: u32 = WM_APP + 1;

static TARGET: AtomicIsize = AtomicIsize::new(0);
/// клавиша, нажатие которой мы съели: её отпускание и автоповтор тоже не пропускаем в систему
static HELD: AtomicU32 = AtomicU32::new(0);
/// зажата ли Win — по событиям самого хука: так надёжнее, чем спрашивать систему в момент нажатия
static WIN: AtomicBool = AtomicBool::new(false);

pub fn start(target: HWND) {
    TARGET.store(target.0 as isize, Ordering::SeqCst);
    // отдельный поток: если окно задумается, Windows не снимет хук по таймауту
    std::thread::spawn(|| unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let set = || SetWindowsHookExW(WH_KEYBOARD_LL, Some(proc), Some(inst.into()), 0).ok();
        let mut hook = set();
        crate::log(if hook.is_some() {
            "хук клавиатуры поставлен"
        } else {
            "хук клавиатуры НЕ поставлен"
        });
        // Windows молча снимает хук, если хоть раз не дождалась ответа (сон, нагрузка), — ставим заново
        let rehook = SetTimer(None, 0, 5000, None);
        // щелчок мышью переносит курсор в тексте — набор для исправления раскладки сбрасываем
        let mouse = SetTimer(None, 0, 60, None);
        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).as_bool() {
            if msg.message == WM_TIMER && msg.wParam.0 == mouse {
                crate::layout::poll_mouse();
                continue;
            }
            if msg.message == WM_TIMER && msg.wParam.0 == rehook && HELD.load(Ordering::SeqCst) == 0 {
                if let Some(fresh) = set() {
                    if let Some(old) = hook.replace(fresh) {
                        let _ = UnhookWindowsHookEx(old);
                    }
                }
            }
            DispatchMessageW(&msg);
        }
        if let Some(h) = hook {
            let _ = UnhookWindowsHookEx(h);
        }
    });
}

fn held(vk: VIRTUAL_KEY) -> bool {
    unsafe { GetAsyncKeyState(vk.0 as i32) < 0 }
}

unsafe extern "system" fn proc(code: i32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    if code == HC_ACTION as i32 {
        let k = &*(lp.0 as *const KBDLLHOOKSTRUCT);
        if k.flags.0 & LLKHF_INJECTED.0 == 0 {
            let down = wp.0 as u32 == WM_KEYDOWN || wp.0 as u32 == WM_SYSKEYDOWN;
            if k.vkCode == VK_LWIN.0 as u32 || k.vkCode == VK_RWIN.0 as u32 {
                WIN.store(down, Ordering::SeqCst);
            }
            let held_key = HELD.load(Ordering::SeqCst);
            if held_key != 0 && k.vkCode == held_key {
                if !down {
                    HELD.store(0, Ordering::SeqCst);
                }
                return LRESULT(1);
            }
            // Win+Пробел; с Shift или Ctrl — это смена раскладки в обратную сторону, её не трогаем
            let win = WIN.load(Ordering::SeqCst) || held(VK_LWIN) || held(VK_RWIN);
            if down && win && !held(VK_SHIFT) && !held(VK_CONTROL) && !held(VK_MENU) && k.vkCode == VK_SPACE.0 as u32 {
                HELD.store(k.vkCode, Ordering::SeqCst);
                mask_win_key();
                let target = HWND(TARGET.load(Ordering::SeqCst) as *mut _);
                // 1 — сигнал «пришло с клавиатуры», для журнала
                let _ = PostMessageW(Some(target), WM_SEARCH, WPARAM(1), LPARAM(0));
                return LRESULT(1);
            }
            // Ctrl+Win+↑ — все окна плитками
            if down && win && held(VK_CONTROL) && !held(VK_SHIFT) && !held(VK_MENU) && k.vkCode == VK_UP.0 as u32
                && crate::mission::ON.load(Ordering::Relaxed)
            {
                HELD.store(k.vkCode, Ordering::SeqCst);
                mask_win_key();
                let target = HWND(TARGET.load(Ordering::SeqCst) as *mut _);
                let _ = PostMessageW(Some(target), crate::mission::WM_MISSION, WPARAM(0), LPARAM(0));
                return LRESULT(1);
            }
            let target = HWND(TARGET.load(Ordering::SeqCst) as *mut _);
            if crate::snap::on_key(k.vkCode, down, target) {
                return LRESULT(1);
            }
            if crate::look::on_key(k.vkCode, down) {
                return LRESULT(1);
            }
            if crate::layout::on_key(k.vkCode, k.scanCode, down, target) {
                return LRESULT(1);
            }
        }
    }
    CallNextHookEx(None, code, wp, lp)
}

/// Пустое нажатие между Win↓ и Win↑, иначе после отпускания Win откроется «Пуск».
/// Заодно наш процесс становится источником последнего ввода и может вывести окно на передний план.
fn mask_win_key() {
    let key = |flags: KEYBD_EVENT_FLAGS| INPUT {
        r#type: INPUT_KEYBOARD,
        Anonymous: INPUT_0 { ki: KEYBDINPUT { wVk: VIRTUAL_KEY(0xE8), dwFlags: flags, ..Default::default() } },
    };
    unsafe {
        SendInput(&[key(KEYBD_EVENT_FLAGS(0)), key(KEYEVENTF_KEYUP)], std::mem::size_of::<INPUT>() as i32);
    }
}
