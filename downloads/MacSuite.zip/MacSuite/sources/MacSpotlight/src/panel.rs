//! Окно поиска: поле ввода и список результатов. Окно создаётся один раз и потом только
//! показывается и прячется — так оно появляется мгновенно.

use std::cell::RefCell;
use std::collections::HashMap;
use std::path::PathBuf;
use std::time::Instant;

use tiny_skia::PixmapMut;
use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::DataExchange::{CloseClipboard, GetClipboardData, IsClipboardFormatAvailable, OpenClipboard};
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::System::Memory::{GlobalLock, GlobalUnlock};
use windows::Win32::System::Threading::{AttachThreadInput, GetCurrentThreadId};
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::Shell::{SHEmptyRecycleBinW, ShellExecuteW};
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::clip;
use crate::gfx::{self, Fonts, Img};
use crate::index::{self, Hit, Kind, Mode, Shared};
use crate::thumbs::{Pool, WM_THUMB};
use crate::win::{self, pcwstr, wide, Surface};

/// поле под тень вокруг панели
const M: f32 = 30.0;
const W: f32 = 680.0;
const FIELD: f32 = 58.0;
const ROW: f32 = 48.0;
const ROWS: usize = 8;
const ICON: f32 = 32.0;
const TIMER_CARET: usize = 1;
const WM_REFOCUS: u32 = WM_APP + 40;
const TIMER_PASTE: usize = 2;
/// кнопки режимов справа в строке поиска
const MODE_W: f32 = 38.0;
/// значки режимов: приложения, файлы, действия, буфер обмена
const MODE_GLYPHS: [char; 4] = ['\u{F0E2}', '\u{F12B}', '\u{E945}', '\u{E77F}'];

struct Panel {
    hwnd: HWND,
    s: f32,
    fonts: Fonts,
    query: Vec<char>,
    caret: usize,
    /// весь текст выделен — следующая буква заменит запрос (так поиск открывается с прошлым запросом)
    all: bool,
    hits: Vec<Hit>,
    sel: usize,
    hover: Option<usize>,
    index: Shared,
    history: HashMap<String, u32>,
    icons: HashMap<(PathBuf, u32), Option<Img>>,
    pool: Pool,
    work: RECT,
    caret_on: bool,
    /// когда окно показали — первые мгновения потерю фокуса не считаем щелчком мимо
    shown: Instant,
    mode: Mode,
    hover_mode: Option<usize>,
}

thread_local! {
    static PANEL: RefCell<Option<Panel>> = const { RefCell::new(None) };
}

fn with<R>(f: impl FnOnce(&mut Panel) -> R) -> Option<R> {
    PANEL.with(|p| p.try_borrow_mut().ok()?.as_mut().map(f))
}

pub fn init(fonts: Fonts, index: Shared) {
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacSpotlight.Panel"),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            ..Default::default()
        };
        RegisterClassW(&wc);
        let Ok(hwnd) = CreateWindowExW(
            WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
            w!("MacSpotlight.Panel"),
            w!("Поиск"),
            WS_POPUP,
            0,
            0,
            1,
            1,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        let p = Panel {
            hwnd,
            s: 1.0,
            fonts,
            query: Vec::new(),
            caret: 0,
            all: false,
            hits: Vec::new(),
            sel: 0,
            hover: None,
            index,
            history: index::load_history(),
            icons: HashMap::new(),
            pool: Pool::new(hwnd),
            work: RECT::default(),
            caret_on: true,
            shown: Instant::now(),
            mode: Mode::All,
            hover_mode: None,
        };
        PANEL.with(|c| *c.borrow_mut() = Some(p));
    }
}

/// Win+Пробел: показать поиск (или спрятать, если уже открыт)
pub fn toggle() {
    let Some(hwnd) = with(|p| p.hwnd) else { return };
    unsafe {
        if IsWindowVisible(hwnd).as_bool() {
            hide();
            return;
        }
    }
    with(|p| {
        let m = win::monitor_at(win::cursor());
        if (m.scale - p.s).abs() > 0.01 {
            p.icons.clear();
        }
        p.s = m.scale;
        p.work = m.work;
        p.all = !p.query.is_empty();
        p.caret = p.query.len();
        p.caret_on = true;
        // каждый раз открываемся в общем поиске, как Spotlight
        p.mode = Mode::All;
        refresh(p);
    });
    with(|p| p.shown = Instant::now());
    with(present);
    unsafe {
        force_foreground(hwnd);
        SetTimer(Some(hwnd), TIMER_CARET, 530, None);
    }
}

/// Вывести окно на передний план, даже если Windows этого не хочет (пока зажата Win):
/// на время присоединяемся к потоку окна, которое сейчас впереди
unsafe fn force_foreground(hwnd: HWND) {
    let fg = GetForegroundWindow();
    let other = GetWindowThreadProcessId(fg, None);
    let me = GetCurrentThreadId();
    let attached = other != 0 && other != me && AttachThreadInput(me, other, true).as_bool();
    let _ = ShowWindow(hwnd, SW_SHOW);
    let _ = BringWindowToTop(hwnd);
    let ok = SetForegroundWindow(hwnd).as_bool();
    let _ = SetFocus(Some(hwnd));
    if attached {
        let _ = AttachThreadInput(me, other, false);
    }
    crate::log(&format!("поиск показан, на переднем плане: {}", if ok { "да" } else { "нет" }));
}

pub fn hide() {
    crate::log("поиск спрятан");
    with(|p| unsafe {
        let _ = KillTimer(Some(p.hwnd), TIMER_CARET);
        let _ = ShowWindow(p.hwnd, SW_HIDE);
    });
}

/// Перечитать индекс (из меню трея)
pub fn reindex() {
    with(|p| p.index.clone()).map(index::rebuild_now);
}

fn refresh(p: &mut Panel) {
    let q: String = p.query.iter().collect();
    p.hits = if p.mode == Mode::Clipboard {
        clip_hits(&q)
    } else {
        match p.index.lock() {
            Ok(items) => index::search(&items, &p.history, &q, ROWS, p.mode),
            Err(_) => Vec::new(),
        }
    };
    p.sel = 0;
    p.hover = None;
}

/// Записи истории буфера под запрос; target — номер записи в истории
fn clip_hits(q: &str) -> Vec<Hit> {
    let q = q.trim().to_lowercase();
    clip::all()
        .into_iter()
        .enumerate()
        .filter_map(|(i, c)| {
            let when = clip::ago(c.at);
            let (title, sub, icon) = match &c.data {
                clip::Data::Text(text) => {
                    if !q.is_empty() && !text.to_lowercase().contains(&q) {
                        return None;
                    }
                    let first = text.trim().lines().next().unwrap_or_default().trim().to_string();
                    let n = text.chars().count();
                    (first, format!("Скопировано {when} · символов: {n}"), None)
                }
                clip::Data::Files(files) => {
                    let names: Vec<String> =
                        files.iter().map(|f| f.file_name().map_or_else(|| f.display().to_string(), |n| n.to_string_lossy().to_string())).collect();
                    if !q.is_empty() && !names.iter().any(|n| n.to_lowercase().contains(&q)) {
                        return None;
                    }
                    let place = if files.len() == 1 {
                        files[0].parent().map(|d| d.display().to_string()).unwrap_or_default()
                    } else {
                        format!("файлов: {}", files.len())
                    };
                    (names.join(", "), format!("Скопировано {when} · {place}"), (files.len() == 1).then(|| files[0].clone()))
                }
            };
            Some(Hit { kind: Kind::Clip, title, sub, target: i.to_string(), icon, score: 0 })
        })
        .take(ROWS)
        .collect()
}

/// Включить режим; нажали на включённый — назад к общему поиску
fn set_mode(p: &mut Panel, m: Mode) {
    p.mode = if p.mode == m { Mode::All } else { m };
    refresh(p);
}

// ---------- вёрстка и отрисовка ----------

fn mode_rect(k: usize) -> [f32; 4] {
    [W - 10.0 - (4 - k) as f32 * MODE_W, (FIELD - 34.0) / 2.0, MODE_W - 4.0, 34.0]
}

/// Какая кнопка режима под точкой окна (физические пиксели)
fn mode_at(p: &Panel, x: i32, y: i32) -> Option<usize> {
    let (lx, ly) = (x as f32 / p.s - M, y as f32 / p.s - M);
    (0..4).find(|&k| {
        let r = mode_rect(k);
        lx >= r[0] && lx < r[0] + r[2] && ly >= r[1] && ly < r[1] + r[3]
    })
}

/// подсказка, когда в истории буфера пусто
const EMPTY_H: f32 = 46.0;

fn height(p: &Panel) -> f32 {
    if p.hits.is_empty() && p.mode != Mode::All {
        FIELD + 1.0 + EMPTY_H
    } else if p.hits.is_empty() {
        FIELD
    } else {
        FIELD + 1.0 + 6.0 + p.hits.len() as f32 * ROW + 6.0
    }
}

fn row_y(i: usize) -> f32 {
    FIELD + 1.0 + 6.0 + i as f32 * ROW
}

fn icon_px(p: &Panel) -> u32 {
    (ICON * p.s).round() as u32
}

fn present(p: &mut Panel) {
    gfx::use_theme(false);
    let s = p.s;
    let h = height(p);
    let (iw, ih) = (((W + 2.0 * M) * s).ceil() as u32, ((h + 2.0 * M) * s).ceil() as u32);
    // значки результатов — у Windows, в фоне
    let px = icon_px(p);
    for hit in &p.hits {
        if let Some(path) = &hit.icon {
            let key = (path.clone(), px);
            if !p.icons.contains_key(&key) {
                p.icons.insert(key.clone(), None);
                p.pool.request(key.0, key.1);
            }
        }
    }
    let got: Vec<_> = p.pool.done.try_iter().collect();
    for d in got {
        p.icons.insert((d.path, d.px), d.img);
    }
    let mut img = Img::new(iw, ih);
    if let Some(mut pm) = img.pixmap_mut() {
        draw(p, &mut pm, h);
    }
    let Some(surf) = Surface::new(iw as i32, ih as i32) else { return };
    unsafe {
        surf.pixels().copy_from_slice(&img.px);
        let wk = p.work;
        let x = wk.left + (wk.right - wk.left - iw as i32) / 2;
        let y = wk.top + ((wk.bottom - wk.top) as f32 * 0.2) as i32 - (M * s) as i32;
        let screen = GetDC(None);
        let pos = POINT { x, y };
        let size = SIZE { cx: iw as i32, cy: ih as i32 };
        let src = POINT::default();
        let blend = BLENDFUNCTION { BlendOp: AC_SRC_OVER as u8, SourceConstantAlpha: 255, AlphaFormat: AC_SRC_ALPHA as u8, ..Default::default() };
        let _ = UpdateLayeredWindow(p.hwnd, Some(screen), Some(&pos), Some(&size), Some(surf.dc), Some(&src), COLORREF(0), Some(&blend), ULW_ALPHA);
        ReleaseDC(None, screen);
    }
}

fn draw(p: &Panel, pm: &mut PixmapMut, h: f32) {
    let s = p.s;
    let o = M * s;
    let x = |v: f32| o + v * s;
    let d = |v: f32| v * s;
    let f = &p.fonts;
    // панель как всплывающие окна Windows 10: тень, прямые углы, тонкая рамка
    gfx::shadow(pm, o, o + d(8.0), d(W), d(h), d(28.0), 0.45);
    gfx::fill_rrect(pm, o, o, d(W), d(h), d(gfx::window_radius()), gfx::surface(0.98));
    gfx::stroke_rrect(pm, o + 0.5, o + 0.5, d(W) - 1.0, d(h) - 1.0, d(gfx::window_radius()), 1.0, gfx::white(0.12));

    // поле ввода
    gfx::glyph(pm, '\u{E721}', x(30.0), x(FIELD / 2.0), 20.0 * s, gfx::white(0.7));
    let px = 20.0 * s;
    let base = x(FIELD / 2.0 + 7.0);
    let tx = x(56.0);
    let text: String = p.query.iter().collect();
    let room = d(W - 56.0 - 22.0 - 4.0 * MODE_W);
    if text.is_empty() {
        let hint = match p.mode {
            Mode::All => "Приложения, файлы, папки и параметры",
            Mode::Apps => "Поиск приложений",
            Mode::Files => "Поиск файлов и папок",
            Mode::Actions => "Действия и параметры Windows",
            Mode::Clipboard => "История буфера обмена",
        };
        gfx::text(pm, &f.regular, &gfx::fit(&f.regular, hint, px, room), tx, base, px, gfx::white(0.4));
    } else {
        if p.all {
            let tw = gfx::measure(&f.regular, &text, px);
            gfx::fill_rrect(pm, tx - d(2.0), x(FIELD / 2.0 - 14.0), tw + d(4.0), d(28.0), 0.0, gfx::accent(0.55));
        }
        let shown = gfx::fit(&f.regular, &text, px, room);
        gfx::text(pm, &f.regular, &shown, tx, base, px, gfx::white(0.95));
    }
    if p.caret_on && !p.all {
        let before: String = p.query[..p.caret].iter().collect();
        let cx = tx + gfx::measure(&f.regular, &before, px);
        gfx::fill_rrect(pm, cx, x(FIELD / 2.0 - 13.0), d(1.5).max(1.0), d(26.0), 0.0, gfx::white(0.9));
    }
    // режимы — справа в строке, как в новом Spotlight: приложения, файлы, действия, буфер
    let sep = mode_rect(0)[0] - 8.0;
    gfx::fill_rrect(pm, x(sep), x(FIELD / 2.0 - 13.0), 1.0, d(26.0), 0.0, gfx::white(0.12));
    for (k, ch) in MODE_GLYPHS.iter().enumerate() {
        let r = mode_rect(k);
        let on = p.mode == Mode::LIST[k];
        if on {
            gfx::fill_rrect(pm, x(r[0]), x(r[1]), d(r[2]), d(r[3]), 0.0, gfx::accent(1.0));
        } else if p.hover_mode == Some(k) {
            gfx::fill_rrect(pm, x(r[0]), x(r[1]), d(r[2]), d(r[3]), 0.0, gfx::white(0.08));
        }
        let col = if on { gfx::rgb(0xFF, 0xFF, 0xFF, 1.0) } else { gfx::white(0.7) };
        gfx::glyph(pm, *ch, x(r[0] + r[2] / 2.0), x(r[1] + r[3] / 2.0), 17.0 * s, col);
    }
    if p.hits.is_empty() {
        if p.mode != Mode::All {
            gfx::fill_rrect(pm, o, x(FIELD), d(W), 1.0, 0.0, gfx::white(0.1));
            let note = match p.mode {
                Mode::Clipboard => "Скопируйте что-нибудь — оно появится здесь",
                Mode::Files => "Введите имя файла или папки",
                _ => "Ничего не найдено",
            };
            gfx::text(pm, &f.regular, note, x(24.0), x(FIELD + 1.0 + EMPTY_H / 2.0 + 5.0), 13.0 * s, gfx::white(0.5));
        }
        return;
    }
    gfx::fill_rrect(pm, o, x(FIELD), d(W), 1.0, 0.0, gfx::white(0.1));

    // результаты
    let ipx = icon_px(p);
    for (i, hit) in p.hits.iter().enumerate() {
        let y = row_y(i);
        if i == p.sel {
            gfx::fill_rrect(pm, x(6.0), x(y), d(W - 12.0), d(ROW), 0.0, gfx::selected());
        } else if p.hover == Some(i) {
            gfx::fill_rrect(pm, x(6.0), x(y), d(W - 12.0), d(ROW), 0.0, gfx::white(0.06));
        }
        let (icx, icy) = (18.0 + ICON / 2.0, y + ROW / 2.0);
        let img = hit.icon.as_ref().and_then(|path| p.icons.get(&(path.clone(), ipx))).and_then(|i| i.as_ref());
        match img {
            Some(img) => gfx::image(pm, img, x(18.0), x(icy - ICON / 2.0), d(ICON), d(ICON), 0.0, 1.0),
            None => {
                let ch = match hit.kind {
                    Kind::App => '\u{E737}',
                    Kind::Folder => '\u{F12B}',
                    Kind::File => '\u{E8A5}',
                    Kind::Setting => '\u{E713}',
                    Kind::Calc => '\u{E8EF}',
                    Kind::Web => '\u{E774}',
                    Kind::Clip => '\u{E77F}',
                    Kind::Action => match hit.target.as_str() {
                        "action:lock" => '\u{E72E}',
                        "action:sleep" => '\u{E708}',
                        "action:emptybin" => '\u{E74D}',
                        "action:finder" => '\u{F12B}',
                        _ => '\u{E7E8}',
                    },
                };
                let accent = matches!(hit.kind, Kind::Calc | Kind::Web | Kind::Setting | Kind::Action | Kind::Clip);
                let col = if accent { gfx::accent(1.0) } else { gfx::white(0.5) };
                gfx::glyph(pm, ch, x(icx), x(icy), 22.0 * s, col);
            }
        }
        // справа у выбранной строки — подсказка, что сделает Enter
        let hint = if i == p.sel {
            match hit.kind {
                Kind::File => "Enter — открыть · Ctrl+Enter — в папке",
                Kind::Calc => "Enter — скопировать",
                Kind::Clip => "Enter — вставить",
                Kind::Action => "Enter — выполнить",
                _ => "Enter — открыть",
            }
        } else {
            ""
        };
        let hpx = 11.5 * s;
        let hw = if hint.is_empty() { 0.0 } else { gfx::measure(&f.regular, hint, hpx) + d(16.0) };
        if !hint.is_empty() {
            gfx::text(pm, &f.regular, hint, x(W - 18.0) - hw + d(16.0), x(y + ROW / 2.0 + 4.0), hpx, gfx::white(0.45));
        }
        let room = d(W - 18.0 - 64.0) - hw;
        let title = gfx::fit(&f.regular, &hit.title, 14.5 * s, room);
        gfx::text(pm, &f.regular, &title, x(64.0), x(y + 21.0), 14.5 * s, gfx::white(0.95));
        let sub = gfx::fit_middle(&f.regular, &hit.sub, 12.0 * s, room);
        gfx::text(pm, &f.regular, &sub, x(64.0), x(y + 38.0), 12.0 * s, gfx::white(0.5));
    }
}

// ---------- действия ----------

fn finder_exe() -> Option<PathBuf> {
    let p = PathBuf::from(std::env::var_os("LOCALAPPDATA")?).join("Programs\\MacFinder\\mac-finder.exe");
    p.exists().then_some(p)
}

fn shell_open(file: &str, args: Option<&str>) {
    let f = wide(file);
    let a = args.map(wide);
    unsafe {
        ShellExecuteW(None, w!("open"), pcwstr(&f), a.as_ref().map_or(windows::core::PCWSTR::null(), |a| pcwstr(a)), None, SW_SHOWNORMAL);
    }
}

/// Папку — в Finder (если он установлен), файл в Finder открывается вместе со своей папкой
fn show_in_finder(path: &str) {
    match finder_exe() {
        Some(exe) => shell_open(&exe.to_string_lossy(), Some(&format!("\"{path}\""))),
        None => shell_open("explorer.exe", Some(&format!("/select,\"{path}\""))),
    }
}

/// Ctrl+V в окно, которое снова впереди, — вставка выбранного из истории буфера
fn paste() {
    let key = |vk: VIRTUAL_KEY, up: bool| INPUT {
        r#type: INPUT_KEYBOARD,
        Anonymous: INPUT_0 { ki: KEYBDINPUT { wVk: vk, dwFlags: if up { KEYEVENTF_KEYUP } else { KEYBD_EVENT_FLAGS(0) }, ..Default::default() } },
    };
    let seq = [key(VK_CONTROL, false), key(VK_V, false), key(VK_V, true), key(VK_CONTROL, true)];
    unsafe {
        SendInput(&seq, std::mem::size_of::<INPUT>() as i32);
    }
}

/// Команды Windows; перезагрузку, выключение и выход сначала подтверждаем
fn run_action(hwnd: HWND, target: &str) {
    let confirm = |text: &str| {
        let t = wide(text);
        unsafe { MessageBoxW(Some(hwnd), pcwstr(&t), w!("Поиск"), MB_YESNO | MB_ICONQUESTION | MB_TOPMOST) == IDYES }
    };
    match target {
        "action:lock" => shell_open("rundll32.exe", Some("user32.dll,LockWorkStation")),
        "action:sleep" => shell_open("rundll32.exe", Some("powrprof.dll,SetSuspendState 0,1,0")),
        "action:restart" if confirm("Перезагрузить компьютер сейчас?\nНесохранённое в программах пропадёт.") => {
            shell_open("shutdown.exe", Some("/r /t 0"))
        }
        "action:shutdown" if confirm("Выключить компьютер сейчас?\nНесохранённое в программах пропадёт.") => {
            shell_open("shutdown.exe", Some("/s /t 0"))
        }
        "action:signout" if confirm("Выйти из учётной записи?\nНесохранённое в программах пропадёт.") => {
            shell_open("shutdown.exe", Some("/l"))
        }
        // корзину Windows очистит со своим вопросом «Вы уверены?»
        "action:emptybin" => unsafe {
            let _ = SHEmptyRecycleBinW(Some(hwnd), windows::core::PCWSTR::null(), 0);
        },
        "action:finder" => match finder_exe() {
            Some(exe) => shell_open(&exe.to_string_lossy(), None),
            None => shell_open("explorer.exe", None),
        },
        _ => {}
    }
}

fn launch(p: &mut Panel, i: usize, reveal: bool) {
    let Some(hit) = p.hits.get(i).cloned() else { return };
    match hit.kind {
        Kind::Clip => {
            // вернуть запись в буфер; вставим, когда окно спрячется и впереди снова будет прежняя программа
            if clip::restore(p.hwnd, hit.target.parse().unwrap_or(0)) {
                unsafe {
                    SetTimer(Some(p.hwnd), TIMER_PASTE, 120, None);
                }
            }
        }
        Kind::Action => run_action(p.hwnd, &hit.target),
        Kind::Calc => win::set_clipboard_text(p.hwnd, &hit.target),
        Kind::Web | Kind::App | Kind::Setting => shell_open(&hit.target, None),
        Kind::Folder => show_in_finder(&hit.target),
        Kind::File if reveal => show_in_finder(&hit.target),
        Kind::File => shell_open(&hit.target, None),
    }
    if !matches!(hit.kind, Kind::Calc | Kind::Web | Kind::Clip) {
        *p.history.entry(hit.target.clone()).or_insert(0) += 1;
        index::save_history(&p.history);
    }
}

fn clipboard_text(hwnd: HWND) -> Option<String> {
    const CF_UNICODETEXT: u32 = 13;
    unsafe {
        IsClipboardFormatAvailable(CF_UNICODETEXT).ok()?;
        OpenClipboard(Some(hwnd)).ok()?;
        let h = GetClipboardData(CF_UNICODETEXT).ok();
        let text = h.and_then(|h| {
            let g = windows::Win32::Foundation::HGLOBAL(h.0);
            let ptr = GlobalLock(g) as *const u16;
            if ptr.is_null() {
                return None;
            }
            let mut n = 0;
            while *ptr.add(n) != 0 {
                n += 1;
            }
            let s = String::from_utf16_lossy(std::slice::from_raw_parts(ptr, n));
            let _ = GlobalUnlock(g);
            Some(s)
        });
        let _ = CloseClipboard();
        text
    }
}

/// Правка текста запроса; true — запрос изменился
fn edit(p: &mut Panel, vk: VIRTUAL_KEY, ctrl: bool) -> bool {
    let n = p.query.len();
    if p.all && matches!(vk, VK_BACK | VK_DELETE) {
        p.query.clear();
        p.caret = 0;
        p.all = false;
        return true;
    }
    if p.all && matches!(vk, VK_LEFT | VK_RIGHT | VK_HOME | VK_END) {
        p.all = false;
    }
    match vk {
        VK_BACK if p.caret > 0 => {
            // Ctrl+Backspace — слово целиком
            let mut from = p.caret - 1;
            if ctrl {
                while from > 0 && p.query[from - 1] != ' ' {
                    from -= 1;
                }
            }
            p.query.drain(from..p.caret);
            p.caret = from;
            true
        }
        VK_DELETE if p.caret < n => {
            p.query.remove(p.caret);
            true
        }
        VK_LEFT => {
            p.caret = p.caret.saturating_sub(1);
            false
        }
        VK_RIGHT => {
            p.caret = (p.caret + 1).min(n);
            false
        }
        VK_HOME => {
            p.caret = 0;
            false
        }
        VK_END => {
            p.caret = n;
            false
        }
        _ => false,
    }
}

fn insert(p: &mut Panel, text: &str) {
    if p.all {
        p.query.clear();
        p.caret = 0;
        p.all = false;
    }
    for c in text.chars().filter(|c| !c.is_control()) {
        p.query.insert(p.caret, c);
        p.caret += 1;
    }
}

fn row_at(p: &Panel, y: i32) -> Option<usize> {
    let ly = y as f32 / p.s - M;
    let i = ((ly - row_y(0)) / ROW).floor();
    (i >= 0.0 && (i as usize) < p.hits.len()).then_some(i as usize)
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    let ctrl = || GetKeyState(VK_CONTROL.0 as i32) < 0;
    match msg {
        WM_ACTIVATE => {
            // щёлкнули мимо — прячемся, как меню; но сразу после показа фокус может на миг
            // уйти (отпустили Win, «Пуск» передумал открываться) — тогда возвращаем его, а не прячемся
            if (wp.0 & 0xFFFF) as u32 == WA_INACTIVE {
                let fresh = with(|p| p.shown.elapsed().as_millis() < 700).unwrap_or(false);
                if fresh {
                    crate::log("фокус ушёл сразу после показа — возвращаю");
                    let _ = PostMessageW(Some(hwnd), WM_REFOCUS, WPARAM(0), LPARAM(0));
                } else {
                    hide();
                }
            }
            LRESULT(0)
        }
        WM_REFOCUS => {
            force_foreground(hwnd);
            LRESULT(0)
        }
        WM_TIMER if wp.0 == TIMER_PASTE => {
            let _ = KillTimer(Some(hwnd), TIMER_PASTE);
            paste();
            LRESULT(0)
        }
        WM_TIMER if wp.0 == TIMER_CARET => {
            with(|p| {
                p.caret_on = !p.caret_on;
                present(p);
            });
            LRESULT(0)
        }
        WM_THUMB => {
            with(present);
            LRESULT(0)
        }
        WM_CHAR => {
            let c = char::from_u32(wp.0 as u32).unwrap_or('\0');
            if !c.is_control() && !ctrl() {
                with(|p| {
                    insert(p, &c.to_string());
                    refresh(p);
                    p.caret_on = true;
                    present(p);
                });
            }
            LRESULT(0)
        }
        WM_KEYDOWN | WM_SYSKEYDOWN => {
            let vk = VIRTUAL_KEY(wp.0 as u16);
            if vk == VK_ESCAPE {
                hide();
                return LRESULT(0);
            }
            if vk == VK_RETURN {
                let reveal = ctrl() || GetKeyState(VK_MENU.0 as i32) < 0;
                let opened = with(|p| {
                    let i = p.sel;
                    launch(p, i, reveal);
                    !p.hits.is_empty()
                });
                if opened == Some(true) {
                    hide();
                }
                return LRESULT(0);
            }
            with(|p| {
                let n = p.hits.len();
                let changed = match vk {
                    VK_DOWN if n > 0 => {
                        p.sel = (p.sel + 1) % n;
                        false
                    }
                    VK_UP if n > 0 => {
                        p.sel = (p.sel + n - 1) % n;
                        false
                    }
                    VK_TAB if n > 0 => {
                        p.sel = (p.sel + 1) % n;
                        false
                    }
                    VK_A if ctrl() => {
                        p.all = !p.query.is_empty();
                        false
                    }
                    VK_V if ctrl() => {
                        if let Some(t) = clipboard_text(p.hwnd) {
                            insert(p, &t.replace(['\r', '\n'], " "));
                        }
                        true
                    }
                    // Ctrl+1…4 — режимы: приложения, файлы, действия, буфер обмена
                    VK_1 | VK_2 | VK_3 | VK_4 if ctrl() => {
                        set_mode(p, Mode::LIST[(vk.0 - VK_1.0) as usize]);
                        false
                    }
                    VK_C if ctrl() => {
                        let t: String = p.query.iter().collect();
                        win::set_clipboard_text(p.hwnd, &t);
                        false
                    }
                    _ => edit(p, vk, ctrl()),
                };
                if changed {
                    refresh(p);
                }
                p.caret_on = true;
                present(p);
            });
            LRESULT(0)
        }
        WM_MOUSEMOVE => {
            let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, ((lp.0 >> 16) & 0xFFFF) as i16 as i32);
            with(|p| {
                let h = row_at(p, y);
                let m = mode_at(p, x, y);
                if h != p.hover || m != p.hover_mode {
                    p.hover = h;
                    p.hover_mode = m;
                    present(p);
                }
            });
            LRESULT(0)
        }
        WM_LBUTTONUP => {
            let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, ((lp.0 >> 16) & 0xFFFF) as i16 as i32);
            // кнопка режима — переключаем и остаёмся в поиске
            if with(|p| {
                let k = mode_at(p, x, y)?;
                set_mode(p, Mode::LIST[k]);
                present(p);
                Some(())
            })
            .flatten()
            .is_some()
            {
                return LRESULT(0);
            }
            let opened = with(|p| {
                let i = row_at(p, y)?;
                launch(p, i, ctrl());
                Some(())
            })
            .flatten();
            if opened.is_some() {
                hide();
            }
            LRESULT(0)
        }
        WM_MOUSEACTIVATE => LRESULT(MA_ACTIVATE as isize),
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

/// Кадр поиска для проверки вёрстки: mac-spotlight.exe --preview запрос out.png
pub fn preview(query: &str) -> Option<Img> {
    let m = win::monitor_at(win::cursor());
    let fonts = Fonts::load()?;
    let shared: Shared = Default::default();
    *shared.lock().ok()? = index::build_now();
    let mut p = Panel {
        hwnd: HWND::default(),
        s: m.scale,
        fonts,
        query: query.chars().collect(),
        caret: query.chars().count(),
        all: false,
        hits: Vec::new(),
        sel: 0,
        hover: None,
        index: shared,
        history: index::load_history(),
        icons: HashMap::new(),
        pool: Pool::new(HWND::default()),
        work: m.work,
        caret_on: true,
        shown: Instant::now(),
        mode: Mode::All,
        hover_mode: None,
    };
    // «2:отчёт» — сразу в режиме: 1 приложения, 2 файлы, 3 действия, 4 буфер
    if let Some((k, q)) = query.split_once(':').filter(|(k, _)| k.len() == 1) {
        if let Ok(k @ 1..=4) = k.parse::<usize>() {
            p.mode = Mode::LIST[k - 1];
            p.query = q.chars().collect();
            p.caret = p.query.len();
        }
    }
    refresh(&mut p);
    let px = icon_px(&p);
    for hit in &p.hits {
        if let Some(path) = &hit.icon {
            let img = win::small_icon(path, px).or_else(|| win::shell_image(path, px, true));
            p.icons.insert((path.clone(), px), img);
        }
    }
    gfx::use_theme(false);
    let h = height(&p);
    let mut img = Img::new(((W + 2.0 * M) * p.s).ceil() as u32, ((h + 2.0 * M) * p.s).ceil() as u32);
    if let Some(mut pm) = img.pixmap_mut() {
        draw(&p, &mut pm, h);
    }
    Some(img)
}
