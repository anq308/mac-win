//! Раскладка окон с клавиатуры, как Rectangle в macOS: Ctrl+Alt+стрелки — половины экрана
//! (повторное нажатие — ⅔ и ⅓), D/F/G — трети, E/T — две трети, U/I/J/K — четверти,
//! Enter — развернуть, C — по центру, Backspace — вернуть как было, Ctrl+Alt+Win+←/→ — на другой монитор

use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use windows::core::BOOL;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Dwm::{DwmGetWindowAttribute, DWMWA_EXTENDED_FRAME_BOUNDS};
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::WindowsAndMessaging::*;

pub const WM_SNAP: u32 = WM_APP + 10;
pub static ON: AtomicBool = AtomicBool::new(true);
/// съеденная клавиша: её отпускание тоже не пропускаем
static EATEN: AtomicU32 = AtomicU32::new(0);

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum A {
    Left,
    Right,
    Top,
    Bottom,
    Max,
    Center,
    Restore,
    Third(u8),
    TwoThirds(u8),
    Quarter(u8),
    Display(i8),
}

impl A {
    fn code(self) -> usize {
        match self {
            A::Left => 1,
            A::Right => 2,
            A::Top => 3,
            A::Bottom => 4,
            A::Max => 5,
            A::Center => 6,
            A::Restore => 7,
            A::Third(i) => 10 + i as usize,
            A::TwoThirds(i) => 20 + i as usize,
            A::Quarter(i) => 30 + i as usize,
            A::Display(d) => if d > 0 { 40 } else { 41 },
        }
    }

    fn from(c: usize) -> Option<A> {
        Some(match c {
            1 => A::Left,
            2 => A::Right,
            3 => A::Top,
            4 => A::Bottom,
            5 => A::Max,
            6 => A::Center,
            7 => A::Restore,
            10..=12 => A::Third((c - 10) as u8),
            20..=21 => A::TwoThirds((c - 20) as u8),
            30..=33 => A::Quarter((c - 30) as u8),
            40 => A::Display(1),
            41 => A::Display(-1),
            _ => return None,
        })
    }
}

fn held(vk: VIRTUAL_KEY) -> bool {
    unsafe { GetAsyncKeyState(vk.0 as i32) < 0 }
}

/// Из хука клавиатуры. true — клавишу съесть
pub fn on_key(vk: u32, down: bool, target: HWND) -> bool {
    if !down {
        if EATEN.load(Ordering::Relaxed) == vk {
            EATEN.store(0, Ordering::Relaxed);
            return true;
        }
        return false;
    }
    if !ON.load(Ordering::Relaxed) || !held(VK_CONTROL) || !held(VK_MENU) || held(VK_SHIFT) {
        return false;
    }
    let win = held(VK_LWIN) || held(VK_RWIN);
    let a = match (vk, win) {
        (0x25, true) => A::Display(-1),
        (0x27, true) => A::Display(1),
        (_, true) => return false,
        (0x25, _) => A::Left,
        (0x27, _) => A::Right,
        (0x26, _) => A::Top,
        (0x28, _) => A::Bottom,
        (0x0D, _) => A::Max,
        (0x43, _) => A::Center,
        (0x08, _) => A::Restore,
        (0x44, _) => A::Third(0),
        (0x46, _) => A::Third(1),
        (0x47, _) => A::Third(2),
        (0x45, _) => A::TwoThirds(0),
        (0x54, _) => A::TwoThirds(1),
        (0x55, _) => A::Quarter(0),
        (0x49, _) => A::Quarter(1),
        (0x4A, _) => A::Quarter(2),
        (0x4B, _) => A::Quarter(3),
        _ => return false,
    };
    EATEN.store(vk, Ordering::Relaxed);
    unsafe {
        let _ = PostMessageW(Some(target), WM_SNAP, WPARAM(a.code()), LPARAM(0));
    }
    true
}

struct Memory {
    /// размер до первой раскладки — для Ctrl+Alt+Backspace
    original: HashMap<isize, RECT>,
    /// прошлое нажатие: окно, действие, шаг, когда
    last: Option<(isize, A, u8, Instant)>,
}

static MEMORY: Mutex<Option<Memory>> = Mutex::new(None);

fn window_ok(h: HWND) -> bool {
    if h.is_invalid() {
        return false;
    }
    let mut cls = [0u16; 64];
    let n = unsafe { GetClassNameW(h, &mut cls) } as usize;
    let cls = String::from_utf16_lossy(&cls[..n]);
    !matches!(cls.as_str(), "Progman" | "WorkerW" | "Shell_TrayWnd" | "Shell_SecondaryTrayWnd")
}

/// Невидимые края окна (тень в Windows 10/11): их добавляем, чтобы видимая часть встала ровно
fn margins(h: HWND) -> (i32, i32, i32, i32) {
    let mut wr = RECT::default();
    let mut ext = RECT::default();
    unsafe {
        let _ = GetWindowRect(h, &mut wr);
        if DwmGetWindowAttribute(h, DWMWA_EXTENDED_FRAME_BOUNDS, &mut ext as *mut _ as *mut _, std::mem::size_of::<RECT>() as u32).is_err() {
            return (0, 0, 0, 0);
        }
    }
    (ext.left - wr.left, ext.top - wr.top, wr.right - ext.right, wr.bottom - ext.bottom)
}

fn visible_rect(h: HWND) -> RECT {
    let mut r = RECT::default();
    unsafe {
        if DwmGetWindowAttribute(h, DWMWA_EXTENDED_FRAME_BOUNDS, &mut r as *mut _ as *mut _, std::mem::size_of::<RECT>() as u32).is_err() {
            let _ = GetWindowRect(h, &mut r);
        }
    }
    r
}

fn work_of(m: HMONITOR) -> RECT {
    let mut mi = MONITORINFO { cbSize: std::mem::size_of::<MONITORINFO>() as u32, ..Default::default() };
    unsafe {
        let _ = GetMonitorInfoW(m, &mut mi);
    }
    mi.rcWork
}

fn place(h: HWND, r: RECT) {
    let (ml, mt, mr, mb) = margins(h);
    unsafe {
        if IsZoomed(h).as_bool() || IsIconic(h).as_bool() {
            let _ = ShowWindow(h, SW_RESTORE);
        }
        let _ = SetWindowPos(h, None, r.left - ml, r.top - mt, r.right - r.left + ml + mr, r.bottom - r.top + mt + mb, SWP_NOZORDER | SWP_NOACTIVATE);
    }
}

fn monitors() -> Vec<HMONITOR> {
    unsafe extern "system" fn each(m: HMONITOR, _: HDC, _: *mut RECT, lp: LPARAM) -> BOOL {
        (*(lp.0 as *mut Vec<HMONITOR>)).push(m);
        TRUE
    }
    let mut v = Vec::new();
    unsafe {
        let _ = EnumDisplayMonitors(None, None, Some(each), LPARAM(&mut v as *mut _ as isize));
    }
    // слева направо — «следующий монитор» как на столе
    v.sort_by_key(|m| work_of(*m).left);
    v
}

/// Из главного окна: выполнить действие с активным окном
pub fn apply(code: usize) {
    apply_to(unsafe { GetForegroundWindow() }, code);
}

unsafe extern "system" fn def_proc(h: HWND, m: u32, w: WPARAM, l: LPARAM) -> LRESULT {
    DefWindowProcW(h, m, w, l)
}

/// --preview snap-test: своё пустое окно раскладываем всеми способами и сверяем с ожидаемым
pub fn self_test() -> String {
    use windows::core::w;
    let mut out = String::new();
    unsafe {
        let inst = windows::Win32::System::LibraryLoader::GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW { lpfnWndProc: Some(def_proc), hInstance: inst.into(), lpszClassName: w!("MacSpotlight.SnapTest"), ..Default::default() };
        RegisterClassW(&wc);
        let Ok(h) = CreateWindowExW(
            WS_EX_TOOLWINDOW,
            w!("MacSpotlight.SnapTest"),
            w!("проверка раскладки"),
            WS_OVERLAPPEDWINDOW | WS_VISIBLE,
            200,
            200,
            700,
            500,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return "окно не создалось".into();
        };
        let wa = work_of(MonitorFromWindow(h, MONITOR_DEFAULTTONEAREST));
        let (ww, wh) = (wa.right - wa.left, wa.bottom - wa.top);
        out += &format!("рабочая область: {ww}×{wh}\n");
        let cases = [
            (A::Left, "левая половина", (0, 0, ww / 2, wh)),
            (A::Left, "левые ⅔ (повтор)", (0, 0, ww * 2 / 3, wh)),
            (A::Right, "правая половина", (ww - ww / 2, 0, ww, wh)),
            (A::Third(1), "средняя треть", (ww / 3, 0, ww * 2 / 3, wh)),
            (A::Quarter(3), "правая нижняя четверть", (ww / 2, wh / 2, ww, wh)),
            (A::Top, "верхняя половина", (0, 0, ww, wh / 2)),
        ];
        for (a, name, (l, t, r, b)) in cases {
            apply_to(h, a.code());
            let v = visible_rect(h);
            let got = (v.left - wa.left, v.top - wa.top, v.right - wa.left, v.bottom - wa.top);
            let ok = (got.0 - l).abs() <= 2 && (got.1 - t).abs() <= 2 && (got.2 - r).abs() <= 2 && (got.3 - b).abs() <= 2;
            out += &format!("{} {name}: {:?}\n", if ok { "ok " } else { "НЕТ" }, got);
        }
        apply_to(h, A::Restore.code());
        let v = visible_rect(h);
        out += &format!("вернуть как было: {}×{}\n", v.right - v.left, v.bottom - v.top);
        let _ = DestroyWindow(h);
    }
    out
}

fn apply_to(h: HWND, code: usize) {
    let Some(a) = A::from(code) else { return };
    if !window_ok(h) {
        return;
    }
    let mut g = match MEMORY.lock() {
        Ok(g) => g,
        Err(_) => return,
    };
    let mem = g.get_or_insert_with(|| Memory { original: HashMap::new(), last: None });
    let key = h.0 as isize;
    if a == A::Restore {
        if let Some(r) = mem.original.remove(&key) {
            drop(g);
            place(h, r);
        }
        return;
    }
    if !mem.original.contains_key(&key) && unsafe { !IsZoomed(h).as_bool() } {
        mem.original.insert(key, visible_rect(h));
    }
    // повтор того же сочетания: ½ → ⅔ → ⅓
    let step = match mem.last {
        Some((w, la, s, at)) if w == key && la == a && at.elapsed() < Duration::from_secs(2) => (s + 1) % 3,
        _ => 0,
    };
    mem.last = Some((key, a, step, Instant::now()));
    drop(g);
    let m = unsafe { MonitorFromWindow(h, MONITOR_DEFAULTTONEAREST) };
    let wa = work_of(m);
    let (x, y, w, hh) = (wa.left, wa.top, wa.right - wa.left, wa.bottom - wa.top);
    let frac = [0.5, 2.0 / 3.0, 1.0 / 3.0][step as usize];
    let rect = |l: f32, t: f32, r: f32, b: f32| RECT {
        left: x + (w as f32 * l).round() as i32,
        top: y + (hh as f32 * t).round() as i32,
        right: x + (w as f32 * r).round() as i32,
        bottom: y + (hh as f32 * b).round() as i32,
    };
    let target = match a {
        A::Left => rect(0.0, 0.0, frac, 1.0),
        A::Right => rect(1.0 - frac, 0.0, 1.0, 1.0),
        A::Top => rect(0.0, 0.0, 1.0, frac),
        A::Bottom => rect(0.0, 1.0 - frac, 1.0, 1.0),
        A::Third(i) => rect(i as f32 / 3.0, 0.0, (i + 1) as f32 / 3.0, 1.0),
        A::TwoThirds(0) => rect(0.0, 0.0, 2.0 / 3.0, 1.0),
        A::TwoThirds(_) => rect(1.0 / 3.0, 0.0, 1.0, 1.0),
        A::Quarter(i) => {
            let (cx, cy) = ((i % 2) as f32 / 2.0, (i / 2) as f32 / 2.0);
            rect(cx, cy, cx + 0.5, cy + 0.5)
        }
        A::Max => {
            unsafe {
                let _ = ShowWindow(h, SW_MAXIMIZE);
            }
            return;
        }
        A::Center => {
            let cur = visible_rect(h);
            let (cw, ch) = ((cur.right - cur.left).min(w), (cur.bottom - cur.top).min(hh));
            RECT { left: x + (w - cw) / 2, top: y + (hh - ch) / 2, right: x + (w + cw) / 2, bottom: y + (hh + ch) / 2 }
        }
        A::Display(d) => {
            let list = monitors();
            let Some(i) = list.iter().position(|mm| *mm == m) else { return };
            if list.len() < 2 {
                return;
            }
            let next = list[(i as i32 + d as i32).rem_euclid(list.len() as i32) as usize];
            let to = work_of(next);
            let zoomed = unsafe { IsZoomed(h).as_bool() };
            let cur = if zoomed { wa } else { visible_rect(h) };
            // то же место в долях экрана
            let kx = (to.right - to.left) as f32 / w as f32;
            let ky = (to.bottom - to.top) as f32 / hh as f32;
            let r = RECT {
                left: to.left + ((cur.left - x) as f32 * kx) as i32,
                top: to.top + ((cur.top - y) as f32 * ky) as i32,
                right: to.left + ((cur.right - x) as f32 * kx) as i32,
                bottom: to.top + ((cur.bottom - y) as f32 * ky) as i32,
            };
            place(h, r);
            if zoomed {
                unsafe {
                    let _ = ShowWindow(h, SW_MAXIMIZE);
                }
            }
            return;
        }
        A::Restore => return,
    };
    place(h, target);
}
