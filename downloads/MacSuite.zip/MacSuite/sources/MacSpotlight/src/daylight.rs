//! Тема и обои по времени суток: светлая тема днём, тёмная вечером (по восходу и закату в городе
//! или по расписанию), обои «Пейзаж дня» или свои картинки на утро, день, вечер и ночь.
//! Настройки — в %LOCALAPPDATA%\MacSpotlight\settings.txt, их меняет «Центр Mac».

use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;

use windows::core::{w, PCWSTR};
use windows::core::BOOL;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::Registry::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::{scenery, sun};

pub fn dir() -> PathBuf {
    PathBuf::from(std::env::var("LOCALAPPDATA").unwrap_or_default()).join("MacSpotlight")
}

pub fn settings_file() -> PathBuf {
    dir().join("settings.txt")
}

pub fn get(key: &str) -> Option<String> {
    let text = std::fs::read_to_string(settings_file()).ok()?;
    text.lines().find_map(|l| {
        let (k, v) = l.split_once('=')?;
        (k.trim() == key).then(|| v.trim().to_string())
    })
}

/// Поменять одну строку настроек, остальные оставить
pub fn set(key: &str, value: Option<&str>) {
    let text = std::fs::read_to_string(settings_file()).unwrap_or_default();
    let mut lines: Vec<String> = text.lines().filter(|l| l.split_once('=').is_none_or(|(k, _)| k.trim() != key)).map(str::to_string).collect();
    if let Some(v) = value {
        lines.push(format!("{key}={v}"));
    }
    let _ = std::fs::create_dir_all(dir());
    let _ = std::fs::write(settings_file(), lines.join("\n") + "\n");
}

struct State {
    /// последнее применённое «день/ночь»: тему переключаем только на границе, ручную смену не перебиваем
    light: Option<bool>,
    /// когда и при какой высоте солнца рисовали обои в последний раз
    scene: Option<(f64, f32)>,
    /// какую свою картинку поставили
    picture: Option<PathBuf>,
    flip: bool,
}

static STATE: Mutex<State> = Mutex::new(State { light: None, scene: None, picture: None, flip: false });
static RENDERING: AtomicBool = AtomicBool::new(false);

fn now() -> f64 {
    sun::now_unix()
}

/// Сейчас «день»? None — автоматическая тема выключена
fn wanted_light() -> Option<bool> {
    match get("theme").as_deref() {
        Some("sun") => {
            let c = sun::city(&get("city").unwrap_or_default());
            let t = now();
            let (rise, set) = sun::sunrise_sunset(t, c.lat, c.lon);
            Some(match (rise, set) {
                (Some(r), Some(s)) => t >= r && t < s,
                // полярный день или ночь
                _ => sun::elevation(t, c.lat, c.lon) > 0.0,
            })
        }
        Some("time") => {
            let light = get("light").and_then(|s| sun::parse_hm(&s)).unwrap_or(7 * 60);
            let dark = get("dark").and_then(|s| sun::parse_hm(&s)).unwrap_or(20 * 60);
            let m = sun::minutes_now();
            Some(if light <= dark { m >= light && m < dark } else { m >= light || m < dark })
        }
        _ => None,
    }
}

const PERSONALIZE: PCWSTR = w!("Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize");

fn reg_dword(name: PCWSTR) -> Option<u32> {
    let mut v = 0u32;
    let mut size = 4u32;
    unsafe { RegGetValueW(HKEY_CURRENT_USER, PERSONALIZE, name, RRF_RT_REG_DWORD, None, Some(&mut v as *mut u32 as *mut _), Some(&mut size)).ok().ok()? };
    Some(v)
}

fn set_dword(name: PCWSTR, v: u32) {
    unsafe {
        let _ = RegSetKeyValueW(HKEY_CURRENT_USER, PERSONALIZE, name, REG_DWORD.0, Some(&v as *const u32 as *const _), 4);
    }
}

/// Светлая или тёмная тема Windows; панель задач днём светлеет, только если так выбрано
pub fn apply_theme(light: bool) {
    let taskbar = get("taskbar").as_deref() == Some("1");
    set_dword(w!("AppsUseLightTheme"), light as u32);
    set_dword(w!("SystemUsesLightTheme"), (light && taskbar) as u32);
    unsafe {
        let msg: Vec<u16> = "ImmersiveColorSet".encode_utf16().chain(Some(0)).collect();
        let _ = SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, WPARAM(0), LPARAM(msg.as_ptr() as isize), SMTO_ABORTIFHUNG, 300, None);
    }
    crate::log(&format!("тема: {}", if light { "светлая" } else { "тёмная" }));
}

/// Раз в минуту (и при запуске): тема и обои
pub fn tick() {
    if let Some(light) = wanted_light() {
        let changed = STATE.lock().map(|mut s| s.light.replace(light) != Some(light)).unwrap_or(false);
        let current = reg_dword(w!("AppsUseLightTheme")).map(|v| v != 0);
        if changed && current != Some(light) {
            apply_theme(light);
        }
    }
    match get("wall").as_deref() {
        Some("scene") => scene_tick(),
        Some("folder") => folder_tick(),
        _ => restore_wallpaper(),
    }
}

// ---------- обои ----------

fn largest_monitor() -> (u32, u32) {
    unsafe extern "system" fn each(m: HMONITOR, _: HDC, _: *mut RECT, lp: LPARAM) -> BOOL {
        let mut mi = MONITORINFO { cbSize: std::mem::size_of::<MONITORINFO>() as u32, ..Default::default() };
        if GetMonitorInfoW(m, &mut mi).as_bool() {
            let best = &mut *(lp.0 as *mut (u32, u32));
            let (w, h) = ((mi.rcMonitor.right - mi.rcMonitor.left) as u32, (mi.rcMonitor.bottom - mi.rcMonitor.top) as u32);
            if w * h > best.0 * best.1 {
                *best = (w, h);
            }
        }
        TRUE
    }
    let mut best = (0u32, 0u32);
    unsafe {
        let _ = EnumDisplayMonitors(None, None, Some(each), LPARAM(&mut best as *mut _ as isize));
    }
    if best.0 == 0 {
        (1920, 1080)
    } else {
        best
    }
}

fn current_wallpaper() -> Option<PathBuf> {
    let mut buf = [0u16; 520];
    unsafe {
        SystemParametersInfoW(SPI_GETDESKWALLPAPER, buf.len() as u32, Some(buf.as_mut_ptr() as *mut _), SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS(0)).ok()?;
    }
    let n = buf.iter().position(|c| *c == 0).unwrap_or(0);
    let s = String::from_utf16_lossy(&buf[..n]);
    (!s.is_empty()).then(|| PathBuf::from(s))
}

fn desktop_value(name: &str) -> Option<String> {
    let (k, n) = (wide("Control Panel\\Desktop"), wide(name));
    let mut buf = [0u16; 64];
    let mut size = (buf.len() * 2) as u32;
    unsafe {
        RegGetValueW(HKEY_CURRENT_USER, PCWSTR(k.as_ptr()), PCWSTR(n.as_ptr()), RRF_RT_REG_SZ, None, Some(buf.as_mut_ptr() as *mut _), Some(&mut size)).ok().ok()?;
    }
    let n = buf.iter().position(|c| *c == 0).unwrap_or(0);
    Some(String::from_utf16_lossy(&buf[..n]))
}

fn set_desktop_value(name: &str, v: &str) {
    let (k, n, d) = (wide("Control Panel\\Desktop"), wide(name), wide(v));
    unsafe {
        let _ = RegSetKeyValueW(HKEY_CURRENT_USER, PCWSTR(k.as_ptr()), PCWSTR(n.as_ptr()), REG_SZ.0, Some(d.as_ptr() as *const _), (d.len() * 2) as u32);
    }
}

fn wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(Some(0)).collect()
}

/// Перед первой сменой запоминаем обои человека, чтобы вернуть их, когда функцию выключат
fn backup_wallpaper() {
    if get("wall_prev").is_some() {
        return;
    }
    let style = desktop_value("WallpaperStyle").unwrap_or_else(|| "10".into());
    let tile = desktop_value("TileWallpaper").unwrap_or_else(|| "0".into());
    let saved = current_wallpaper().and_then(|p| {
        let ext = p.extension().map(|e| e.to_string_lossy().to_string()).unwrap_or_else(|| "jpg".into());
        let to = dir().join("wallpaper").join(format!("original.{ext}"));
        let _ = std::fs::create_dir_all(to.parent()?);
        std::fs::copy(&p, &to).ok().map(|_| to)
    });
    set("wall_prev", Some(&saved.map(|p| p.display().to_string()).unwrap_or_default()));
    set("wall_prev_style", Some(&format!("{style},{tile}")));
}

fn set_wallpaper(p: &Path, fill: bool) {
    if fill {
        set_desktop_value("WallpaperStyle", "10");
        set_desktop_value("TileWallpaper", "0");
    }
    let w = wide(&p.display().to_string());
    unsafe {
        let _ = SystemParametersInfoW(SPI_SETDESKWALLPAPER, 0, Some(w.as_ptr() as *mut _), SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
    }
}

/// Функцию выключили — возвращаем то, что было до нас
fn restore_wallpaper() {
    let Some(prev) = get("wall_prev") else { return };
    if let Some((style, tile)) = get("wall_prev_style").as_deref().and_then(|s| s.split_once(',')) {
        set_desktop_value("WallpaperStyle", style);
        set_desktop_value("TileWallpaper", tile);
    }
    if !prev.is_empty() && Path::new(&prev).exists() {
        set_wallpaper(Path::new(&prev), false);
    }
    set("wall_prev", None);
    set("wall_prev_style", None);
    if let Ok(mut s) = STATE.lock() {
        s.scene = None;
        s.picture = None;
    }
    crate::log("обои: вернул прежние");
}

fn scene_tick() {
    let c = sun::city(&get("city").unwrap_or_default());
    let t = now();
    let e = sun::elevation(t, c.lat, c.lon) as f32;
    // перерисовываем, когда солнце заметно сдвинулось, и не реже раза в 20 минут
    let due = STATE.lock().map(|s| s.scene.is_none_or(|(at, le)| (e - le).abs() > 1.5 || t - at > 1200.0)).unwrap_or(false);
    if !due || RENDERING.swap(true, Ordering::SeqCst) {
        return;
    }
    backup_wallpaper();
    let flip = STATE
        .lock()
        .map(|mut s| {
            s.flip = !s.flip;
            s.flip
        })
        .unwrap_or(false);
    let (lat, lon) = (c.lat, c.lon);
    std::thread::spawn(move || {
        let (w, h) = largest_monitor();
        let img = scenery::at(w, h, t, lat, lon);
        let path = dir().join("wallpaper").join(if flip { "scene-a.png" } else { "scene-b.png" });
        let _ = std::fs::create_dir_all(path.parent().unwrap_or(Path::new(".")));
        if let Some(png) = crate::win::encode_png(&img) {
            if std::fs::write(&path, png).is_ok() {
                set_wallpaper(&path, true);
                if let Ok(mut s) = STATE.lock() {
                    s.scene = Some((t, e));
                }
            }
        }
        RENDERING.store(false, Ordering::SeqCst);
    });
}

/// Своя папка: картинки с «утро», «день», «вечер», «ночь» в имени — по времени суток, иначе по кругу
pub fn pick_picture(folder: &Path, e: f32, evening: bool, minutes: u32) -> Option<PathBuf> {
    let mut files: Vec<PathBuf> = std::fs::read_dir(folder)
        .ok()?
        .flatten()
        .map(|e| e.path())
        .filter(|p| p.extension().is_some_and(|x| matches!(x.to_string_lossy().to_lowercase().as_str(), "jpg" | "jpeg" | "png" | "bmp")))
        .collect();
    files.sort();
    if files.is_empty() {
        return None;
    }
    let part = if e < -6.0 {
        ["ночь", "night"]
    } else if e < 12.0 && !evening {
        ["утро", "morning"]
    } else if e < 12.0 {
        ["вечер", "evening"]
    } else {
        ["день", "day"]
    };
    let named = files.iter().find(|p| {
        let n = p.file_stem().map(|s| s.to_string_lossy().to_lowercase()).unwrap_or_default();
        part.iter().any(|w| n.contains(w))
    });
    named.cloned().or_else(|| files.get((minutes as usize * files.len() / 1440).min(files.len() - 1)).cloned())
}

fn folder_tick() {
    let Some(folder) = get("wall_dir") else { return };
    let c = sun::city(&get("city").unwrap_or_default());
    let t = now();
    let e = sun::elevation(t, c.lat, c.lon) as f32;
    let evening = sun::elevation(t + 600.0, c.lat, c.lon) < e as f64;
    let Some(p) = pick_picture(Path::new(&folder), e, evening, sun::minutes_now()) else { return };
    let same = STATE.lock().map(|s| s.picture.as_ref() == Some(&p)).unwrap_or(false);
    if same {
        return;
    }
    backup_wallpaper();
    set_wallpaper(&p, true);
    if let Ok(mut s) = STATE.lock() {
        s.picture = Some(p);
    }
}

/// --preview day-test out.txt [кадр.png]: город, восход и закат, что выбрано, скорость отрисовки обоев
pub fn self_test(frame: Option<&Path>) -> String {
    let c = sun::city(&get("city").unwrap_or_default());
    let t = now();
    let (rise, set) = sun::sunrise_sunset(t, c.lat, c.lon);
    let mut out = format!(
        "город: {} (пояс UTC{:+}), восход {}, закат {}, солнце сейчас {:.1}°\n",
        c.name,
        sun::tz_minutes() / 60,
        rise.map(sun::clock).unwrap_or_else(|| "—".into()),
        set.map(sun::clock).unwrap_or_else(|| "—".into()),
        sun::elevation(t, c.lat, c.lon)
    );
    out += &format!("тема: {:?}, сейчас «день»: {:?}, обои: {:?}\n", get("theme"), wanted_light(), get("wall"));
    let (w, h) = largest_monitor();
    let started = std::time::Instant::now();
    let img = scenery::at(w, h, t, c.lat, c.lon);
    let drawn = started.elapsed();
    let png = crate::win::encode_png(&img);
    out += &format!("обои {w}×{h}: рисование {} мс, всего с PNG {} мс\n", drawn.as_millis(), started.elapsed().as_millis());
    if let (Some(f), Some(png)) = (frame, png) {
        let _ = std::fs::write(f, png);
    }
    out
}
