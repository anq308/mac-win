//! Исправление раскладки: набрали «ghbdtn» — Pause или Shift дважды — стало «привет».
//! Хук запоминает последние нажатия в текущем поле (только в памяти, на диск ничего не пишется),
//! по сочетанию стираем напечатанное и печатаем те же клавиши в другой раскладке, а раскладку окна переключаем.
//! Shift+Pause — то же для выделенного текста.

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;
use std::time::{Duration, Instant};

use windows::core::HSTRING;
use windows::Win32::Foundation::*;
use windows::Win32::Globalization::*;
use windows::Win32::System::Com::*;
use windows::Win32::System::DataExchange::*;
use windows::Win32::System::Memory::*;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::WindowsAndMessaging::*;

pub const WM_FIX: u32 = WM_APP + 6;

/// Включено ли исправление (меню в трее)
pub static ON: AtomicBool = AtomicBool::new(true);
/// Идёт исправление: свои же нажатия и буфер обмена не трогаем
static BUSY: AtomicBool = AtomicBool::new(false);

#[derive(Clone, Copy)]
struct Key {
    vk: u16,
    scan: u16,
    shift: bool,
    caps: bool,
    hkl: isize,
}

struct Typed {
    keys: Vec<Key>,
    window: isize,
}

static TYPED: Mutex<Typed> = Mutex::new(Typed { keys: Vec::new(), window: 0 });

/// Двойное нажатие Shift: когда отпустили в прошлый раз и было ли между ними что-то ещё
struct Taps {
    down: Option<Instant>,
    other: bool,
    last: Option<Instant>,
}

static TAPS: Mutex<Taps> = Mutex::new(Taps { down: None, other: false, last: None });

const LIMIT: usize = 300;

fn held(vk: VIRTUAL_KEY) -> bool {
    unsafe { GetAsyncKeyState(vk.0 as i32) < 0 }
}

/// Клавиши, которые печатают символ (буквы, цифры, знаки, пробел, цифровой блок)
fn printable(vk: u32) -> bool {
    matches!(vk, 0x20 | 0x30..=0x39 | 0x41..=0x5A | 0x60..=0x6F | 0xBA..=0xC0 | 0xDB..=0xDF | 0xE2)
}

fn clear() {
    if let Ok(mut t) = TYPED.lock() {
        t.keys.clear();
    }
}

/// Вызывается хуком на каждое настоящее (не программное) нажатие. true — клавишу съесть
pub fn on_key(vk: u32, scan: u32, down: bool, target: HWND) -> bool {
    if !ON.load(Ordering::Relaxed) {
        return false;
    }
    let shift_key = matches!(vk, 0x10 | 0xA0 | 0xA1);
    if let Ok(mut t) = TAPS.lock() {
        if shift_key {
            if down {
                if t.down.is_none() {
                    t.down = Some(Instant::now());
                    t.other = false;
                }
            } else if let Some(d) = t.down.take() {
                let tap = !t.other && d.elapsed() < Duration::from_millis(300);
                if tap && t.last.is_some_and(|l| l.elapsed() < Duration::from_millis(450)) {
                    t.last = None;
                    if !fullscreen() {
                        unsafe {
                            let _ = PostMessageW(Some(target), WM_FIX, WPARAM(0), LPARAM(0));
                        }
                    }
                } else {
                    t.last = tap.then(Instant::now);
                }
            }
        } else if down {
            t.other = true;
            t.last = None;
        }
    }
    // в игре на весь экран Pause — её собственная клавиша, а набранное там — не текст
    if vk == VK_PAUSE.0 as u32 && !fullscreen() {
        if down && !BUSY.load(Ordering::Relaxed) {
            let sel = held(VK_SHIFT);
            unsafe {
                let _ = PostMessageW(Some(target), WM_FIX, WPARAM(sel as usize), LPARAM(0));
            }
        }
        return true;
    }
    if !down || BUSY.load(Ordering::Relaxed) {
        return false;
    }
    match vk {
        // сами по себе модификаторы и Caps Lock набор не прерывают
        0x10 | 0x11 | 0x12 | 0x14 | 0x5B | 0x5C | 0xA0..=0xA5 => return false,
        _ => {}
    }
    let Ok(mut t) = TYPED.lock() else { return false };
    let fg = unsafe { GetForegroundWindow() };
    if t.window != fg.0 as isize {
        t.keys.clear();
        t.window = fg.0 as isize;
    }
    let combo = held(VK_CONTROL) || held(VK_MENU) || held(VK_LWIN) || held(VK_RWIN);
    if combo {
        t.keys.clear();
    } else if vk == VK_BACK.0 as u32 {
        t.keys.pop();
    } else if printable(vk) {
        if t.keys.len() >= LIMIT {
            t.keys.remove(0);
        }
        let hkl = unsafe { GetKeyboardLayout(GetWindowThreadProcessId(fg, None)) };
        let caps = unsafe { GetKeyState(VK_CAPITAL.0 as i32) } & 1 != 0;
        t.keys.push(Key { vk: vk as u16, scan: scan as u16, shift: held(VK_SHIFT), caps, hkl: hkl.0 as isize });
    } else {
        // Enter, Tab, стрелки, Home, Delete и прочее — курсор ушёл, старый набор уже не тот
        t.keys.clear();
    }
    false
}

/// Раз в несколько десятков миллисекунд из потока хука: щелчок мышью переносит курсор — набор сбрасываем
pub fn poll_mouse() {
    let empty = TYPED.lock().map_or(true, |t| t.keys.is_empty());
    if !empty && (held(VK_LBUTTON) || held(VK_RBUTTON) || held(VK_MBUTTON)) {
        clear();
    }
}

/// Игра или видео на весь экран: там двойной Shift — это бег или пауза, а не просьба исправить текст
fn fullscreen() -> bool {
    unsafe {
        let fg = GetForegroundWindow();
        if fg.is_invalid() {
            return false;
        }
        let mut cls = [0u16; 64];
        let n = GetClassNameW(fg, &mut cls) as usize;
        let cls = String::from_utf16_lossy(&cls[..n]);
        if cls == "Progman" || cls == "WorkerW" {
            return false;
        }
        let mut r = RECT::default();
        let _ = GetWindowRect(fg, &mut r);
        let m = windows::Win32::Graphics::Gdi::MonitorFromWindow(fg, windows::Win32::Graphics::Gdi::MONITOR_DEFAULTTONEAREST);
        let mut mi = windows::Win32::Graphics::Gdi::MONITORINFO {
            cbSize: std::mem::size_of::<windows::Win32::Graphics::Gdi::MONITORINFO>() as u32,
            ..Default::default()
        };
        let _ = windows::Win32::Graphics::Gdi::GetMonitorInfoW(m, &mut mi);
        let s = mi.rcMonitor;
        r.left <= s.left && r.top <= s.top && r.right >= s.right && r.bottom >= s.bottom
    }
}

// ---------- исправление ----------

/// Из окна: Pause / Shift дважды (selection = false) или Shift+Pause (selection = true)
pub fn fix(selection: bool) {
    if BUSY.swap(true, Ordering::SeqCst) {
        return;
    }
    std::thread::spawn(move || {
        unsafe {
            let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
        }
        // пока зажаты Shift, Ctrl или Alt, наши нажатия превратились бы в сочетания
        let t = Instant::now();
        while (held(VK_SHIFT) || held(VK_CONTROL) || held(VK_MENU)) && t.elapsed() < Duration::from_millis(1500) {
            std::thread::sleep(Duration::from_millis(15));
        }
        if selection {
            fix_selection();
        } else {
            fix_typed();
        }
        // программы успевают обработать введённое до того, как хук снова начнёт запоминать
        std::thread::sleep(Duration::from_millis(60));
        BUSY.store(false, Ordering::SeqCst);
    });
}

fn chars(k: &Key, hkl: isize) -> String {
    let mut state = [0u8; 256];
    if k.shift {
        state[VK_SHIFT.0 as usize] = 0x80;
        state[VK_LSHIFT.0 as usize] = 0x80;
    }
    if k.caps {
        state[VK_CAPITAL.0 as usize] = 0x01;
    }
    let mut buf = [0u16; 8];
    // 4 — не трогать состояние «мёртвых» клавиш системы
    let n = unsafe { ToUnicodeEx(k.vk as u32, k.scan as u32, &state, &mut buf, 4, Some(HKL(hkl as *mut _))) };
    if n > 0 {
        String::from_utf16_lossy(&buf[..n as usize])
    } else {
        String::new()
    }
}

fn layouts() -> Vec<isize> {
    unsafe {
        let n = GetKeyboardLayoutList(None).max(0) as usize;
        let mut list = vec![HKL::default(); n];
        let n = GetKeyboardLayoutList(Some(&mut list)).max(0) as usize;
        list.truncate(n);
        list.into_iter().map(|h| h.0 as isize).collect()
    }
}

/// Раскладка, в которую переводим: другой язык; если их больше двух — та, что встречалась в наборе последней
fn other_layout(src: isize, hint: &[isize]) -> Option<isize> {
    let list = layouts();
    let lang = |h: isize| h & 0xFFFF;
    if let Some(h) = hint.iter().rev().find(|h| lang(**h) != lang(src) && list.contains(h)) {
        return Some(*h);
    }
    list.iter().copied().find(|h| lang(*h) != lang(src))
}

/// Проверка орфографии Windows для языка раскладки — чтобы не переделывать слова, набранные правильно
struct Speller(Option<ISpellChecker>);

impl Speller {
    fn new(hkl: isize) -> Speller {
        let mut name = [0u16; 85];
        let n = unsafe { LCIDToLocaleName((hkl & 0xFFFF) as u32, Some(&mut name), 0) };
        if n <= 1 {
            return Speller(None);
        }
        let tag = HSTRING::from_wide(&name[..n as usize - 1]);
        let checker = unsafe {
            CoCreateInstance::<_, ISpellCheckerFactory>(&SpellCheckerFactory, None, CLSCTX_INPROC_SERVER).ok().and_then(|f| {
                if f.IsSupported(&tag).is_ok_and(|b| b.as_bool()) {
                    f.CreateSpellChecker(&tag).ok()
                } else {
                    None
                }
            })
        };
        Speller(checker)
    }

    /// Слово есть в словаре. Без словаря — «не знаю», считаем, что нет
    fn knows(&self, word: &str) -> bool {
        let Some(c) = &self.0 else { return false };
        let w = word.trim_matches(|ch: char| !ch.is_alphanumeric());
        if w.is_empty() || !w.chars().any(char::is_alphabetic) {
            return false;
        }
        unsafe {
            let Ok(errors) = c.Check(&HSTRING::from(w)) else { return false };
            let mut e = None;
            errors.Next(&mut e) == S_FALSE
        }
    }
}

/// Сколько слов с конца переделывать: последнее — всегда, а предыдущие — пока не встретится слово,
/// набранное правильно (есть в словаре своей раскладки, а в другой раскладке получается ерунда)
fn first_wrong(run: &[Key], src: isize, dst: isize) -> usize {
    let mut words: Vec<(usize, usize)> = Vec::new();
    let mut start = None;
    for (i, k) in run.iter().enumerate() {
        let space = k.vk == 0x20;
        match (space, start) {
            (false, None) => start = Some(i),
            (true, Some(s)) => {
                words.push((s, i));
                start = None;
            }
            _ => {}
        }
    }
    if let Some(s) = start {
        words.push((s, run.len()));
    }
    let Some(last) = words.last() else { return 0 };
    let mut begin = last.0;
    if words.len() == 1 {
        return begin;
    }
    let (a, b) = (Speller::new(src), Speller::new(dst));
    for &(s, e) in words.iter().rev().skip(1) {
        let typed: String = run[s..e].iter().map(|k| chars(k, src)).collect();
        let other: String = run[s..e].iter().map(|k| chars(k, dst)).collect();
        if a.knows(&typed) && !b.knows(&other) {
            break;
        }
        begin = s;
    }
    begin
}

/// Что исправить: (сколько символов стереть, что напечатать, начало в наборе, раскладка)
fn plan(keys: &[Key]) -> Option<(usize, String, usize, isize)> {
    let src = keys.last()?.hkl;
    let hint: Vec<isize> = keys.iter().map(|k| k.hkl).collect();
    let dst = other_layout(src, &hint)?;
    let start = keys.iter().rposition(|k| k.hkl != src).map_or(0, |i| i + 1);
    let from = start + first_wrong(&keys[start..], src, dst);
    let part = &keys[from..];
    let typed: String = part.iter().map(|k| chars(k, src)).collect();
    let fixed: String = part.iter().map(|k| chars(k, dst)).collect();
    Some((typed.encode_utf16().count(), fixed, from, dst))
}

fn fix_typed() {
    let fg = unsafe { GetForegroundWindow() };
    let keys = match TYPED.lock() {
        Ok(t) if t.window == fg.0 as isize => t.keys.clone(),
        _ => return,
    };
    let Some((erase, text, from, dst)) = plan(&keys) else {
        return;
    };
    switch_layout(fg, dst);
    if erase > 0 {
        let mut inputs = Vec::new();
        for _ in 0..erase {
            inputs.push(vk_input(VK_BACK, false));
            inputs.push(vk_input(VK_BACK, true));
        }
        push_text(&mut inputs, &text);
        send(&inputs);
    }
    // в наборе теперь другая раскладка: повторное нажатие вернёт как было
    if let Ok(mut t) = TYPED.lock() {
        if t.window == fg.0 as isize && t.keys.len() == keys.len() {
            for k in &mut t.keys[from..] {
                k.hkl = dst;
            }
        }
    }
}

/// Перевод готового текста: направление — по тому, букв какой раскладки в нём больше
fn convert_text(text: &str) -> Option<(String, isize)> {
    let list = layouts();
    let owner = |c: char| -> Option<isize> {
        if !c.is_alphabetic() {
            return None;
        }
        let mut found = list.iter().filter(|h| unsafe { VkKeyScanExW(c as u16, HKL(**h as *mut _)) } != -1);
        let first = found.next().copied();
        // буква должна быть только в одной раскладке
        if found.next().is_some() {
            None
        } else {
            first
        }
    };
    let mut votes: Vec<(isize, usize)> = Vec::new();
    for c in text.chars().filter_map(owner) {
        match votes.iter_mut().find(|v| v.0 == c) {
            Some(v) => v.1 += 1,
            None => votes.push((c, 1)),
        }
    }
    let src = votes.iter().max_by_key(|v| v.1)?.0;
    let dst = other_layout(src, &[])?;
    let out = text
        .chars()
        .map(|c| {
            let r = if (c as u32) < 0x10000 { unsafe { VkKeyScanExW(c as u16, HKL(src as *mut _)) } } else { -1 };
            // -1 — нет такой клавиши; Ctrl или Alt в сочетании — не переводим
            if r == -1 || (r >> 8) & 6 != 0 {
                return c.to_string();
            }
            let vk = (r & 0xFF) as u16;
            let scan = unsafe { MapVirtualKeyExW(vk as u32, MAPVK_VK_TO_VSC, Some(HKL(src as *mut _))) } as u16;
            let k = Key { vk, scan, shift: (r >> 8) & 1 != 0, caps: false, hkl: src };
            let s = chars(&k, dst);
            if s.is_empty() {
                c.to_string()
            } else {
                s
            }
        })
        .collect();
    Some((out, dst))
}

fn fix_selection() {
    let fg = unsafe { GetForegroundWindow() };
    let saved = clipboard_text();
    let seq = unsafe { GetClipboardSequenceNumber() };
    crate::clip::quiet(Duration::from_millis(1500));
    send(&[vk_input(VK_CONTROL, false), vk_input(VK_C, false), vk_input(VK_C, true), vk_input(VK_CONTROL, true)]);
    let t = Instant::now();
    while unsafe { GetClipboardSequenceNumber() } == seq && t.elapsed() < Duration::from_millis(700) {
        std::thread::sleep(Duration::from_millis(15));
    }
    if unsafe { GetClipboardSequenceNumber() } == seq {
        return; // ничего не выделено
    }
    std::thread::sleep(Duration::from_millis(30));
    let text = clipboard_text();
    // вернуть, что лежало в буфере до нас (если там был текст)
    if let Some(s) = saved {
        set_clipboard_text(&s);
    }
    let Some(text) = text.filter(|t| !t.is_empty() && t.chars().count() <= 3000) else { return };
    let Some((out, dst)) = convert_text(&text) else { return };
    switch_layout(fg, dst);
    let mut inputs = Vec::new();
    push_text(&mut inputs, &out);
    send(&inputs);
    clear();
}

// ---------- ввод ----------

fn vk_input(vk: VIRTUAL_KEY, up: bool) -> INPUT {
    INPUT {
        r#type: INPUT_KEYBOARD,
        Anonymous: INPUT_0 { ki: KEYBDINPUT { wVk: vk, dwFlags: if up { KEYEVENTF_KEYUP } else { KEYBD_EVENT_FLAGS(0) }, ..Default::default() } },
    }
}

fn push_text(inputs: &mut Vec<INPUT>, text: &str) {
    for c in text.replace("\r\n", "\n").chars() {
        if c == '\n' {
            inputs.push(vk_input(VK_RETURN, false));
            inputs.push(vk_input(VK_RETURN, true));
            continue;
        }
        let mut buf = [0u16; 2];
        for u in c.encode_utf16(&mut buf) {
            for up in [false, true] {
                let flags = if up { KEYEVENTF_UNICODE | KEYEVENTF_KEYUP } else { KEYEVENTF_UNICODE };
                inputs.push(INPUT {
                    r#type: INPUT_KEYBOARD,
                    Anonymous: INPUT_0 { ki: KEYBDINPUT { wScan: *u, dwFlags: flags, ..Default::default() } },
                });
            }
        }
    }
}

fn send(inputs: &[INPUT]) {
    if !inputs.is_empty() {
        unsafe {
            SendInput(inputs, std::mem::size_of::<INPUT>() as i32);
        }
    }
}

/// Попросить окно сменить раскладку — так же, как это делает сама Windows по Alt+Shift
fn switch_layout(fg: HWND, hkl: isize) {
    unsafe {
        let mut gti = GUITHREADINFO { cbSize: std::mem::size_of::<GUITHREADINFO>() as u32, ..Default::default() };
        let tid = GetWindowThreadProcessId(fg, None);
        let target = if GetGUIThreadInfo(tid, &mut gti).is_ok() && !gti.hwndFocus.is_invalid() { gti.hwndFocus } else { fg };
        let _ = PostMessageW(Some(target), WM_INPUTLANGCHANGEREQUEST, WPARAM(0), LPARAM(hkl));
    }
}

// ---------- буфер обмена ----------

const CF_UNICODETEXT: u32 = 13;

fn clipboard_text() -> Option<String> {
    unsafe {
        for _ in 0..10 {
            if OpenClipboard(None).is_ok() {
                let mut out = None;
                if let Ok(h) = GetClipboardData(CF_UNICODETEXT) {
                    let g = HGLOBAL(h.0);
                    let p = GlobalLock(g) as *const u16;
                    if !p.is_null() {
                        let mut n = 0;
                        while *p.add(n) != 0 {
                            n += 1;
                        }
                        out = Some(String::from_utf16_lossy(std::slice::from_raw_parts(p, n)));
                        let _ = GlobalUnlock(g);
                    }
                }
                let _ = CloseClipboard();
                return out;
            }
            std::thread::sleep(Duration::from_millis(20));
        }
        None
    }
}

fn set_clipboard_text(s: &str) {
    let w: Vec<u16> = s.encode_utf16().chain(Some(0)).collect();
    unsafe {
        for _ in 0..10 {
            if OpenClipboard(None).is_ok() {
                let _ = EmptyClipboard();
                if let Ok(h) = GlobalAlloc(GMEM_MOVEABLE, w.len() * 2) {
                    let p = GlobalLock(h) as *mut u16;
                    if !p.is_null() {
                        std::ptr::copy_nonoverlapping(w.as_ptr(), p, w.len());
                        let _ = GlobalUnlock(h);
                        let _ = SetClipboardData(CF_UNICODETEXT, Some(HANDLE(h.0)));
                    }
                }
                let _ = CloseClipboard();
                return;
            }
            std::thread::sleep(Duration::from_millis(20));
        }
    }
}

// ---------- проверка без клавиатуры ----------

/// --preview layout-test out.txt: набор «как будто напечатали» и что из него получится
pub fn self_test() -> String {
    unsafe {
        let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
    }
    let list = layouts();
    let find = |lang: isize| list.iter().copied().find(|h| h & 0xFFFF == lang);
    let (Some(en), Some(ru)) = (find(0x409), find(0x419)) else {
        return "нет английской или русской раскладки".into();
    };
    // строка, напечатанная в раскладке hkl, — обратно в нажатия
    let typed = |s: &str, hkl: isize| -> Vec<Key> {
        s.chars()
            .filter_map(|c| {
                let r = unsafe { VkKeyScanExW(c as u16, HKL(hkl as *mut _)) };
                (r != -1).then(|| {
                    let vk = (r & 0xFF) as u16;
                    let scan = unsafe { MapVirtualKeyExW(vk as u32, MAPVK_VK_TO_VSC, Some(HKL(hkl as *mut _))) } as u16;
                    Key { vk, scan, shift: (r >> 8) & 1 != 0, caps: false, hkl }
                })
            })
            .collect()
    };
    let mut out = format!("словарь en: {}, ru: {}\n", Speller::new(en).0.is_some(), Speller::new(ru).0.is_some());
    let cases: [(&[(&str, isize)], &str); 6] = [
        (&[("ghbdtn", en)], "привет"),
        (&[("ntrcn yt nfr ljk;ty ,snm", en)], "текст не так должен быть"),
        (&[("I love ghbdtn", en)], "I love привет"),
        (&[("руддщ цщкдв", ru)], "hello world"),
        (&[("привет ", ru), ("rfr ltkf", en)], "привет как дела"),
        (&[("Cvjnhb vjq ajnj", en)], "Смотри мой фото"),
    ];
    for (parts, want) in cases {
        let mut keys = Vec::new();
        let mut shown = String::new();
        for (s, h) in parts {
            keys.extend(typed(s, *h));
            shown.push_str(s);
        }
        let got = match plan(&keys) {
            Some((erase, text, _, _)) => {
                let kept: String = shown.chars().take(shown.chars().count() - erase).collect();
                kept + &text
            }
            None => "—".into(),
        };
        out += &format!("{} «{shown}» → «{got}»\n", if got == want { "ok " } else { "НЕТ" });
    }
    for s in ["Ghbdtn, rfr ltkf?", "Руддщ"] {
        let got = convert_text(s).map(|r| r.0).unwrap_or_default();
        out += &format!("выделение «{s}» → «{got}»\n");
    }
    out
}
