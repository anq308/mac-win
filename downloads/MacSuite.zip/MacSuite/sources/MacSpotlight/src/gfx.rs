use ab_glyph::{point, Font, FontVec, PxScale, ScaleFont};
use tiny_skia::*;

/// Картинка в формате GDI: BGRA, альфа премультиплицирована
#[derive(Clone)]
pub struct Img {
    pub w: u32,
    pub h: u32,
    pub px: Vec<u8>,
}

impl Img {
    pub fn new(w: u32, h: u32) -> Img {
        Img { w, h, px: vec![0; (w * h * 4) as usize] }
    }

    pub fn pixmap(&self) -> Option<PixmapRef<'_>> {
        PixmapRef::from_bytes(&self.px, self.w, self.h)
    }

    pub fn pixmap_mut(&mut self) -> Option<PixmapMut<'_>> {
        PixmapMut::from_bytes(&mut self.px, self.w, self.h)
    }
}

/// Буферы у нас в порядке BGRA, а tiny-skia считает их RGBA — поэтому R и B меняем местами
pub fn rgb(r: u8, g: u8, b: u8, a: f32) -> Color {
    Color::from_rgba8(b, g, r, (a.clamp(0.0, 1.0) * 255.0).round() as u8)
}

pub fn solid(c: Color) -> Paint<'static> {
    let mut p = Paint::default();
    p.set_color(c);
    p.anti_alias = true;
    p
}

pub fn stroke(width: f32) -> Stroke {
    Stroke { width, line_cap: LineCap::Round, line_join: LineJoin::Round, ..Default::default() }
}

/// Углы как в Windows 10 — почти прямые
pub fn rrect(x: f32, y: f32, w: f32, h: f32, r: f32) -> Option<Path> {
    round_rect(x, y, w, h, corner(r, w, h))
}

pub fn round_rect(x: f32, y: f32, w: f32, h: f32, r: f32) -> Option<Path> {
    let r = r.min(w / 2.0).min(h / 2.0).max(0.0);
    let k = r * 0.552_284_8;
    let mut pb = PathBuilder::new();
    pb.move_to(x + r, y);
    pb.line_to(x + w - r, y);
    pb.cubic_to(x + w - r + k, y, x + w, y + r - k, x + w, y + r);
    pb.line_to(x + w, y + h - r);
    pb.cubic_to(x + w, y + h - r + k, x + w - r + k, y + h, x + w - r, y + h);
    pb.line_to(x + r, y + h);
    pb.cubic_to(x + r - k, y + h, x, y + h - r + k, x, y + h - r);
    pb.line_to(x, y + r);
    pb.cubic_to(x, y + r - k, x + r - k, y, x + r, y);
    pb.close();
    pb.finish()
}

pub fn fill_rrect(pm: &mut PixmapMut, x: f32, y: f32, w: f32, h: f32, r: f32, c: Color) {
    if let Some(p) = rrect(x, y, w, h, r) {
        pm.fill_path(&p, &solid(c), FillRule::Winding, Transform::identity(), None);
    }
}

pub fn stroke_rrect(pm: &mut PixmapMut, x: f32, y: f32, w: f32, h: f32, r: f32, width: f32, c: Color) {
    if let Some(p) = rrect(x, y, w, h, r) {
        pm.stroke_path(&p, &solid(c), &stroke(width), Transform::identity(), None);
    }
}

/// Картинка в прямоугольнике (x, y, w, h) со скруглением radius и прозрачностью opacity
pub fn image(pm: &mut PixmapMut, img: &Img, x: f32, y: f32, w: f32, h: f32, radius: f32, opacity: f32) {
    let Some(src) = img.pixmap() else { return };
    let (kx, ky) = (w / img.w as f32, h / img.h as f32);
    let exact = (kx - 1.0).abs() < 0.01 && (ky - 1.0).abs() < 0.01;
    let quality = if exact { FilterQuality::Nearest } else { FilterQuality::Bicubic };
    let paint = Paint {
        shader: Pattern::new(src, SpreadMode::Pad, quality, opacity, Transform::from_row(kx, 0.0, 0.0, ky, x, y)),
        anti_alias: true,
        ..Default::default()
    };
    if let Some(p) = rrect(x, y, w, h, radius) {
        pm.fill_path(&p, &paint, FillRule::Winding, Transform::identity(), None);
    }
}

/// Мягкая тень: размытый прямоугольник, записанный в альфу (цвет чёрный)
pub fn shadow(pm: &mut PixmapMut, x: f32, y: f32, w: f32, h: f32, blur: f32, opacity: f32) {
    let (pw, ph) = (pm.width() as i64, pm.height() as i64);
    // три прохода box blur ≈ гауссово размытие
    let r = (blur / 2.0).max(1.0) as usize;
    let m = 3 * r as i64 + 1;
    let (rx0, ry0) = ((x as i64 - m).max(0), (y as i64 - m).max(0));
    let (rx1, ry1) = (((x + w).ceil() as i64 + m).min(pw), ((y + h).ceil() as i64 + m).min(ph));
    if rx1 <= rx0 || ry1 <= ry0 {
        return;
    }
    let (rw, rh) = ((rx1 - rx0) as usize, (ry1 - ry0) as usize);
    let mut a = vec![0f32; rw * rh];
    let (x0, y0) = ((x.max(0.0) as i64 - rx0).max(0) as usize, (y.max(0.0) as i64 - ry0).max(0) as usize);
    let (x1, y1) = ((((x + w) as i64).min(pw) - rx0).max(0) as usize, (((y + h) as i64).min(ph) - ry0).max(0) as usize);
    for yy in y0..y1.min(rh) {
        a[yy * rw + x0..yy * rw + x1.min(rw)].fill(opacity);
    }
    for _ in 0..3 {
        box_blur(&mut a, rw, rh, r, 1, rw);
        box_blur(&mut a, rh, rw, r, rw, 1);
    }
    let data = pm.data_mut();
    for (j, v) in a.iter().enumerate() {
        let sa = v.clamp(0.0, 1.0);
        if sa <= 0.0 {
            continue;
        }
        let i = (ry0 as usize + j / rw) * pw as usize + rx0 as usize + j % rw;
        let inv = 1.0 - sa;
        let p = &mut data[i * 4..i * 4 + 4];
        p[0] = (p[0] as f32 * inv) as u8;
        p[1] = (p[1] as f32 * inv) as u8;
        p[2] = (p[2] as f32 * inv) as u8;
        p[3] = (sa * 255.0 + p[3] as f32 * inv).round().min(255.0) as u8;
    }
}

fn box_blur(a: &mut [f32], len: usize, lines: usize, r: usize, step: usize, next: usize) {
    let mut line = vec![0f32; len];
    let d = (2 * r + 1) as f32;
    for l in 0..lines {
        let base = l * next;
        for i in 0..len {
            line[i] = a[base + i * step];
        }
        let mut sum: f32 = line.iter().take(r + 1).sum();
        for i in 0..len {
            a[base + i * step] = sum / d;
            if i + r + 1 < len {
                sum += line[i + r + 1];
            }
            if i >= r {
                sum -= line[i - r];
            }
        }
    }
}

pub struct Fonts {
    pub regular: FontVec,
}

impl Fonts {
    pub fn load() -> Option<Fonts> {
        let dir = std::env::var("WINDIR").unwrap_or_else(|_| "C:\\Windows".into());
        let font = match variable_font(400.0) {
            Some(f) => f,
            None => FontVec::try_from_vec(std::fs::read(format!("{dir}\\Fonts\\segoeui.ttf")).ok()?).ok()?,
        };
        Some(Fonts { regular: font })
    }
}

/// PxScale в ab_glyph задаётся по высоте ascent−descent, а нам нужен кегль по em
fn em_scale(font: &FontVec, px: f32) -> PxScale {
    let upm = font.units_per_em().unwrap_or(2048.0);
    PxScale::from(px * font.height_unscaled() / upm)
}

pub fn measure(font: &FontVec, s: &str, px: f32) -> f32 {
    let sf = font.as_scaled(em_scale(font, px));
    let mut w = 0.0;
    let mut prev = None;
    for c in s.chars() {
        let id = sf.glyph_id(c);
        if let Some(p) = prev {
            w += sf.kern(p, id);
        }
        w += sf.h_advance(id);
        prev = Some(id);
    }
    w
}

/// Строка, урезанная с многоточием в конце под ширину max
pub fn fit(font: &FontVec, s: &str, px: f32, max: f32) -> String {
    if measure(font, s, px) <= max {
        return s.to_string();
    }
    let mut chars: Vec<char> = s.chars().collect();
    while !chars.is_empty() {
        chars.pop();
        let t = chars.iter().collect::<String>().trim_end().to_string() + "…";
        if measure(font, &t, px) <= max {
            return t;
        }
    }
    "…".into()
}

/// Многоточие в середине, как в Finder: «длинное_им…ние.png» — расширение остаётся видно
pub fn fit_middle(font: &FontVec, s: &str, px: f32, max: f32) -> String {
    if measure(font, s, px) <= max {
        return s.to_string();
    }
    let chars: Vec<char> = s.chars().collect();
    let n = chars.len();
    for cut in 1..n {
        let head = (n - cut) / 2;
        let tail = n - cut - head;
        let t: String = chars[..head].iter().chain(['…'].iter()).chain(chars[n - tail..].iter()).collect();
        if measure(font, &t, px) <= max {
            return t;
        }
    }
    "…".into()
}

/// Текст с базовой линией в (x, baseline); смешивание src-over по покрытию глифа
pub fn text(pm: &mut PixmapMut, font: &FontVec, s: &str, x: f32, baseline: f32, px: f32, color: Color) {
    let (pw, ph) = (pm.width() as i32, pm.height() as i32);
    let c = color.premultiply();
    let (cr, cg, cb, ca) = (c.red(), c.green(), c.blue(), c.alpha());
    let data = pm.data_mut();
    let scale = em_scale(font, px);
    let sf = font.as_scaled(scale);
    let mut pen = x;
    let mut prev = None;
    for ch in s.chars() {
        let id = sf.glyph_id(ch);
        if let Some(p) = prev {
            pen += sf.kern(p, id);
        }
        let glyph = id.with_scale_and_position(scale, point(pen, baseline));
        if let Some(og) = font.outline_glyph(glyph) {
            let b = og.px_bounds();
            og.draw(|gx, gy, a| {
                let xx = b.min.x as i32 + gx as i32;
                let y = b.min.y as i32 + gy as i32;
                if a <= 0.0 || xx < 0 || xx >= pw || y < 0 || y >= ph {
                    return;
                }
                let a = a.min(1.0);
                let i = ((y * pw + xx) * 4) as usize;
                let sa = ca * a;
                let inv = 1.0 - sa;
                let blend = |dst: u8, src: f32| ((src * a * 255.0) + dst as f32 * inv).round().min(255.0) as u8;
                data[i] = blend(data[i], cr);
                data[i + 1] = blend(data[i + 1], cg);
                data[i + 2] = blend(data[i + 2], cb);
                data[i + 3] = ((sa * 255.0) + data[i + 3] as f32 * inv).round().min(255.0) as u8;
            });
        }
        pen += sf.h_advance(id);
        prev = Some(id);
    }
}

// ---------- тема Windows: цвета, акцент и значки берутся из системы ----------

#[derive(Clone, Copy)]
pub struct Theme {
    pub dark: bool,
    pub accent: (u8, u8, u8),
}

const DEFAULT_THEME: Theme = Theme { dark: true, accent: (0x00, 0x78, 0xD7) };

thread_local! {
    /// тема, которой рисуем прямо сейчас
    static THEME: std::cell::Cell<Theme> = const { std::cell::Cell::new(DEFAULT_THEME) };
    /// (окна программ, панель задач и всплывающие окна) — у Windows они настраиваются отдельно
    static SCHEMES: std::cell::Cell<(Theme, Theme)> = const { std::cell::Cell::new((DEFAULT_THEME, DEFAULT_THEME)) };
    /// системный шрифт значков Windows 10
    static ICONS: Option<FontVec> = {
        let dir = std::env::var("WINDIR").unwrap_or_else(|_| "C:\\Windows".into());
        fluent_icons().or_else(|| std::fs::read(format!("{dir}\\Fonts\\segmdl2.ttf")).ok().and_then(|v| FontVec::try_from_vec(v).ok()))
    };
}

fn reg_dword(path: &str, name: &str) -> Option<u32> {
    use windows::Win32::System::Registry::{RegGetValueW, HKEY_CURRENT_USER, RRF_RT_REG_DWORD};
    let (p, n) = (wide_z(path), wide_z(name));
    let mut v = 0u32;
    let mut size = 4u32;
    let r = unsafe {
        RegGetValueW(
            HKEY_CURRENT_USER,
            windows::core::PCWSTR(p.as_ptr()),
            windows::core::PCWSTR(n.as_ptr()),
            RRF_RT_REG_DWORD,
            None,
            Some(&mut v as *mut u32 as *mut std::ffi::c_void),
            Some(&mut size),
        )
    };
    r.is_ok().then_some(v)
}

fn wide_z(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(Some(0)).collect()
}

/// Перечитать тему и акцент из настроек Windows (при запуске и когда их поменяли)
pub fn load_themes() {
    const KEY: &str = "Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize";
    // AccentColorMenu хранится как 0xAABBGGRR
    let accent = reg_dword("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Accent", "AccentColorMenu")
        .map_or((0x00, 0x78, 0xD7), |v| ((v & 0xFF) as u8, (v >> 8 & 0xFF) as u8, (v >> 16 & 0xFF) as u8));
    let apps = Theme { dark: reg_dword(KEY, "AppsUseLightTheme") == Some(0), accent };
    let system = Theme { dark: reg_dword(KEY, "SystemUsesLightTheme") != Some(1), accent };
    let (apps, system) = fluent_accents(apps, system);
    SCHEMES.with(|s| s.set((apps, system)));
}

/// Рисовать дальше в теме окон программ (apps) или панели задач и всплывающих окон
pub fn use_theme(apps: bool) {
    let (a, s) = SCHEMES.with(|s| s.get());
    THEME.with(|t| t.set(if apps { a } else { s }));
}

pub fn theme() -> Theme {
    THEME.with(|t| t.get())
}

pub fn accent(a: f32) -> Color {
    let (r, g, b) = theme().accent;
    rgb(r, g, b, a)
}

/// «Чернила» темы: белые в тёмной, чёрные в светлой — для текста, линий и подсветки
pub fn white(a: f32) -> Color {
    if theme().dark {
        rgb(0xFF, 0xFF, 0xFF, a)
    } else {
        rgb(0x00, 0x00, 0x00, a)
    }
}

pub fn selected() -> Color {
    if theme().dark {
        rgb(0x4D, 0x4D, 0x4D, 1.0)
    } else {
        rgb(0xCC, 0xE8, 0xFF, 1.0)
    }
}

/// Значок из шрифта Segoe MDL2 Assets, отцентрованный в точке (cx, cy); false — шрифта нет
pub fn glyph(pm: &mut PixmapMut, ch: char, cx: f32, cy: f32, px: f32, color: Color) -> bool {
    ICONS.with(|f| {
        let Some(font) = f else { return false };
        let scale = em_scale(font, px);
        let g = font.glyph_id(ch).with_scale_and_position(scale, point(0.0, 0.0));
        let Some(og) = font.outline_glyph(g) else { return false };
        let b = og.px_bounds();
        let dx = (cx - (b.min.x + b.max.x) / 2.0).round();
        let dy = (cy - (b.min.y + b.max.y) / 2.0).round();
        blit(pm, &og, dx, dy, color);
        true
    })
}

/// Смешивание покрытия глифа с картинкой (src-over)
fn blit(pm: &mut PixmapMut, og: &ab_glyph::OutlinedGlyph, dx: f32, dy: f32, color: Color) {
    let (pw, ph) = (pm.width() as i32, pm.height() as i32);
    let c = color.premultiply();
    let (cr, cg, cb, ca) = (c.red(), c.green(), c.blue(), c.alpha());
    let data = pm.data_mut();
    let b = og.px_bounds();
    og.draw(|gx, gy, a| {
        let xx = (b.min.x + dx) as i32 + gx as i32;
        let y = (b.min.y + dy) as i32 + gy as i32;
        if a <= 0.0 || xx < 0 || xx >= pw || y < 0 || y >= ph {
            return;
        }
        let a = a.min(1.0);
        let i = ((y * pw + xx) * 4) as usize;
        let sa = ca * a;
        let inv = 1.0 - sa;
        let blend = |dst: u8, src: f32| ((src * a * 255.0) + dst as f32 * inv).round().min(255.0) as u8;
        data[i] = blend(data[i], cr);
        data[i + 1] = blend(data[i + 1], cg);
        data[i + 2] = blend(data[i + 2], cb);
        data[i + 3] = ((sa * 255.0) + data[i + 3] as f32 * inv).round().min(255.0) as u8;
    });
}

/// Фон всплывающих панелей, как у меню и флайаутов Windows 10
pub fn surface(a: f32) -> Color {
    if win11() {
        return if theme().dark { rgb(0x2C, 0x2C, 0x2C, a) } else { rgb(0xF9, 0xF9, 0xF9, a) };
    }
    if theme().dark {
        rgb(0x1F, 0x1F, 0x1F, a)
    } else {
        rgb(0xF2, 0xF2, 0xF2, a)
    }
}

// ---------- Windows 11: одна и та же программа сама подстраивается под систему ----------

/// Windows 11 (сборка 22000 и новее). MAC_STYLE=10 или 11 — принудительно, для проверки вёрстки
pub fn win11() -> bool {
    static V: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *V.get_or_init(|| match std::env::var("MAC_STYLE").ok().as_deref() {
        Some("11") => true,
        Some("10") => false,
        _ => windows_build() >= 22000,
    })
}

fn windows_build() -> u32 {
    use windows::Win32::System::Registry::{RegGetValueW, HKEY_LOCAL_MACHINE, RRF_RT_REG_SZ};
    let (p, n) = (wide_z("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"), wide_z("CurrentBuildNumber"));
    let mut buf = [0u16; 32];
    let mut size = 64u32;
    let r = unsafe {
        RegGetValueW(
            HKEY_LOCAL_MACHINE,
            windows::core::PCWSTR(p.as_ptr()),
            windows::core::PCWSTR(n.as_ptr()),
            RRF_RT_REG_SZ,
            None,
            Some(buf.as_mut_ptr() as *mut std::ffi::c_void),
            Some(&mut size),
        )
    };
    if r.is_err() {
        return 0;
    }
    String::from_utf16_lossy(&buf).trim_matches('\0').parse().unwrap_or(0)
}

/// Масштаб экрана: радиусы задаются в пикселях, а скругление должно быть одинаковым на глаз
fn ui_scale() -> f32 {
    static V: std::sync::OnceLock<f32> = std::sync::OnceLock::new();
    *V.get_or_init(|| unsafe { windows::Win32::UI::HiDpi::GetDpiForSystem() }.max(96) as f32 / 96.0)
}

/// Windows 10 — почти прямые углы; Windows 11 — 8 у окон и панелей, 4 у кнопок и строк
fn corner(r: f32, w: f32, h: f32) -> f32 {
    if !win11() {
        return r.min(2.0);
    }
    let k = ui_scale();
    if r > 0.0 {
        r.min(8.0 * k)
    } else if w.min(h) <= 3.0 * k {
        0.0
    } else {
        4.0 * k
    }
}

/// Радиус всплывающей панели (в логических пикселях)
#[allow(dead_code)]
pub fn window_radius() -> f32 {
    if win11() {
        8.0
    } else {
        0.0
    }
}

/// Цвет текста и значков на акцентной заливке: в тёмной теме Windows 11 акцент светлый и текст на нём чёрный
#[allow(dead_code)]
pub fn on_accent(a: f32) -> Color {
    if win11() && theme().dark {
        rgb(0x00, 0x00, 0x00, a * 0.9)
    } else {
        rgb(0xFF, 0xFF, 0xFF, a)
    }
}

fn fonts_dir() -> String {
    std::env::var("MAC_FONT_DIR").unwrap_or_else(|_| std::env::var("WINDIR").unwrap_or_else(|_| "C:\\Windows".into()) + "\\Fonts")
}

/// Segoe UI Variable — шрифт Windows 11, насыщенность задаётся осью wght
pub fn variable_font(weight: f32) -> Option<FontVec> {
    use ab_glyph::VariableFont;
    if !win11() {
        return None;
    }
    let mut f = FontVec::try_from_vec(std::fs::read(format!("{}\\SegUIVar.ttf", fonts_dir())).ok()?).ok()?;
    f.set_variation(b"wght", weight);
    f.set_variation(b"opsz", 10.5);
    Some(f)
}

/// Segoe Fluent Icons — значки Windows 11, коды те же, что у MDL2
fn fluent_icons() -> Option<FontVec> {
    if !win11() {
        return None;
    }
    let d = fonts_dir();
    let data = std::fs::read(format!("{d}\\SegoeIcons.ttf")).or_else(|_| std::fs::read(format!("{d}\\Segoe Fluent Icons.ttf"))).ok()?;
    FontVec::try_from_vec(data).ok()
}

/// Акцент Windows 11: в тёмной теме светлый оттенок из системной палитры, в светлой — тёмный
fn fluent_accents(apps: Theme, system: Theme) -> (Theme, Theme) {
    use windows::Win32::System::Registry::{RegGetValueW, HKEY_CURRENT_USER, RRF_RT_REG_BINARY};
    if !win11() {
        return (apps, system);
    }
    let (p, n) = (wide_z("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Accent"), wide_z("AccentPalette"));
    let mut b = [0u8; 32];
    let mut size = 32u32;
    let ok = unsafe {
        RegGetValueW(
            HKEY_CURRENT_USER,
            windows::core::PCWSTR(p.as_ptr()),
            windows::core::PCWSTR(n.as_ptr()),
            RRF_RT_REG_BINARY,
            None,
            Some(b.as_mut_ptr() as *mut std::ffi::c_void),
            Some(&mut size),
        )
        .is_ok()
    } && size == 32;
    let pick = |dark: bool| {
        let i = if dark { 4 } else { 16 };
        match (ok, dark) {
            (true, _) => (b[i], b[i + 1], b[i + 2]),
            (false, true) => (0x4C, 0xC2, 0xFF),
            (false, false) => (0x00, 0x67, 0xC0),
        }
    };
    (Theme { accent: pick(apps.dark), ..apps }, Theme { accent: pick(system.dark), ..system })
}
