#![windows_subsystem = "windows"]

mod capture;
mod editor;
mod gfx;
mod hook;
mod library;
mod ocr;
mod overlay;
mod thumb;

use std::ffi::c_void;
use std::mem::size_of;

use hook::Shot;
use overlay::{Mode, Pick};
use windows::core::{w, PCWSTR};
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::System::Ole::OleInitialize;
use windows::Win32::System::Registry::*;
use windows::Win32::System::Threading::CreateMutexW;
use windows::Win32::UI::HiDpi::{SetProcessDpiAwarenessContext, DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2};
use windows::Win32::UI::Shell::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use capture::{pcwstr, wide};
use gfx::Img;

const WM_TRAY: u32 = WM_APP + 2;
/// снимок из меню трея откладываем, чтобы само меню успело исчезнуть с экрана
const TIMER_DEFERRED: usize = 1;

const MENU_PANEL: usize = 1;
const MENU_AREA: usize = 2;
const MENU_WINDOW: usize = 3;
const MENU_SCREEN: usize = 4;
const MENU_FOLDER: usize = 5;
const MENU_AUTOSTART: usize = 6;
const MENU_EXIT: usize = 7;
const MENU_LIBRARY: usize = 8;
const MENU_TEXT: usize = 9;

static mut MAIN: HWND = HWND(std::ptr::null_mut());
static mut DEFERRED: usize = 0;
static mut TASKBAR_CREATED: u32 = 0;

fn main_hwnd() -> HWND {
    unsafe { MAIN }
}

fn main() {
    // panic = "abort" не оставляет следов — пишем причину в лог рядом с exe
    std::panic::set_hook(Box::new(|info| {
        if let Ok(exe) = std::env::current_exe() {
            let log = exe.with_file_name("crash.log");
            let line = format!("{:?}: {info}
", std::time::SystemTime::now());
            let _ = std::fs::OpenOptions::new().create(true).append(true).open(log)
                .and_then(|mut f| std::io::Write::write_all(&mut f, line.as_bytes()));
        }
    }));
    unsafe {
        let _ = SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
    }
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.first().map(String::as_str) == Some("--preview") {
        preview(&args[1..]);
        return;
    }
    let want_library = args.first().map(String::as_str) == Some("--library");
    if args.first().map(String::as_str) == Some("--edit") {
        if let Some(p) = args.get(1) {
            unsafe {
                let _ = OleInitialize(None);
            }
            editor::run_file(p.into());
        }
        return;
    }
    unsafe {
        let _ = CreateMutexW(None, true, w!("Local\\MacShot.Instance"));
        if GetLastError() == ERROR_ALREADY_EXISTS {
            // повторный запуск (ярлык, двойной клик по exe) открывает хранилище в уже работающей копии
            if let Ok(main) = FindWindowW(w!("MacShot.Main"), None) {
                let _ = AllowSetForegroundWindow(ASFW_ANY);
                let _ = PostMessageW(Some(main), hook::WM_SHOT, WPARAM(Shot::Library as usize), LPARAM(0));
            }
            return;
        }
        let _ = OleInitialize(None);
    }
    let Some(fonts) = gfx::Fonts::load() else { return };
    gfx::load_themes();
    overlay::init(fonts, finish_pick);
    thumb::init();
    editor::init();
    library::init();

    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacShot.Main"),
            ..Default::default()
        };
        RegisterClassW(&wc);
        let Ok(hwnd) = CreateWindowExW(
            WS_EX_TOOLWINDOW,
            w!("MacShot.Main"),
            w!("MacShot"),
            WS_POPUP,
            0,
            0,
            0,
            0,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        MAIN = hwnd;
        TASKBAR_CREATED = RegisterWindowMessageW(w!("TaskbarCreated"));
        add_tray(hwnd);
        hook::start(hwnd);
        if want_library {
            library::open(None);
        }

        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).as_bool() {
            let _ = TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        remove_tray(hwnd);
    }
}

fn shoot(shot: Shot) {
    match shot {
        Shot::Panel => overlay::open(Mode::Area, true),
        Shot::Area => overlay::open(Mode::Area, false),
        Shot::Window => overlay::open(Mode::Window, true),
        Shot::Library => library::open(None),
        Shot::Text => overlay::open(Mode::Text, false),
        Shot::Screen => {
            overlay::close();
            let m = capture::monitor_at(capture::cursor());
            if let Some(img) = capture::grab(m.rect) {
                finish(img);
            }
        }
    }
}

fn finish_pick(p: Pick) {
    let img = match p {
        Pick::Text(img) => return ocr::start(img, main_hwnd()),
        Pick::Area(img) | Pick::Screen(img) => img,
        Pick::Window { win, fallback, scale, shadow } => {
            // чистый кадр окна, даже если его что-то перекрывало; если не вышло — то, что было видно на экране
            let raw = capture::print_window(&win).unwrap_or(fallback);
            let rounded = !capture::is_maximized(win.hwnd);
            capture::style_window(&raw, scale, rounded, shadow)
        }
    };
    finish(img);
}

/// Показать итог: в «островке» MacMixer сверху экрана, а если его нет — обычным уведомлением из трея
fn tell(title: &str, body: &str) {
    use windows::Win32::System::DataExchange::COPYDATASTRUCT;
    let data: Vec<u16> = format!("{title}\0{body}").encode_utf16().collect();
    let cd = COPYDATASTRUCT { dwData: 0x4D49, cbData: (data.len() * 2) as u32, lpData: data.as_ptr() as *mut c_void };
    unsafe {
        if let Ok(mixer) = FindWindowW(w!("MacMixer.Main"), None) {
            if SendMessageW(mixer, WM_COPYDATA, Some(WPARAM(main_hwnd().0 as usize)), Some(LPARAM(&cd as *const _ as isize))).0 != 0 {
                return;
            }
        }
        let mut nid = NOTIFYICONDATAW {
            cbSize: size_of::<NOTIFYICONDATAW>() as u32,
            hWnd: main_hwnd(),
            uID: 1,
            uFlags: NIF_INFO,
            ..Default::default()
        };
        let fill = |dst: &mut [u16], s: &str| {
            let v: Vec<u16> = s.encode_utf16().take(dst.len() - 1).collect();
            dst[..v.len()].copy_from_slice(&v);
        };
        fill(&mut nid.szInfoTitle, title);
        fill(&mut nid.szInfo, body);
        let _ = Shell_NotifyIconW(NIM_MODIFY, &nid);
    }
}

/// Распознавание закончилось: текст в буфер и короткий итог
fn ocr_done() {
    let Some(text) = ocr::take() else { return };
    let text = text.trim();
    if text.is_empty() {
        tell("Текст не найден", "На выделенном участке нечего распознать");
    } else if capture::text_to_clipboard(text, main_hwnd()) {
        tell("Текст скопирован", text.lines().next().unwrap_or_default());
    } else {
        tell("Не удалось скопировать", "Буфер обмена занят другой программой");
    }
}

/// Как на маке: файл в «Снимки экрана», копия в буфере и миниатюра в углу
fn finish(img: Img) {
    if img.w == 0 || img.h == 0 {
        return;
    }
    let Some(png) = capture::encode_png(&img) else { return };
    let path = capture::new_path();
    capture::save(&png, &path);
    library::add(&path);
    capture::to_clipboard(&img, &png, main_hwnd());
    thumb::show(img, png, path);
}

// ---------- трей ----------

fn tray_icon() -> HICON {
    // значки в трее — в теме панели задач
    gfx::use_theme(false);
    let size = unsafe { GetSystemMetrics(SM_CXSMICON) }.max(16) as u32 * 2;
    let mut img = Img::new(size, size);
    if let Some(mut pm) = img.pixmap_mut() {
        let s = size as f32 / 32.0;
        let white = gfx::white(1.0);
        // значок «Ножниц» Windows — как остальные значки в трее; без шрифта — свой рисунок
        let drawn = gfx::glyph(&mut pm, '\u{E924}', 16.0 * s, 16.0 * s, 26.0 * s, white);
        let mut pb = tiny_skia::PathBuilder::new();
        let (a, b, l) = (4.0 * s, 28.0 * s, 8.0 * s);
        for (x, y, dx, dy) in [(a, a, 1.0, 1.0), (b, a, -1.0, 1.0), (a, b, 1.0, -1.0), (b, b, -1.0, -1.0)] {
            pb.move_to(x + dx * l, y);
            pb.line_to(x, y);
            pb.line_to(x, y + dy * l);
        }
        if let Some(p) = pb.finish().filter(|_| !drawn) {
            pm.stroke_path(&p, &gfx::solid(white), &gfx::stroke(3.0 * s), tiny_skia::Transform::identity(), None);
        }
        if let Some(c) = tiny_skia::PathBuilder::from_circle(16.0 * s, 16.0 * s, 5.0 * s).filter(|_| !drawn) {
            pm.fill_path(&c, &gfx::solid(gfx::accent(1.0)), tiny_skia::FillRule::Winding, tiny_skia::Transform::identity(), None);
        }
    }
    unsafe {
        // иконкам нужна непремультиплицированная альфа
        for p in img.px.chunks_exact_mut(4) {
            let a = p[3] as u32;
            if a > 0 {
                for c in &mut p[..3] {
                    *c = ((*c as u32 * 255 + a / 2) / a).min(255) as u8;
                }
            }
        }
        let color = CreateBitmap(size as i32, size as i32, 1, 32, Some(img.px.as_ptr() as *const c_void));
        let mask = CreateBitmap(size as i32, size as i32, 1, 1, None);
        let info = ICONINFO { fIcon: true.into(), hbmColor: color, hbmMask: mask, ..Default::default() };
        let icon = CreateIconIndirect(&info).unwrap_or_default();
        let _ = DeleteObject(color.into());
        let _ = DeleteObject(mask.into());
        icon
    }
}

/// Значок окон хранилища и редактора: «Ножницы» акцентного цвета — виден и на светлом заголовке
pub fn app_icon() -> HICON {
    let size = unsafe { GetSystemMetrics(SM_CXICON) }.max(32) as u32;
    let mut img = Img::new(size, size);
    if let Some(mut pm) = img.pixmap_mut() {
        let k = size as f32;
        if !gfx::glyph(&mut pm, '\u{E924}', k / 2.0, k / 2.0, k * 0.8, gfx::accent(1.0)) {
            return tray_icon();
        }
    }
    unsafe {
        for p in img.px.chunks_exact_mut(4) {
            let a = p[3] as u32;
            if a > 0 {
                for c in &mut p[..3] {
                    *c = ((*c as u32 * 255 + a / 2) / a).min(255) as u8;
                }
            }
        }
        let color = CreateBitmap(size as i32, size as i32, 1, 32, Some(img.px.as_ptr() as *const c_void));
        let mask = CreateBitmap(size as i32, size as i32, 1, 1, None);
        let info = ICONINFO { fIcon: true.into(), hbmColor: color, hbmMask: mask, ..Default::default() };
        let icon = CreateIconIndirect(&info).unwrap_or_default();
        let _ = DeleteObject(color.into());
        let _ = DeleteObject(mask.into());
        icon
    }
}

fn tray_data(hwnd: HWND) -> NOTIFYICONDATAW {
    let mut nid = NOTIFYICONDATAW {
        cbSize: size_of::<NOTIFYICONDATAW>() as u32,
        hWnd: hwnd,
        uID: 1,
        uFlags: NIF_ICON | NIF_MESSAGE | NIF_TIP,
        uCallbackMessage: WM_TRAY,
        hIcon: tray_icon(),
        ..Default::default()
    };
    let tip = wide("Снимки экрана — Win+Shift+S");
    nid.szTip[..tip.len()].copy_from_slice(&tip);
    nid
}

fn add_tray(hwnd: HWND) {
    unsafe {
        let nid = tray_data(hwnd);
        let _ = Shell_NotifyIconW(NIM_ADD, &nid);
    }
}

fn remove_tray(hwnd: HWND) {
    unsafe {
        let nid = NOTIFYICONDATAW { cbSize: size_of::<NOTIFYICONDATAW>() as u32, hWnd: hwnd, uID: 1, ..Default::default() };
        let _ = Shell_NotifyIconW(NIM_DELETE, &nid);
    }
}

fn tray_menu(hwnd: HWND) {
    unsafe {
        let Ok(m) = CreatePopupMenu() else { return };
        let item = |id: usize, s: &str| {
            let t = wide(s);
            let _ = AppendMenuW(m, MF_STRING, id, pcwstr(&t));
        };
        item(MENU_LIBRARY, "Хранилище снимков\tWin+Shift+2");
        let _ = SetMenuDefaultItem(m, MENU_LIBRARY as u32, 0);
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        item(MENU_PANEL, "Панель снимков\tWin+Shift+S");
        item(MENU_AREA, "Снимок области\tWin+Shift+4");
        item(MENU_WINDOW, "Снимок окна");
        item(MENU_SCREEN, "Снимок экрана\tWin+Shift+3");
        item(MENU_TEXT, "Скопировать текст с экрана\tWin+Shift+1");
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        item(MENU_FOLDER, "Открыть папку снимков");
        let flags = if autostart_enabled() { MF_STRING | MF_CHECKED } else { MF_STRING };
        let _ = AppendMenuW(m, flags, MENU_AUTOSTART, w!("Запускать вместе с Windows"));
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        item(MENU_EXIT, "Выход");
        let p = capture::cursor();
        let _ = SetForegroundWindow(hwnd);
        let cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, p.x, p.y, Some(0), hwnd, None).0 as usize;
        let _ = DestroyMenu(m);
        let defer = |s: Shot| {
            DEFERRED = s as usize;
            SetTimer(Some(hwnd), TIMER_DEFERRED, 250, None);
        };
        match cmd {
            MENU_LIBRARY => library::open(None),
            MENU_PANEL => defer(Shot::Panel),
            MENU_AREA => defer(Shot::Area),
            MENU_WINDOW => defer(Shot::Window),
            MENU_SCREEN => defer(Shot::Screen),
            MENU_TEXT => defer(Shot::Text),
            MENU_FOLDER => {
                let d = wide(&capture::screenshots_dir().to_string_lossy());
                ShellExecuteW(None, w!("open"), pcwstr(&d), None, None, SW_SHOWNORMAL);
            }
            MENU_AUTOSTART => set_autostart(!autostart_enabled()),
            MENU_EXIT => PostQuitMessage(0),
            _ => {}
        }
    }
}

const RUN_KEY: PCWSTR = w!("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
const RUN_VALUE: PCWSTR = w!("MacShot");

fn autostart_enabled() -> bool {
    let mut size = 0u32;
    let r = unsafe { RegGetValueW(HKEY_CURRENT_USER, RUN_KEY, RUN_VALUE, RRF_RT_REG_SZ, None, None, Some(&mut size)) };
    r == ERROR_SUCCESS
}

fn set_autostart(on: bool) {
    unsafe {
        if on {
            let Ok(exe) = std::env::current_exe() else { return };
            let cmd = wide(&format!("\"{}\"", exe.display()));
            let _ = RegSetKeyValueW(
                HKEY_CURRENT_USER,
                RUN_KEY,
                RUN_VALUE,
                REG_SZ.0,
                Some(cmd.as_ptr() as *const c_void),
                (cmd.len() * 2) as u32,
            );
        } else {
            let _ = RegDeleteKeyValueW(HKEY_CURRENT_USER, RUN_KEY, RUN_VALUE);
        }
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        hook::WM_SHOT => {
            if let Some(s) = Shot::from(wp.0) {
                shoot(s);
            }
            LRESULT(0)
        }
        ocr::WM_OCR => {
            ocr_done();
            LRESULT(0)
        }
        WM_TIMER if wp.0 == TIMER_DEFERRED => {
            let _ = KillTimer(Some(hwnd), TIMER_DEFERRED);
            if let Some(s) = Shot::from(DEFERRED) {
                shoot(s);
            }
            LRESULT(0)
        }
        WM_TRAY => {
            match (lp.0 & 0xFFFF) as u32 {
                WM_LBUTTONUP => {
                    DEFERRED = Shot::Panel as usize;
                    SetTimer(Some(hwnd), TIMER_DEFERRED, 150, None);
                }
                WM_RBUTTONUP => tray_menu(hwnd),
                _ => {}
            }
            LRESULT(0)
        }
        m if m == TASKBAR_CREATED && m != 0 => {
            add_tray(hwnd);
            LRESULT(0)
        }
        WM_SETTINGCHANGE => {
            // сменили тему или цвет акцента — перерисуем значок в трее
            gfx::load_themes();
            let nid = tray_data(hwnd);
            let _ = Shell_NotifyIconW(NIM_MODIFY, &nid);
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

// ---------- превью для проверки вёрстки ----------

/// mac-shot.exe --preview overlay|area|screen|thumb|window|editor out.png
fn preview(args: &[String]) {
    let kind = args.first().map(String::as_str).unwrap_or("overlay");
    let out = args.get(1).cloned().unwrap_or_else(|| "preview.png".into());
    let Some(fonts) = gfx::Fonts::load() else { return };
    gfx::load_themes();
    overlay::init(fonts, |_| {});
    let m = capture::monitor_at(capture::cursor());
    // mac-shot.exe --preview ocr:картинка.png отчёт.txt — что прочитал каждый язык
    if let Some(path) = kind.strip_prefix("ocr:") {
        let report = std::thread::scope(|s| {
            s.spawn(|| {
                unsafe {
                    let _ = windows::Win32::System::Com::CoInitializeEx(None, windows::Win32::System::Com::COINIT_MULTITHREADED);
                }
                let Ok(bytes) = std::fs::read(path) else { return "нет файла".to_string() };
                let mut r = png::Decoder::new(std::io::Cursor::new(bytes)).read_info().ok();
                let Some(reader) = r.as_mut() else { return "не PNG".to_string() };
                let mut buf = vec![0; reader.output_buffer_size()];
                let Ok(info) = reader.next_frame(&mut buf) else { return "не PNG".to_string() };
                let step = info.color_type.samples();
                let mut img = Img::new(info.width, info.height);
                for (d, s) in img.px.chunks_exact_mut(4).zip(buf.chunks_exact(step)) {
                    d.copy_from_slice(&[s[2], s[1], s[0], 255]);
                }
                ocr::report(&img)
            })
            .join()
            .unwrap_or_default()
        });
        let _ = std::fs::write(out, report);
        return;
    }
    let img = match kind {
        "overlay" => overlay::preview(Mode::Window, None),
        "screen" => overlay::preview(Mode::Screen, None),
        "area" => {
            let r = m.rect;
            let (w, h) = (r.right - r.left, r.bottom - r.top);
            let sel = RECT { left: r.left + w / 4, top: r.top + h / 5, right: r.left + w * 3 / 5, bottom: r.top + h / 2 };
            overlay::preview(Mode::Area, Some(sel))
        }
        "editor" => editor::preview(1500, 950),
        "library" | "library-view" | "library-select" => {
            let mode = kind.strip_prefix("library-").unwrap_or("");
            library::preview((1160.0 * m.scale) as i32, (780.0 * m.scale) as i32, mode)
        }
        "window" | "thumb" => {
            let wins = capture::windows();
            let raw = wins.iter().find_map(capture::print_window).or_else(|| capture::grab(m.rect));
            raw.map(|raw| {
                let styled = capture::style_window(&raw, m.scale, true, true);
                if kind == "thumb" { thumb::render(&styled, m.scale) } else { styled }
            })
        }
        _ => None,
    };
    if let Some(png) = img.as_ref().and_then(capture::encode_png) {
        let _ = std::fs::write(out, png);
    }
}
