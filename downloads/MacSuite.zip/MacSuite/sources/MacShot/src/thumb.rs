//! Плавающая миниатюра в углу экрана после снимка, как на маке:
//! клик — разметка, перетащить — вставить файл куда угодно, правый клик — меню

use std::cell::RefCell;
use std::path::PathBuf;
use std::time::Instant;

use tiny_skia::{FillRule, FilterQuality, Paint, Pattern, SpreadMode, Transform};
use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::System::Com::IDataObject;
use windows::Win32::System::Ole::DROPEFFECT_COPY;
use windows::Win32::UI::Controls::WM_MOUSELEAVE;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::Shell::{BHID_DataObject, IShellItem, SHCreateItemFromParsingName, SHDoDragDrop, ShellExecuteW};
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::capture::{self, pcwstr, wide, Surface};
use crate::gfx::{self, Img};

const MARGIN: f32 = 18.0; // место под тень
const MAX_W: f32 = 240.0;
const MAX_H: f32 = 150.0;
const STAY_MS: u128 = 5000;
const SLIDE_MS: f32 = 220.0;
const TIMER: usize = 1;

const MENU_OPEN: usize = 1;
const MENU_PAINT: usize = 2;
const MENU_FOLDER: usize = 3;
const MENU_COPY: usize = 4;
const MENU_DELETE: usize = 5;
const MENU_CLOSE: usize = 6;
const MENU_EDIT: usize = 7;
const MENU_LIBRARY: usize = 8;

struct Thumb {
    hwnd: HWND,
    path: PathBuf,
    img: Img,
    png: Vec<u8>,
    frame: Img,
    /// конечная позиция окна и стартовая (за краем экрана)
    x_in: i32,
    x_out: i32,
    y: i32,
    shown: Instant,
    leaving: Option<Instant>,
    hover: bool,
    press: Option<(i32, i32)>,
}

thread_local! {
    static THUMB: RefCell<Option<Thumb>> = const { RefCell::new(None) };
}

fn with<R>(f: impl FnOnce(&mut Thumb) -> R) -> Option<R> {
    THUMB.with(|s| s.try_borrow_mut().ok()?.as_mut().map(f))
}

pub fn init() {
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacShot.Thumb"),
            hCursor: LoadCursorW(None, IDC_HAND).unwrap_or_default(),
            ..Default::default()
        };
        RegisterClassW(&wc);
    }
}

/// Рисунок миниатюры: картинка со скруглением, светлая рамка и тень
pub fn render(img: &Img, scale: f32) -> Img {
    gfx::use_theme(false);
    let fit = (MAX_W * scale / img.w as f32).min(MAX_H * scale / img.h as f32).min(1.0);
    let (tw, th) = ((img.w as f32 * fit).round().max(24.0 * scale), (img.h as f32 * fit).round().max(24.0 * scale));
    let small = img.downscale(tw as u32, th as u32);
    let m = (MARGIN * scale).round();
    let mut out = Img::new((tw + m * 2.0) as u32, (th + m * 2.0) as u32);
    let Some(src) = small.pixmap() else { return out };
    let Some(mut pm) = out.pixmap_mut() else { return out };
    gfx::shadow(&mut pm, m, m + 3.0 * scale, tw, th, 16.0 * scale, 0.45);
    let r = 8.0 * scale;
    // подложка, чтобы снимки окон с прозрачной тенью не терялись на фоне
    gfx::fill_rrect(&mut pm, m, m, tw, th, r, gfx::surface(1.0));
    if let Some(path) = gfx::rrect(m, m, tw, th, r) {
        let paint = Paint {
            shader: Pattern::new(src, SpreadMode::Pad, FilterQuality::Nearest, 1.0, Transform::from_translate(m, m)),
            anti_alias: true,
            ..Default::default()
        };
        pm.fill_path(&path, &paint, FillRule::Winding, Transform::identity(), None);
    }
    gfx::stroke_rrect(&mut pm, m + 0.5, m + 0.5, tw - 1.0, th - 1.0, r, 1.0 * scale, gfx::white(0.25));
    out
}

pub fn show(img: Img, png: Vec<u8>, path: PathBuf) {
    close();
    let mon = capture::monitor_at(capture::cursor());
    let frame = render(&img, mon.scale);
    let (fw, fh) = (frame.w as i32, frame.h as i32);
    let gap = (6.0 * mon.scale) as i32;
    let x_in = mon.work.right - fw - gap;
    let y = mon.work.bottom - fh - gap;
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let Ok(hwnd) = CreateWindowExW(
            WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
            w!("MacShot.Thumb"),
            w!("Снимок экрана"),
            WS_POPUP,
            mon.work.right,
            y,
            fw,
            fh,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        let t = Thumb {
            hwnd,
            path,
            img,
            png,
            frame,
            x_in,
            x_out: mon.rect.right + 4,
            y,
            shown: Instant::now(),
            leaving: None,
            hover: false,
            press: None,
        };
        present(&t, t.x_out);
        THUMB.with(|s| *s.borrow_mut() = Some(t));
        let _ = ShowWindow(hwnd, SW_SHOWNOACTIVATE);
        SetTimer(Some(hwnd), TIMER, 15, None);
    }
}

pub fn close() {
    take();
}

/// Убирает миниатюру с экрана и отдаёт её данные
fn take() -> Option<Thumb> {
    let t = THUMB.with(|s| s.borrow_mut().take())?;
    unsafe {
        let _ = DestroyWindow(t.hwnd);
    }
    Some(t)
}

fn edit() {
    if let Some(t) = take() {
        crate::editor::open(t.img, t.path);
    }
}

fn present(t: &Thumb, x: i32) {
    let (w, h) = (t.frame.w as i32, t.frame.h as i32);
    let Some(mut s) = Surface::new(w, h) else { return };
    s.data().copy_from_slice(&t.frame.px);
    unsafe {
        let screen = GetDC(None);
        let pos = POINT { x, y: t.y };
        let size = SIZE { cx: w, cy: h };
        let src = POINT::default();
        let blend = BLENDFUNCTION { BlendOp: AC_SRC_OVER as u8, SourceConstantAlpha: 255, AlphaFormat: AC_SRC_ALPHA as u8, ..Default::default() };
        let _ = UpdateLayeredWindow(t.hwnd, Some(screen), Some(&pos), Some(&size), Some(s.dc), Some(&src), COLORREF(0), Some(&blend), ULW_ALPHA);
        ReleaseDC(None, screen);
    }
}

fn ease(k: f32) -> f32 {
    1.0 - (1.0 - k.clamp(0.0, 1.0)).powi(3)
}

/// Кадр анимации; false — миниатюра уехала и окно пора закрыть
fn tick(t: &mut Thumb) -> bool {
    let lerp = |a: i32, b: i32, k: f32| a + ((b - a) as f32 * k).round() as i32;
    if let Some(start) = t.leaving {
        let k = start.elapsed().as_millis() as f32 / SLIDE_MS;
        let x = lerp(t.x_in, t.x_out, ease(k));
        unsafe {
            let _ = SetWindowPos(t.hwnd, None, x, t.y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
        }
        return k < 1.0;
    }
    let el = t.shown.elapsed().as_millis();
    let k = el as f32 / SLIDE_MS;
    if k <= 1.05 {
        let x = lerp(t.x_out, t.x_in, ease(k));
        unsafe {
            let _ = SetWindowPos(t.hwnd, None, x, t.y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
        }
    }
    if t.hover || t.press.is_some() {
        // пока курсор на миниатюре, таймер исчезновения стоит на месте
        t.shown = Instant::now() - std::time::Duration::from_millis(SLIDE_MS as u64 + 10);
    } else if el > STAY_MS {
        t.leaving = Some(Instant::now());
    }
    true
}

fn open_file(path: &PathBuf) {
    let p = wide(&path.to_string_lossy());
    unsafe {
        ShellExecuteW(None, w!("open"), pcwstr(&p), None, None, SW_SHOWNORMAL);
    }
}

fn run(exe: &str, args: &str) {
    let (e, a) = (wide(exe), wide(args));
    unsafe {
        ShellExecuteW(None, w!("open"), pcwstr(&e), pcwstr(&a), None, SW_SHOWNORMAL);
    }
}

/// Перетаскивание файла снимка в другие программы средствами оболочки
fn drag(hwnd: HWND, path: &PathBuf) {
    let p = wide(&path.to_string_lossy());
    unsafe {
        let Ok(item) = SHCreateItemFromParsingName::<_, _, IShellItem>(pcwstr(&p), None) else { return };
        let Ok(data) = item.BindToHandler::<_, IDataObject>(None, &BHID_DataObject) else { return };
        let _ = SHDoDragDrop(Some(hwnd), &data, None, DROPEFFECT_COPY);
    }
}

fn menu(hwnd: HWND) -> usize {
    unsafe {
        let Ok(m) = CreatePopupMenu() else { return 0 };
        let _ = AppendMenuW(m, MF_STRING, MENU_EDIT, w!("Разметка"));
        let _ = AppendMenuW(m, MF_STRING, MENU_OPEN, w!("Открыть"));
        let _ = AppendMenuW(m, MF_STRING, MENU_PAINT, w!("Изменить в Paint"));
        let _ = AppendMenuW(m, MF_STRING, MENU_LIBRARY, w!("Показать в хранилище"));
        let _ = AppendMenuW(m, MF_STRING, MENU_FOLDER, w!("Показать в папке"));
        let _ = AppendMenuW(m, MF_STRING, MENU_COPY, w!("Скопировать"));
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        let _ = AppendMenuW(m, MF_STRING, MENU_DELETE, w!("Удалить"));
        let _ = AppendMenuW(m, MF_STRING, MENU_CLOSE, w!("Закрыть"));
        let p = capture::cursor();
        let _ = SetForegroundWindow(hwnd);
        let cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, p.x, p.y, Some(0), hwnd, None);
        let _ = DestroyMenu(m);
        cmd.0 as usize
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    let pt = || ((lp.0 & 0xFFFF) as i16 as i32, ((lp.0 >> 16) & 0xFFFF) as i16 as i32);
    match msg {
        WM_TIMER => {
            if with(tick) == Some(false) {
                close();
            }
            LRESULT(0)
        }
        WM_MOUSEMOVE => {
            let start_drag = with(|t| {
                if !t.hover {
                    t.hover = true;
                    let mut tme = TRACKMOUSEEVENT {
                        cbSize: std::mem::size_of::<TRACKMOUSEEVENT>() as u32,
                        dwFlags: TME_LEAVE,
                        hwndTrack: hwnd,
                        dwHoverTime: 0,
                    };
                    let _ = TrackMouseEvent(&mut tme);
                }
                let (x, y) = pt();
                let far = |(px, py): (i32, i32)| {
                    (x - px).abs() > GetSystemMetrics(SM_CXDRAG) || (y - py).abs() > GetSystemMetrics(SM_CYDRAG)
                };
                match t.press {
                    Some(p) if far(p) => {
                        t.press = None;
                        Some(t.path.clone())
                    }
                    _ => None,
                }
            })
            .flatten();
            if let Some(path) = start_drag {
                let _ = ReleaseCapture();
                let _ = ShowWindow(hwnd, SW_HIDE);
                drag(hwnd, &path);
                close();
            }
            LRESULT(0)
        }
        WM_MOUSELEAVE => {
            with(|t| t.hover = false);
            LRESULT(0)
        }
        WM_LBUTTONDOWN => {
            with(|t| t.press = Some(pt()));
            SetCapture(hwnd);
            LRESULT(0)
        }
        WM_LBUTTONUP => {
            let _ = ReleaseCapture();
            if with(|t| t.press.take().is_some()) == Some(true) {
                edit();
            }
            LRESULT(0)
        }
        WM_RBUTTONUP => {
            with(|t| t.hover = true);
            let cmd = menu(hwnd);
            let Some(path) = with(|t| t.path.clone()) else { return LRESULT(0) };
            let quoted = format!("\"{}\"", path.display());
            match cmd {
                MENU_EDIT => edit(),
                MENU_LIBRARY => {
                    close();
                    crate::library::open(Some(&path));
                }
                MENU_OPEN => {
                    close();
                    open_file(&path);
                }
                MENU_PAINT => {
                    close();
                    run("mspaint.exe", &quoted);
                }
                MENU_FOLDER => {
                    close();
                    run("explorer.exe", &format!("/select,{quoted}"));
                }
                MENU_COPY => {
                    with(|t| capture::to_clipboard(&t.img, &t.png, hwnd));
                    close();
                }
                MENU_DELETE => {
                    let _ = std::fs::remove_file(&path);
                    close();
                }
                MENU_CLOSE => close(),
                _ => {
                    with(|t| t.hover = false);
                }
            }
            LRESULT(0)
        }
        WM_MOUSEACTIVATE => LRESULT(MA_NOACTIVATE as isize),
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}
