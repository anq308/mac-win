//! Разметка снимка, как Markup на маке: перо, маркер, стрелки, рамки, текст и пикселизация.
//! «Готово» перезаписывает файл снимка и кладёт результат в буфер обмена.

use std::cell::RefCell;
use std::ffi::c_void;
use std::path::PathBuf;

use tiny_skia::{FillRule, LineCap, Path, PathBuilder, PixmapMut, PixmapPaint, Rect, StrokeDash, Transform};
use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Dwm::{DwmSetWindowAttribute, DWMWA_USE_IMMERSIVE_DARK_MODE};
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::HiDpi::AdjustWindowRectExForDpi;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::capture::{self, pcwstr, wide, Surface};
use crate::gfx::{self, Fonts, Icon, Img};

#[derive(Clone, Copy, PartialEq)]
enum Tool {
    Pen,
    Marker,
    Arrow,
    Rect,
    Ellipse,
    Text,
    Pixelate,
}

/// Инструмент, иконка и клавиша (по коду клавиши, чтобы работало и в русской раскладке)
const TOOLS: [(Tool, Icon, u16); 7] = [
    (Tool::Pen, Icon::Pen, b'P' as u16),
    (Tool::Marker, Icon::Marker, b'M' as u16),
    (Tool::Arrow, Icon::Arrow, b'A' as u16),
    (Tool::Rect, Icon::Rect, b'R' as u16),
    (Tool::Ellipse, Icon::Ellipse, b'O' as u16),
    (Tool::Text, Icon::Text, b'T' as u16),
    (Tool::Pixelate, Icon::Pixelate, b'B' as u16),
];

const COLORS: [(u8, u8, u8); 6] =
    [(0xFF, 0x3B, 0x30), (0xFF, 0xCC, 0x00), (0x34, 0xC7, 0x59), (0x0A, 0x84, 0xFF), (0xFF, 0xFF, 0xFF), (0x1C, 0x1C, 0x1E)];

// толщины для каждой из трёх кнопок размера, в логических пикселях
const WIDTH: [f32; 3] = [3.0, 6.0, 11.0];
const MARKER: [f32; 3] = [12.0, 20.0, 32.0];
const TEXT_PX: [f32; 3] = [18.0, 28.0, 44.0];
const BLOCK: [f32; 3] = [7.0, 12.0, 20.0];

const TB: f32 = 52.0;
const PAD: f32 = 16.0;

#[derive(Clone)]
struct Shape {
    tool: Tool,
    color: usize,
    size: usize,
    /// масштаб экрана в момент рисования — чтобы повтор после отмены дал ту же картинку
    s: f32,
    pts: Vec<(f32, f32)>,
    text: String,
}

#[derive(Clone, Copy, PartialEq)]
enum Btn {
    Tool(usize),
    Color(usize),
    Size(usize),
    Undo,
    Redo,
    Copy,
    Done,
}

struct Editor {
    hwnd: HWND,
    path: PathBuf,
    fonts: Fonts,
    base: Img,
    /// снимок со всеми завершёнными фигурами
    img: Img,
    shapes: Vec<Shape>,
    redo: Vec<Shape>,
    /// фигура, которую сейчас рисуют или текст, который сейчас печатают
    live: Option<Shape>,
    typing: bool,
    tool: usize,
    color: usize,
    size: usize,
    s: f32,
    cw: i32,
    ch: i32,
    frame: Option<Surface>,
    /// уменьшенная копия img под размер окна
    view: Option<Img>,
    hover: Option<Btn>,
    pressed: Option<Btn>,
    edits: u32,
    saved: u32,
}

thread_local! {
    static EDITOR: RefCell<Option<Editor>> = const { RefCell::new(None) };
    /// запущен как `mac-shot.exe --edit файл.png`: закрыли редактор — завершаем процесс
    static STANDALONE: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

fn with<R>(f: impl FnOnce(&mut Editor) -> R) -> Option<R> {
    EDITOR.with(|s| s.try_borrow_mut().ok()?.as_mut().map(f))
}

fn is_open() -> bool {
    EDITOR.with(|s| s.borrow().is_some())
}

pub fn init() {
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacShot.Editor"),
            ..Default::default()
        };
        RegisterClassW(&wc);
    }
}

fn new_editor(img: Img, path: PathBuf, fonts: Fonts, s: f32) -> Editor {
    Editor {
        hwnd: HWND::default(),
        path,
        fonts,
        base: img.clone(),
        img,
        shapes: Vec::new(),
        redo: Vec::new(),
        live: None,
        typing: false,
        tool: 2,
        color: 0,
        size: 1,
        s,
        cw: 0,
        ch: 0,
        frame: None,
        view: None,
        hover: None,
        pressed: None,
        edits: 0,
        saved: 0,
    }
}

pub fn open(img: Img, path: PathBuf) {
    if let Some(old) = with(|e| e.hwnd) {
        // прошлый редактор сначала спросит про несохранённое; если отказались закрывать — новый не открываем
        unsafe { SendMessageW(old, WM_CLOSE, None, None) };
        if is_open() {
            return;
        }
    }
    let Some(fonts) = Fonts::load() else { return };
    let mon = capture::monitor_at(capture::cursor());
    let s = mon.scale;
    let mut e = new_editor(img, path, fonts, s);
    let work = mon.work;
    let (ww, wh) = ((work.right - work.left) as f32, (work.bottom - work.top) as f32);
    let cw = (e.img.w as f32 + PAD * 2.0 * s).max(min_width(&e)).min(ww * 0.92);
    let ch = (e.img.h as f32 + (TB + PAD * 2.0) * s).max(360.0 * s).min(wh * 0.92);
    let title = wide(&format!(
        "Разметка — {}",
        e.path.file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default()
    ));
    unsafe {
        let mut r = RECT { left: 0, top: 0, right: cw as i32, bottom: ch as i32 };
        let _ = AdjustWindowRectExForDpi(&mut r, WS_OVERLAPPEDWINDOW, false, WINDOW_EX_STYLE(0), (s * 96.0) as u32);
        let (rw, rh) = (r.right - r.left, r.bottom - r.top);
        let x = work.left + ((ww as i32 - rw) / 2).max(0);
        let y = work.top + ((wh as i32 - rh) / 2).max(0);
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let Ok(hwnd) = CreateWindowExW(
            WINDOW_EX_STYLE(0),
            w!("MacShot.Editor"),
            pcwstr(&title),
            WS_OVERLAPPEDWINDOW,
            x,
            y,
            rw,
            rh,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        gfx::use_theme(true);
        let dark: i32 = gfx::theme().dark as i32;
        let _ = DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, &dark as *const i32 as *const c_void, 4);
        let icon = crate::app_icon();
        SendMessageW(hwnd, WM_SETICON, Some(WPARAM(ICON_BIG as usize)), Some(LPARAM(icon.0 as isize)));
        SendMessageW(hwnd, WM_SETICON, Some(WPARAM(ICON_SMALL as usize)), Some(LPARAM(icon.0 as isize)));
        let mut rc = RECT::default();
        let _ = GetClientRect(hwnd, &mut rc);
        e.hwnd = hwnd;
        e.cw = rc.right;
        e.ch = rc.bottom;
        EDITOR.with(|st| *st.borrow_mut() = Some(e));
        let _ = ShowWindow(hwnd, SW_SHOW);
        let _ = SetForegroundWindow(hwnd);
    }
}

fn close() {
    if let Some(e) = EDITOR.with(|s| s.borrow_mut().take()) {
        unsafe {
            let _ = DestroyWindow(e.hwnd);
            if STANDALONE.get() {
                PostQuitMessage(0);
            }
        }
    }
}

/// Разметка любого PNG с диска в отдельном процессе
pub fn run_file(path: PathBuf) {
    let Some(img) = capture::load_png(&path) else { return };
    STANDALONE.set(true);
    init();
    open(img, path);
    if !is_open() {
        return;
    }
    unsafe {
        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).as_bool() {
            let _ = TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
}

// ---------- геометрия ----------

fn geom(e: &Editor) -> (f32, f32, f32, u32, u32) {
    geom_of(e.cw, e.ch, e.s, &e.img)
}

fn to_img(e: &Editor, x: i32, y: i32) -> (f32, f32) {
    let (k, ox, oy, ..) = geom(e);
    ((x as f32 - ox) / k, (y as f32 - oy) / k)
}

fn layout(e: &Editor) -> Vec<(Btn, [f32; 4])> {
    let s = e.s;
    let bh = 36.0 * s;
    let y = (TB * s - bh) / 2.0;
    let mut v = Vec::new();
    let mut x = 10.0 * s;
    for i in 0..TOOLS.len() {
        v.push((Btn::Tool(i), [x, y, bh, bh]));
        x += bh + 2.0 * s;
    }
    x += 12.0 * s;
    for i in 0..COLORS.len() {
        v.push((Btn::Color(i), [x, y, 28.0 * s, bh]));
        x += 28.0 * s;
    }
    x += 12.0 * s;
    for i in 0..WIDTH.len() {
        v.push((Btn::Size(i), [x, y, 30.0 * s, bh]));
        x += 32.0 * s;
    }
    x += 12.0 * s;
    v.push((Btn::Undo, [x, y, bh, bh]));
    x += bh + 2.0 * s;
    v.push((Btn::Redo, [x, y, bh, bh]));
    let px = 14.0 * s;
    let mut r = e.cw as f32 - 10.0 * s;
    for (b, label) in [(Btn::Done, "Готово"), (Btn::Copy, "Скопировать")] {
        let bw = gfx::measure(&e.fonts.semibold, label, px) + 28.0 * s;
        r -= bw;
        v.push((b, [r, y, bw, bh]));
        r -= 8.0 * s;
    }
    v
}

fn min_width(e: &Editor) -> f32 {
    let l = layout(e);
    let right = |b: &Btn| matches!(b, Btn::Copy | Btn::Done);
    let left_end = l.iter().filter(|(b, _)| !right(b)).map(|(_, r)| r[0] + r[2]).fold(0.0, f32::max);
    let right_start = l.iter().filter(|(b, _)| right(b)).map(|(_, r)| r[0]).fold(f32::MAX, f32::min);
    left_end + (e.cw as f32 - right_start) + 20.0 * e.s
}

fn button_at(e: &Editor, x: i32, y: i32) -> Option<Btn> {
    let (x, y) = (x as f32, y as f32);
    layout(e).into_iter().find(|(_, r)| x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]).map(|(b, _)| b)
}

// ---------- фигуры ----------

fn norm(a: (f32, f32), b: (f32, f32)) -> (f32, f32, f32, f32) {
    (a.0.min(b.0), a.1.min(b.1), a.0.max(b.0), a.1.max(b.1))
}

/// Плавная линия через середины отрезков — дрожание руки не превращается в ломаную
fn smooth(pts: &[(f32, f32)]) -> Option<Path> {
    let mut pb = PathBuilder::new();
    let first = *pts.first()?;
    pb.move_to(first.0, first.1);
    if pts.len() == 1 {
        pb.line_to(first.0 + 0.01, first.1);
    } else {
        for i in 1..pts.len() - 1 {
            let (a, b) = (pts[i], pts[i + 1]);
            pb.quad_to(a.0, a.1, (a.0 + b.0) / 2.0, (a.1 + b.1) / 2.0);
        }
        let last = pts[pts.len() - 1];
        pb.line_to(last.0, last.1);
    }
    pb.finish()
}

fn arrow(pm: &mut PixmapMut, a: (f32, f32), z: (f32, f32), w: f32, s: f32, c: tiny_skia::Color, t: Transform) {
    let (dx, dy) = (z.0 - a.0, z.1 - a.1);
    let len = (dx * dx + dy * dy).sqrt();
    if len < 1.0 {
        return;
    }
    let (ux, uy) = (dx / len, dy / len);
    let h = (w * 3.0 + 8.0 * s).min(len * 0.7);
    let hw = h * 0.6;
    let paint = gfx::solid(c);
    let mut pb = PathBuilder::new();
    pb.move_to(a.0, a.1);
    pb.line_to(z.0 - ux * h * 0.5, z.1 - uy * h * 0.5);
    if let Some(p) = pb.finish() {
        pm.stroke_path(&p, &paint, &gfx::stroke(w), t, None);
    }
    let (cx, cy) = (z.0 - ux * h, z.1 - uy * h);
    let mut pb = PathBuilder::new();
    pb.move_to(z.0, z.1);
    pb.line_to(cx - uy * hw, cy + ux * hw);
    pb.line_to(cx + uy * hw, cy - ux * hw);
    pb.close();
    if let Some(p) = pb.finish() {
        pm.fill_path(&p, &paint, FillRule::Winding, t, None);
        // скруглённые уголки наконечника
        pm.stroke_path(&p, &paint, &gfx::stroke(w * 0.5), t, None);
    }
}

/// Рисует фигуру; t переводит координаты снимка в координаты pm.
/// Пикселизация здесь только обозначается рамкой — сами пиксели меняет pixelate()
fn draw_shape(pm: &mut PixmapMut, sh: &Shape, t: Transform, fonts: &Fonts, caret: bool) {
    let (r, g, b) = COLORS[sh.color];
    let color = gfx::rgb(r, g, b, 1.0);
    let s = sh.s;
    let w = WIDTH[sh.size] * s;
    let (Some(&a), Some(&z)) = (sh.pts.first(), sh.pts.last()) else { return };
    match sh.tool {
        Tool::Pen => {
            if let Some(p) = smooth(&sh.pts) {
                pm.stroke_path(&p, &gfx::solid(color), &gfx::stroke(w), t, None);
            }
        }
        Tool::Marker => {
            if let Some(p) = smooth(&sh.pts) {
                let mut st = gfx::stroke(MARKER[sh.size] * s);
                st.line_cap = LineCap::Square;
                pm.stroke_path(&p, &gfx::solid(gfx::rgb(r, g, b, 0.4)), &st, t, None);
            }
        }
        Tool::Arrow => arrow(pm, a, z, w, s, color, t),
        Tool::Rect => {
            let (x0, y0, x1, y1) = norm(a, z);
            if let Some(p) = gfx::rrect(x0, y0, x1 - x0, y1 - y0, w * 0.6) {
                pm.stroke_path(&p, &gfx::solid(color), &gfx::stroke(w), t, None);
            }
        }
        Tool::Ellipse => {
            let (x0, y0, x1, y1) = norm(a, z);
            if let Some(p) = Rect::from_ltrb(x0, y0, x1.max(x0 + 0.5), y1.max(y0 + 0.5)).and_then(PathBuilder::from_oval) {
                pm.stroke_path(&p, &gfx::solid(color), &gfx::stroke(w), t, None);
            }
        }
        Tool::Text => {
            let px = TEXT_PX[sh.size] * s * t.sx;
            let (x, y) = (a.0 * t.sx + t.tx, a.1 * t.sy + t.ty);
            gfx::text(pm, &fonts.semibold, &sh.text, x, y, px, color);
            if caret {
                let cx = x + gfx::measure(&fonts.semibold, &sh.text, px) + 1.0;
                if let Some(rc) = Rect::from_xywh(cx, y - px * 0.85, (px / 14.0).max(1.5), px * 1.05) {
                    pm.fill_rect(rc, &gfx::solid(gfx::accent(1.0)), Transform::identity(), None);
                }
            }
        }
        Tool::Pixelate => {
            let (x0, y0, x1, y1) = norm(a, z);
            if let Some(p) = gfx::rrect(x0, y0, x1 - x0, y1 - y0, 0.0) {
                pm.fill_path(&p, &gfx::solid(gfx::rgb(0xFF, 0xFF, 0xFF, 0.12)), FillRule::Winding, t, None);
                let mut st = gfx::stroke(1.5 / t.sx);
                st.dash = StrokeDash::new(vec![5.0 / t.sx, 4.0 / t.sx], 0.0);
                pm.stroke_path(&p, &gfx::solid(gfx::rgb(0xFF, 0xFF, 0xFF, 0.9)), &st, t, None);
            }
        }
    }
}

/// Крупные «пиксели»: каждый блок заливается средним цветом
fn pixelate(img: &mut Img, a: (f32, f32), z: (f32, f32), block: usize) {
    let (x0, y0, x1, y1) = norm(a, z);
    let clamp = |v: f32, max: u32| (v.round().max(0.0) as usize).min(max as usize);
    let (x0, x1) = (clamp(x0, img.w), clamp(x1, img.w));
    let (y0, y1) = (clamp(y0, img.h), clamp(y1, img.h));
    let block = block.max(2);
    let stride = img.w as usize * 4;
    for by in (y0..y1).step_by(block) {
        for bx in (x0..x1).step_by(block) {
            let (ex, ey) = ((bx + block).min(x1), (by + block).min(y1));
            let mut acc = [0u32; 4];
            for y in by..ey {
                for x in bx..ex {
                    let i = y * stride + x * 4;
                    for c in 0..4 {
                        acc[c] += img.px[i + c] as u32;
                    }
                }
            }
            let n = ((ex - bx) * (ey - by)) as u32;
            let avg = acc.map(|v| (v / n) as u8);
            for y in by..ey {
                for x in bx..ex {
                    let i = y * stride + x * 4;
                    img.px[i..i + 4].copy_from_slice(&avg);
                }
            }
        }
    }
}

fn apply(img: &mut Img, sh: &Shape, fonts: &Fonts) {
    if sh.tool == Tool::Pixelate {
        if let (Some(&a), Some(&z)) = (sh.pts.first(), sh.pts.last()) {
            pixelate(img, a, z, (BLOCK[sh.size] * sh.s).round() as usize);
        }
    } else if let Some(mut pm) = img.pixmap_mut() {
        draw_shape(&mut pm, sh, Transform::identity(), fonts, false);
    }
}

/// Shift: квадрат/круг и стрелка с шагом 45°
fn constrain(tool: Tool, a: (f32, f32), p: (f32, f32)) -> (f32, f32) {
    let (dx, dy) = (p.0 - a.0, p.1 - a.1);
    match tool {
        Tool::Rect | Tool::Ellipse | Tool::Pixelate => {
            let d = dx.abs().max(dy.abs());
            (a.0 + d * dx.signum(), a.1 + d * dy.signum())
        }
        Tool::Arrow => {
            let len = (dx * dx + dy * dy).sqrt();
            let step = std::f32::consts::FRAC_PI_4;
            let ang = (dy.atan2(dx) / step).round() * step;
            (a.0 + len * ang.cos(), a.1 + len * ang.sin())
        }
        _ => p,
    }
}

fn commit(e: &mut Editor, sh: Shape) {
    apply(&mut e.img, &sh, &e.fonts);
    e.shapes.push(sh);
    e.redo.clear();
    e.edits += 1;
    e.view = None;
}

fn commit_typing(e: &mut Editor) {
    if !e.typing {
        return;
    }
    e.typing = false;
    if let Some(sh) = e.live.take() {
        if !sh.text.trim().is_empty() {
            commit(e, sh);
        }
    }
}

fn rebuild(e: &mut Editor) {
    e.img = e.base.clone();
    for sh in &e.shapes {
        apply(&mut e.img, sh, &e.fonts);
    }
    e.view = None;
}

fn undo(e: &mut Editor) {
    if e.typing {
        e.typing = false;
        e.live = None;
        return;
    }
    if let Some(sh) = e.shapes.pop() {
        e.redo.push(sh);
        rebuild(e);
        e.edits += 1;
    }
}

fn redo(e: &mut Editor) {
    commit_typing(e);
    if let Some(sh) = e.redo.pop() {
        apply(&mut e.img, &sh, &e.fonts);
        e.shapes.push(sh);
        e.view = None;
        e.edits += 1;
    }
}

fn copy(e: &mut Editor) -> Option<Vec<u8>> {
    commit_typing(e);
    let png = capture::encode_png(&e.img)?;
    capture::to_clipboard(&e.img, &png, e.hwnd);
    Some(png)
}

fn save(e: &mut Editor) {
    if let Some(png) = copy(e) {
        if capture::save(&png, &e.path) {
            e.saved = e.edits;
        }
    }
}

// ---------- отрисовка ----------

fn prepare_view(e: &mut Editor) {
    let (k, _, _, vw, vh) = geom(e);
    if k < 1.0 && e.view.as_ref().is_none_or(|v| v.w != vw || v.h != vh) {
        e.view = Some(e.img.downscale(vw, vh));
    }
}

fn compose(e: &Editor, pm: &mut PixmapMut) {
    gfx::use_theme(true);
    pm.fill(gfx::canvas());
    let (k, ox, oy, vw, vh) = geom(e);
    let src = if k < 1.0 { e.view.as_ref() } else { Some(&e.img) };
    if let Some(src) = src.and_then(|i| i.pixmap()) {
        pm.draw_pixmap(ox as i32, oy as i32, src, &PixmapPaint::default(), Transform::identity(), None);
    }
    gfx::stroke_rrect(pm, ox - 0.5, oy - 0.5, vw as f32 + 1.0, vh as f32 + 1.0, 0.0, 1.0, gfx::white(0.12));
    if let Some(sh) = &e.live {
        draw_shape(pm, sh, Transform::from_row(k, 0.0, 0.0, k, ox, oy), &e.fonts, e.typing);
    }
    toolbar(e, pm);
}

fn toolbar(e: &Editor, pm: &mut PixmapMut) {
    let s = e.s;
    let white = gfx::white;
    if let Some(r) = Rect::from_xywh(0.0, 0.0, e.cw as f32, TB * s) {
        pm.fill_rect(r, &gfx::solid(gfx::base()), Transform::identity(), None);
    }
    if let Some(r) = Rect::from_xywh(0.0, TB * s - 1.0, e.cw as f32, 1.0) {
        pm.fill_rect(r, &gfx::solid(white(0.08)), Transform::identity(), None);
    }
    let isz = 20.0 * s;
    let px = 14.0 * s;
    for (btn, [x, y, w, h]) in layout(e) {
        let hover = e.hover == Some(btn);
        let pressed = hover && e.pressed == Some(btn);
        let hover_bg = |pm: &mut PixmapMut| {
            if hover {
                gfx::fill_rrect(pm, x, y, w, h, 9.0 * s, white(if pressed { 0.16 } else { 0.10 }));
            }
        };
        if matches!(btn, Btn::Color(0) | Btn::Size(0) | Btn::Undo) {
            gfx::fill_rrect(pm, x - 7.0 * s, y + 9.0 * s, 1.0 * s, h - 18.0 * s, 0.0, white(0.15));
        }
        let (cx, cy) = (x + w / 2.0, y + h / 2.0);
        match btn {
            Btn::Tool(i) => {
                if e.tool == i {
                    gfx::fill_rrect(pm, x, y, w, h, 9.0 * s, gfx::accent(if hover { 1.0 } else { 0.85 }));
                } else {
                    hover_bg(pm);
                }
                let fg = if e.tool == i { gfx::on_accent(1.0) } else { white(0.9) };
                gfx::icon(pm, TOOLS[i].1, cx - isz / 2.0, cy - isz / 2.0, isz, fg);
            }
            Btn::Color(i) => {
                let (r, g, b) = COLORS[i];
                if let Some(c) = PathBuilder::from_circle(cx, cy, 8.0 * s) {
                    pm.fill_path(&c, &gfx::solid(gfx::rgb(r, g, b, 1.0)), FillRule::Winding, Transform::identity(), None);
                    pm.stroke_path(&c, &gfx::solid(white(0.3)), &gfx::stroke(1.0 * s), Transform::identity(), None);
                }
                if e.color == i || hover {
                    if let Some(c) = PathBuilder::from_circle(cx, cy, 11.5 * s) {
                        let a = if e.color == i { 0.95 } else { 0.35 };
                        pm.stroke_path(&c, &gfx::solid(white(a)), &gfx::stroke(2.0 * s), Transform::identity(), None);
                    }
                }
            }
            Btn::Size(i) => {
                if e.size == i {
                    gfx::fill_rrect(pm, x, y, w, h, 9.0 * s, white(0.14));
                } else {
                    hover_bg(pm);
                }
                let d = [5.0, 8.0, 12.0][i] * s;
                if let Some(c) = PathBuilder::from_circle(cx, cy, d / 2.0) {
                    pm.fill_path(&c, &gfx::solid(white(1.0)), FillRule::Winding, Transform::identity(), None);
                }
            }
            Btn::Undo | Btn::Redo => {
                let enabled = if btn == Btn::Undo { !e.shapes.is_empty() || e.typing } else { !e.redo.is_empty() };
                if enabled {
                    hover_bg(pm);
                }
                let kind = if btn == Btn::Undo { Icon::Undo } else { Icon::Redo };
                gfx::icon(pm, kind, cx - isz / 2.0, cy - isz / 2.0, isz, white(if enabled { 1.0 } else { 0.3 }));
            }
            Btn::Copy | Btn::Done => {
                let (label, bg) = if btn == Btn::Done {
                    ("Готово", gfx::accent(if hover { 1.0 } else { 0.85 }))
                } else {
                    ("Скопировать", white(if pressed { 0.18 } else if hover { 0.14 } else { 0.08 }))
                };
                gfx::fill_rrect(pm, x, y, w, h, 9.0 * s, bg);
                let tw = gfx::measure(&e.fonts.semibold, label, px);
                let fg = if btn == Btn::Done { gfx::on_accent(1.0) } else { white(0.92) };
                gfx::text(pm, &e.fonts.semibold, label, cx - tw / 2.0, cy + px * 0.36, px, fg);
            }
        }
    }
}

fn paint(e: &mut Editor, hdc: HDC) {
    if e.cw <= 0 || e.ch <= 0 {
        return;
    }
    if e.frame.as_ref().is_none_or(|f| f.w != e.cw || f.h != e.ch) {
        e.frame = Surface::new(e.cw, e.ch);
    }
    prepare_view(e);
    let Some(frame) = e.frame.as_ref() else { return };
    let data = unsafe { frame.pixels() };
    if let Some(mut pm) = PixmapMut::from_bytes(data, e.cw as u32, e.ch as u32) {
        compose(e, &mut pm);
    }
    unsafe {
        let _ = BitBlt(hdc, 0, 0, e.cw, e.ch, Some(frame.dc), 0, 0, SRCCOPY);
    }
}

fn redraw(e: &Editor) {
    unsafe {
        let _ = InvalidateRect(Some(e.hwnd), None, false);
    }
}

// ---------- ввод ----------

enum Act {
    None,
    Close,
    Done,
}

fn click(e: &mut Editor, b: Btn) -> Act {
    match b {
        Btn::Tool(i) => {
            commit_typing(e);
            e.tool = i;
        }
        Btn::Color(i) => {
            e.color = i;
            // цвет печатаемого текста меняется на лету
            if let Some(sh) = e.live.as_mut().filter(|_| e.typing) {
                sh.color = i;
            }
        }
        Btn::Size(i) => {
            e.size = i;
            if let Some(sh) = e.live.as_mut().filter(|_| e.typing) {
                sh.size = i;
            }
        }
        Btn::Undo => undo(e),
        Btn::Redo => redo(e),
        Btn::Copy => {
            copy(e);
        }
        Btn::Done => return Act::Done,
    }
    Act::None
}

fn handle(e: &mut Editor, msg: u32, wp: WPARAM, lp: LPARAM) -> Act {
    let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, ((lp.0 >> 16) & 0xFFFF) as i16 as i32);
    let key = |vk: VIRTUAL_KEY| unsafe { GetKeyState(vk.0 as i32) < 0 };
    match msg {
        WM_MOUSEMOVE => {
            let hover = button_at(e, x, y);
            let mut changed = hover != e.hover;
            e.hover = hover;
            let drawing = unsafe { GetCapture() } == e.hwnd && !e.typing;
            if let Some(sh) = e.live.as_mut().filter(|_| drawing) {
                let (k, ox, oy, ..) = geom_of(e.cw, e.ch, e.s, &e.img);
                let p = ((x as f32 - ox) / k, (y as f32 - oy) / k);
                match sh.tool {
                    Tool::Pen | Tool::Marker => {
                        let last = sh.pts[sh.pts.len() - 1];
                        if ((p.0 - last.0).powi(2) + (p.1 - last.1).powi(2)).sqrt() * k >= 1.5 {
                            sh.pts.push(p);
                        }
                    }
                    _ => {
                        let p = if key(VK_SHIFT) { constrain(sh.tool, sh.pts[0], p) } else { p };
                        sh.pts[1] = p;
                    }
                }
                changed = true;
            }
            if changed {
                redraw(e);
            }
            Act::None
        }
        WM_LBUTTONDOWN => {
            if let Some(b) = button_at(e, x, y) {
                e.pressed = Some(b);
            } else if y as f32 >= TB * e.s {
                commit_typing(e);
                let p = to_img(e, x, y);
                let tool = TOOLS[e.tool].0;
                let mut sh = Shape { tool, color: e.color, size: e.size, s: e.s, pts: vec![p], text: String::new() };
                if tool == Tool::Text {
                    // щелчок — верх строки, а храним базовую линию
                    sh.pts[0].1 += TEXT_PX[e.size] * e.s * 0.8;
                    e.typing = true;
                } else {
                    if !matches!(tool, Tool::Pen | Tool::Marker) {
                        sh.pts.push(p);
                    }
                    unsafe { SetCapture(e.hwnd) };
                }
                e.live = Some(sh);
            }
            redraw(e);
            Act::None
        }
        WM_LBUTTONUP => {
            unsafe {
                let _ = ReleaseCapture();
            }
            if let Some(b) = e.pressed.take() {
                let act = if button_at(e, x, y) == Some(b) { click(e, b) } else { Act::None };
                redraw(e);
                return act;
            }
            if !e.typing {
                if let Some(sh) = e.live.take() {
                    let (k, ..) = geom(e);
                    let (a, z) = (sh.pts[0], sh.pts[sh.pts.len() - 1]);
                    // случайный щелчок без движения не оставляет пустых фигур
                    let big = (z.0 - a.0).abs() * k >= 3.0 || (z.1 - a.1).abs() * k >= 3.0;
                    if matches!(sh.tool, Tool::Pen | Tool::Marker) || big {
                        commit(e, sh);
                    }
                }
            }
            redraw(e);
            Act::None
        }
        WM_KEYDOWN => {
            if e.typing {
                return Act::None;
            }
            let ctrl = key(VK_CONTROL);
            let vk = wp.0 as u16;
            match vk {
                v if ctrl && v == b'Z' as u16 => {
                    if key(VK_SHIFT) {
                        redo(e)
                    } else {
                        undo(e)
                    }
                }
                v if ctrl && v == b'Y' as u16 => redo(e),
                v if ctrl && v == b'C' as u16 => {
                    copy(e);
                }
                v if ctrl && v == b'S' as u16 => save(e),
                v if v == VK_RETURN.0 => return Act::Done,
                v if v == VK_ESCAPE.0 => {
                    if e.live.take().is_none() {
                        return Act::Close;
                    }
                    unsafe {
                        let _ = ReleaseCapture();
                    }
                }
                v if !ctrl => {
                    if let Some(i) = TOOLS.iter().position(|t| t.2 == v) {
                        e.tool = i;
                    }
                }
                _ => {}
            }
            redraw(e);
            Act::None
        }
        WM_CHAR if e.typing => {
            match wp.0 as u32 {
                13 | 27 => commit_typing(e),
                8 => {
                    if let Some(sh) = e.live.as_mut() {
                        sh.text.pop();
                    }
                }
                c if c >= 32 => {
                    if let (Some(sh), Some(ch)) = (e.live.as_mut(), char::from_u32(c)) {
                        sh.text.push(ch);
                    }
                }
                _ => {}
            }
            redraw(e);
            Act::None
        }
        _ => Act::None,
    }
}

/// Масштаб снимка в окне и его левый верхний угол; без заимствования редактора — когда live уже взят как &mut
fn geom_of(cw: i32, ch: i32, s: f32, img: &Img) -> (f32, f32, f32, u32, u32) {
    let (tb, pad) = (TB * s, PAD * s);
    let aw = (cw as f32 - pad * 2.0).max(1.0);
    let ah = (ch as f32 - tb - pad * 2.0).max(1.0);
    let k = (aw / img.w as f32).min(ah / img.h as f32).min(1.0);
    let (vw, vh) = ((img.w as f32 * k).round().max(1.0) as u32, (img.h as f32 * k).round().max(1.0) as u32);
    let k = vw as f32 / img.w as f32;
    let ox = ((cw - vw as i32) / 2) as f32;
    let oy = (tb + ((ch as f32 - tb - vh as f32) / 2.0).max(0.0)).round();
    (k, ox, oy, vw, vh)
}

fn request_close(hwnd: HWND) {
    let changed = with(|e| {
        commit_typing(e);
        e.edits != e.saved && !e.shapes.is_empty()
    })
    .unwrap_or(false);
    if changed {
        let r = unsafe {
            MessageBoxW(Some(hwnd), w!("Сохранить изменения в снимке?"), w!("Разметка"), MB_YESNOCANCEL | MB_ICONQUESTION)
        };
        match r {
            IDYES => {
                with(save);
            }
            IDNO => {}
            _ => return,
        }
    }
    close();
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_PAINT => {
            let mut ps = PAINTSTRUCT::default();
            let hdc = BeginPaint(hwnd, &mut ps);
            with(|e| paint(e, hdc));
            let _ = EndPaint(hwnd, &ps);
            LRESULT(0)
        }
        WM_ERASEBKGND => LRESULT(1),
        WM_SIZE => {
            with(|e| {
                e.cw = (lp.0 & 0xFFFF) as i32;
                e.ch = ((lp.0 >> 16) & 0xFFFF) as i32;
                e.view = None;
                redraw(e);
            });
            LRESULT(0)
        }
        WM_GETMINMAXINFO => {
            if let Some((mw, s)) = with(|e| (min_width(e), e.s)) {
                let mmi = &mut *(lp.0 as *mut MINMAXINFO);
                mmi.ptMinTrackSize.x = (mw + 16.0 * s) as i32;
                mmi.ptMinTrackSize.y = (320.0 * s) as i32;
            }
            LRESULT(0)
        }
        WM_DPICHANGED => {
            with(|e| {
                e.s = ((wp.0 >> 16) & 0xFFFF) as f32 / 96.0;
                e.view = None;
            });
            let r = &*(lp.0 as *const RECT);
            let _ = SetWindowPos(hwnd, None, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE);
            LRESULT(0)
        }
        WM_SETCURSOR if (lp.0 & 0xFFFF) as u32 == HTCLIENT => {
            let mut p = POINT::default();
            let _ = GetCursorPos(&mut p);
            let _ = ScreenToClient(hwnd, &mut p);
            let cursor = with(|e| {
                if (p.y as f32) < TB * e.s {
                    IDC_ARROW
                } else if TOOLS[e.tool].0 == Tool::Text {
                    IDC_IBEAM
                } else {
                    IDC_CROSS
                }
            })
            .unwrap_or(IDC_ARROW);
            SetCursor(LoadCursorW(None, cursor).ok());
            LRESULT(1)
        }
        WM_MOUSEMOVE | WM_LBUTTONDOWN | WM_LBUTTONUP | WM_KEYDOWN | WM_CHAR => {
            match with(|e| handle(e, msg, wp, lp)) {
                Some(Act::Close) => request_close(hwnd),
                Some(Act::Done) => {
                    with(save);
                    close();
                }
                _ => {}
            }
            LRESULT(0)
        }
        WM_CLOSE => {
            request_close(hwnd);
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

/// Кадр редактора с примерами фигур — для проверки вёрстки без окна
pub fn preview(w: i32, h: i32) -> Option<Img> {
    let fonts = Fonts::load()?;
    let m = capture::monitor_at(capture::cursor());
    let r = m.rect;
    let shot = capture::grab(RECT { left: r.left, top: r.top, right: r.left + 1200, bottom: r.top + 760 })?;
    let mut e = new_editor(shot, PathBuf::new(), fonts, m.scale);
    e.cw = w;
    e.ch = h;
    let s = e.s;
    let mk = |tool, color, size, pts: Vec<(f32, f32)>, text: &str| Shape { tool, color, size, s, pts, text: text.into() };
    let wave: Vec<(f32, f32)> = (0..40).map(|i| (80.0 + i as f32 * 8.0, 520.0 + (i as f32 * 0.4).sin() * 30.0)).collect();
    for sh in [
        mk(Tool::Rect, 0, 1, vec![(60.0, 60.0), (420.0, 260.0)], ""),
        mk(Tool::Arrow, 0, 1, vec![(700.0, 420.0), (440.0, 250.0)], ""),
        mk(Tool::Ellipse, 3, 1, vec![(760.0, 80.0), (1060.0, 260.0)], ""),
        mk(Tool::Marker, 1, 1, vec![(500.0, 620.0), (900.0, 620.0)], ""),
        mk(Tool::Pen, 2, 1, wave, ""),
        mk(Tool::Pixelate, 0, 1, vec![(800.0, 300.0), (1100.0, 420.0)], ""),
        mk(Tool::Text, 0, 1, vec![(560.0, 520.0)], "Смотри сюда"),
    ] {
        commit(&mut e, sh);
    }
    e.live = Some(mk(Tool::Text, 4, 2, vec![(100.0, 700.0)], "Печатаю…"));
    e.typing = true;
    e.hover = Some(Btn::Tool(0));
    prepare_view(&mut e);
    let mut out = Img::new(w as u32, h as u32);
    let mut pm = out.pixmap_mut()?;
    compose(&e, &mut pm);
    Some(out)
}
