//! Хранилище снимков: сетка по дням, просмотр, перетаскивание файлов в любые программы.
//! Каждый снимок MacShot попадает сюда жёсткой ссылкой на файл из «Снимков экрана»:
//! удаление там не трогает хранилище, а правки в разметке видны в обоих местах.

use std::cell::RefCell;
use std::ffi::c_void;
use std::path::{Path, PathBuf};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::time::SystemTime;

use tiny_skia::{FillRule, FilterQuality, Paint, Pattern, PixmapMut, SpreadMode, Transform};
use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Dwm::{DwmSetWindowAttribute, DWMWA_USE_IMMERSIVE_DARK_MODE};
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::Com::IDataObject;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::System::Ole::DROPEFFECT_COPY;
use windows::Win32::System::SystemInformation::GetLocalTime;
use windows::Win32::System::Time::{FileTimeToSystemTime, SystemTimeToTzSpecificLocalTime};
use windows::Win32::UI::Controls::WM_MOUSELEAVE;
use windows::Win32::UI::HiDpi::AdjustWindowRectExForDpi;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::Shell::Common::ITEMIDLIST;
use windows::Win32::UI::Shell::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::capture::{self, pcwstr, wide, Surface};
use crate::gfx::{self, Fonts, Icon, Img};

const WM_THUMB: u32 = WM_APP + 10;
const TIMER_SCROLL: usize = 1;

// разметка в логических пикселях
const HEADER: f32 = 72.0;
const PAD: f32 = 28.0;
const GAP: f32 = 14.0;
const SEC: f32 = 46.0;
const CAP: f32 = 30.0;
const INSET: f32 = 7.0;
const ASPECT: f32 = 0.625;
const ZOOM: (f32, f32, f32) = (150.0, 210.0, 320.0);
const THUMB: (u32, u32) = (420, 280);
/// сколько миниатюр держать в памяти, прежде чем выгружать дальние
const KEEP: usize = 240;

const MONTHS: [&str; 12] = [
    "января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря",
];

// ---------- хранение ----------

fn base_dir() -> PathBuf {
    PathBuf::from(std::env::var("LOCALAPPDATA").unwrap_or_default()).join("MacShot")
}

pub fn dir() -> PathBuf {
    let d = base_dir().join("Library");
    if !d.exists() {
        let _ = std::fs::create_dir_all(&d);
        import_old(&d);
    }
    d
}

fn thumbs_dir() -> PathBuf {
    let d = base_dir().join("thumbs");
    let _ = std::fs::create_dir_all(&d);
    d
}

/// Первый запуск: забираем снимки MacShot, сделанные до появления хранилища
fn import_old(lib: &Path) {
    let Ok(rd) = std::fs::read_dir(capture::screenshots_dir()) else { return };
    for e in rd.flatten() {
        let name = e.file_name().to_string_lossy().into_owned();
        if parse_name(&name).is_some() && name.ends_with(".png") {
            link_or_copy(&e.path(), &lib.join(&name));
        }
    }
}

fn link_or_copy(src: &Path, dst: &Path) -> bool {
    std::fs::hard_link(src, dst).is_ok() || std::fs::copy(src, dst).is_ok()
}

/// Новый снимок в хранилище; окно, если открыто, сразу его покажет
pub fn add(src: &Path) {
    let lib = dir();
    let Some(name) = src.file_stem().map(|s| s.to_string_lossy().into_owned()) else { return };
    let mut dst = lib.join(format!("{name}.png"));
    let mut n = 2;
    while dst.exists() {
        dst = lib.join(format!("{name} ({n}).png"));
        n += 1;
    }
    link_or_copy(src, &dst);
    with(|l| {
        refresh(l);
        redraw(l);
    });
}

// ---------- время ----------

#[derive(Clone, Copy, Default, PartialEq, PartialOrd)]
struct Stamp {
    y: i32,
    mo: u32,
    d: u32,
    h: u32,
    mi: u32,
    s: u32,
}

impl Stamp {
    fn day(&self) -> i64 {
        // дни от эпохи по алгоритму Хиннанта — нужно только чтобы понять «сегодня/вчера»
        let (y, m) = if self.mo <= 2 { (self.y as i64 - 1, self.mo as i64 + 9) } else { (self.y as i64, self.mo as i64 - 3) };
        let era = y.div_euclid(400);
        let yoe = y - era * 400;
        let doy = (153 * m + 2) / 5 + self.d as i64 - 1;
        era * 146097 + yoe * 365 + yoe / 4 - yoe / 100 + doy
    }
}

/// «Снимок экрана 2026-10-11 в 14.03.22» (+ « (2)») → время из имени
fn parse_name(name: &str) -> Option<Stamp> {
    let rest = name.strip_prefix("Снимок экрана ")?;
    let (date, rest) = rest.split_once(" в ")?;
    let mut d = date.split('-').map(|v| v.parse::<u32>().ok());
    let (y, mo, day) = (d.next()??, d.next()??, d.next()??);
    let t: String = rest.chars().take(8).collect();
    let mut t = t.split('.').map(|v| v.parse::<u32>().ok());
    let (h, mi, s) = (t.next()??, t.next()??, t.next()??);
    Some(Stamp { y: y as i32, mo, d: day, h, mi, s })
}

fn local_stamp(t: SystemTime) -> Stamp {
    let since = t.duration_since(SystemTime::UNIX_EPOCH).unwrap_or_default();
    let ticks = (since.as_secs() + 11_644_473_600) * 10_000_000 + since.subsec_nanos() as u64 / 100;
    let ft = FILETIME { dwLowDateTime: ticks as u32, dwHighDateTime: (ticks >> 32) as u32 };
    unsafe {
        let mut utc = SYSTEMTIME::default();
        let mut local = SYSTEMTIME::default();
        if FileTimeToSystemTime(&ft, &mut utc).is_err() || SystemTimeToTzSpecificLocalTime(None, &utc, &mut local).is_err() {
            return Stamp::default();
        }
        Stamp {
            y: local.wYear as i32,
            mo: local.wMonth as u32,
            d: local.wDay as u32,
            h: local.wHour as u32,
            mi: local.wMinute as u32,
            s: local.wSecond as u32,
        }
    }
}

fn today() -> Stamp {
    let t = unsafe { GetLocalTime() };
    Stamp { y: t.wYear as i32, mo: t.wMonth as u32, d: t.wDay as u32, ..Default::default() }
}

fn day_title(st: &Stamp) -> String {
    let now = today();
    match now.day() - st.day() {
        0 => "Сегодня".into(),
        1 => "Вчера".into(),
        _ if st.y == now.y => format!("{} {}", st.d, MONTHS[(st.mo as usize).clamp(1, 12) - 1]),
        _ => format!("{} {} {}", st.d, MONTHS[(st.mo as usize).clamp(1, 12) - 1], st.y),
    }
}

fn plural(n: usize, forms: [&str; 3]) -> String {
    let (m10, m100) = (n % 10, n % 100);
    let f = if m10 == 1 && m100 != 11 {
        forms[0]
    } else if (2..=4).contains(&m10) && !(12..=14).contains(&m100) {
        forms[1]
    } else {
        forms[2]
    };
    format!("{n} {f}")
}

// ---------- модель ----------

enum Thumb {
    None,
    Pending,
    Ready(Img),
}

struct Item {
    path: PathBuf,
    mtime: SystemTime,
    when: Stamp,
    w: u32,
    h: u32,
    thumb: Thumb,
    /// миниатюра, ужатая ровно под текущий размер плитки
    fit: Option<Img>,
    sel: bool,
}

/// Размер картинки прямо из заголовка PNG, не распаковывая файл
fn png_size(p: &Path) -> (u32, u32) {
    use std::io::Read;
    let mut b = [0u8; 24];
    let ok = std::fs::File::open(p).and_then(|mut f| f.read_exact(&mut b)).is_ok();
    if !ok || &b[1..4] != b"PNG" {
        return (0, 0);
    }
    let be = |i: usize| u32::from_be_bytes([b[i], b[i + 1], b[i + 2], b[i + 3]]);
    (be(16), be(20))
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum Btn {
    Folder,
    Copy,
    Delete,
    Clear,
    Back,
    Prev,
    Next,
    Edit,
    Reveal,
}

impl Btn {
    fn label(self) -> &'static str {
        match self {
            Btn::Folder => "Открыть папку",
            Btn::Copy => "Копировать",
            Btn::Delete => "Удалить",
            Btn::Clear => "Снять выбор",
            Btn::Back => "‹  Все снимки",
            Btn::Prev => "‹",
            Btn::Next => "›",
            Btn::Edit => "Разметка",
            Btn::Reveal => "Показать в папке",
        }
    }
}

#[derive(Clone, Copy, PartialEq)]
enum Hit {
    None,
    Btn(Btn),
    Tile(usize),
    Bar,
    Image,
}

struct Press {
    hit: Hit,
    x: i32,
    y: i32,
    /// клик по уже выбранной плитке без модификаторов: сбросить остальных только если не начали тащить
    collapse: bool,
}

struct Viewer {
    idx: usize,
    full: Img,
    fit: Option<Img>,
}

struct Lib {
    hwnd: HWND,
    fonts: Fonts,
    s: f32,
    cw: i32,
    ch: i32,
    frame: Option<Surface>,
    items: Vec<Item>,
    scroll: f32,
    target: f32,
    zoom: f32,
    anchor: Option<usize>,
    hover: Hit,
    press: Option<Press>,
    bar_drag: Option<(i32, f32)>,
    view: Option<Viewer>,
    jobs: Option<Sender<PathBuf>>,
    results: Option<Receiver<(PathBuf, Option<Img>)>>,
}

thread_local! {
    static LIB: RefCell<Option<Lib>> = const { RefCell::new(None) };
}

fn with<R>(f: impl FnOnce(&mut Lib) -> R) -> Option<R> {
    LIB.with(|s| s.try_borrow_mut().ok()?.as_mut().map(f))
}

fn new_lib(fonts: Fonts, s: f32) -> Lib {
    Lib {
        hwnd: HWND::default(),
        fonts,
        s,
        cw: 0,
        ch: 0,
        frame: None,
        items: Vec::new(),
        scroll: 0.0,
        target: 0.0,
        zoom: ZOOM.1,
        anchor: None,
        hover: Hit::None,
        press: None,
        bar_drag: None,
        view: None,
        jobs: None,
        results: None,
    }
}

/// Перечитать папку: новые файлы добавить, исчезнувшие убрать, изменённые — перерисовать
fn refresh(l: &mut Lib) {
    let mut old: Vec<Item> = std::mem::take(&mut l.items);
    let viewing = l.view.as_ref().map(|v| old[v.idx].path.clone());
    let mut items = Vec::new();
    if let Ok(rd) = std::fs::read_dir(dir()) {
        for e in rd.flatten() {
            let path = e.path();
            if !path.extension().is_some_and(|x| x.eq_ignore_ascii_case("png")) {
                continue;
            }
            let mtime = e.metadata().and_then(|m| m.modified()).unwrap_or(SystemTime::UNIX_EPOCH);
            if let Some(i) = old.iter().position(|it| it.path == path) {
                let mut it = old.swap_remove(i);
                if it.mtime != mtime {
                    it.mtime = mtime;
                    (it.w, it.h) = png_size(&path);
                    it.thumb = Thumb::None;
                    it.fit = None;
                }
                items.push(it);
                continue;
            }
            let name = path.file_stem().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
            let when = parse_name(&name).unwrap_or_else(|| local_stamp(mtime));
            let (w, h) = png_size(&path);
            items.push(Item { path, mtime, when, w, h, thumb: Thumb::None, fit: None, sel: false });
        }
    }
    items.sort_by(|a, b| b.when.partial_cmp(&a.when).unwrap_or(std::cmp::Ordering::Equal).then(b.path.cmp(&a.path)));
    l.items = items;
    l.anchor = None;
    if let Some(p) = viewing {
        match l.items.iter().position(|it| it.path == p) {
            Some(i) => {
                if let Some(v) = l.view.as_mut() {
                    v.idx = i;
                }
            }
            None => l.view = None,
        }
    }
    clamp_scroll(l);
}

// ---------- миниатюры в фоне ----------

fn load_thumb(src: &Path) -> Option<Img> {
    let cache = thumbs_dir().join(src.file_name()?);
    let src_time = std::fs::metadata(src).and_then(|m| m.modified()).ok();
    let cache_time = std::fs::metadata(&cache).and_then(|m| m.modified()).ok();
    if cache_time.is_some() && cache_time >= src_time {
        if let Some(img) = capture::load_png(&cache) {
            return Some(img);
        }
    }
    let img = capture::load_png(src)?;
    let k = (THUMB.0 as f32 / img.w as f32).min(THUMB.1 as f32 / img.h as f32).min(1.0);
    let small = if k < 1.0 {
        img.downscale((img.w as f32 * k).round() as u32, (img.h as f32 * k).round() as u32)
    } else {
        img
    };
    if let Some(png) = capture::encode_png(&small) {
        let _ = std::fs::write(&cache, png);
    }
    Some(small)
}

fn start_worker(l: &mut Lib) {
    let (jtx, jrx) = channel::<PathBuf>();
    let (rtx, rrx) = channel();
    let hwnd = l.hwnd.0 as isize;
    std::thread::spawn(move || {
        for p in jrx {
            let img = load_thumb(&p);
            if rtx.send((p, img)).is_err() {
                break;
            }
            unsafe {
                let _ = PostMessageW(Some(HWND(hwnd as *mut c_void)), WM_THUMB, WPARAM(0), LPARAM(0));
            }
        }
    });
    l.jobs = Some(jtx);
    l.results = Some(rrx);
}

fn take_thumbs(l: &mut Lib) {
    let Some(rx) = l.results.as_ref() else { return };
    let got: Vec<_> = rx.try_iter().collect();
    for (p, img) in got {
        if let Some(it) = l.items.iter_mut().find(|it| it.path == p) {
            it.fit = None;
            it.thumb = match img {
                Some(i) => Thumb::Ready(i),
                // битый файл: больше не просим, плитка останется пустой
                None => Thumb::Ready(Img::new(1, 1)),
            };
        }
    }
}

// ---------- геометрия ----------

struct Geo {
    /// (y, первый элемент, сколько) для каждого дня
    secs: Vec<(f32, usize, usize)>,
    tiles: Vec<[f32; 4]>,
    img_h: f32,
    total: f32,
    cols: usize,
}

fn geo(l: &Lib) -> Geo {
    let s = l.s;
    let avail = (l.cw as f32 - PAD * 2.0 * s).max(100.0);
    let cols = ((avail + GAP * s) / ((l.zoom + GAP) * s)).floor().max(1.0) as usize;
    let tw = ((avail - GAP * s * (cols - 1) as f32) / cols as f32).floor();
    let img_h = ((tw - INSET * 2.0 * s) * ASPECT).round();
    let th = INSET * s + img_h + CAP * s;
    let mut secs = Vec::new();
    let mut tiles = Vec::with_capacity(l.items.len());
    let mut y = 6.0 * s;
    let mut i = 0;
    while i < l.items.len() {
        let day = l.items[i].when.day();
        let n = l.items[i..].iter().take_while(|it| it.when.day() == day).count();
        secs.push((y, i, n));
        y += SEC * s;
        for k in 0..n {
            let (col, row) = ((k % cols) as f32, (k / cols) as f32);
            tiles.push([PAD * s + col * (tw + GAP * s), y + row * (th + GAP * s), tw, th]);
        }
        let rows = n.div_ceil(cols) as f32;
        y += rows * (th + GAP * s) - GAP * s + 22.0 * s;
        i += n;
    }
    Geo { secs, tiles, img_h, total: y + PAD * s, cols }
}

fn view_h(l: &Lib) -> f32 {
    (l.ch as f32 - HEADER * l.s).max(1.0)
}

fn max_scroll(l: &Lib) -> f32 {
    (geo(l).total - view_h(l)).max(0.0)
}

fn clamp_scroll(l: &mut Lib) {
    let m = max_scroll(l);
    l.target = l.target.clamp(0.0, m);
    l.scroll = l.scroll.clamp(0.0, m);
}

/// Кнопки шапки справа налево
fn buttons(l: &Lib) -> Vec<(Btn, [f32; 4])> {
    let s = l.s;
    let px = 14.0 * s;
    let h = 34.0 * s;
    let y = (HEADER * s - h) / 2.0;
    let list: Vec<Btn> = if l.view.is_some() {
        vec![Btn::Delete, Btn::Reveal, Btn::Copy, Btn::Edit, Btn::Next, Btn::Prev]
    } else {
        let n = l.items.iter().filter(|it| it.sel).count();
        match n {
            0 => vec![Btn::Folder],
            1 => vec![Btn::Folder, Btn::Delete, Btn::Copy, Btn::Clear],
            _ => vec![Btn::Folder, Btn::Delete, Btn::Clear],
        }
    };
    let mut x = l.cw as f32 - PAD * s;
    let mut out = Vec::new();
    for b in list {
        let w = match b {
            Btn::Prev | Btn::Next => h,
            _ => gfx::measure(&l.fonts.regular, b.label(), px) + 28.0 * s,
        };
        x -= w;
        out.push((b, [x, y, w, h]));
        x -= 8.0 * s;
    }
    if l.view.is_some() {
        let w = gfx::measure(&l.fonts.regular, Btn::Back.label(), px) + 28.0 * s;
        out.push((Btn::Back, [PAD * s - 10.0 * s, y, w, h]));
    }
    out
}

fn inside(r: &[f32; 4], x: f32, y: f32) -> bool {
    x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]
}

/// Где на экране картинка в режиме просмотра
fn view_rect(l: &Lib) -> Option<[f32; 4]> {
    let v = l.view.as_ref()?;
    let s = l.s;
    let (top, pad) = (HEADER * s, 28.0 * s);
    let aw = (l.cw as f32 - pad * 2.0).max(1.0);
    let ah = (l.ch as f32 - top - pad * 2.0).max(1.0);
    let k = (aw / v.full.w as f32).min(ah / v.full.h as f32).min(1.0);
    let (w, h) = ((v.full.w as f32 * k).round().max(1.0), (v.full.h as f32 * k).round().max(1.0));
    Some([((l.cw as f32 - w) / 2.0).round(), (top + (l.ch as f32 - top - h) / 2.0).round(), w, h])
}

fn scrollbar(l: &Lib, g: &Geo) -> Option<[f32; 4]> {
    let vh = view_h(l);
    if g.total <= vh {
        return None;
    }
    let s = l.s;
    let top = HEADER * l.s + 6.0 * s;
    let track = vh - 12.0 * s;
    let len = (vh / g.total * track).max(40.0 * s);
    let pos = top + (track - len) * (l.scroll / (g.total - vh)).clamp(0.0, 1.0);
    Some([l.cw as f32 - 12.0 * s, pos, 8.0 * s, len])
}

fn hit(l: &Lib, x: i32, y: i32) -> Hit {
    let (x, y) = (x as f32, y as f32);
    for (b, r) in buttons(l) {
        if inside(&r, x, y) {
            return Hit::Btn(b);
        }
    }
    if y < HEADER * l.s {
        return Hit::None;
    }
    if l.view.is_some() {
        return match view_rect(l) {
            Some(r) if inside(&r, x, y) => Hit::Image,
            _ => Hit::None,
        };
    }
    let g = geo(l);
    if let Some(bar) = scrollbar(l, &g) {
        if x >= bar[0] - 4.0 * l.s {
            return Hit::Bar;
        }
    }
    let cy = y - HEADER * l.s + l.scroll;
    match g.tiles.iter().position(|r| inside(r, x, cy)) {
        Some(i) => Hit::Tile(i),
        None => Hit::None,
    }
}

// ---------- отрисовка ----------

fn white(a: f32) -> tiny_skia::Color {
    gfx::white(a)
}

/// Подготовка перед кадром: заказать недостающие миниатюры, ужать готовые под плитки, выгрузить дальние
fn prepare(l: &mut Lib) {
    take_thumbs(l);
    if let (Some(r), Some(v)) = (view_rect(l), l.view.as_mut()) {
        let (w, h) = (r[2] as u32, r[3] as u32);
        if (w, h) != (v.full.w, v.full.h) && v.fit.as_ref().is_none_or(|f| (f.w, f.h) != (w, h)) {
            v.fit = Some(v.full.downscale(w, h));
        }
        return;
    }
    let g = geo(l);
    let vh = view_h(l);
    let (lo, hi) = (l.scroll - vh, l.scroll + vh * 2.0);
    let s = l.s;
    let bw = |r: &[f32; 4]| r[2] - INSET * 2.0 * s;
    for (i, r) in g.tiles.iter().enumerate() {
        let near = r[1] + r[3] >= lo && r[1] <= hi;
        let it = &mut l.items[i];
        if !near {
            continue;
        }
        match &it.thumb {
            Thumb::None => {
                if let Some(tx) = &l.jobs {
                    if tx.send(it.path.clone()).is_ok() {
                        it.thumb = Thumb::Pending;
                    }
                }
            }
            Thumb::Pending => {}
            Thumb::Ready(t) => {
                let k = (bw(r) / t.w as f32).min(g.img_h / t.h as f32);
                let (fw, fh) = ((t.w as f32 * k).round().max(1.0) as u32, (t.h as f32 * k).round().max(1.0) as u32);
                if it.fit.as_ref().is_none_or(|f| (f.w, f.h) != (fw, fh)) {
                    it.fit = Some(t.downscale(fw, fh));
                }
            }
        }
    }
    let ready = l.items.iter().filter(|it| matches!(it.thumb, Thumb::Ready(_))).count();
    if ready > KEEP {
        let (lo, hi) = (l.scroll - vh * 3.0, l.scroll + vh * 4.0);
        for (i, r) in g.tiles.iter().enumerate() {
            if r[1] + r[3] < lo || r[1] > hi {
                let it = &mut l.items[i];
                if matches!(it.thumb, Thumb::Ready(_)) {
                    it.thumb = Thumb::None;
                    it.fit = None;
                }
            }
        }
    }
}

fn draw_img(pm: &mut PixmapMut, img: &Img, x: f32, y: f32, radius: f32) {
    let Some(src) = img.pixmap() else { return };
    let Some(path) = gfx::rrect(x, y, img.w as f32, img.h as f32, radius) else { return };
    let paint = Paint {
        shader: Pattern::new(src, SpreadMode::Pad, FilterQuality::Nearest, 1.0, Transform::from_translate(x, y)),
        anti_alias: true,
        ..Default::default()
    };
    pm.fill_path(&path, &paint, FillRule::Winding, Transform::identity(), None);
}

fn button(l: &Lib, pm: &mut PixmapMut, b: Btn, r: &[f32; 4]) {
    let s = l.s;
    let hover = l.hover == Hit::Btn(b);
    let pressed = hover && l.press.as_ref().is_some_and(|p| p.hit == Hit::Btn(b));
    let bg = match (b, hover) {
        (Btn::Delete, true) => gfx::danger(if pressed { 0.85 } else { 1.0 }),
        (Btn::Back, false) => white(0.0),
        (_, true) => white(if pressed { 0.16 } else { 0.11 }),
        _ => white(0.06),
    };
    gfx::fill_rrect(pm, r[0], r[1], r[2], r[3], r[3] / 2.0, bg);
    let px = match b {
        Btn::Prev | Btn::Next => 22.0 * s,
        _ => 14.0 * s,
    };
    let tw = gfx::measure(&l.fonts.regular, b.label(), px);
    let color = if b == Btn::Delete && hover { gfx::pure(1.0) } else { white(0.92) };
    let base = r[1] + r[3] / 2.0 + px * if px > 16.0 * s { 0.30 } else { 0.36 };
    gfx::text(pm, &l.fonts.regular, b.label(), r[0] + (r[2] - tw) / 2.0, base, px, color);
}

fn compose(l: &Lib, pm: &mut PixmapMut) {
    gfx::use_theme(true);
    let s = l.s;
    let (w, h) = (l.cw as f32, l.ch as f32);
    pm.fill(gfx::base());
    if l.view.is_some() {
        compose_view(l, pm);
    } else if l.items.is_empty() {
        let cy = h / 2.0;
        let isz = 56.0 * s;
        gfx::icon(pm, Icon::Area, (w - isz) / 2.0, cy - isz - 20.0 * s, isz, white(0.35));
        let t = "Пока пусто";
        let px = 20.0 * s;
        gfx::text(pm, &l.fonts.semibold, t, (w - gfx::measure(&l.fonts.semibold, t, px)) / 2.0, cy + 14.0 * s, px, white(0.9));
        let t = "Снимки, сделанные через Win+Shift+S, появятся здесь сами";
        let px = 14.0 * s;
        gfx::text(pm, &l.fonts.regular, t, (w - gfx::measure(&l.fonts.regular, t, px)) / 2.0, cy + 42.0 * s, px, white(0.5));
    } else {
        compose_grid(l, pm);
    }

    // шапка поверх прокручиваемого содержимого
    gfx::fill_rrect(pm, 0.0, 0.0, w, HEADER * s, 0.0, gfx::base());
    if l.scroll > 1.0 || l.view.is_some() {
        gfx::fill_rrect(pm, 0.0, HEADER * s - 1.0, w, 1.0, 0.0, white(0.07));
    }
    let base = HEADER * s / 2.0 + 8.0 * s;
    if let Some(v) = &l.view {
        let it = &l.items[v.idx];
        let st = it.when;
        let title = format!("{}, {:02}:{:02}", day_title(&st), st.h, st.mi);
        let back = buttons(l).into_iter().find(|(b, _)| *b == Btn::Back).map(|(_, r)| r[0] + r[2]).unwrap_or(PAD * s);
        let x = back + 18.0 * s;
        gfx::text(pm, &l.fonts.semibold, &title, x, base - 1.0 * s, 17.0 * s, white(0.95));
        let tw = gfx::measure(&l.fonts.semibold, &title, 17.0 * s);
        let sub = format!("{} × {}  ·  {} из {}", it.w, it.h, v.idx + 1, l.items.len());
        gfx::text(pm, &l.fonts.regular, &sub, x + tw + 12.0 * s, base - 1.0 * s, 13.0 * s, white(0.45));
    } else {
        let title = "Хранилище";
        gfx::text(pm, &l.fonts.semibold, title, PAD * s, base, 24.0 * s, white(0.96));
        let tw = gfx::measure(&l.fonts.semibold, title, 24.0 * s);
        let n = l.items.iter().filter(|it| it.sel).count();
        let sub = if n > 0 {
            format!("выбрано {} — перетащите в любое окно", n)
        } else {
            plural(l.items.len(), ["снимок", "снимка", "снимков"])
        };
        let color = if n > 0 { gfx::accent(1.0) } else { white(0.45) };
        gfx::text(pm, &l.fonts.regular, &sub, PAD * s + tw + 14.0 * s, base, 14.0 * s, color);
    }
    for (b, r) in buttons(l) {
        button(l, pm, b, &r);
    }
}

fn compose_grid(l: &Lib, pm: &mut PixmapMut) {
    let s = l.s;
    let g = geo(l);
    let top = HEADER * s;
    let off = top - l.scroll;
    for &(y, first, n) in &g.secs {
        let sy = off + y;
        if sy > l.ch as f32 || sy + SEC * s < top {
            continue;
        }
        let title = day_title(&l.items[first].when);
        let base = sy + SEC * s - 16.0 * s;
        gfx::text(pm, &l.fonts.semibold, &title, PAD * s, base, 17.0 * s, white(0.92));
        let tw = gfx::measure(&l.fonts.semibold, &title, 17.0 * s);
        gfx::text(pm, &l.fonts.regular, &n.to_string(), PAD * s + tw + 10.0 * s, base, 14.0 * s, white(0.38));
    }
    for (i, r) in g.tiles.iter().enumerate() {
        let (x, y) = (r[0], off + r[1]);
        if y > l.ch as f32 || y + r[3] < top - 2.0 {
            continue;
        }
        let it = &l.items[i];
        let hover = l.hover == Hit::Tile(i);
        let rad = 12.0 * s;
        let bg = if it.sel {
            gfx::selected()
        } else if hover {
            gfx::hover()
        } else {
            white(0.035)
        };
        gfx::fill_rrect(pm, x, y, r[2], r[3], rad, bg);
        let (bx, by, bw, bh) = (x + INSET * s, y + INSET * s, r[2] - INSET * 2.0 * s, g.img_h);
        match (&it.thumb, &it.fit) {
            (Thumb::Ready(_), Some(f)) if f.w > 1 => {
                let fx = (bx + (bw - f.w as f32) / 2.0).round();
                let fy = (by + (bh - f.h as f32) / 2.0).round();
                draw_img(pm, f, fx, fy, 6.0 * s);
                gfx::stroke_rrect(pm, fx + 0.5, fy + 0.5, f.w as f32 - 1.0, f.h as f32 - 1.0, 6.0 * s, 1.0, white(0.06));
            }
            _ => gfx::fill_rrect(pm, bx, by, bw, bh, 6.0 * s, white(0.06)),
        }
        let cap = by + bh + 20.0 * s;
        let time = format!("{:02}:{:02}", it.when.h, it.when.mi);
        gfx::text(pm, &l.fonts.semibold, &time, bx + 3.0 * s, cap, 13.0 * s, white(0.88));
        let dims = format!("{} × {}", it.w, it.h);
        let dw = gfx::measure(&l.fonts.regular, &dims, 12.0 * s);
        gfx::text(pm, &l.fonts.regular, &dims, bx + bw - dw - 3.0 * s, cap, 12.0 * s, white(0.4));
        if it.sel {
            gfx::stroke_rrect(pm, x + 1.0 * s, y + 1.0 * s, r[2] - 2.0 * s, r[3] - 2.0 * s, rad - 1.0 * s, 2.0 * s, gfx::accent(1.0));
            // галочка в углу, как в «Фото»
            let (cx, cy, cr) = (x + r[2] - 18.0 * s, y + 18.0 * s, 10.0 * s);
            if let Some(c) = tiny_skia::PathBuilder::from_circle(cx, cy, cr) {
                pm.fill_path(&c, &gfx::solid(gfx::accent(1.0)), FillRule::Winding, Transform::identity(), None);
            }
            let mut pb = tiny_skia::PathBuilder::new();
            pb.move_to(cx - 4.5 * s, cy + 0.2 * s);
            pb.line_to(cx - 1.2 * s, cy + 3.5 * s);
            pb.line_to(cx + 4.8 * s, cy - 3.2 * s);
            if let Some(p) = pb.finish() {
                pm.stroke_path(&p, &gfx::solid(gfx::on_accent(1.0)), &gfx::stroke(2.0 * s), Transform::identity(), None);
            }
        }
    }
    if let Some(bar) = scrollbar(l, &g) {
        let active = l.hover == Hit::Bar || l.bar_drag.is_some();
        let bw = if active { 8.0 * s } else { 5.0 * s };
        gfx::fill_rrect(pm, bar[0] + bar[2] - bw, bar[1], bw, bar[3], bw / 2.0, white(if active { 0.34 } else { 0.16 }));
    }
}

fn compose_view(l: &Lib, pm: &mut PixmapMut) {
    let s = l.s;
    let (Some(v), Some(r)) = (&l.view, view_rect(l)) else { return };
    gfx::shadow(pm, r[0], r[1] + 8.0 * s, r[2], r[3], 30.0 * s, 0.5);
    let img = v.fit.as_ref().filter(|f| (f.w, f.h) == (r[2] as u32, r[3] as u32)).unwrap_or(&v.full);
    draw_img(pm, img, r[0], r[1], 6.0 * s);
    if l.hover == Hit::Image {
        let t = "Перетащите, чтобы вставить в чат или папку";
        let px = 13.0 * s;
        let cy = (r[1] + r[3] - 26.0 * s).min(l.ch as f32 - 24.0 * s);
        gfx::pill(pm, &l.fonts.regular, t, r[0] + r[2] / 2.0, cy, px, s);
    }
}

fn paint(l: &mut Lib, hdc: HDC) {
    if l.cw <= 0 || l.ch <= 0 {
        return;
    }
    if l.frame.as_ref().is_none_or(|f| f.w != l.cw || f.h != l.ch) {
        l.frame = Surface::new(l.cw, l.ch);
    }
    prepare(l);
    let Some(frame) = l.frame.as_ref() else { return };
    let data = unsafe { frame.pixels() };
    if let Some(mut pm) = PixmapMut::from_bytes(data, l.cw as u32, l.ch as u32) {
        compose(l, &mut pm);
    }
    unsafe {
        let _ = BitBlt(hdc, 0, 0, l.cw, l.ch, Some(frame.dc), 0, 0, SRCCOPY);
    }
}

fn redraw(l: &Lib) {
    unsafe {
        let _ = InvalidateRect(Some(l.hwnd), None, false);
    }
}

// ---------- действия ----------

fn selected(l: &Lib) -> Vec<PathBuf> {
    if let Some(v) = &l.view {
        return vec![l.items[v.idx].path.clone()];
    }
    l.items.iter().filter(|it| it.sel).map(|it| it.path.clone()).collect()
}

fn select_only(l: &mut Lib, i: usize) {
    for (k, it) in l.items.iter_mut().enumerate() {
        it.sel = k == i;
    }
    l.anchor = Some(i);
}

fn clear_sel(l: &mut Lib) {
    for it in &mut l.items {
        it.sel = false;
    }
    l.anchor = None;
}

fn open_view(l: &mut Lib, i: usize) {
    let Some(it) = l.items.get(i) else { return };
    let Some(full) = capture::load_png(&it.path) else { return };
    select_only(l, i);
    l.view = Some(Viewer { idx: i, full, fit: None });
}

fn step_view(l: &mut Lib, d: i32) {
    let Some(v) = &l.view else { return };
    let n = l.items.len() as i32;
    let i = v.idx as i32 + d;
    if i >= 0 && i < n {
        open_view(l, i as usize);
    }
}

/// Прокрутить так, чтобы плитка была видна целиком
fn reveal(l: &mut Lib, i: usize) {
    let g = geo(l);
    let Some(r) = g.tiles.get(i) else { return };
    let vh = view_h(l);
    // заголовок дня тоже должен быть виден у первой строки
    let pad = SEC * l.s;
    if r[1] - pad < l.target {
        l.target = r[1] - pad;
    } else if r[1] + r[3] + 12.0 * l.s > l.target + vh {
        l.target = r[1] + r[3] + 12.0 * l.s - vh;
    }
    clamp_scroll(l);
    animate(l);
}

fn animate(l: &Lib) {
    unsafe {
        SetTimer(Some(l.hwnd), TIMER_SCROLL, 15, None);
    }
}

fn copy_file(l: &Lib, p: &Path) {
    if let (Ok(png), Some(img)) = (std::fs::read(p), capture::load_png(p)) {
        capture::to_clipboard(&img, &png, l.hwnd);
    }
}

fn recycle(hwnd: HWND, paths: &[PathBuf]) {
    let mut from: Vec<u16> = Vec::new();
    for p in paths {
        from.extend(p.to_string_lossy().encode_utf16());
        from.push(0);
        let _ = std::fs::remove_file(thumbs_dir().join(p.file_name().unwrap_or_default()));
    }
    from.push(0);
    let mut op = SHFILEOPSTRUCTW {
        hwnd,
        wFunc: FO_DELETE,
        pFrom: windows::core::PCWSTR(from.as_ptr()),
        fFlags: (FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI).0 as u16,
        ..Default::default()
    };
    unsafe {
        let _ = SHFileOperationW(&mut op);
    }
}

/// Перетаскивание файлов средствами оболочки: работает с Telegram, Discord, браузером, проводником
fn drag_files(hwnd: HWND, paths: &[PathBuf]) {
    unsafe {
        let pidls: Vec<*mut ITEMIDLIST> = paths
            .iter()
            .map(|p| {
                let w = wide(&p.to_string_lossy());
                ILCreateFromPathW(pcwstr(&w))
            })
            .filter(|p| !p.is_null())
            .collect();
        if pidls.is_empty() {
            return;
        }
        let list: Vec<*const ITEMIDLIST> = pidls.iter().map(|p| *p as *const ITEMIDLIST).collect();
        if let Ok(arr) = SHCreateShellItemArrayFromIDLists(&list) {
            if let Ok(data) = arr.BindToHandler::<_, IDataObject>(None, &BHID_DataObject) {
                // только копирование: иначе проводник по умолчанию переместит файл и он пропадёт из хранилища
                let _ = SHDoDragDrop(Some(hwnd), &data, None, DROPEFFECT_COPY);
            }
        }
        for p in pidls {
            ILFree(Some(p as *const ITEMIDLIST));
        }
    }
}

fn show_in_folder(p: &Path) {
    let args = wide(&format!("/select,\"{}\"", p.display()));
    unsafe {
        ShellExecuteW(None, w!("open"), w!("explorer.exe"), pcwstr(&args), None, SW_SHOWNORMAL);
    }
}

fn open_folder() {
    let d = wide(&dir().to_string_lossy());
    unsafe {
        ShellExecuteW(None, w!("open"), pcwstr(&d), None, None, SW_SHOWNORMAL);
    }
}

const MENU_VIEW: usize = 1;
const MENU_EDIT: usize = 2;
const MENU_COPY: usize = 3;
const MENU_REVEAL: usize = 4;
const MENU_OPEN: usize = 5;
const MENU_DELETE: usize = 6;

fn context_menu(hwnd: HWND, n: usize) -> usize {
    unsafe {
        let Ok(m) = CreatePopupMenu() else { return 0 };
        if n == 1 {
            let _ = AppendMenuW(m, MF_STRING, MENU_VIEW, w!("Просмотр"));
            let _ = AppendMenuW(m, MF_STRING, MENU_EDIT, w!("Разметка"));
            let _ = AppendMenuW(m, MF_STRING, MENU_COPY, w!("Копировать\tCtrl+C"));
            let _ = AppendMenuW(m, MF_STRING, MENU_OPEN, w!("Открыть в программе"));
        }
        let _ = AppendMenuW(m, MF_STRING, MENU_REVEAL, w!("Показать в папке"));
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        let del = wide(&if n == 1 { "Удалить\tDel".to_string() } else { format!("Удалить ({n})\tDel") });
        let _ = AppendMenuW(m, MF_STRING, MENU_DELETE, pcwstr(&del));
        let p = capture::cursor();
        let cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, p.x, p.y, Some(0), hwnd, None);
        let _ = DestroyMenu(m);
        cmd.0 as usize
    }
}

/// Что сделать уже после выхода из обработчика: эти вызовы крутят свой цикл сообщений
enum Act {
    None,
    Drag(Vec<PathBuf>),
    Menu,
    Btn(Btn),
    Delete,
}

fn press_btn(l: &mut Lib, b: Btn) -> Act {
    match b {
        Btn::Folder => open_folder(),
        Btn::Clear => clear_sel(l),
        Btn::Back => l.view = None,
        Btn::Prev => step_view(l, -1),
        Btn::Next => step_view(l, 1),
        Btn::Copy => {
            if let Some(p) = selected(l).first() {
                copy_file(l, p);
            }
        }
        Btn::Reveal => {
            if let Some(p) = selected(l).first() {
                show_in_folder(p);
            }
        }
        Btn::Delete => return Act::Delete,
        Btn::Edit => return Act::Btn(Btn::Edit),
    }
    Act::None
}

fn handle(l: &mut Lib, msg: u32, wp: WPARAM, lp: LPARAM) -> Act {
    let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, ((lp.0 >> 16) & 0xFFFF) as i16 as i32);
    let ctrl = unsafe { GetKeyState(VK_CONTROL.0 as i32) < 0 };
    let shift = unsafe { GetKeyState(VK_SHIFT.0 as i32) < 0 };
    match msg {
        WM_MOUSEMOVE => {
            if let Some((y0, s0)) = l.bar_drag {
                let g = geo(l);
                if let Some(bar) = scrollbar(l, &g) {
                    let track = view_h(l) - 12.0 * l.s - bar[3];
                    let k = (y - y0) as f32 / track.max(1.0);
                    l.scroll = s0 + k * (g.total - view_h(l));
                    l.target = l.scroll;
                    clamp_scroll(l);
                }
                redraw(l);
                return Act::None;
            }
            if let Some(p) = &l.press {
                let far = unsafe {
                    (x - p.x).abs() > GetSystemMetrics(SM_CXDRAG) || (y - p.y).abs() > GetSystemMetrics(SM_CYDRAG)
                };
                if far && matches!(p.hit, Hit::Tile(_) | Hit::Image) {
                    l.press = None;
                    return Act::Drag(selected(l));
                }
            }
            let h = hit(l, x, y);
            if h != l.hover {
                l.hover = h;
                unsafe {
                    let mut tme = TRACKMOUSEEVENT {
                        cbSize: std::mem::size_of::<TRACKMOUSEEVENT>() as u32,
                        dwFlags: TME_LEAVE,
                        hwndTrack: l.hwnd,
                        dwHoverTime: 0,
                    };
                    let _ = TrackMouseEvent(&mut tme);
                }
                redraw(l);
            }
            Act::None
        }
        WM_LBUTTONDOWN => {
            unsafe { SetCapture(l.hwnd) };
            let h = hit(l, x, y);
            let mut collapse = false;
            match h {
                Hit::Bar => {
                    l.bar_drag = Some((y, l.scroll));
                }
                Hit::Tile(i) => {
                    if ctrl {
                        l.items[i].sel = !l.items[i].sel;
                        l.anchor = Some(i);
                    } else if shift {
                        let a = l.anchor.unwrap_or(i);
                        for (k, it) in l.items.iter_mut().enumerate() {
                            it.sel = (a.min(i)..=a.max(i)).contains(&k);
                        }
                    } else if l.items[i].sel {
                        collapse = true;
                    } else {
                        select_only(l, i);
                    }
                }
                Hit::None if l.view.is_none() && !ctrl && !shift => clear_sel(l),
                _ => {}
            }
            l.press = Some(Press { hit: h, x, y, collapse });
            redraw(l);
            Act::None
        }
        WM_LBUTTONUP => {
            unsafe {
                let _ = ReleaseCapture();
            }
            l.bar_drag = None;
            let Some(p) = l.press.take() else { return Act::None };
            let h = hit(l, x, y);
            let act = match p.hit {
                Hit::Btn(b) if h == Hit::Btn(b) => press_btn(l, b),
                Hit::Tile(i) if p.collapse => {
                    select_only(l, i);
                    Act::None
                }
                _ => Act::None,
            };
            l.hover = hit(l, x, y);
            redraw(l);
            act
        }
        WM_LBUTTONDBLCLK => match hit(l, x, y) {
            Hit::Tile(i) => {
                open_view(l, i);
                redraw(l);
                Act::None
            }
            _ => Act::None,
        },
        WM_RBUTTONUP => match hit(l, x, y) {
            Hit::Tile(i) => {
                if !l.items[i].sel {
                    select_only(l, i);
                }
                redraw(l);
                Act::Menu
            }
            Hit::Image => Act::Menu,
            _ => Act::None,
        },
        WM_MOUSEWHEEL => {
            let delta = ((wp.0 >> 16) & 0xFFFF) as i16 as f32 / 120.0;
            if l.view.is_some() {
                step_view(l, if delta > 0.0 { -1 } else { 1 });
                redraw(l);
            } else if ctrl {
                l.zoom = (l.zoom + delta * 20.0).clamp(ZOOM.0, ZOOM.2);
                clamp_scroll(l);
                redraw(l);
            } else {
                l.target -= delta * 110.0 * l.s;
                clamp_scroll(l);
                animate(l);
            }
            Act::None
        }
        WM_KEYDOWN => {
            let vk = VIRTUAL_KEY(wp.0 as u16);
            if l.view.is_some() {
                match vk {
                    VK_ESCAPE | VK_BACK | VK_SPACE => l.view = None,
                    VK_LEFT | VK_UP => step_view(l, -1),
                    VK_RIGHT | VK_DOWN => step_view(l, 1),
                    VK_DELETE => return Act::Delete,
                    VK_E => return Act::Btn(Btn::Edit),
                    VK_C if ctrl => {
                        press_btn(l, Btn::Copy);
                    }
                    _ => return Act::None,
                }
                redraw(l);
                return Act::None;
            }
            let n = l.items.len();
            let cur = l.anchor.or_else(|| l.items.iter().position(|it| it.sel));
            let cols = geo(l).cols as i32;
            let mv = match vk {
                VK_LEFT => Some(-1),
                VK_RIGHT => Some(1),
                VK_UP => Some(-cols),
                VK_DOWN => Some(cols),
                VK_HOME => Some(-(n as i32)),
                VK_END => Some(n as i32),
                _ => None,
            };
            if let Some(d) = mv {
                if n > 0 {
                    let i = match cur {
                        Some(c) => (c as i32 + d).clamp(0, n as i32 - 1) as usize,
                        None => 0,
                    };
                    select_only(l, i);
                    reveal(l, i);
                    redraw(l);
                }
                return Act::None;
            }
            match vk {
                VK_RETURN | VK_SPACE => {
                    if let Some(c) = cur {
                        open_view(l, c);
                    }
                }
                VK_ESCAPE => clear_sel(l),
                VK_DELETE => return Act::Delete,
                VK_A if ctrl => {
                    for it in &mut l.items {
                        it.sel = true;
                    }
                }
                VK_C if ctrl => {
                    press_btn(l, Btn::Copy);
                }
                VK_OEM_PLUS | VK_ADD if ctrl => l.zoom = (l.zoom + 20.0).min(ZOOM.2),
                VK_OEM_MINUS | VK_SUBTRACT if ctrl => l.zoom = (l.zoom - 20.0).max(ZOOM.0),
                _ => return Act::None,
            }
            clamp_scroll(l);
            redraw(l);
            Act::None
        }
        _ => Act::None,
    }
}

fn run_act(hwnd: HWND, act: Act) {
    match act {
        Act::None => {}
        Act::Drag(paths) => {
            if !paths.is_empty() {
                unsafe {
                    let _ = ReleaseCapture();
                }
                drag_files(hwnd, &paths);
            }
        }
        Act::Delete => {
            let Some(paths) = with(|l| selected(l)) else { return };
            if paths.is_empty() {
                return;
            }
            recycle(hwnd, &paths);
            with(|l| {
                // в просмотре после удаления показываем соседний снимок
                let next = l.view.as_ref().map(|v| v.idx);
                l.view = None;
                refresh(l);
                if let Some(i) = next {
                    if !l.items.is_empty() {
                        open_view(l, i.min(l.items.len() - 1));
                    }
                } else {
                    clear_sel(l);
                }
                redraw(l);
            });
        }
        Act::Btn(Btn::Edit) => {
            let Some(p) = with(|l| selected(l).into_iter().next()).flatten() else { return };
            if let Some(img) = capture::load_png(&p) {
                crate::editor::open(img, p);
            }
        }
        Act::Btn(_) => {}
        Act::Menu => {
            let Some(paths) = with(|l| selected(l)) else { return };
            if paths.is_empty() {
                return;
            }
            let cmd = context_menu(hwnd, paths.len());
            let first = paths[0].clone();
            match cmd {
                MENU_VIEW => {
                    with(|l| {
                        if let Some(i) = l.items.iter().position(|it| it.path == first) {
                            open_view(l, i);
                        }
                        redraw(l);
                    });
                }
                MENU_EDIT => run_act(hwnd, Act::Btn(Btn::Edit)),
                MENU_COPY => {
                    with(|l| copy_file(l, &first));
                }
                MENU_OPEN => {
                    let f = wide(&first.to_string_lossy());
                    unsafe {
                        ShellExecuteW(None, w!("open"), pcwstr(&f), None, None, SW_SHOWNORMAL);
                    }
                }
                MENU_REVEAL => show_in_folder(&first),
                MENU_DELETE => run_act(hwnd, Act::Delete),
                _ => {}
            }
        }
    }
}

// ---------- окно ----------

pub fn init() {
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            style: CS_DBLCLKS,
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacShot.Library"),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            ..Default::default()
        };
        RegisterClassW(&wc);
    }
}

/// Показать хранилище; focus — выделить и прокрутить к этому снимку
pub fn open(focus: Option<&Path>) {
    let existing = with(|l| l.hwnd);
    if existing.is_none() {
        create();
    }
    with(|l| {
        refresh(l);
        if let Some(f) = focus.and_then(|f| f.file_name()) {
            if let Some(i) = l.items.iter().position(|it| it.path.file_name() == Some(f)) {
                l.view = None;
                select_only(l, i);
                reveal(l, i);
            }
        }
        redraw(l);
        unsafe {
            if IsIconic(l.hwnd).as_bool() {
                let _ = ShowWindow(l.hwnd, SW_RESTORE);
            }
            let _ = SetForegroundWindow(l.hwnd);
        }
    });
}

fn create() {
    let Some(fonts) = Fonts::load() else { return };
    let mon = capture::monitor_at(capture::cursor());
    let s = mon.scale;
    let mut l = new_lib(fonts, s);
    let work = mon.work;
    let (ww, wh) = ((work.right - work.left) as f32, (work.bottom - work.top) as f32);
    let (cw, ch) = ((1160.0 * s).min(ww * 0.9), (780.0 * s).min(wh * 0.9));
    unsafe {
        let mut r = RECT { left: 0, top: 0, right: cw as i32, bottom: ch as i32 };
        let _ = AdjustWindowRectExForDpi(&mut r, WS_OVERLAPPEDWINDOW, false, WINDOW_EX_STYLE(0), (s * 96.0) as u32);
        let (rw, rh) = (r.right - r.left, r.bottom - r.top);
        let x = work.left + ((ww as i32 - rw) / 2).max(0);
        let y = work.top + ((wh as i32 - rh) / 2).max(0);
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let Ok(hwnd) = CreateWindowExW(
            WINDOW_EX_STYLE(0),
            w!("MacShot.Library"),
            w!("Хранилище снимков"),
            WS_OVERLAPPEDWINDOW,
            x,
            y,
            rw,
            rh,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        gfx::use_theme(true);
        let dark: i32 = gfx::theme().dark as i32;
        let _ = DwmSetWindowAttribute(hwnd, DWMWA_USE_IMMERSIVE_DARK_MODE, &dark as *const i32 as *const c_void, 4);
        let icon = crate::app_icon();
        SendMessageW(hwnd, WM_SETICON, Some(WPARAM(ICON_BIG as usize)), Some(LPARAM(icon.0 as isize)));
        SendMessageW(hwnd, WM_SETICON, Some(WPARAM(ICON_SMALL as usize)), Some(LPARAM(icon.0 as isize)));
        let mut rc = RECT::default();
        let _ = GetClientRect(hwnd, &mut rc);
        l.hwnd = hwnd;
        l.cw = rc.right;
        l.ch = rc.bottom;
        start_worker(&mut l);
        LIB.with(|st| *st.borrow_mut() = Some(l));
        let _ = ShowWindow(hwnd, SW_SHOW);
    }
}

fn close() {
    if let Some(l) = LIB.with(|s| s.borrow_mut().take()) {
        unsafe {
            let _ = DestroyWindow(l.hwnd);
        }
        // l падает здесь: канал заданий закрывается, и фоновый поток завершается сам
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_PAINT => {
            let mut ps = PAINTSTRUCT::default();
            let hdc = BeginPaint(hwnd, &mut ps);
            with(|l| paint(l, hdc));
            let _ = EndPaint(hwnd, &ps);
            LRESULT(0)
        }
        WM_ERASEBKGND => LRESULT(1),
        WM_SIZE => {
            with(|l| {
                l.cw = (lp.0 & 0xFFFF) as i32;
                l.ch = ((lp.0 >> 16) & 0xFFFF) as i32;
                clamp_scroll(l);
                redraw(l);
            });
            LRESULT(0)
        }
        WM_GETMINMAXINFO => {
            if let Some(s) = with(|l| l.s) {
                let mmi = &mut *(lp.0 as *mut MINMAXINFO);
                mmi.ptMinTrackSize.x = (640.0 * s) as i32;
                mmi.ptMinTrackSize.y = (420.0 * s) as i32;
            }
            LRESULT(0)
        }
        WM_DPICHANGED => {
            with(|l| {
                l.s = ((wp.0 >> 16) & 0xFFFF) as f32 / 96.0;
                for it in &mut l.items {
                    it.fit = None;
                }
            });
            let r = &*(lp.0 as *const RECT);
            let _ = SetWindowPos(hwnd, None, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE);
            LRESULT(0)
        }
        WM_THUMB => {
            with(|l| redraw(l));
            LRESULT(0)
        }
        WM_TIMER if wp.0 == TIMER_SCROLL => {
            with(|l| {
                let d = l.target - l.scroll;
                if d.abs() < 0.5 {
                    l.scroll = l.target;
                    let _ = KillTimer(Some(hwnd), TIMER_SCROLL);
                } else {
                    l.scroll += d * 0.3;
                }
                redraw(l);
            });
            LRESULT(0)
        }
        WM_ACTIVATE => {
            // вернулись в окно — подхватываем правки и удаления, сделанные снаружи
            if (wp.0 & 0xFFFF) as u32 != WA_INACTIVE {
                with(|l| {
                    refresh(l);
                    redraw(l);
                });
            }
            DefWindowProcW(hwnd, msg, wp, lp)
        }
        WM_MOUSELEAVE => {
            with(|l| {
                l.hover = Hit::None;
                redraw(l);
            });
            LRESULT(0)
        }
        WM_MOUSEMOVE | WM_LBUTTONDOWN | WM_LBUTTONUP | WM_LBUTTONDBLCLK | WM_RBUTTONUP | WM_MOUSEWHEEL | WM_KEYDOWN => {
            if let Some(act) = with(|l| handle(l, msg, wp, lp)) {
                run_act(hwnd, act);
            }
            LRESULT(0)
        }
        WM_CLOSE => {
            close();
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

/// Кадр хранилища для проверки вёрстки: миниатюры грузятся сразу, без фонового потока
pub fn preview(w: i32, h: i32, mode: &str) -> Option<Img> {
    let fonts = Fonts::load()?;
    let m = capture::monitor_at(capture::cursor());
    let mut l = new_lib(fonts, m.scale);
    l.cw = w;
    l.ch = h;
    refresh(&mut l);
    let n = l.items.len().min(40);
    for it in &mut l.items[..n] {
        it.thumb = load_thumb(&it.path).map_or(Thumb::None, Thumb::Ready);
    }
    match mode {
        "view" if n > 0 => open_view(&mut l, 0),
        "select" if n > 2 => {
            l.items[1].sel = true;
            l.items[2].sel = true;
            l.hover = Hit::Tile(3.min(n - 1));
        }
        _ => l.hover = Hit::Tile(0),
    }
    prepare(&mut l);
    let mut out = Img::new(w as u32, h as u32);
    let mut pm = out.pixmap_mut()?;
    compose(&l, &mut pm);
    Some(out)
}
