//! Текст со снимка: распознавание, встроенное в Windows. Вызовы WinRT блокирующие,
//! поэтому идут в своём потоке, а окну приходит сообщение с готовым текстом

use std::sync::Mutex;

use windows::core::{Result, HSTRING};
use windows::Globalization::Language;
use windows::Graphics::Imaging::{BitmapAlphaMode, BitmapPixelFormat, SoftwareBitmap};
use windows::Media::Ocr::OcrEngine;
use windows::Storage::Streams::DataWriter;
use windows::Win32::Foundation::{HWND, LPARAM, WPARAM};
use windows::Win32::System::Com::{CoInitializeEx, COINIT_MULTITHREADED};
use windows::Win32::UI::WindowsAndMessaging::{PostMessageW, WM_APP};

use crate::gfx::Img;

pub const WM_OCR: u32 = WM_APP + 3;

static RESULT: Mutex<Option<String>> = Mutex::new(None);

/// Распознать в фоне; когда готово, окно получит WM_OCR
pub fn start(img: Img, target: HWND) {
    let target = target.0 as isize;
    std::thread::spawn(move || {
        unsafe {
            let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
        }
        let text = recognize(&img);
        if let Ok(mut r) = RESULT.lock() {
            *r = Some(text);
        }
        unsafe {
            let _ = PostMessageW(Some(HWND(target as *mut _)), WM_OCR, WPARAM(0), LPARAM(0));
        }
    });
}

pub fn take() -> Option<String> {
    RESULT.lock().ok()?.take()
}

/// Мелкий текст с экрана распознаётся заметно лучше, если картинку увеличить
fn upscale(img: &Img, k: u32) -> Img {
    let (w, h) = (img.w as usize, img.h as usize);
    let (nw, nh) = (w * k as usize, h * k as usize);
    let mut px = vec![0u8; nw * nh * 4];
    for y in 0..nh {
        let fy = (y as f32 + 0.5) / k as f32 - 0.5;
        let y0 = (fy.floor().max(0.0) as usize).min(h - 1);
        let y1 = (y0 + 1).min(h - 1);
        let ty = (fy - y0 as f32).clamp(0.0, 1.0);
        for x in 0..nw {
            let fx = (x as f32 + 0.5) / k as f32 - 0.5;
            let x0 = (fx.floor().max(0.0) as usize).min(w - 1);
            let x1 = (x0 + 1).min(w - 1);
            let tx = (fx - x0 as f32).clamp(0.0, 1.0);
            for c in 0..4 {
                let at = |xx: usize, yy: usize| img.px[(yy * w + xx) * 4 + c] as f32;
                let top = at(x0, y0) * (1.0 - tx) + at(x1, y0) * tx;
                let bottom = at(x0, y1) * (1.0 - tx) + at(x1, y1) * tx;
                px[(y * nw + x) * 4 + c] = (top * (1.0 - ty) + bottom * ty) as u8;
            }
        }
    }
    Img { w: nw as u32, h: nh as u32, px }
}

fn bitmap(img: &Img) -> Result<SoftwareBitmap> {
    let w = DataWriter::new()?;
    w.WriteBytes(&img.px)?;
    SoftwareBitmap::CreateCopyWithAlphaFromBuffer(&w.DetachBuffer()?, BitmapPixelFormat::Bgra8, img.w as i32, img.h as i32, BitmapAlphaMode::Premultiplied)
}

/// Строки текста от распознавателя одного языка
fn read_with(tag: &str, bmp: &SoftwareBitmap) -> Result<Vec<String>> {
    let lang = Language::CreateLanguage(&HSTRING::from(tag))?;
    let engine = OcrEngine::TryCreateFromLanguage(&lang)?;
    let result = engine.RecognizeAsync(bmp)?.get()?;
    let lines = result.Lines()?;
    let mut out = Vec::new();
    for i in 0..lines.Size()? {
        out.push(lines.GetAt(i)?.Text()?.to_string());
    }
    Ok(out)
}

fn languages() -> Vec<String> {
    let mut out = Vec::new();
    if let Ok(list) = OcrEngine::AvailableRecognizerLanguages() {
        for i in 0..list.Size().unwrap_or(0) {
            if let Some(tag) = list.GetAt(i).ok().and_then(|l| l.LanguageTag().ok()) {
                out.push(tag.to_string());
            }
        }
    }
    out
}

fn prepare(img: &Img) -> Option<SoftwareBitmap> {
    if img.w == 0 || img.h == 0 {
        return None;
    }
    let side = img.w.max(img.h);
    let max = OcrEngine::MaxImageDimension().unwrap_or(4000);
    let k = (if img.h < 300 { 4 } else if img.h < 1000 { 2 } else { 1 }).min((max / side).max(1));
    if k > 1 {
        bitmap(&upscale(img, k)).ok()
    } else {
        bitmap(img).ok()
    }
}

fn cyrillic(c: char) -> bool {
    ('\u{0400}'..='\u{04FF}').contains(&c)
}

/// Доля кириллицы среди букв строки
fn cyrillic_share(line: &str) -> f32 {
    let letters: Vec<char> = line.chars().filter(|c| c.is_alphabetic()).collect();
    if letters.is_empty() {
        return 0.0;
    }
    letters.iter().filter(|c| cyrillic(**c)).count() as f32 / letters.len() as f32
}

/// Русская модель хорошо читает кириллицу, а латиницу путает (l и I, 3 и З); английская — наоборот
/// и превращает русский текст в мусор. Поэтому строка собирается из лучшего, что дала каждая
fn join_line(cyr: &str, lat: &str) -> String {
    // в строке почти нет кириллицы — это английский текст, отдаём английской модели
    if cyrillic_share(cyr) < 0.3 {
        return lat.to_string();
    }
    let (a, b): (Vec<&str>, Vec<&str>) = (cyr.split_whitespace().collect(), lat.split_whitespace().collect());
    if a.len() != b.len() {
        // слова не совпали по счёту: латинское слово ищем у английской модели по похожему написанию
        let norm = |s: &str| s.to_lowercase().replace(['i', '|', '1'], "l");
        return a.iter().map(|x| if x.chars().any(cyrillic) { *x } else { b.iter().find(|y| norm(y) == norm(x)).copied().unwrap_or(*x) }).collect::<Vec<_>>().join(" ");
    }
    // слова совпали по счёту: кириллические берём у русской модели, остальные — у английской
    a.iter().zip(&b).map(|(x, y)| if x.chars().any(cyrillic) { *x } else { *y }).collect::<Vec<_>>().join(" ")
}

/// Итог по всем языкам. Первым идёт результат с наибольшим количеством кириллицы
fn merge(all: Vec<(String, Vec<String>)>) -> Vec<String> {
    let mut all: Vec<_> = all.into_iter().filter(|(_, l)| !l.is_empty()).collect();
    let is_latin = |t: &str| t.starts_with("en");
    let Some(lat) = all.iter().position(|(t, _)| is_latin(t)) else {
        return all.into_iter().next().map(|(_, l)| l).unwrap_or_default();
    };
    let lat = all.remove(lat).1;
    let Some(cyr) = all.into_iter().map(|(_, l)| l).max_by_key(|l| l.iter().flat_map(|s| s.chars()).filter(|c| cyrillic(*c)).count()) else {
        return lat;
    };
    if cyr.len() != lat.len() {
        return cyr;
    }
    cyr.iter().zip(&lat).map(|(c, l)| join_line(c, l)).collect()
}

fn recognize(img: &Img) -> String {
    let Some(bmp) = prepare(img) else { return String::new() };
    let all: Vec<(String, Vec<String>)> = languages().into_iter().filter_map(|t| read_with(&t, &bmp).ok().map(|l| (t, l))).collect();
    merge(all).join("\r\n")
}

/// Для проверки: что прочитал каждый язык и что получилось в итоге
pub fn report(img: &Img) -> String {
    let mut out = String::new();
    let Some(bmp) = prepare(img) else { return "нет картинки".into() };
    let mut all = Vec::new();
    for t in languages() {
        match read_with(&t, &bmp) {
            Ok(l) => {
                out += &format!("[{t}]\n{}\n", l.join("\n"));
                all.push((t.clone(), l));
            }
            Err(e) => out += &format!("[{t}] ошибка {e}\n"),
        }
    }
    out + &format!("[итог]\n{}\n", merge(all).join("\n"))
}
