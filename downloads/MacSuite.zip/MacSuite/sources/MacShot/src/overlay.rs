//! Полноэкранный оверлей поверх «замороженного» снимка: выбор окна, области или экрана

use std::cell::RefCell;

use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::capture::{self, contains, Monitor, Surface, Win};
use crate::gfx::{self, Fonts, Icon, Img};

#[derive(Clone, Copy, PartialEq)]
pub enum Mode {
    Window,
    Area,
    Screen,
    /// как область, но с выделенного берём текст
    Text,
}

/// Что получилось после выбора
pub enum Pick {
    Area(Img),
    Text(Img),
    Screen(Img),
    Window { win: Win, fallback: Img, scale: f32, shadow: bool },
}

const BUTTONS: [(Mode, &str); 4] = [(Mode::Window, "Окно"), (Mode::Area, "Область"), (Mode::Screen, "Весь экран"), (Mode::Text, "Текст")];

struct Overlay {
    hwnd: HWND,
    origin: (i32, i32),
    shot: Img,
    dim: Vec<u8>,
    frame: Surface,
    wins: Vec<Win>,
    mons: Vec<Monitor>,
    mode: Mode,
    toolbar: bool,
    /// монитор, на котором показываем панель, и его масштаб
    home: Monitor,
    cur: (i32, i32),
    drag: Option<(i32, i32)>,
    hover_btn: Option<usize>,
    pressed_btn: Option<usize>,
    /// кадр устарел и будет собран заново при следующем WM_PAINT
    dirty: bool,
}

thread_local! {
    static OVERLAY: RefCell<Option<Overlay>> = const { RefCell::new(None) };
    static FONTS: RefCell<Option<Fonts>> = const { RefCell::new(None) };
    static DONE: RefCell<Option<Box<dyn Fn(Pick)>>> = RefCell::new(None);
}

fn with<R>(f: impl FnOnce(&mut Overlay) -> R) -> Option<R> {
    OVERLAY.with(|s| s.try_borrow_mut().ok()?.as_mut().map(f))
}

pub fn is_open() -> bool {
    OVERLAY.with(|s| s.borrow().is_some())
}

pub fn init(fonts: Fonts, done: impl Fn(Pick) + 'static) {
    FONTS.with(|f| *f.borrow_mut() = Some(fonts));
    DONE.with(|d| *d.borrow_mut() = Some(Box::new(done)));
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacShot.Overlay"),
            ..Default::default()
        };
        RegisterClassW(&wc);
    }
}

pub fn open(mode: Mode, toolbar: bool) {
    if is_open() {
        with(|o| {
            o.mode = mode;
            o.toolbar |= toolbar;
            render(o);
        });
        return;
    }
    let vs = capture::virtual_screen();
    // окна перечисляем до появления оверлея, иначе он закроет собой всё
    let wins = capture::windows();
    let Some(shot) = capture::grab(vs) else { return };
    let (w, h) = (vs.right - vs.left, vs.bottom - vs.top);
    let Some(frame) = Surface::new(w, h) else { return };
    let off = |r: RECT| RECT { left: r.left - vs.left, top: r.top - vs.top, right: r.right - vs.left, bottom: r.bottom - vs.top };
    let wins = wins.into_iter().map(|x| Win { hwnd: x.hwnd, rect: off(x.rect) }).collect();
    let mons = capture::monitors()
        .into_iter()
        .map(|m| Monitor { rect: off(m.rect), work: off(m.work), scale: m.scale })
        .collect();
    let p = capture::cursor();
    let home = capture::monitor_at(p);
    let home = Monitor { rect: off(home.rect), work: off(home.work), scale: home.scale };
    let dim = shot.px.iter().enumerate().map(|(i, &v)| if i % 4 == 3 { 255 } else { (v as u16 * 120 / 255) as u8 }).collect();

    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let Ok(hwnd) = CreateWindowExW(
            WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
            w!("MacShot.Overlay"),
            w!("Снимок экрана"),
            WS_POPUP,
            vs.left,
            vs.top,
            w,
            h,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        let mut o = Overlay {
            hwnd,
            origin: (vs.left, vs.top),
            shot,
            dim,
            frame,
            wins,
            mons,
            mode,
            toolbar,
            home,
            cur: (p.x - vs.left, p.y - vs.top),
            drag: None,
            hover_btn: None,
            pressed_btn: None,
            dirty: true,
        };
        // первый кадр собираем сразу, чтобы окно не мелькнуло пустым
        compose(&mut o);
        o.dirty = false;
        OVERLAY.with(|s| *s.borrow_mut() = Some(o));
        let _ = ShowWindow(hwnd, SW_SHOW);
        let _ = SetForegroundWindow(hwnd);
        let _ = SetFocus(Some(hwnd));
    }
}

pub fn close() {
    let o = OVERLAY.with(|s| s.borrow_mut().take());
    if let Some(o) = o {
        unsafe {
            let _ = DestroyWindow(o.hwnd);
        }
    }
}

/// Монтаж кадра для оверлея; отдельно от окна, чтобы можно было снять превью в PNG
fn compose(o: &mut Overlay) {
    gfx::use_theme(false);
    let (w, h) = (o.frame.w, o.frame.h);
    let hl = highlight(o);
    let data = unsafe { o.frame.pixels() };
    data.copy_from_slice(&o.dim);
    if let Some(r) = hl {
        let stride = w as usize * 4;
        let (x0, x1) = (r.left.clamp(0, w) as usize * 4, r.right.clamp(0, w) as usize * 4);
        for y in r.top.clamp(0, h)..r.bottom.clamp(0, h) {
            let row = y as usize * stride;
            data[row + x0..row + x1].copy_from_slice(&o.shot.px[row + x0..row + x1]);
        }
    }
    let scale = o.home.scale;
    let Some(mut pm) = tiny_skia::PixmapMut::from_bytes(data, w as u32, h as u32) else { return };
    FONTS.with(|f| {
        let f = f.borrow();
        let Some(fonts) = f.as_ref() else { return };
        if let Some(r) = hl {
            let (x, y, rw, rh) = (r.left as f32, r.top as f32, (r.right - r.left) as f32, (r.bottom - r.top) as f32);
            if o.mode == Mode::Window {
                gfx::fill_rrect(&mut pm, x, y, rw, rh, 0.0, gfx::accent(0.14));
            }
            let bw = (2.0 * scale).round();
            gfx::stroke_rrect(&mut pm, x + bw / 2.0, y + bw / 2.0, rw - bw, rh - bw, 0.0, bw, gfx::accent(1.0));
            // размер выделения — под правым нижним углом, а если не влезает, то внутри
            let label = format!("{} × {}", r.right - r.left, r.bottom - r.top);
            let px = 13.0 * scale;
            let lw = gfx::measure(&fonts.semibold, &label, px) + 20.0 * scale;
            let lh = px + 14.0 * scale;
            let mut cx = (x + rw - lw / 2.0).max(lw / 2.0 + 4.0);
            let mut cy = y + rh + 8.0 * scale + lh / 2.0;
            if cy + lh / 2.0 > h as f32 {
                cy = y + rh - 8.0 * scale - lh / 2.0;
                cx -= 8.0 * scale;
            }
            if o.drag.is_some() || o.mode != Mode::Screen {
                gfx::pill(&mut pm, &fonts.semibold, &label, cx, cy, px, scale);
            }
        }
        if o.toolbar && o.drag.is_none() {
            toolbar(o, &mut pm, fonts);
        }
    });
}

/// Кадр собираем в WM_PAINT: Windows склеивает пачку движений мыши в одну перерисовку,
/// и оверлей не отстаёт от курсора
fn render(o: &mut Overlay) {
    o.dirty = true;
    unsafe {
        let _ = InvalidateRect(Some(o.hwnd), None, false);
    }
}

fn norm(a: (i32, i32), b: (i32, i32)) -> RECT {
    RECT { left: a.0.min(b.0), top: a.1.min(b.1), right: a.0.max(b.0) + 1, bottom: a.1.max(b.1) + 1 }
}

fn hovered_window(o: &Overlay) -> Option<Win> {
    o.wins.iter().find(|w| contains(&w.rect, o.cur.0, o.cur.1)).copied()
}

fn hovered_monitor(o: &Overlay) -> Option<&Monitor> {
    o.mons.iter().find(|m| contains(&m.rect, o.cur.0, o.cur.1))
}

fn highlight(o: &Overlay) -> Option<RECT> {
    if o.hover_btn.is_some() {
        return None;
    }
    match o.mode {
        Mode::Area | Mode::Text => o.drag.map(|d| norm(d, o.cur)),
        Mode::Window => hovered_window(o).map(|w| w.rect),
        Mode::Screen => hovered_monitor(o).map(|m| m.rect),
    }
}

struct Layout {
    panel: (f32, f32, f32, f32),
    buttons: Vec<(f32, f32, f32, f32)>,
}

const CLOSE: usize = 4;

fn layout(o: &Overlay, fonts: &Fonts) -> Layout {
    let s = o.home.scale;
    let px = 14.0 * s;
    let (pad, gap, bh, icon) = (6.0 * s, 2.0 * s, 40.0 * s, 20.0 * s);
    let mut widths: Vec<f32> =
        BUTTONS.iter().map(|(_, l)| 14.0 * s + icon + 8.0 * s + gfx::measure(&fonts.regular, l, px) + 16.0 * s).collect();
    widths.push(bh);
    let sep = 13.0 * s;
    let pw = pad * 2.0 + widths.iter().sum::<f32>() + gap * 2.0 + sep;
    let ph = bh + pad * 2.0 + 26.0 * s;
    let work = &o.home.work;
    let px0 = ((work.left + work.right) as f32 - pw) / 2.0;
    let py0 = work.bottom as f32 - ph - 28.0 * s;
    let mut x = px0 + pad;
    let mut buttons = Vec::new();
    for (i, bw) in widths.iter().enumerate() {
        if i == CLOSE {
            x += sep - gap;
        }
        buttons.push((x, py0 + pad, *bw, bh));
        x += bw + gap;
    }
    Layout { panel: (px0, py0, pw, ph), buttons }
}

fn toolbar(o: &Overlay, pm: &mut tiny_skia::PixmapMut, fonts: &Fonts) {
    let s = o.home.scale;
    let l = layout(o, fonts);
    let (x, y, w, h) = l.panel;
    gfx::shadow(pm, x, y + 6.0 * s, w, h, 24.0 * s, 0.35);
    gfx::fill_rrect(pm, x, y, w, h, 14.0 * s, gfx::surface(0.97));
    gfx::stroke_rrect(pm, x + 0.5, y + 0.5, w - 1.0, h - 1.0, 14.0 * s, 1.0, gfx::white(0.10));
    let white = gfx::white(1.0);
    let px = 14.0 * s;
    for (i, &(bx, by, bw, bh)) in l.buttons.iter().enumerate() {
        let active = i < CLOSE && BUTTONS[i].0 == o.mode;
        let hover = o.hover_btn == Some(i);
        let bg = if active {
            Some(gfx::accent(if hover { 1.0 } else { 0.85 }))
        } else if hover {
            Some(gfx::white(if o.pressed_btn == Some(i) { 0.16 } else { 0.10 }))
        } else {
            None
        };
        if let Some(bg) = bg {
            gfx::fill_rrect(pm, bx, by, bw, bh, 9.0 * s, bg);
        }
        let isz = 20.0 * s;
        let iy = by + (bh - isz) / 2.0;
        if i == CLOSE {
            gfx::icon(pm, Icon::Close, bx + (bw - isz) / 2.0, iy, isz, gfx::white(0.8));
            continue;
        }
        // на акцентной кнопке значок и подпись белые в любой теме
        let fg = if active { gfx::on_accent(1.0) } else { white };
        let kind = match BUTTONS[i].0 {
            Mode::Window => Icon::Window,
            Mode::Area => Icon::Area,
            Mode::Screen => Icon::Screen,
            Mode::Text => Icon::Text,
        };
        gfx::icon(pm, kind, bx + 14.0 * s, iy, isz, fg);
        gfx::text(pm, &fonts.regular, BUTTONS[i].1, bx + 14.0 * s + isz + 8.0 * s, by + bh / 2.0 + px * 0.36, px, fg);
    }
    // разделитель перед крестиком
    let (cx, cy, _, ch) = l.buttons[CLOSE];
    let sx = cx - 13.0 * s / 2.0 + 0.5;
    gfx::fill_rrect(pm, sx - 0.5 * s, cy + 9.0 * s, 1.0 * s, ch - 18.0 * s, 0.0, gfx::white(0.15));
    let hint = match o.mode {
        Mode::Area => "Выделите область  ·  Пробел — окно  ·  Esc — отмена",
        Mode::Window => "Щёлкните окно  ·  Alt — без тени  ·  Пробел — область",
        Mode::Screen => "Щёлкните экран или нажмите Enter  ·  Esc — отмена",
        Mode::Text => "Выделите текст — он сразу скопируется  ·  Esc — отмена",
    };
    let hp = 12.0 * s;
    let tw = gfx::measure(&fonts.regular, hint, hp);
    gfx::text(pm, &fonts.regular, hint, x + (w - tw) / 2.0, y + h - 12.0 * s, hp, gfx::white(0.55));
}

fn button_at(o: &Overlay, x: i32, y: i32) -> Option<usize> {
    if !o.toolbar || o.drag.is_some() {
        return None;
    }
    FONTS.with(|f| {
        let f = f.borrow();
        let l = layout(o, f.as_ref()?);
        let (x, y) = (x as f32, y as f32);
        let (px, py, pw, ph) = l.panel;
        if !(x >= px && x < px + pw && y >= py && y < py + ph) {
            return None;
        }
        // внутри панели, но мимо кнопок — всё равно считаем панелью, чтобы клик не ушёл в выделение
        Some(l.buttons.iter().position(|&(bx, by, bw, bh)| x >= bx && x < bx + bw && y >= by && y < by + bh).unwrap_or(usize::MAX))
    })
}

enum Act {
    None,
    Close,
    Pick(Pick),
}

fn pick_now(o: &mut Overlay) -> Act {
    let alt = unsafe { GetKeyState(VK_MENU.0 as i32) < 0 };
    match o.mode {
        Mode::Area | Mode::Text => match o.drag.take() {
            Some(d) => {
                let r = norm(d, o.cur);
                if r.right - r.left < 4 || r.bottom - r.top < 4 {
                    render(o);
                    return Act::None;
                }
                let img = o.shot.crop(r.left, r.top, r.right - r.left, r.bottom - r.top);
                Act::Pick(if o.mode == Mode::Text { Pick::Text(img) } else { Pick::Area(img) })
            }
            None => Act::None,
        },
        Mode::Window => match hovered_window(o) {
            Some(w) => {
                let r = w.rect;
                let fallback = o.shot.crop(r.left, r.top, r.right - r.left, r.bottom - r.top);
                let scale = o
                    .mons
                    .iter()
                    .find(|m| contains(&m.rect, (r.left + r.right) / 2, (r.top + r.bottom) / 2))
                    .map_or(o.home.scale, |m| m.scale);
                let rect = RECT {
                    left: r.left + o.origin.0,
                    top: r.top + o.origin.1,
                    right: r.right + o.origin.0,
                    bottom: r.bottom + o.origin.1,
                };
                Act::Pick(Pick::Window { win: Win { hwnd: w.hwnd, rect }, fallback, scale, shadow: !alt })
            }
            None => Act::None,
        },
        Mode::Screen => match hovered_monitor(o) {
            Some(m) => {
                let r = m.rect;
                Act::Pick(Pick::Screen(o.shot.crop(r.left, r.top, r.right - r.left, r.bottom - r.top)))
            }
            None => Act::None,
        },
    }
}

fn set_mode(o: &mut Overlay, m: Mode) -> Act {
    o.mode = m;
    o.drag = None;
    render(o);
    Act::None
}

fn handle(o: &mut Overlay, msg: u32, wp: WPARAM, lp: LPARAM) -> Act {
    let pt = || ((lp.0 & 0xFFFF) as i16 as i32, ((lp.0 >> 16) & 0xFFFF) as i16 as i32);
    match msg {
        WM_MOUSEMOVE => {
            let was = (highlight(o), o.hover_btn);
            o.cur = pt();
            o.hover_btn = button_at(o, o.cur.0, o.cur.1);
            // курсор ходит внутри того же окна/экрана — картинка та же, перерисовывать нечего
            if (highlight(o), o.hover_btn) != was {
                render(o);
            }
            Act::None
        }
        WM_LBUTTONDOWN => {
            o.cur = pt();
            if let Some(b) = button_at(o, o.cur.0, o.cur.1) {
                o.pressed_btn = Some(b);
            } else if matches!(o.mode, Mode::Area | Mode::Text) {
                o.drag = Some(o.cur);
                unsafe { SetCapture(o.hwnd) };
            }
            render(o);
            Act::None
        }
        WM_LBUTTONUP => {
            o.cur = pt();
            unsafe {
                let _ = ReleaseCapture();
            }
            if let Some(b) = o.pressed_btn.take() {
                if button_at(o, o.cur.0, o.cur.1) != Some(b) {
                    render(o);
                    return Act::None;
                }
                return match b {
                    CLOSE => Act::Close,
                    i if i < CLOSE => set_mode(o, BUTTONS[i].0),
                    _ => Act::None,
                };
            }
            if o.hover_btn.is_some() && o.drag.is_none() {
                return Act::None;
            }
            pick_now(o)
        }
        WM_RBUTTONUP => {
            if o.drag.take().is_some() {
                render(o);
                Act::None
            } else {
                Act::Close
            }
        }
        WM_KEYDOWN | WM_SYSKEYDOWN => match VIRTUAL_KEY(wp.0 as u16) {
            VK_ESCAPE => {
                if o.drag.take().is_some() {
                    render(o);
                    Act::None
                } else {
                    Act::Close
                }
            }
            VK_SPACE if o.drag.is_none() => {
                let m = if o.mode == Mode::Window { Mode::Area } else { Mode::Window };
                set_mode(o, m)
            }
            VK_RETURN => {
                o.mode = Mode::Screen;
                pick_now(o)
            }
            VK_1 => set_mode(o, Mode::Window),
            VK_2 => set_mode(o, Mode::Area),
            VK_3 => set_mode(o, Mode::Screen),
            VK_4 => set_mode(o, Mode::Text),
            _ => Act::None,
        },
        _ => Act::None,
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_PAINT => {
            let mut ps = PAINTSTRUCT::default();
            let hdc = BeginPaint(hwnd, &mut ps);
            with(|o| {
                if o.dirty {
                    o.dirty = false;
                    compose(o);
                }
                let _ = BitBlt(hdc, 0, 0, o.frame.w, o.frame.h, Some(o.frame.dc), 0, 0, SRCCOPY);
            });
            let _ = EndPaint(hwnd, &ps);
            LRESULT(0)
        }
        WM_ERASEBKGND => LRESULT(1),
        WM_SETCURSOR => {
            let cursor = with(|o| if matches!(o.mode, Mode::Area | Mode::Text) && o.hover_btn.is_none() { IDC_CROSS } else { IDC_ARROW })
                .unwrap_or(IDC_ARROW);
            SetCursor(LoadCursorW(None, cursor).ok());
            LRESULT(1)
        }
        // окно растянуто на все мониторы: смену DPI игнорируем, иначе Windows попытается его отмасштабировать
        WM_DPICHANGED => LRESULT(0),
        WM_ACTIVATEAPP if wp.0 == 0 => {
            close();
            LRESULT(0)
        }
        WM_SYSCHAR | WM_SYSKEYUP => LRESULT(0),
        WM_MOUSEMOVE | WM_LBUTTONDOWN | WM_LBUTTONUP | WM_RBUTTONUP | WM_KEYDOWN | WM_SYSKEYDOWN => {
            match with(|o| handle(o, msg, wp, lp)) {
                Some(Act::Close) => close(),
                Some(Act::Pick(p)) => {
                    close();
                    DONE.with(|d| {
                        if let Some(done) = d.borrow().as_ref() {
                            done(p);
                        }
                    });
                }
                _ => {}
            }
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

/// Кадр оверлея в PNG без показа окна — для проверки вёрстки
pub fn preview(mode: Mode, sel: Option<RECT>) -> Option<Img> {
    let vs = capture::virtual_screen();
    let wins = capture::windows();
    let shot = capture::grab(vs)?;
    let frame = Surface::new(vs.right - vs.left, vs.bottom - vs.top)?;
    let off = |r: RECT| RECT { left: r.left - vs.left, top: r.top - vs.top, right: r.right - vs.left, bottom: r.bottom - vs.top };
    let mons: Vec<Monitor> =
        capture::monitors().into_iter().map(|m| Monitor { rect: off(m.rect), work: off(m.work), scale: m.scale }).collect();
    let first = mons.first()?;
    let home = Monitor { rect: first.rect, work: first.work, scale: first.scale };
    let dim = shot.px.iter().enumerate().map(|(i, &v)| if i % 4 == 3 { 255 } else { (v as u16 * 120 / 255) as u8 }).collect();
    let cur = sel.map_or(((home.rect.left + home.rect.right) / 2, (home.rect.top + home.rect.bottom) / 3), |r| (r.right, r.bottom));
    let mut o = Overlay {
        hwnd: HWND::default(),
        origin: (vs.left, vs.top),
        shot,
        dim,
        frame,
        wins: wins.into_iter().map(|x| Win { hwnd: x.hwnd, rect: off(x.rect) }).collect(),
        mons,
        mode,
        toolbar: true,
        home,
        cur,
        drag: sel.map(|r| (r.left, r.top)),
        hover_btn: None,
        pressed_btn: None,
        dirty: true,
    };
    compose(&mut o);
    Some(o.frame.into_img())
}
