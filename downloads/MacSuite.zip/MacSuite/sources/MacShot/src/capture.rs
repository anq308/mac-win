use std::ffi::c_void;
use std::mem::size_of;
use std::path::{Path, PathBuf};

use tiny_skia::{FillRule, FilterQuality, Paint, Pattern, SpreadMode, Transform};
use windows::core::{w, BOOL, PCWSTR};
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Dwm::{DwmGetWindowAttribute, DWMWA_CLOAKED, DWMWA_EXTENDED_FRAME_BOUNDS};
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::Storage::Xps::{PrintWindow, PRINT_WINDOW_FLAGS};
use windows::Win32::System::Com::CoTaskMemFree;
use windows::Win32::System::DataExchange::*;
use windows::Win32::System::Memory::{GlobalAlloc, GlobalLock, GlobalUnlock, GMEM_MOVEABLE};
use windows::Win32::System::Ole::{CF_DIB, CF_UNICODETEXT};
use windows::Win32::System::SystemInformation::GetLocalTime;
use windows::Win32::System::Threading::GetCurrentProcessId;
use windows::Win32::UI::HiDpi::{GetDpiForMonitor, MDT_EFFECTIVE_DPI};
use windows::Win32::UI::Shell::{FOLDERID_Screenshots, SHGetKnownFolderPath, KF_FLAG_CREATE};
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::gfx::{self, Img};

pub fn virtual_screen() -> RECT {
    unsafe {
        let x = GetSystemMetrics(SM_XVIRTUALSCREEN);
        let y = GetSystemMetrics(SM_YVIRTUALSCREEN);
        RECT {
            left: x,
            top: y,
            right: x + GetSystemMetrics(SM_CXVIRTUALSCREEN),
            bottom: y + GetSystemMetrics(SM_CYVIRTUALSCREEN),
        }
    }
}

fn dib(dc: HDC, w: i32, h: i32) -> Option<(HBITMAP, *mut u8)> {
    let bi = BITMAPINFO {
        bmiHeader: BITMAPINFOHEADER {
            biSize: size_of::<BITMAPINFOHEADER>() as u32,
            biWidth: w,
            biHeight: -h,
            biPlanes: 1,
            biBitCount: 32,
            biCompression: BI_RGB.0,
            ..Default::default()
        },
        ..Default::default()
    };
    let mut bits: *mut c_void = std::ptr::null_mut();
    let bmp = unsafe { CreateDIBSection(Some(dc), &bi, DIB_RGB_COLORS, &mut bits, None, 0).ok()? };
    (!bits.is_null()).then_some((bmp, bits as *mut u8))
}

/// Буфер кадра в памяти: DIB-секция, выбранная в совместимый DC
pub struct Surface {
    pub dc: HDC,
    bmp: HBITMAP,
    old: HGDIOBJ,
    bits: *mut u8,
    pub w: i32,
    pub h: i32,
}

impl Surface {
    pub fn new(w: i32, h: i32) -> Option<Surface> {
        unsafe {
            let screen = GetDC(None);
            let dc = CreateCompatibleDC(Some(screen));
            ReleaseDC(None, screen);
            let Some((bmp, bits)) = dib(dc, w, h) else {
                let _ = DeleteDC(dc);
                return None;
            };
            let old = SelectObject(dc, bmp.into());
            Some(Surface { dc, bmp, old, bits, w, h })
        }
    }

    pub fn data(&mut self) -> &mut [u8] {
        unsafe { self.pixels() }
    }

    /// Пиксели без привязки к заимствованию: кадр рисуется, пока читаются соседние поля владельца
    pub unsafe fn pixels<'a>(&self) -> &'a mut [u8] {
        std::slice::from_raw_parts_mut(self.bits, (self.w * self.h * 4) as usize)
    }

    pub fn into_img(mut self) -> Img {
        let px = self.data().to_vec();
        Img { w: self.w as u32, h: self.h as u32, px }
    }
}

impl Drop for Surface {
    fn drop(&mut self) {
        unsafe {
            SelectObject(self.dc, self.old);
            let _ = DeleteObject(self.bmp.into());
            let _ = DeleteDC(self.dc);
        }
    }
}

fn opaque(px: &mut [u8]) {
    for p in px.chunks_exact_mut(4) {
        p[3] = 255;
    }
}

/// Снимок прямоугольника экрана (физические пиксели)
pub fn grab(r: RECT) -> Option<Img> {
    let (w, h) = (r.right - r.left, r.bottom - r.top);
    if w <= 0 || h <= 0 {
        return None;
    }
    let mut s = Surface::new(w, h)?;
    unsafe {
        let screen = GetDC(None);
        // без CAPTUREBLT: с ним на части систем мигает курсор, а слоистые окна DWM и так отдаёт
        let ok = BitBlt(s.dc, 0, 0, w, h, Some(screen), r.left, r.top, SRCCOPY).is_ok();
        ReleaseDC(None, screen);
        if !ok {
            return None;
        }
    }
    opaque(s.data());
    Some(s.into_img())
}

pub struct Monitor {
    pub rect: RECT,
    pub work: RECT,
    pub scale: f32,
}

pub fn monitors() -> Vec<Monitor> {
    unsafe extern "system" fn cb(m: HMONITOR, _: HDC, _: *mut RECT, lp: LPARAM) -> BOOL {
        let out = &mut *(lp.0 as *mut Vec<Monitor>);
        let mut mi = MONITORINFO { cbSize: size_of::<MONITORINFO>() as u32, ..Default::default() };
        if GetMonitorInfoW(m, &mut mi).as_bool() {
            out.push(Monitor { rect: mi.rcMonitor, work: mi.rcWork, scale: monitor_scale(m) });
        }
        true.into()
    }
    let mut out: Vec<Monitor> = Vec::new();
    unsafe {
        let _ = EnumDisplayMonitors(None, None, Some(cb), LPARAM(&mut out as *mut _ as isize));
    }
    out
}

fn monitor_scale(m: HMONITOR) -> f32 {
    let (mut x, mut y) = (96u32, 96u32);
    unsafe {
        let _ = GetDpiForMonitor(m, MDT_EFFECTIVE_DPI, &mut x, &mut y);
    }
    x as f32 / 96.0
}

pub fn cursor() -> POINT {
    let mut p = POINT::default();
    unsafe {
        let _ = GetCursorPos(&mut p);
    }
    p
}

pub fn monitor_at(p: POINT) -> Monitor {
    unsafe {
        let m = MonitorFromPoint(p, MONITOR_DEFAULTTONEAREST);
        let mut mi = MONITORINFO { cbSize: size_of::<MONITORINFO>() as u32, ..Default::default() };
        let _ = GetMonitorInfoW(m, &mut mi);
        Monitor { rect: mi.rcMonitor, work: mi.rcWork, scale: monitor_scale(m) }
    }
}

pub fn contains(r: &RECT, x: i32, y: i32) -> bool {
    x >= r.left && x < r.right && y >= r.top && y < r.bottom
}

#[derive(Clone, Copy)]
pub struct Win {
    pub hwnd: HWND,
    pub rect: RECT,
}

fn frame_rect(hwnd: HWND) -> RECT {
    let mut r = RECT::default();
    unsafe {
        let got = DwmGetWindowAttribute(
            hwnd,
            DWMWA_EXTENDED_FRAME_BOUNDS,
            &mut r as *mut RECT as *mut c_void,
            size_of::<RECT>() as u32,
        );
        if got.is_err() {
            let _ = GetWindowRect(hwnd, &mut r);
        }
    }
    r
}

fn class_name(hwnd: HWND) -> String {
    let mut buf = [0u16; 64];
    let n = unsafe { GetClassNameW(hwnd, &mut buf) } as usize;
    String::from_utf16_lossy(&buf[..n])
}

/// Видимые окна верхнего уровня в порядке Z (сверху вниз) — для подсветки под курсором
pub fn windows() -> Vec<Win> {
    unsafe extern "system" fn cb(hwnd: HWND, lp: LPARAM) -> BOOL {
        let out = &mut *(lp.0 as *mut Vec<Win>);
        if !IsWindowVisible(hwnd).as_bool() || IsIconic(hwnd).as_bool() {
            return true.into();
        }
        let mut pid = 0u32;
        GetWindowThreadProcessId(hwnd, Some(&mut pid));
        if pid == GetCurrentProcessId() {
            return true.into();
        }
        let mut cloaked = 0u32;
        let _ = DwmGetWindowAttribute(hwnd, DWMWA_CLOAKED, &mut cloaked as *mut u32 as *mut c_void, 4);
        if cloaked != 0 {
            return true.into();
        }
        // прозрачные для мыши оверлеи (NVIDIA, Discord и т.п.) растянуты на весь экран — пропускаем
        let ex = GetWindowLongW(hwnd, GWL_EXSTYLE) as u32;
        if ex & WS_EX_TRANSPARENT.0 != 0 {
            return true.into();
        }
        let class = class_name(hwnd);
        if class == "Progman" || class == "WorkerW" {
            return true.into();
        }
        let rect = frame_rect(hwnd);
        if rect.right - rect.left < 8 || rect.bottom - rect.top < 8 {
            return true.into();
        }
        out.push(Win { hwnd, rect });
        true.into()
    }
    let mut out: Vec<Win> = Vec::new();
    unsafe {
        let _ = EnumWindows(Some(cb), LPARAM(&mut out as *mut _ as isize));
    }
    out
}

/// Окно целиком, даже если оно перекрыто другими (PW_RENDERFULLCONTENT)
pub fn print_window(w: &Win) -> Option<Img> {
    unsafe {
        let mut wr = RECT::default();
        GetWindowRect(w.hwnd, &mut wr).ok()?;
        let (ww, wh) = (wr.right - wr.left, wr.bottom - wr.top);
        let s = Surface::new(ww, wh)?;
        if !PrintWindow(w.hwnd, s.dc, PRINT_WINDOW_FLAGS(2)).as_bool() {
            return None;
        }
        let r = w.rect;
        let mut img = s.into_img().crop(r.left - wr.left, r.top - wr.top, r.right - r.left, r.bottom - r.top);
        // игры и часть видео рисуются мимо PrintWindow и дают чёрный кадр
        let lit = img.px.chunks_exact(4).step_by(97).any(|p| p[0] > 8 || p[1] > 8 || p[2] > 8);
        if !lit || img.w == 0 || img.h == 0 {
            return None;
        }
        opaque(&mut img.px);
        Some(img)
    }
}

pub fn is_maximized(hwnd: HWND) -> bool {
    unsafe { IsZoomed(hwnd).as_bool() }
}

/// Снимок окна «как на маке»: скруглённые углы и мягкая тень на прозрачном фоне
pub fn style_window(img: &Img, scale: f32, rounded: bool, with_shadow: bool) -> Img {
    // пропорции как у macOS: широкие поля, тень заметно смещена вниз и хорошо видна на белом фоне
    let m = if with_shadow { (56.0 * scale).round() } else { 0.0 };
    // снизу места больше: тень смещена вниз и иначе обрежется
    let mb = if with_shadow { (84.0 * scale).round() } else { 0.0 };
    let (w, h) = (img.w as f32, img.h as f32);
    let mut out = Img::new((w + m * 2.0) as u32, (h + m + mb) as u32);
    let Some(src) = img.pixmap() else { return out };
    let Some(mut pm) = out.pixmap_mut() else { return out };
    if with_shadow {
        // большая мягкая тень и плотная у самого края, чтобы окно не «расплывалось»
        gfx::shadow(&mut pm, m + 4.0 * scale, m + 22.0 * scale, w - 8.0 * scale, h - 10.0 * scale, 44.0 * scale, 0.6);
        gfx::shadow(&mut pm, m, m + 2.0 * scale, w, h, 6.0 * scale, 0.28);
    }
    let radius = if rounded { 8.0 * scale } else { 0.0 };
    if let Some(path) = gfx::rrect(m, m, w, h, radius) {
        let paint = Paint {
            shader: Pattern::new(src, SpreadMode::Pad, FilterQuality::Nearest, 1.0, Transform::from_translate(m, m)),
            anti_alias: true,
            ..Default::default()
        };
        pm.fill_path(&path, &paint, FillRule::Winding, Transform::identity(), None);
        if with_shadow {
            // тонкая тёмная обводка, как у окон на маке
            let sw = 1.0;
            if let Some(edge) = gfx::rrect(m + sw / 2.0, m + sw / 2.0, w - sw, h - sw, radius) {
                let st = tiny_skia::Stroke { width: sw, ..Default::default() };
                pm.stroke_path(&edge, &gfx::solid(gfx::rgb(0, 0, 0, 0.22)), &st, Transform::identity(), None);
            }
        }
    }
    out
}

// ---------- сохранение ----------

pub fn screenshots_dir() -> PathBuf {
    let dir = unsafe {
        SHGetKnownFolderPath(&FOLDERID_Screenshots, KF_FLAG_CREATE, None).ok().map(|p| {
            let s = p.to_string().unwrap_or_default();
            CoTaskMemFree(Some(p.0 as *const c_void));
            PathBuf::from(s)
        })
    };
    let dir = dir.filter(|d| !d.as_os_str().is_empty()).unwrap_or_else(|| {
        PathBuf::from(std::env::var("USERPROFILE").unwrap_or_default()).join("Pictures\\Screenshots")
    });
    let _ = std::fs::create_dir_all(&dir);
    dir
}

/// Имя как на маке: «Снимок экрана 2026-10-11 в 14.03.22.png»
pub fn new_path() -> PathBuf {
    let t = unsafe { GetLocalTime() };
    let base = format!(
        "Снимок экрана {:04}-{:02}-{:02} в {:02}.{:02}.{:02}",
        t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond
    );
    let dir = screenshots_dir();
    let mut p = dir.join(format!("{base}.png"));
    let mut n = 2;
    while p.exists() {
        p = dir.join(format!("{base} ({n}).png"));
        n += 1;
    }
    p
}

pub fn encode_png(img: &Img) -> Option<Vec<u8>> {
    let mut rgba = Vec::with_capacity(img.px.len());
    let has_alpha = img.px.chunks_exact(4).any(|p| p[3] != 255);
    for p in img.px.chunks_exact(4) {
        let a = p[3] as u32;
        let un = |c: u8| if a == 0 { 0 } else { ((c as u32 * 255 + a / 2) / a).min(255) as u8 };
        rgba.extend_from_slice(&[un(p[2]), un(p[1]), un(p[0])]);
        if has_alpha {
            rgba.push(p[3]);
        }
    }
    let mut out = Vec::new();
    {
        let mut enc = png::Encoder::new(&mut out, img.w, img.h);
        enc.set_color(if has_alpha { png::ColorType::Rgba } else { png::ColorType::Rgb });
        enc.set_depth(png::BitDepth::Eight);
        enc.set_compression(png::Compression::Fast);
        let mut wr = enc.write_header().ok()?;
        wr.write_image_data(&rgba).ok()?;
    }
    Some(out)
}

/// PNG с диска в наш BGRA с премультиплицированной альфой
pub fn load_png(path: &Path) -> Option<Img> {
    let mut dec = png::Decoder::new(std::io::BufReader::new(std::fs::File::open(path).ok()?));
    dec.set_transformations(png::Transformations::normalize_to_color8());
    let mut reader = dec.read_info().ok()?;
    let mut buf = vec![0; reader.output_buffer_size()];
    let info = reader.next_frame(&mut buf).ok()?;
    let mut img = Img::new(info.width, info.height);
    let n = info.color_type.samples();
    for (src, dst) in buf[..info.buffer_size()].chunks_exact(n).zip(img.px.chunks_exact_mut(4)) {
        let (r, g, b, a) = match n {
            1 => (src[0], src[0], src[0], 255),
            2 => (src[0], src[0], src[0], src[1]),
            3 => (src[0], src[1], src[2], 255),
            _ => (src[0], src[1], src[2], src[3]),
        };
        let pm = |c: u8| ((c as u32 * a as u32 + 127) / 255) as u8;
        dst.copy_from_slice(&[pm(b), pm(g), pm(r), a]);
    }
    Some(img)
}

pub fn save(png: &[u8], path: &Path) -> bool {
    std::fs::write(path, png).is_ok()
}

unsafe fn global(bytes: &[u8]) -> Option<HANDLE> {
    let h = GlobalAlloc(GMEM_MOVEABLE, bytes.len()).ok()?;
    let p = GlobalLock(h) as *mut u8;
    if p.is_null() {
        return None;
    }
    std::ptr::copy_nonoverlapping(bytes.as_ptr(), p, bytes.len());
    let _ = GlobalUnlock(h);
    Some(HANDLE(h.0))
}

/// Текст в буфер обмена
pub fn text_to_clipboard(text: &str, owner: HWND) -> bool {
    let wide: Vec<u16> = text.encode_utf16().chain(Some(0)).collect();
    let bytes = unsafe { std::slice::from_raw_parts(wide.as_ptr() as *const u8, wide.len() * 2) };
    unsafe {
        // буфер может быть занят другой программой — пробуем несколько раз
        for _ in 0..10 {
            if OpenClipboard(Some(owner)).is_ok() {
                let _ = EmptyClipboard();
                let mut ok = false;
                if let Some(h) = global(bytes) {
                    ok = SetClipboardData(CF_UNICODETEXT.0 as u32, Some(h)).is_ok();
                }
                let _ = CloseClipboard();
                return ok;
            }
            std::thread::sleep(std::time::Duration::from_millis(20));
        }
    }
    false
}

/// В буфер кладём PNG (с прозрачностью — его берут браузеры, Telegram, Discord)
/// и обычный DIB на белом фоне для остальных программ
pub fn to_clipboard(img: &Img, png: &[u8], owner: HWND) {
    let mut dib = Vec::with_capacity(size_of::<BITMAPINFOHEADER>() + img.px.len());
    let hdr = BITMAPINFOHEADER {
        biSize: size_of::<BITMAPINFOHEADER>() as u32,
        biWidth: img.w as i32,
        biHeight: img.h as i32,
        biPlanes: 1,
        biBitCount: 32,
        biCompression: BI_RGB.0,
        ..Default::default()
    };
    dib.extend_from_slice(unsafe {
        std::slice::from_raw_parts(&hdr as *const _ as *const u8, size_of::<BITMAPINFOHEADER>())
    });
    let stride = img.w as usize * 4;
    for row in img.px.chunks_exact(stride).rev() {
        for p in row.chunks_exact(4) {
            let white = 255 - p[3] as u32;
            dib.extend_from_slice(&[
                (p[0] as u32 + white) as u8,
                (p[1] as u32 + white) as u8,
                (p[2] as u32 + white) as u8,
                255,
            ]);
        }
    }
    unsafe {
        // буфер может быть занят другой программой — пробуем несколько раз
        let mut opened = false;
        for _ in 0..10 {
            if OpenClipboard(Some(owner)).is_ok() {
                opened = true;
                break;
            }
            std::thread::sleep(std::time::Duration::from_millis(20));
        }
        if !opened {
            return;
        }
        let _ = EmptyClipboard();
        if let Some(h) = global(png) {
            let _ = SetClipboardData(RegisterClipboardFormatW(w!("PNG")), Some(h));
        }
        if let Some(h) = global(&dib) {
            let _ = SetClipboardData(CF_DIB.0 as u32, Some(h));
        }
        let _ = CloseClipboard();
    }
}

pub fn wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(Some(0)).collect()
}

pub fn pcwstr(v: &[u16]) -> PCWSTR {
    PCWSTR(v.as_ptr())
}
