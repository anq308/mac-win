//! Глобальные сочетания через низкоуровневый хук клавиатуры:
//! Win+Shift+S занят системой, RegisterHotKey его не получит, а хук может «съесть» нажатие раньше Windows.

use std::sync::atomic::{AtomicIsize, AtomicU32, Ordering};

use windows::Win32::Foundation::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::WindowsAndMessaging::*;

pub const WM_SHOT: u32 = WM_APP + 1;

#[derive(Clone, Copy, PartialEq)]
#[repr(usize)]
pub enum Shot {
    /// Win+Shift+S / Win+Shift+5 — оверлей с панелью режимов
    Panel = 1,
    /// Win+Shift+4 — сразу выбор области
    Area = 2,
    /// Win+Shift+3 — весь экран под курсором
    Screen = 3,
    /// из меню трея: сразу выбор окна
    Window = 4,
    /// Win+Shift+2 — хранилище снимков
    Library = 5,
    /// Win+Shift+1 — выделить область и скопировать текст с неё
    Text = 6,
}

impl Shot {
    pub fn from(v: usize) -> Option<Shot> {
        [Shot::Panel, Shot::Area, Shot::Screen, Shot::Window, Shot::Library, Shot::Text].into_iter().find(|s| *s as usize == v)
    }
}

static TARGET: AtomicIsize = AtomicIsize::new(0);
/// Клавиша, нажатие которой мы съели: её отпускание и автоповтор тоже не пропускаем в систему
static HELD: AtomicU32 = AtomicU32::new(0);

pub fn start(target: HWND) {
    TARGET.store(target.0 as isize, Ordering::SeqCst);
    // отдельный поток: если UI задумается (PrintWindow, сохранение PNG), Windows не снимет хук по таймауту
    std::thread::spawn(|| unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let set = || SetWindowsHookExW(WH_KEYBOARD_LL, Some(proc), Some(inst.into()), 0).ok();
        let mut hook = set();
        // Windows молча снимает хук, если система хоть раз не дождалась ответа (сон, нагрузка),
        // и Win+Shift+S уходит к «Ножницам». Поэтому периодически ставим его заново.
        SetTimer(None, 0, 5000, None);
        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).as_bool() {
            if msg.message == WM_TIMER && HELD.load(Ordering::SeqCst) == 0 {
                if let Some(fresh) = set() {
                    if let Some(old) = hook.replace(fresh) {
                        let _ = UnhookWindowsHookEx(old);
                    }
                }
            }
            DispatchMessageW(&msg);
        }
        if let Some(h) = hook {
            let _ = UnhookWindowsHookEx(h);
        }
    });
}

fn held(vk: VIRTUAL_KEY) -> bool {
    unsafe { GetAsyncKeyState(vk.0 as i32) < 0 }
}

unsafe extern "system" fn proc(code: i32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    if code == HC_ACTION as i32 {
        let k = &*(lp.0 as *const KBDLLHOOKSTRUCT);
        if k.flags.0 & LLKHF_INJECTED.0 == 0 {
            let down = wp.0 as u32 == WM_KEYDOWN || wp.0 as u32 == WM_SYSKEYDOWN;
            let held_key = HELD.load(Ordering::SeqCst);
            if held_key != 0 && k.vkCode == held_key {
                if !down {
                    HELD.store(0, Ordering::SeqCst);
                }
                return LRESULT(1);
            }
            if down
                && (held(VK_LWIN) || held(VK_RWIN))
                && held(VK_SHIFT)
                && !held(VK_CONTROL)
                && !held(VK_MENU)
            {
                let shot = match k.vkCode {
                    0x53 | 0x35 => Some(Shot::Panel), // S, 5
                    0x34 => Some(Shot::Area),
                    0x33 => Some(Shot::Screen),
                    0x32 => Some(Shot::Library),
                    0x31 => Some(Shot::Text),
                    _ => None,
                };
                if let Some(shot) = shot {
                    HELD.store(k.vkCode, Ordering::SeqCst);
                    mask_win_key();
                    let target = HWND(TARGET.load(Ordering::SeqCst) as *mut _);
                    let _ = PostMessageW(Some(target), WM_SHOT, WPARAM(shot as usize), LPARAM(0));
                    return LRESULT(1);
                }
            }
        }
    }
    CallNextHookEx(None, code, wp, lp)
}

/// Пустое нажатие между Win↓ и Win↑, иначе после отпускания Win откроется меню «Пуск».
/// Заодно наш процесс становится источником последнего ввода и может вывести оверлей на передний план.
fn mask_win_key() {
    let key = |flags: KEYBD_EVENT_FLAGS| INPUT {
        r#type: INPUT_KEYBOARD,
        Anonymous: INPUT_0 { ki: KEYBDINPUT { wVk: VIRTUAL_KEY(0xE8), dwFlags: flags, ..Default::default() } },
    };
    unsafe {
        SendInput(&[key(KEYBD_EVENT_FLAGS(0)), key(KEYEVENTF_KEYUP)], std::mem::size_of::<INPUT>() as i32);
    }
}
