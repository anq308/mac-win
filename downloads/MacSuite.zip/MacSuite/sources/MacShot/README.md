﻿# MacShot — исходники

Скриншоты как на MacBook для Windows: Rust, чистый Win32 + tiny-skia + ab_glyph, без GPU.

## Сборка

Нужны Rust (тулчейн `stable-x86_64-pc-windows-gnu`) и MinGW:

```
winget install BrechtSanders.WinLibs.POSIX.UCRT
.\build.ps1          # -> target\release\mac-shot.exe
.\install.ps1        # копирует в %LOCALAPPDATA%\MacShot, автозапуск, ярлык в «Пуске»
```

С MSVC-тулчейном хватит обычного `cargo build --release`.

## Файлы

| Файл | Что внутри |
|---|---|
| `main.rs` | трей, запуск, сохранение снимка (файл + буфер + хранилище + миниатюра) |
| `hook.rs` | низкоуровневый хук клавиатуры: Win+Shift+S/5/4/3/2 |
| `overlay.rs` | полноэкранный выбор: окно / область / весь экран |
| `capture.rs` | захват экрана и окон (PrintWindow), тень, PNG, буфер обмена |
| `thumb.rs` | плавающая миниатюра в углу после снимка |
| `editor.rs` | разметка: перо, маркер, стрелки, рамки, текст, пикселизация |
| `library.rs` | хранилище снимков: сетка по дням, просмотр, перетаскивание |
| `gfx.rs` | отрисовка: картинки, тени, текст, иконки |

## Отладка вёрстки

```
mac-shot.exe --preview overlay|area|screen|window|thumb|editor|library|library-select|library-view out.png
mac-shot.exe --edit файл.png     # редактор отдельно
mac-shot.exe --library           # открыть хранилище
```
