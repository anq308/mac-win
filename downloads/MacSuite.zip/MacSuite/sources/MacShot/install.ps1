﻿# Установка: копирует exe в %LOCALAPPDATA%\MacShot, включает автозапуск и запускает
$dir = "$env:LOCALAPPDATA\MacShot"
$exe = "$dir\mac-shot.exe"
Get-Process mac-shot -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Milliseconds 300
New-Item -ItemType Directory -Force $dir | Out-Null
Copy-Item "$PSScriptRoot\target\release\mac-shot.exe" $exe -Force
Set-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" -Name MacShot -Value "`"$exe`""
$sh = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath("Programs")) "Хранилище снимков (MacShot).lnk"))
$sh.TargetPath = $exe
$sh.Arguments = "--library"
$sh.Save()
Start-Process $exe
Write-Host "MacShot установлен: $exe"
