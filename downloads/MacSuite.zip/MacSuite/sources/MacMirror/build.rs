//! Собирает расшифровку FairPlay (C-код playfair) и вшивает значок в exe

fn main() {
    println!("cargo:rerun-if-changed=playfair");
    cc::Build::new()
        .files(["hand_garble.c", "modified_md5.c", "omg_hax.c", "playfair.c", "sap_hash.c"].map(|f| format!("playfair/{f}")))
        .opt_level(2)
        .warnings(false)
        .compile("playfair");

    println!("cargo:rerun-if-changed=app.rc");
    println!("cargo:rerun-if-changed=app.ico");
    let out = std::env::var("OUT_DIR").unwrap_or_default();
    let res = format!("{out}/app.res.o");
    // windres из MinGW (build.ps1 добавляет его в PATH)
    let ok = std::process::Command::new("windres").args(["app.rc", "-O", "coff", "-o", &res]).status().is_ok_and(|s| s.success());
    if ok {
        println!("cargo:rustc-link-arg-bins={res}");
    } else {
        println!("cargo:warning=windres не найден — exe соберётся без значка");
    }
}
