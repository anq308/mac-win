﻿# Build: .\build.ps1  ->  target\release\mac-mirror.exe
# Needs full MinGW (dlltool/as/ld): winget install BrechtSanders.WinLibs.POSIX.UCRT
$mingw = Get-ChildItem "$env:LOCALAPPDATA\Microsoft\WinGet\Packages" -Directory -Filter "BrechtSanders.WinLibs*" |
    Select-Object -First 1 | ForEach-Object { Join-Path $_.FullName "mingw64\bin" }
$env:PATH = "$mingw;$env:USERPROFILE\.cargo\bin;$env:PATH"
# libstdc++ for the AAC decoder goes inside the exe (no MinGW DLLs needed)
$env:CXXSTDLIB = "static=stdc++"
Set-Location $PSScriptRoot
# пути сборки (с именем пользователя) не попадают в exe
$env:RUSTFLAGS = "--remap-path-prefix=$env:USERPROFILE=~ --remap-path-prefix=$(Split-Path $PSScriptRoot -Parent)=src"
cargo build --release
