//! Приёмник AirPlay («Повтор экрана» iPhone) — по устройству UxPlay/RPiPlay:
//! RTSP-запросы на порту 7000, пара ключей (pair-setup / pair-verify), FairPlay, затем
//! видеопоток H.264 по отдельному TCP-соединению, зашифрованный AES-CTR

use std::io::{BufRead, BufReader, Cursor, Read, Write};
use std::net::{IpAddr, SocketAddr, TcpListener, TcpStream, UdpSocket};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::Sender;
use std::sync::Arc;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use aes::cipher::{KeyIvInit, StreamCipher};
use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use plist::{Dictionary, Value};
use sha2::{Digest, Sha512};
use x25519_dalek::{PublicKey, StaticSecret};

use crate::decode::Cmd;
use crate::fairplay::FairPlay;
use crate::log;
use crate::net;

pub const MODEL: &str = "AppleTV3,2";
pub const VERSION: &str = "220.68";
pub const PI: &str = "2e388006-13ba-4041-9a67-25dd4a43d536";
/// возможности приёмника: повтор экрана, звук, FairPlay, «старое» сопряжение (бит 27) — как у UxPlay
const FEATURES: u64 = 0x5A7F_FEE6;

type Aes128Ctr = ctr::Ctr128BE<aes::Aes128>;

pub struct Config {
    pub name: String,
    pub mac: [u8; 6],
    pub key: SigningKey,
    /// размер «экрана» приёмника: iPhone вписывает в него картинку
    pub width: u32,
    pub height: u32,
    pub fps: u32,
}

impl Config {
    pub fn device_id(&self) -> String {
        self.mac.iter().map(|b| format!("{b:02X}")).collect::<Vec<_>>().join(":")
    }

    pub fn pk_hex(&self) -> String {
        net::hex(self.key.verifying_key().as_bytes())
    }

    pub fn features_txt(&self) -> String {
        format!("0x{:X},0x{:X}", FEATURES & 0xFFFF_FFFF, FEATURES >> 32)
    }
}

/// Что приёмник сообщает окну
pub enum Note {
    /// телефон начал подключаться
    Client { name: String, model: String },
    /// пошло видео
    Streaming,
    /// показ закончился
    Stopped,
}

pub struct Hooks {
    pub note: Box<dyn Fn(Note) + Send + Sync>,
    pub video: Sender<Cmd>,
}

/// Запустить приёмник; возвращает порт (7000, если свободен)
pub fn start(cfg: Arc<Config>, hooks: Arc<Hooks>) -> std::io::Result<u16> {
    start_on(cfg, hooks, "0.0.0.0")
}

fn start_on(cfg: Arc<Config>, hooks: Arc<Hooks>, host: &str) -> std::io::Result<u16> {
    let listener = TcpListener::bind((host, 7000)).or_else(|_| TcpListener::bind((host, 0)))?;
    let port = listener.local_addr()?.port();
    std::thread::spawn(move || {
        for s in listener.incoming().flatten() {
            let (cfg, hooks) = (cfg.clone(), hooks.clone());
            std::thread::spawn(move || {
                let peer = s.peer_addr().map(|a| a.to_string()).unwrap_or_default();
                log(&format!("подключение {peer}"));
                let mut c = Conn::new(cfg, hooks, &s);
                if let Err(e) = c.serve(s) {
                    log(&format!("соединение {peer}: {e}"));
                }
                c.stop();
                log(&format!("отключение {peer}"));
            });
        }
    });
    Ok(port)
}

struct Request {
    method: String,
    url: String,
    proto: String,
    headers: Vec<(String, String)>,
    body: Vec<u8>,
}

impl Request {
    fn header(&self, name: &str) -> Option<&str> {
        self.headers.iter().find(|(k, _)| k.eq_ignore_ascii_case(name)).map(|(_, v)| v.as_str())
    }
}

struct Response {
    code: u16,
    reason: &'static str,
    headers: Vec<(String, String)>,
    body: Vec<u8>,
    close: bool,
}

impl Response {
    fn ok() -> Response {
        Response { code: 200, reason: "OK", headers: Vec::new(), body: Vec::new(), close: false }
    }

    fn err(code: u16, reason: &'static str) -> Response {
        Response { code, reason, ..Response::ok() }
    }

    fn header(mut self, k: &str, v: &str) -> Response {
        self.headers.push((k.into(), v.into()));
        self
    }

    fn plist(v: Value) -> Response {
        let mut body = Vec::new();
        let _ = v.to_writer_binary(&mut body);
        Response { body, ..Response::ok() }.header("Content-Type", "application/x-apple-binary-plist")
    }

    fn bytes(b: Vec<u8>) -> Response {
        Response { body: b, ..Response::ok() }.header("Content-Type", "application/octet-stream")
    }
}

fn read_request(r: &mut impl BufRead) -> std::io::Result<Option<Request>> {
    let mut line = Vec::new();
    // пустые строки между запросами пропускаем
    loop {
        line.clear();
        if r.read_until(b'\n', &mut line)? == 0 {
            return Ok(None);
        }
        if !String::from_utf8_lossy(&line).trim().is_empty() {
            break;
        }
    }
    let first = String::from_utf8_lossy(&line).trim().to_string();
    let mut parts = first.split_whitespace();
    let (method, url, proto) = (
        parts.next().unwrap_or_default().to_string(),
        parts.next().unwrap_or_default().to_string(),
        parts.next().unwrap_or("RTSP/1.0").to_string(),
    );
    let mut headers = Vec::new();
    loop {
        line.clear();
        if r.read_until(b'\n', &mut line)? == 0 {
            return Ok(None);
        }
        let l = String::from_utf8_lossy(&line).trim_end().to_string();
        if l.is_empty() {
            break;
        }
        if let Some((k, v)) = l.split_once(':') {
            headers.push((k.trim().to_string(), v.trim().to_string()));
        }
    }
    let len = headers
        .iter()
        .find(|(k, _)| k.eq_ignore_ascii_case("Content-Length"))
        .and_then(|(_, v)| v.parse::<usize>().ok())
        .unwrap_or(0);
    if len > 32 * 1024 * 1024 {
        return Err(std::io::Error::other("слишком большой запрос"));
    }
    let mut body = vec![0u8; len];
    r.read_exact(&mut body)?;
    Ok(Some(Request { method, url, proto, headers, body }))
}

fn sha512(parts: &[&[u8]]) -> [u8; 64] {
    let mut h = Sha512::new();
    for p in parts {
        h.update(p);
    }
    h.finalize().into()
}

fn key16(parts: &[&[u8]]) -> [u8; 16] {
    let mut k = [0u8; 16];
    k.copy_from_slice(&sha512(parts)[..16]);
    k
}

fn uint(v: u64) -> Value {
    Value::Integer(v.into())
}

fn dict_u64(d: &Dictionary, k: &str) -> Option<u64> {
    let i = d.get(k)?.as_signed_integer().map(|v| v as u64);
    i.or_else(|| d.get(k)?.as_unsigned_integer())
}

/// Состояние одного соединения с телефоном
struct Conn {
    cfg: Arc<Config>,
    hooks: Arc<Hooks>,
    peer: IpAddr,
    our_x: Option<(StaticSecret, PublicKey)>,
    their_x: Option<[u8; 32]>,
    their_ed: Option<[u8; 32]>,
    secret: Option<[u8; 32]>,
    fairplay: FairPlay,
    aeskey: Option<[u8; 16]>,
    aesiv: Option<[u8; 16]>,
    /// остановка потоков этого соединения: видео, звук, синхронизация времени
    stop: Arc<AtomicBool>,
    audio_stop: Arc<AtomicBool>,
    mirroring: bool,
}

impl Conn {
    fn new(cfg: Arc<Config>, hooks: Arc<Hooks>, s: &TcpStream) -> Conn {
        let peer = s.peer_addr().map(|a| a.ip()).unwrap_or(IpAddr::from([0, 0, 0, 0]));
        Conn {
            cfg,
            hooks,
            peer,
            our_x: None,
            their_x: None,
            their_ed: None,
            secret: None,
            fairplay: FairPlay::default(),
            aeskey: None,
            aesiv: None,
            stop: Arc::new(AtomicBool::new(false)),
            audio_stop: Arc::new(AtomicBool::new(false)),
            mirroring: false,
        }
    }

    fn stop(&mut self) {
        self.stop.store(true, Ordering::SeqCst);
        self.audio_stop.store(true, Ordering::SeqCst);
        if self.mirroring {
            self.mirroring = false;
            (self.hooks.note)(Note::Stopped);
        }
    }

    fn serve(&mut self, s: TcpStream) -> std::io::Result<()> {
        let _ = s.set_nodelay(true);
        let mut w = s.try_clone()?;
        let mut r = BufReader::new(s);
        while let Some(req) = read_request(&mut r)? {
            let cseq = req.header("CSeq").map(str::to_string);
            if req.url != "/feedback" {
                log(&format!("{} {} ({} байт)", req.method, req.url, req.body.len()));
            }
            let res = self.handle(&req);
            let mut out = format!("{} {} {}\r\n", req.proto, res.code, res.reason);
            for (k, v) in &res.headers {
                out += &format!("{k}: {v}\r\n");
            }
            if cseq.is_some() && req.method != "RECORD" {
                out += "Audio-Jack-Status: connected; type=digital\r\n";
            }
            out += &format!("Server: AirTunes/{VERSION}\r\n");
            if let Some(c) = &cseq {
                out += &format!("CSeq: {c}\r\n");
            }
            out += &format!("Content-Length: {}\r\n\r\n", res.body.len());
            let mut bytes = out.into_bytes();
            bytes.extend_from_slice(&res.body);
            w.write_all(&bytes)?;
            if res.close {
                break;
            }
        }
        Ok(())
    }

    fn handle(&mut self, req: &Request) -> Response {
        match (req.method.as_str(), req.url.as_str()) {
            ("GET", "/info") => self.info(req),
            ("POST", "/pair-setup") => self.pair_setup(req),
            ("POST", "/pair-verify") => self.pair_verify(req),
            ("POST", "/fp-setup") => match self.fairplay.setup(&req.body) {
                Some(b) => Response::bytes(b),
                None => Response::err(501, "Not Implemented"),
            },
            ("OPTIONS", _) => Response::ok().header("Public", "SETUP, RECORD, FLUSH, TEARDOWN, OPTIONS, GET_PARAMETER, SET_PARAMETER"),
            ("SETUP", _) => self.setup(req),
            ("RECORD", _) => Response::ok().header("Audio-Latency", "0").header("Audio-Jack-Status", "connected; type=analog"),
            ("GET_PARAMETER", _) => {
                if String::from_utf8_lossy(&req.body).contains("volume") {
                    let r = Response { body: b"volume: 0.000000\r\n".to_vec(), ..Response::ok() };
                    r.header("Content-Type", "text/parameters")
                } else {
                    Response::ok()
                }
            }
            ("TEARDOWN", _) => self.teardown(req),
            ("SET_PARAMETER", _) => {
                // кнопки громкости на iPhone
                let text = String::from_utf8_lossy(&req.body);
                if let Some(v) = text.trim().strip_prefix("volume:").and_then(|v| v.trim().parse::<f32>().ok()) {
                    crate::audio::set_phone_volume(v);
                }
                Response::ok()
            }
            // громкость, обложка, «сейчас играет», сердцебиение и прочее просто подтверждаем
            _ => Response::ok(),
        }
    }

    fn info(&self, req: &Request) -> Response {
        let cfg = &self.cfg;
        let mut d = Dictionary::new();
        let is_plist = req.header("Content-Type").is_some_and(|c| c.contains("apple-binary-plist"));
        if is_plist {
            // первый запрос: телефон просит записи TXT службы
            let q = Value::from_reader(Cursor::new(&req.body)).ok();
            let which = q
                .as_ref()
                .and_then(|v| v.as_dictionary())
                .and_then(|d| d.get("qualifier"))
                .and_then(|v| v.as_array())
                .and_then(|a| a.first())
                .and_then(|v| v.as_string())
                .unwrap_or_default()
                .to_string();
            if which == "txtAirPlay" {
                d.insert("txtAirPlay".into(), Value::Data(net::txt_bytes(&net::airplay_txt(cfg))));
            } else if which == "txtRAOP" {
                d.insert("txtRAOP".into(), Value::Data(net::txt_bytes(&net::raop_txt(cfg))));
            }
            return Response::plist(Value::Dictionary(d));
        }
        let id = cfg.device_id().to_lowercase();
        d.insert("deviceID".into(), Value::String(id.clone()));
        d.insert("macAddress".into(), Value::String(id));
        d.insert("pk".into(), Value::Data(cfg.key.verifying_key().as_bytes().to_vec()));
        d.insert("features".into(), uint(FEATURES));
        d.insert("name".into(), Value::String(cfg.name.clone()));
        d.insert("pi".into(), Value::String(PI.into()));
        d.insert("vv".into(), uint(2));
        d.insert("statusFlags".into(), uint(68));
        d.insert("keepAliveLowPower".into(), Value::Boolean(true));
        d.insert("sourceVersion".into(), Value::String(VERSION.into()));
        d.insert("keepAliveSendStatsAsBody".into(), Value::Boolean(true));
        d.insert("model".into(), Value::String(MODEL.into()));
        d.insert("initialVolume".into(), Value::Real(0.0));
        let latency = |t: u64| {
            let mut l = Dictionary::new();
            l.insert("type".into(), uint(t));
            l.insert("inputLatencyMicros".into(), uint(0));
            l.insert("audioType".into(), Value::String("default".into()));
            l.insert("outputLatencyMicros".into(), Value::Boolean(false));
            Value::Dictionary(l)
        };
        d.insert("audioLatencies".into(), Value::Array(vec![latency(100), latency(101)]));
        let format = |t: u64| {
            let mut f = Dictionary::new();
            f.insert("type".into(), uint(t));
            f.insert("audioInputFormats".into(), uint(0x3ff_fffc));
            f.insert("audioOutputFormats".into(), uint(0x3ff_fffc));
            Value::Dictionary(f)
        };
        d.insert("audioFormats".into(), Value::Array(vec![format(100), format(101)]));
        let mut disp = Dictionary::new();
        disp.insert("uuid".into(), Value::String("e0ff8a27-6738-3d56-8a16-cc53aacee925".into()));
        disp.insert("widthPhysical".into(), uint(0));
        disp.insert("heightPhysical".into(), uint(0));
        disp.insert("width".into(), uint(cfg.width as u64));
        disp.insert("height".into(), uint(cfg.height as u64));
        disp.insert("widthPixels".into(), uint(cfg.width as u64));
        disp.insert("heightPixels".into(), uint(cfg.height as u64));
        disp.insert("rotation".into(), Value::Boolean(false));
        disp.insert("refreshRate".into(), Value::Real(1.0 / cfg.fps as f64));
        disp.insert("maxFPS".into(), uint(cfg.fps as u64));
        disp.insert("overscanned".into(), Value::Boolean(false));
        disp.insert("features".into(), uint(14));
        d.insert("displays".into(), Value::Array(vec![Value::Dictionary(disp)]));
        Response::plist(Value::Dictionary(d))
    }

    fn pair_setup(&mut self, req: &Request) -> Response {
        if req.body.len() != 32 {
            return Response::err(400, "Bad Request");
        }
        Response::bytes(self.cfg.key.verifying_key().as_bytes().to_vec())
    }

    /// Ключи, которыми шифруется подпись в pair-verify
    fn verify_cipher(&self) -> Option<Aes128Ctr> {
        let s = self.secret?;
        let key = key16(&[b"Pair-Verify-AES-Key", &s]);
        let iv = key16(&[b"Pair-Verify-AES-IV", &s]);
        Some(Aes128Ctr::new(&key.into(), &iv.into()))
    }

    fn pair_verify(&mut self, req: &Request) -> Response {
        let b = &req.body;
        if b.len() < 4 {
            return Response::err(400, "Bad Request");
        }
        match b[0] {
            1 if b.len() == 4 + 32 + 32 => {
                let mut their_x = [0u8; 32];
                their_x.copy_from_slice(&b[4..36]);
                let mut their_ed = [0u8; 32];
                their_ed.copy_from_slice(&b[36..68]);
                let ours = StaticSecret::random_from_rng(rand::rngs::OsRng);
                let our_pub = PublicKey::from(&ours);
                self.secret = Some(ours.diffie_hellman(&PublicKey::from(their_x)).to_bytes());
                // подписываем оба открытых ключа и шифруем подпись общим секретом
                let mut msg = Vec::with_capacity(64);
                msg.extend_from_slice(our_pub.as_bytes());
                msg.extend_from_slice(&their_x);
                let mut sig = self.cfg.key.sign(&msg).to_bytes();
                if let Some(mut c) = self.verify_cipher() {
                    c.apply_keystream(&mut sig);
                }
                let mut out = our_pub.as_bytes().to_vec();
                out.extend_from_slice(&sig);
                self.our_x = Some((ours, our_pub));
                self.their_x = Some(their_x);
                self.their_ed = Some(their_ed);
                Response::bytes(out)
            }
            0 if b.len() == 4 + 64 => {
                let (Some(mut c), Some((_, our_pub)), Some(their_x), Some(their_ed)) =
                    (self.verify_cipher(), self.our_x.as_ref(), self.their_x, self.their_ed)
                else {
                    return Response::err(400, "Bad Request");
                };
                // первые 64 байта гаммы ушли на нашу подпись
                let mut skip = [0u8; 64];
                c.apply_keystream(&mut skip);
                let mut sig = [0u8; 64];
                sig.copy_from_slice(&b[4..68]);
                c.apply_keystream(&mut sig);
                let mut msg = their_x.to_vec();
                msg.extend_from_slice(our_pub.as_bytes());
                let ok = VerifyingKey::from_bytes(&their_ed)
                    .ok()
                    .is_some_and(|k| k.verify(&msg, &Signature::from_bytes(&sig)).is_ok());
                log(&format!("pair-verify: подпись телефона {}", if ok { "верна" } else { "НЕ сошлась" }));
                if ok {
                    Response::ok().header("Content-Type", "application/octet-stream")
                } else {
                    Response { close: true, ..Response::err(470, "Connection Authorization Required") }
                }
            }
            _ => Response::err(400, "Bad Request"),
        }
    }

    fn setup(&mut self, req: &Request) -> Response {
        let Ok(Value::Dictionary(d)) = Value::from_reader(Cursor::new(&req.body)) else {
            return Response::err(400, "Bad Request");
        };
        let mut res = Dictionary::new();

        if let (Some(ekey), Some(eiv)) = (d.get("ekey").and_then(|v| v.as_data()), d.get("eiv").and_then(|v| v.as_data())) {
            let name = d.get("name").and_then(|v| v.as_string()).unwrap_or("iPhone").to_string();
            let model = d.get("model").and_then(|v| v.as_string()).unwrap_or_default().to_string();
            log(&format!("SETUP от «{name}» ({model}), eiv {} байт", eiv.len()));
            let Some(mut key) = self.fairplay.decrypt(ekey) else {
                log("FairPlay: нет ключа — рукопожатие не прошло");
                return Response::err(400, "Bad Request");
            };
            // после сопряжения ключ дополнительно смешивается с общим секретом
            if let Some(s) = self.secret {
                key = key16(&[&key, &s]);
            }
            self.aeskey = Some(key);
            if eiv.len() == 16 {
                let mut iv = [0u8; 16];
                iv.copy_from_slice(eiv);
                self.aesiv = Some(iv);
            }
            (self.hooks.note)(Note::Client { name, model });

            let timing_port = dict_u64(&d, "timingPort").unwrap_or(0) as u16;
            let local = UdpSocket::bind("0.0.0.0:0").ok();
            let lport = local.as_ref().and_then(|s| s.local_addr().ok()).map_or(0, |a| a.port());
            if let Some(sock) = local {
                let (peer, stop) = (self.peer, self.stop.clone());
                std::thread::spawn(move || ntp(sock, SocketAddr::new(peer, timing_port), stop));
            }
            res.insert("timingPort".into(), uint(lport as u64));
            res.insert("eventPort".into(), uint(0));
        }

        if let Some(streams) = d.get("streams").and_then(|v| v.as_array()) {
            let mut out = Vec::new();
            for st in streams {
                let Some(sd) = st.as_dictionary() else { continue };
                match dict_u64(sd, "type") {
                    Some(110) => {
                        let id = dict_u64(sd, "streamConnectionID").unwrap_or(0);
                        let Some(key) = self.aeskey else { continue };
                        let Ok(l) = TcpListener::bind("0.0.0.0:0") else { continue };
                        let port = l.local_addr().map_or(0, |a| a.port());
                        let (stop, hooks) = (self.stop.clone(), self.hooks.clone());
                        log(&format!("видео: поток {id}, порт {port}"));
                        self.mirroring = true;
                        std::thread::spawn(move || {
                            if let Err(e) = mirror(l, key, id, stop, hooks) {
                                log(&format!("видео: {e}"));
                            }
                        });
                        let mut r = Dictionary::new();
                        r.insert("dataPort".into(), uint(port as u64));
                        r.insert("type".into(), uint(110));
                        out.push(Value::Dictionary(r));
                    }
                    Some(96) => {
                        // у звука свой флаг остановки: TEARDOWN только звука не должен обрывать видео
                        self.audio_stop.store(true, Ordering::SeqCst);
                        self.audio_stop = Arc::new(AtomicBool::new(false));
                        let data = UdpSocket::bind("0.0.0.0:0").ok();
                        let control = UdpSocket::bind("0.0.0.0:0").ok();
                        let dport = data.as_ref().and_then(|s| s.local_addr().ok()).map_or(0, |a| a.port());
                        let cport = control.as_ref().and_then(|s| s.local_addr().ok()).map_or(0, |a| a.port());
                        let ct = dict_u64(sd, "ct").unwrap_or(0);
                        log(&format!("звук: формат {ct}, порты {dport}/{cport}"));
                        if let (Some(s), Some(key), Some(iv)) = (data, self.aeskey, self.aesiv) {
                            let (stop, video) = (self.audio_stop.clone(), self.hooks.video.clone());
                            std::thread::spawn(move || crate::audio::receive(s, ct, key, iv, stop, video));
                        }
                        if let Some(s) = control {
                            let stop = self.audio_stop.clone();
                            std::thread::spawn(move || drain(s, stop));
                        }
                        let mut r = Dictionary::new();
                        r.insert("dataPort".into(), uint(dport as u64));
                        r.insert("controlPort".into(), uint(cport as u64));
                        r.insert("type".into(), uint(96));
                        out.push(Value::Dictionary(r));
                    }
                    t => log(&format!("SETUP: неизвестный поток {t:?}")),
                }
            }
            res.insert("streams".into(), Value::Array(out));
        }
        Response::plist(Value::Dictionary(res))
    }

    fn teardown(&mut self, req: &Request) -> Response {
        let types: Vec<u64> = Value::from_reader(Cursor::new(&req.body))
            .ok()
            .and_then(|v| v.into_dictionary())
            .and_then(|d| d.get("streams").and_then(|s| s.as_array()).cloned())
            .unwrap_or_default()
            .iter()
            .filter_map(|s| s.as_dictionary().and_then(|d| dict_u64(d, "type")))
            .collect();
        log(&format!("TEARDOWN {types:?}"));
        // только звук — показ продолжается
        if types == [96] {
            self.audio_stop.store(true, Ordering::SeqCst);
            return Response::ok();
        }
        self.stop();
        self.stop = Arc::new(AtomicBool::new(false));
        self.audio_stop = Arc::new(AtomicBool::new(false));
        Response { close: types.is_empty(), ..Response::ok() }.header("Connection", "close")
    }
}

/// Принять видео: 128-байтный заголовок + данные; кадры расшифровываются непрерывной гаммой AES-CTR
fn mirror(l: TcpListener, aeskey: [u8; 16], id: u64, stop: Arc<AtomicBool>, hooks: Arc<Hooks>) -> std::io::Result<()> {
    l.set_nonblocking(true)?;
    let mut s = loop {
        if stop.load(Ordering::SeqCst) {
            return Ok(());
        }
        match l.accept() {
            Ok((s, _)) => break s,
            Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => std::thread::sleep(Duration::from_millis(50)),
            Err(e) => return Err(e),
        }
    };
    s.set_nonblocking(false)?;
    s.set_read_timeout(Some(Duration::from_millis(500)))?;
    let key = key16(&[format!("AirPlayStreamKey{id}").as_bytes(), &aeskey]);
    let iv = key16(&[format!("AirPlayStreamIV{id}").as_bytes(), &aeskey]);
    let mut cipher = Aes128Ctr::new(&key.into(), &iv.into());
    let mut sps_pps: Vec<u8> = Vec::new();
    let mut started = false;
    let mut frames = 0u64;
    let _ = hooks.video.send(Cmd::Reset);

    let read_full = |s: &mut TcpStream, buf: &mut [u8], stop: &AtomicBool| -> std::io::Result<bool> {
        let mut got = 0;
        while got < buf.len() {
            if stop.load(Ordering::SeqCst) {
                return Ok(false);
            }
            match s.read(&mut buf[got..]) {
                Ok(0) => return Ok(false),
                Ok(n) => got += n,
                Err(e) if matches!(e.kind(), std::io::ErrorKind::WouldBlock | std::io::ErrorKind::TimedOut) => {}
                Err(e) => return Err(e),
            }
        }
        Ok(true)
    };

    let mut head = [0u8; 128];
    loop {
        if !read_full(&mut s, &mut head, &stop)? {
            break;
        }
        let size = u32::from_le_bytes([head[0], head[1], head[2], head[3]]) as usize;
        if size > 16 * 1024 * 1024 {
            return Err(std::io::Error::other(format!("кадр {size} байт — поток сбился")));
        }
        let mut payload = vec![0u8; size];
        if !read_full(&mut s, &mut payload, &stop)? {
            break;
        }
        match head[4] {
            0 => {
                cipher.apply_keystream(&mut payload);
                // длины NAL (4 байта, big-endian) → стартовые коды 00 00 00 01
                let mut i = 0;
                let mut valid = true;
                while i + 4 <= payload.len() {
                    let n = u32::from_be_bytes([payload[i], payload[i + 1], payload[i + 2], payload[i + 3]]) as usize;
                    if n > payload.len() - i - 4 {
                        valid = false;
                        break;
                    }
                    payload[i..i + 4].copy_from_slice(&[0, 0, 0, 1]);
                    i += 4 + n;
                }
                if !valid {
                    log("видео: кадр не разобрался — пропускаю");
                    continue;
                }
                let mut au = std::mem::take(&mut sps_pps);
                au.extend_from_slice(&payload);
                if !started {
                    started = true;
                    (hooks.note)(Note::Streaming);
                }
                frames += 1;
                if hooks.video.send(Cmd::Frame(au)).is_err() {
                    break;
                }
            }
            1 => {
                // SPS + PPS в виде avcC, без шифрования; размер картинки — float в заголовке
                let w = f32::from_le_bytes([head[56], head[57], head[58], head[59]]);
                let h = f32::from_le_bytes([head[60], head[61], head[62], head[63]]);
                if payload.len() > 8 {
                    let sps_n = u16::from_be_bytes([payload[6], payload[7]]) as usize;
                    let pps_at = 8 + sps_n;
                    if payload.len() >= pps_at + 3 {
                        let pps_n = u16::from_be_bytes([payload[pps_at + 1], payload[pps_at + 2]]) as usize;
                        if payload.len() >= pps_at + 3 + pps_n {
                            sps_pps.clear();
                            sps_pps.extend_from_slice(&[0, 0, 0, 1]);
                            sps_pps.extend_from_slice(&payload[8..8 + sps_n]);
                            sps_pps.extend_from_slice(&[0, 0, 0, 1]);
                            sps_pps.extend_from_slice(&payload[pps_at + 3..pps_at + 3 + pps_n]);
                        }
                    }
                }
                log(&format!("видео: параметры H.264, картинка {w}×{h}, опция 0x{:02x}", head[6]));
            }
            _ => {}
        }
    }
    log(&format!("видео: поток закрыт, кадров {frames}"));
    Ok(())
}

/// Синхронизация времени: каждые 3 с спрашиваем часы телефона (ответы не нужны — показываем сразу)
fn ntp(sock: UdpSocket, to: SocketAddr, stop: Arc<AtomicBool>) {
    let _ = sock.set_read_timeout(Some(Duration::from_millis(500)));
    let mut buf = [0u8; 128];
    let mut tick = 0u32;
    while !stop.load(Ordering::SeqCst) {
        if tick % 6 == 0 && to.port() != 0 {
            let mut req = [0u8; 32];
            req[..4].copy_from_slice(&[0x80, 0xd2, 0x00, 0x07]);
            let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default();
            let secs = now.as_secs() + 2_208_988_800;
            let frac = ((now.subsec_nanos() as u64) << 32) / 1_000_000_000;
            req[24..28].copy_from_slice(&(secs as u32).to_be_bytes());
            req[28..32].copy_from_slice(&(frac as u32).to_be_bytes());
            let _ = sock.send_to(&req, to);
        }
        let _ = sock.recv_from(&mut buf);
        tick += 1;
    }
}

/// Принимать и выбрасывать пакеты, пока соединение живо
fn drain(sock: UdpSocket, stop: Arc<AtomicBool>) {
    let _ = sock.set_read_timeout(Some(Duration::from_millis(500)));
    let mut buf = vec![0u8; 4096];
    while !stop.load(Ordering::SeqCst) {
        let _ = sock.recv_from(&mut buf);
    }
}

/// Проверка протокола без телефона: «поддельный iPhone» на 127.0.0.1 проходит /info, сопряжение
/// в обе стороны и FairPlay. mac-mirror.exe --selftest-airplay
pub fn selftest() -> Result<String, String> {
    use ed25519_dalek::SigningKey;
    let cfg = Arc::new(Config {
        name: "Тест".into(),
        mac: [2, 0x11, 0x22, 0x33, 0x44, 0x55],
        key: SigningKey::generate(&mut rand::rngs::OsRng),
        width: 1920,
        height: 1920,
        fps: 60,
    });
    let (tx, _rx) = std::sync::mpsc::channel();
    let hooks = Arc::new(Hooks { note: Box::new(|_| {}), video: tx });
    let port = start_on(cfg.clone(), hooks, "127.0.0.1").map_err(|e| e.to_string())?;
    let s = TcpStream::connect(("127.0.0.1", port)).map_err(|e| e.to_string())?;
    s.set_read_timeout(Some(Duration::from_secs(5))).ok();
    let mut w = s.try_clone().map_err(|e| e.to_string())?;
    let mut r = BufReader::new(s);
    let mut seq = 0;
    let mut call = |method: &str, url: &str, ctype: Option<&str>, body: &[u8]| -> Result<(u16, Vec<u8>), String> {
        seq += 1;
        let mut req = format!("{method} {url} RTSP/1.0\r\nCSeq: {seq}\r\nContent-Length: {}\r\n", body.len());
        if let Some(c) = ctype {
            req += &format!("Content-Type: {c}\r\n");
        }
        req += "\r\n";
        let mut b = req.into_bytes();
        b.extend_from_slice(body);
        w.write_all(&b).map_err(|e| e.to_string())?;
        let mut line = String::new();
        r.read_line(&mut line).map_err(|e| e.to_string())?;
        let code: u16 = line.split_whitespace().nth(1).and_then(|c| c.parse().ok()).unwrap_or(0);
        let mut len = 0usize;
        let mut cseq_ok = false;
        loop {
            let mut h = String::new();
            r.read_line(&mut h).map_err(|e| e.to_string())?;
            let h = h.trim_end();
            if h.is_empty() {
                break;
            }
            if let Some(v) = h.strip_prefix("Content-Length: ") {
                len = v.parse().unwrap_or(0);
            }
            if h == format!("CSeq: {seq}") {
                cseq_ok = true;
            }
        }
        let mut body = vec![0u8; len];
        r.read_exact(&mut body).map_err(|e| e.to_string())?;
        if !cseq_ok {
            return Err(format!("{method} {url}: нет CSeq в ответе"));
        }
        Ok((code, body))
    };
    let mut report = Vec::new();

    // 1. /info: полный словарь
    let (code, body) = call("GET", "/info", None, &[])?;
    let info = Value::from_reader(Cursor::new(&body)).map_err(|e| format!("/info не plist: {e}"))?;
    let d = info.as_dictionary().ok_or("/info не словарь")?;
    let feat = d.get("features").and_then(|v| v.as_unsigned_integer());
    report.push(format!("/info {code}: {} ключей, features {feat:x?}, name {:?}", d.len(), d.get("name").and_then(|v| v.as_string())));

    // 2. /info с qualifier txtAirPlay
    let mut q = Dictionary::new();
    q.insert("qualifier".into(), Value::Array(vec![Value::String("txtAirPlay".into())]));
    let mut qb = Vec::new();
    Value::Dictionary(q).to_writer_binary(&mut qb).map_err(|e| e.to_string())?;
    let (_, body) = call("GET", "/info", Some("application/x-apple-binary-plist"), &qb)?;
    let txt = Value::from_reader(Cursor::new(&body)).ok().and_then(|v| v.into_dictionary()).and_then(|d| d.get("txtAirPlay").and_then(|v| v.as_data()).map(|d| d.len()));
    report.push(format!("txtAirPlay: {txt:?} байт"));

    // 3. pair-setup: получаем постоянный ключ приёмника
    let (code, server_ed) = call("POST", "/pair-setup", Some("application/octet-stream"), &[7u8; 32])?;
    if server_ed.as_slice() != cfg.key.verifying_key().as_bytes() {
        return Err(format!("pair-setup {code}: не тот ключ"));
    }
    report.push(format!("pair-setup {code}: ключ совпал"));

    // 4. pair-verify, шаг 1: проверяем подпись приёмника
    let client_ed = SigningKey::generate(&mut rand::rngs::OsRng);
    let cx = StaticSecret::random_from_rng(rand::rngs::OsRng);
    let cx_pub = PublicKey::from(&cx);
    let mut b = vec![1, 0, 0, 0];
    b.extend_from_slice(cx_pub.as_bytes());
    b.extend_from_slice(client_ed.verifying_key().as_bytes());
    let (code, resp) = call("POST", "/pair-verify", Some("application/octet-stream"), &b)?;
    if resp.len() != 96 {
        return Err(format!("pair-verify 1 {code}: ответ {} байт", resp.len()));
    }
    let mut sx = [0u8; 32];
    sx.copy_from_slice(&resp[..32]);
    let shared = cx.diffie_hellman(&PublicKey::from(sx)).to_bytes();
    let key = key16(&[b"Pair-Verify-AES-Key", &shared]);
    let iv = key16(&[b"Pair-Verify-AES-IV", &shared]);
    let mut c = Aes128Ctr::new(&key.into(), &iv.into());
    let mut sig = [0u8; 64];
    sig.copy_from_slice(&resp[32..]);
    c.apply_keystream(&mut sig);
    let mut msg = sx.to_vec();
    msg.extend_from_slice(cx_pub.as_bytes());
    let ok = VerifyingKey::from_bytes(&<[u8; 32]>::try_from(server_ed.as_slice()).unwrap_or([0; 32]))
        .map_err(|e| e.to_string())?
        .verify(&msg, &Signature::from_bytes(&sig))
        .is_ok();
    report.push(format!("pair-verify 1 {code}: подпись приёмника {}", if ok { "верна" } else { "НЕВЕРНА" }));
    if !ok {
        return Err(report.join("; "));
    }

    // 5. pair-verify, шаг 2: наша подпись, зашифрованная продолжением той же гаммы
    let mut msg = cx_pub.as_bytes().to_vec();
    msg.extend_from_slice(&sx);
    let mut sig = client_ed.sign(&msg).to_bytes();
    c.apply_keystream(&mut sig);
    let mut b = vec![0, 0, 0, 0];
    b.extend_from_slice(&sig);
    let (code, _) = call("POST", "/pair-verify", Some("application/octet-stream"), &b)?;
    report.push(format!("pair-verify 2: {code}"));
    if code != 200 {
        return Err(report.join("; "));
    }

    // 6. FairPlay: оба шага рукопожатия и расшифровка ключа (значение не проверить без iPhone — только что не падает)
    let mut fp1 = [0u8; 16];
    fp1[..6].copy_from_slice(&[0x46, 0x50, 0x4c, 0x59, 3, 1]);
    fp1[14] = 1;
    let (code, r1) = call("POST", "/fp-setup", Some("application/octet-stream"), &fp1)?;
    let mut fp2 = vec![0u8; 164];
    fp2[..6].copy_from_slice(&[0x46, 0x50, 0x4c, 0x59, 3, 1]);
    for (i, x) in fp2.iter_mut().enumerate().skip(12) {
        *x = i as u8;
    }
    let (code2, r2) = call("POST", "/fp-setup", Some("application/octet-stream"), &fp2)?;
    report.push(format!("fp-setup {code}: {} байт, {code2}: {} байт", r1.len(), r2.len()));
    let mut fp = FairPlay::default();
    fp.setup(&fp2);
    report.push(format!("playfair: ключ {:?}", fp.decrypt(&[5u8; 72]).map(|k| net::hex(&k))));
    Ok(report.join("\n"))
}