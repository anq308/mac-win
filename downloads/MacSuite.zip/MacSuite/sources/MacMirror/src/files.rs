//! Куда класть снимки и записи, имена файлов по времени, картинка в буфер обмена

use std::path::PathBuf;

use windows::Win32::Foundation::{GlobalFree, HANDLE, HWND};
use windows::Win32::Graphics::Gdi::{BITMAPINFOHEADER, BI_RGB};
use windows::Win32::System::Com::CoTaskMemFree;
use windows::Win32::System::DataExchange::{CloseClipboard, EmptyClipboard, OpenClipboard, SetClipboardData};
use windows::Win32::System::Memory::{GlobalAlloc, GlobalLock, GlobalUnlock, GMEM_MOVEABLE};
use windows::Win32::System::Ole::CF_DIB;
use windows::Win32::System::SystemInformation::GetLocalTime;
use windows::Win32::UI::Shell::{FOLDERID_Pictures, SHGetKnownFolderPath, KF_FLAG_DEFAULT};

use crate::gfx::Img;

/// «Изображения\iPhone» — туда и снимки, и записи: всё в одном месте
pub fn pictures_dir() -> PathBuf {
    let base = unsafe {
        SHGetKnownFolderPath(&FOLDERID_Pictures, KF_FLAG_DEFAULT, None).ok().map(|p| {
            let s = p.to_string().unwrap_or_default();
            CoTaskMemFree(Some(p.0 as *const _));
            PathBuf::from(s)
        })
    };
    base.unwrap_or_else(|| PathBuf::from(std::env::var("USERPROFILE").unwrap_or_default()).join("Pictures")).join("iPhone")
}

fn stamp() -> String {
    let t = unsafe { GetLocalTime() };
    format!("{:04}-{:02}-{:02} {:02}-{:02}-{:02}", t.wYear, t.wMonth, t.wDay, t.wHour, t.wMinute, t.wSecond)
}

fn unique(kind: &str, ext: &str) -> PathBuf {
    let dir = pictures_dir();
    let _ = std::fs::create_dir_all(&dir);
    let base = format!("{kind} {}", stamp());
    let mut p = dir.join(format!("{base}.{ext}"));
    let mut n = 2;
    while p.exists() {
        p = dir.join(format!("{base} ({n}).{ext}"));
        n += 1;
    }
    p
}

pub fn shot_path() -> PathBuf {
    unique("Снимок iPhone", "png")
}

pub fn video_path() -> PathBuf {
    unique("Запись iPhone", "mp4")
}

/// Картинка в буфер обмена (CF_DIB): её можно сразу вставить в мессенджер или документ
pub fn copy_image(hwnd: HWND, img: &Img) -> bool {
    let (w, h) = (img.w as usize, img.h as usize);
    let head = BITMAPINFOHEADER {
        biSize: std::mem::size_of::<BITMAPINFOHEADER>() as u32,
        biWidth: w as i32,
        biHeight: h as i32,
        biPlanes: 1,
        biBitCount: 32,
        biCompression: BI_RGB.0,
        biSizeImage: (w * h * 4) as u32,
        ..Default::default()
    };
    let hs = std::mem::size_of::<BITMAPINFOHEADER>();
    unsafe {
        let Ok(mem) = GlobalAlloc(GMEM_MOVEABLE, hs + w * h * 4) else { return false };
        let p = GlobalLock(mem) as *mut u8;
        if p.is_null() {
            let _ = GlobalFree(Some(mem));
            return false;
        }
        std::ptr::copy_nonoverlapping(&head as *const _ as *const u8, p, hs);
        // DIB хранится снизу вверх
        for y in 0..h {
            let src = &img.px[(h - 1 - y) * w * 4..(h - y) * w * 4];
            std::ptr::copy_nonoverlapping(src.as_ptr(), p.add(hs + y * w * 4), w * 4);
        }
        let _ = GlobalUnlock(mem);
        if OpenClipboard(Some(hwnd)).is_err() {
            let _ = GlobalFree(Some(mem));
            return false;
        }
        let _ = EmptyClipboard();
        let ok = SetClipboardData(CF_DIB.0 as u32, Some(HANDLE(mem.0))).is_ok();
        let _ = CloseClipboard();
        if !ok {
            let _ = GlobalFree(Some(mem));
        }
        ok
    }
}

// ---------- настройки между запусками ----------

/// Настройки: %LOCALAPPDATA%\MacMirror\settings.txt, по строке «ключ=значение»
#[derive(Clone, Default)]
pub struct Settings {
    /// крестик прячет окно в трей, приёмник продолжает ждать телефон
    pub tray: bool,
    /// уже показали подсказку «программа в трее»
    pub hinted: bool,
    pub topmost: bool,
    pub muted: bool,
    /// положение окна: левый, верхний, правый, нижний край
    pub pos: Option<(i32, i32, i32, i32)>,
}

fn settings_path() -> PathBuf {
    crate::data_dir().join("settings.txt")
}

pub fn load_settings() -> Settings {
    let mut s = Settings { tray: true, ..Default::default() };
    let text = std::fs::read_to_string(settings_path()).unwrap_or_default();
    for line in text.lines() {
        let Some((k, v)) = line.split_once('=') else { continue };
        let on = v.trim() == "1";
        match k.trim() {
            "tray" => s.tray = on,
            "hinted" => s.hinted = on,
            "topmost" => s.topmost = on,
            "muted" => s.muted = on,
            "pos" => {
                let n: Vec<i32> = v.split(',').filter_map(|x| x.trim().parse().ok()).collect();
                if n.len() == 4 && n[2] - n[0] > 100 && n[3] - n[1] > 100 {
                    s.pos = Some((n[0], n[1], n[2], n[3]));
                }
            }
            _ => {}
        }
    }
    s
}

pub fn save_settings(s: &Settings) {
    let b = |v: bool| if v { "1" } else { "0" };
    let mut text = format!("tray={}\nhinted={}\ntopmost={}\nmuted={}\n", b(s.tray), b(s.hinted), b(s.topmost), b(s.muted));
    if let Some((l, t, r, bt)) = s.pos {
        text += &format!("pos={l},{t},{r},{bt}\n");
    }
    let _ = std::fs::write(settings_path(), text);
}

const RUN_KEY: windows::core::PCWSTR = windows::core::w!("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
const RUN_VALUE: windows::core::PCWSTR = windows::core::w!("MacMirror");

pub fn autostart_enabled() -> bool {
    use windows::Win32::System::Registry::*;
    let mut size = 0u32;
    unsafe { RegGetValueW(HKEY_CURRENT_USER, RUN_KEY, RUN_VALUE, RRF_RT_REG_SZ, None, None, Some(&mut size)).is_ok() }
}

/// Автозапуск: при входе в Windows программа стартует сразу в трей и ждёт телефон
pub fn set_autostart(on: bool) {
    use windows::Win32::System::Registry::*;
    unsafe {
        if on {
            let Ok(exe) = std::env::current_exe() else { return };
            let cmd: Vec<u16> = format!("\"{}\" --tray", exe.display()).encode_utf16().chain(Some(0)).collect();
            let _ = RegSetKeyValueW(HKEY_CURRENT_USER, RUN_KEY, RUN_VALUE, REG_SZ.0, Some(cmd.as_ptr() as *const _), (cmd.len() * 2) as u32);
        } else {
            let _ = RegDeleteKeyValueW(HKEY_CURRENT_USER, RUN_KEY, RUN_VALUE);
        }
    }
}
