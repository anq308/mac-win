//! Видео: декодер H.264 из Windows (Media Foundation), перевод кадра в BGRA и запись в MP4.
//! Всё в одном потоке: туда приходят кадры от приёмника и команды записи от окна

use std::mem::ManuallyDrop;
use std::path::PathBuf;
use std::sync::mpsc::{Receiver, RecvTimeoutError};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use windows::core::{Result, HSTRING};
use windows::Win32::Media::MediaFoundation::*;
use windows::Win32::System::Com::{CoCreateInstance, CoInitializeEx, CLSCTX_INPROC_SERVER, COINIT_MULTITHREADED};

use crate::log;

pub enum Cmd {
    /// кадр H.264 в виде Annex B (со стартовыми кодами)
    Frame(Vec<u8>),
    /// новый поток: декодер начинает заново
    Reset,
    /// начать запись в файл или остановить (None)
    Record(Option<PathBuf>),
    /// звук для записи: стерео, 44.1 кГц
    Audio(Vec<i16>),
}

/// Готовый кадр для окна (уже без чёрных полей, если внутри альбомная картинка)
pub struct Frame {
    pub w: u32,
    pub h: u32,
    pub bgra: Vec<u8>,
}

/// Прямоугольник картинки внутри кадра: x, y, ширина, высота
pub type Crop = (u32, u32, u32, u32);

/// Поиск картинки внутри чёрных полей. iPhone при повороте не меняет размер кадра, а вписывает
/// альбомную картинку в вертикальный кадр с полями сверху и снизу — их срезаем, и окно поворачивается
fn detect_crop(pic: &Nv12) -> Option<Crop> {
    let (w, h, st) = (pic.w as usize, pic.h as usize, pic.stride);
    // чёрный в ограниченном диапазоне — 16; с запасом на шум сжатия
    let dark = |v: u8| v <= 24;
    let row_dark = |y: usize| (0..w).step_by(5).all(|x| dark(pic.y[y * st + x]));
    let top = (0..h).find(|&y| !row_dark(y))?;
    let bottom = (0..h).rev().find(|&y| !row_dark(y))?;
    let col_dark = |x: usize| (top..=bottom).step_by(5).all(|y| dark(pic.y[y * st + x]));
    let left = (0..w).find(|&x| !col_dark(x))?;
    let right = (0..w).rev().find(|&x| !col_dark(x))?;
    let (cw, ch) = (right + 1 - left, bottom + 1 - top);
    let even = |v: usize| (v & !1) as u32;
    // вертикальный кадр, внутри — альбомная картинка с одинаковыми полями сверху и снизу
    if h > w && cw as f32 / ch as f32 >= 1.25 && top.abs_diff(h - 1 - bottom) <= h / 25 {
        return Some((0, even(top), even(w), even(ch)));
    }
    // и наоборот: альбомный кадр, внутри вертикальная картинка
    if w > h && (cw as f32 / ch as f32) <= 0.8 && left.abs_diff(w - 1 - right) <= w / 25 {
        return Some((even(left), 0, even(cw), even(h)));
    }
    None
}

pub enum Event {
    Frame,
    Recording,
    /// запись закончена: файл и причина, если не по кнопке
    Recorded(PathBuf, Option<String>),
}

static LATEST: Mutex<Option<Arc<Frame>>> = Mutex::new(None);

pub fn latest() -> Option<Arc<Frame>> {
    LATEST.lock().ok()?.clone()
}

pub fn start(rx: Receiver<Cmd>, event: impl Fn(Event) + Send + 'static) {
    std::thread::spawn(move || {
        unsafe {
            let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
            let _ = MFStartup(MF_VERSION, MFSTARTUP_FULL);
        }
        let mut dec: Option<Decoder> = None;
        let mut rec: Option<Recorder> = None;
        let mut want_rec: Option<PathBuf> = None;
        // обрезка меняется, только если новая держится несколько кадров подряд — без мигания
        let mut crop: Option<Crop> = None;
        let mut cand: (Option<Crop>, u32) = (None, 0);
        loop {
            let cmd = match rx.recv_timeout(Duration::from_millis(500)) {
                Ok(c) => c,
                Err(RecvTimeoutError::Timeout) => continue,
                Err(RecvTimeoutError::Disconnected) => break,
            };
            match cmd {
                Cmd::Reset => {
                    dec = None;
                    crop = None;
                }
                Cmd::Audio(pcm) => {
                    if let Some(r) = rec.as_mut() {
                        r.write_audio(&pcm);
                    }
                }
                Cmd::Record(Some(path)) => want_rec = Some(path),
                Cmd::Record(None) => {
                    want_rec = None;
                    if let Some(r) = rec.take() {
                        let p = r.finish();
                        event(Event::Recorded(p, None));
                    }
                }
                Cmd::Frame(au) => {
                    if dec.is_none() {
                        match Decoder::new() {
                            Ok(d) => dec = Some(d),
                            Err(e) => {
                                log(&format!("декодер не создан: {e}"));
                                continue;
                            }
                        }
                    }
                    let Some(d) = dec.as_mut() else { continue };
                    let mut got = false;
                    let r = d.push(&au, |full| {
                        got = true;
                        let found = detect_crop(full);
                        let near = |a: Option<Crop>, b: Option<Crop>| match (a, b) {
                            (Some(a), Some(b)) => a.1.abs_diff(b.1) <= 4 && a.3.abs_diff(b.3) <= 8 && a.0.abs_diff(b.0) <= 4 && a.2.abs_diff(b.2) <= 8,
                            (None, None) => true,
                            _ => false,
                        };
                        if near(found, crop) {
                            cand = (None, 0);
                        } else if near(found, cand.0) && cand.1 > 0 {
                            cand.1 += 1;
                            if cand.1 >= 6 {
                                crop = found;
                                cand = (None, 0);
                                log(&format!("картинка внутри кадра {}×{}: {crop:?}", full.w, full.h));
                            }
                        } else {
                            cand = (found, 1);
                        }
                        let view = match crop {
                            Some((x, y, w, h)) if x + w <= full.w && y + h <= full.h => full.crop(x, y, w, h),
                            _ => full.crop(0, 0, full.w, full.h),
                        };
                        let pic = &view;
                        let frame = Arc::new(Frame { w: pic.w, h: pic.h, bgra: pic.to_bgra() });
                        if let Ok(mut l) = LATEST.lock() {
                            *l = Some(frame);
                        }
                        // запись: начинаем с первого кадра после нажатия; размер сменился (повернули) — заканчиваем
                        if let Some(r) = &rec {
                            if r.w != pic.w & !1 || r.h != pic.h & !1 {
                                // повернули: этот файл закрываем и сразу продолжаем в новом, уже в новой ориентации
                                if let Some(r) = rec.take() {
                                    let p = r.finish();
                                    want_rec = Some(next_part(&p));
                                    event(Event::Recorded(p, Some("повернули экран — продолжаю в новом файле".into())));
                                }
                            }
                        }
                        if let Some(path) = want_rec.take() {
                            match Recorder::new(&path, pic.w, pic.h) {
                                Ok(r) => {
                                    rec = Some(r);
                                    event(Event::Recording);
                                }
                                Err(e) => {
                                    log(&format!("запись не началась: {e}"));
                                    event(Event::Recorded(path, Some(format!("ошибка: {e}"))));
                                }
                            }
                        }
                        if let Some(r) = rec.as_mut() {
                            if let Err(e) = r.write(&pic) {
                                log(&format!("запись: {e}"));
                            }
                        }
                    });
                    if let Err(e) = r {
                        log(&format!("декодер: {e} — начинаю заново"));
                        dec = None;
                    }
                    if got {
                        event(Event::Frame);
                    }
                }
            }
        }
        if let Some(r) = rec.take() {
            r.finish();
        }
    });
}

/// Кадр NV12 из декодера: яркость, затем пары цветности
pub struct Nv12<'a> {
    pub w: u32,
    pub h: u32,
    pub stride: usize,
    pub y: &'a [u8],
    pub uv: &'a [u8],
}

impl<'a> Nv12<'a> {
    /// Часть кадра без копирования (x и y чётные)
    pub fn crop(&self, x: u32, y: u32, w: u32, h: u32) -> Nv12<'a> {
        let (x, y) = ((x & !1) as usize, (y & !1) as usize);
        Nv12 { w, h, stride: self.stride, y: &self.y[y * self.stride + x..], uv: &self.uv[(y / 2) * self.stride + x..] }
    }

    /// BGRA (непрозрачный), BT.709 с ограниченным диапазоном — так кодирует iPhone; в несколько потоков
    pub fn to_bgra(&self) -> Vec<u8> {
        let (w, h) = (self.w as usize, self.h as usize);
        let mut out = vec![0u8; w * h * 4];
        let threads = std::thread::available_parallelism().map_or(4, |n| n.get()).clamp(1, 8);
        let rows = h.div_ceil(threads).next_multiple_of(2);
        std::thread::scope(|sc| {
            for (band, chunk) in out.chunks_mut(rows * w * 4).enumerate() {
                let y0 = band * rows;
                sc.spawn(move || {
                    for (dy, line) in chunk.chunks_mut(w * 4).enumerate() {
                        let y = y0 + dy;
                        let yl = &self.y[y * self.stride..];
                        let cl = &self.uv[(y / 2) * self.stride..];
                        for x in 0..w {
                            let c = 1192 * (yl[x] as i32 - 16).max(0);
                            let u = cl[x & !1] as i32 - 128;
                            let v = cl[(x & !1) + 1] as i32 - 128;
                            let r = (c + 1836 * v) >> 10;
                            let g = (c - 218 * u - 546 * v) >> 10;
                            let b = (c + 2163 * u) >> 10;
                            let p = &mut line[x * 4..x * 4 + 4];
                            p[0] = b.clamp(0, 255) as u8;
                            p[1] = g.clamp(0, 255) as u8;
                            p[2] = r.clamp(0, 255) as u8;
                            p[3] = 255;
                        }
                    }
                });
            }
        });
        out
    }
}

fn video_type(sub: windows::core::GUID, w: u32, h: u32, fps: u32) -> Result<IMFMediaType> {
    unsafe {
        let t = MFCreateMediaType()?;
        t.SetGUID(&MF_MT_MAJOR_TYPE, &MFMediaType_Video)?;
        t.SetGUID(&MF_MT_SUBTYPE, &sub)?;
        if w > 0 {
            t.SetUINT64(&MF_MT_FRAME_SIZE, ((w as u64) << 32) | h as u64)?;
            t.SetUINT64(&MF_MT_FRAME_RATE, ((fps as u64) << 32) | 1)?;
            t.SetUINT64(&MF_MT_PIXEL_ASPECT_RATIO, (1u64 << 32) | 1)?;
            t.SetUINT32(&MF_MT_INTERLACE_MODE, MFVideoInterlace_Progressive.0 as u32)?;
        }
        Ok(t)
    }
}

pub struct Decoder {
    mft: IMFTransform,
    /// видимый размер
    w: u32,
    h: u32,
    /// размер буфера (выровненный) и шаг строки
    coded_h: u32,
    stride: usize,
    t: i64,
}

impl Decoder {
    pub fn new() -> Result<Decoder> {
        unsafe {
            let mft: IMFTransform = CoCreateInstance(&CLSID_MSH264DecoderMFT, None, CLSCTX_INPROC_SERVER)?;
            // без накопления кадров: показываем сразу, как пришёл
            // иначе декодер копит до 16 кадров про запас — картинка отстаёт на полсекунды
            if let Err(e) = mft.GetAttributes().and_then(|a| a.SetUINT32(&MF_LOW_LATENCY, 1)) {
                log(&format!("декодер: режим низкой задержки не включился ({e})"));
            }
            mft.SetInputType(0, &video_type(MFVideoFormat_H264, 0, 0, 0)?, 0)?;
            let mut d = Decoder { mft, w: 0, h: 0, coded_h: 0, stride: 0, t: 0 };
            d.output_type()?;
            d.mft.ProcessMessage(MFT_MESSAGE_NOTIFY_BEGIN_STREAMING, 0)?;
            d.mft.ProcessMessage(MFT_MESSAGE_NOTIFY_START_OF_STREAM, 0)?;
            Ok(d)
        }
    }

    /// Выбрать NV12 на выходе и узнать размеры (после смены потока — заново)
    fn output_type(&mut self) -> Result<()> {
        unsafe {
            let mut i = 0;
            loop {
                let t = self.mft.GetOutputAvailableType(0, i)?;
                if t.GetGUID(&MF_MT_SUBTYPE)? == MFVideoFormat_NV12 {
                    self.mft.SetOutputType(0, &t, 0)?;
                    break;
                }
                i += 1;
            }
            let t = self.mft.GetOutputCurrentType(0)?;
            if let Ok(size) = t.GetUINT64(&MF_MT_FRAME_SIZE) {
                let (cw, ch) = ((size >> 32) as u32, size as u32);
                self.coded_h = ch;
                self.stride = t.GetUINT32(&MF_MT_DEFAULT_STRIDE).map_or(cw as usize, |s| (s as i32).unsigned_abs() as usize);
                let (mut w, mut h) = (cw, ch);
                let mut area = MFVideoArea::default();
                let mut n = 0u32;
                let blob = std::slice::from_raw_parts_mut(&mut area as *mut MFVideoArea as *mut u8, std::mem::size_of::<MFVideoArea>());
                if t.GetBlob(&MF_MT_MINIMUM_DISPLAY_APERTURE, blob, Some(&mut n)).is_ok() && area.Area.cx > 0 {
                    w = area.Area.cx as u32;
                    h = area.Area.cy as u32;
                }
                if (w, h) != (self.w, self.h) {
                    log(&format!("декодер: кадр {w}×{h} (буфер {cw}×{ch}, шаг {})", self.stride));
                }
                self.w = w.min(cw);
                self.h = h.min(ch);
            }
        }
        Ok(())
    }

    /// Отдать кадр и забрать всё, что готово
    pub fn push(&mut self, au: &[u8], mut out: impl FnMut(&Nv12)) -> Result<()> {
        unsafe {
            let buf = MFCreateMemoryBuffer(au.len() as u32)?;
            let mut p = std::ptr::null_mut();
            buf.Lock(&mut p, None, None)?;
            std::ptr::copy_nonoverlapping(au.as_ptr(), p, au.len());
            buf.Unlock()?;
            buf.SetCurrentLength(au.len() as u32)?;
            let s = MFCreateSample()?;
            s.AddBuffer(&buf)?;
            s.SetSampleTime(self.t)?;
            s.SetSampleDuration(166_666)?;
            self.t += 166_666;
            for _ in 0..2 {
                match self.mft.ProcessInput(0, &s, 0) {
                    Ok(()) => break,
                    Err(e) if e.code() == MF_E_NOTACCEPTING => self.drain(&mut out)?,
                    Err(e) => return Err(e),
                }
            }
            self.drain(&mut out)
        }
    }

    fn drain(&mut self, out: &mut impl FnMut(&Nv12)) -> Result<()> {
        unsafe {
            loop {
                let info = self.mft.GetOutputStreamInfo(0)?;
                let provides = info.dwFlags & (MFT_OUTPUT_STREAM_PROVIDES_SAMPLES.0 | MFT_OUTPUT_STREAM_CAN_PROVIDE_SAMPLES.0) as u32 != 0;
                let sample = if provides {
                    None
                } else {
                    let s = MFCreateSample()?;
                    s.AddBuffer(&MFCreateMemoryBuffer(info.cbSize.max(1))?)?;
                    Some(s)
                };
                let mut db = [MFT_OUTPUT_DATA_BUFFER {
                    dwStreamID: 0,
                    pSample: ManuallyDrop::new(sample),
                    dwStatus: 0,
                    pEvents: ManuallyDrop::new(None),
                }];
                let mut status = 0u32;
                let r = self.mft.ProcessOutput(0, &mut db, &mut status);
                let sample = ManuallyDrop::take(&mut db[0].pSample);
                drop(ManuallyDrop::take(&mut db[0].pEvents));
                match r {
                    Ok(()) => {
                        if let Some(s) = sample {
                            self.emit(&s, out)?;
                        }
                    }
                    Err(e) if e.code() == MF_E_TRANSFORM_NEED_MORE_INPUT => return Ok(()),
                    Err(e) if e.code() == MF_E_TRANSFORM_STREAM_CHANGE => self.output_type()?,
                    Err(e) => return Err(e),
                }
            }
        }
    }

    fn emit(&self, s: &IMFSample, out: &mut impl FnMut(&Nv12)) -> Result<()> {
        if self.w == 0 || self.h == 0 {
            return Ok(());
        }
        unsafe {
            let b = s.ConvertToContiguousBuffer()?;
            let mut p = std::ptr::null_mut();
            let mut len = 0u32;
            b.Lock(&mut p, None, Some(&mut len))?;
            let data = std::slice::from_raw_parts(p, len as usize);
            let ysize = self.stride * self.coded_h as usize;
            let need = ysize + self.stride * (self.coded_h as usize).div_ceil(2);
            if data.len() >= need {
                let pic = Nv12 { w: self.w, h: self.h, stride: self.stride, y: &data[..ysize], uv: &data[ysize..] };
                out(&pic);
            }
            b.Unlock()?;
        }
        Ok(())
    }
}

/// Запись в MP4: кадры NV12 кодирует H.264-кодировщик Windows (на видеокарте, если она умеет),
/// звук — AAC. Пока телефон молчит, пишется тишина, чтобы звук не уезжал от картинки
pub struct Recorder {
    writer: IMFSinkWriter,
    stream: u32,
    audio: Option<u32>,
    /// сколько отсчётов звука (на канал) уже записано
    audio_frames: u64,
    pub w: u32,
    pub h: u32,
    start: Instant,
    last: Option<i64>,
    path: PathBuf,
    packed: Vec<u8>,
}

const REC_FPS: u32 = 30;
const AUDIO_RATE: u64 = crate::audio::RATE as u64;

/// «Запись … .mp4» → «Запись … (2).mp4», «(3)» и так далее
fn next_part(p: &std::path::Path) -> PathBuf {
    let stem = p.file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
    let (base, n) = match stem.rsplit_once(" (") {
        Some((b, rest)) if rest.trim_end_matches(')').parse::<u32>().is_ok() => (b.to_string(), rest.trim_end_matches(')').parse::<u32>().unwrap_or(1)),
        _ => (stem.clone(), 1),
    };
    let mut k = n + 1;
    loop {
        let c = p.with_file_name(format!("{base} ({k}).mp4"));
        if !c.exists() {
            return c;
        }
        k += 1;
    }
}

fn audio_type(aac: bool) -> Result<IMFMediaType> {
    unsafe {
        let t = MFCreateMediaType()?;
        t.SetGUID(&MF_MT_MAJOR_TYPE, &MFMediaType_Audio)?;
        t.SetGUID(&MF_MT_SUBTYPE, if aac { &MFAudioFormat_AAC } else { &MFAudioFormat_PCM })?;
        t.SetUINT32(&MF_MT_AUDIO_NUM_CHANNELS, 2)?;
        t.SetUINT32(&MF_MT_AUDIO_SAMPLES_PER_SECOND, AUDIO_RATE as u32)?;
        t.SetUINT32(&MF_MT_AUDIO_BITS_PER_SAMPLE, 16)?;
        if aac {
            // 192 кбит/с
            t.SetUINT32(&MF_MT_AUDIO_AVG_BYTES_PER_SECOND, 24_000)?;
        } else {
            t.SetUINT32(&MF_MT_AUDIO_BLOCK_ALIGNMENT, 4)?;
            t.SetUINT32(&MF_MT_AUDIO_AVG_BYTES_PER_SECOND, AUDIO_RATE as u32 * 4)?;
        }
        Ok(t)
    }
}

impl Recorder {
    pub fn new(path: &std::path::Path, w: u32, h: u32) -> Result<Recorder> {
        // кодировщику нужны чётные стороны
        let (w, h) = (w & !1, h & !1);
        unsafe {
            let mut attrs = None;
            MFCreateAttributes(&mut attrs, 2)?;
            let attrs = attrs.ok_or_else(windows::core::Error::empty)?;
            attrs.SetUINT32(&MF_READWRITE_ENABLE_HARDWARE_TRANSFORMS, 1)?;
            attrs.SetUINT32(&MF_SINK_WRITER_DISABLE_THROTTLING, 1)?;
            let writer = MFCreateSinkWriterFromURL(&HSTRING::from(path.as_os_str()), None, &attrs)?;
            let outt = video_type(MFVideoFormat_H264, w, h, REC_FPS)?;
            // ~0.2 бита на точку при 30 к/с — чёткий текст интерфейса
            let bitrate = ((w * h) as f32 * REC_FPS as f32 * 0.2).clamp(4e6, 24e6) as u32;
            outt.SetUINT32(&MF_MT_AVG_BITRATE, bitrate)?;
            let stream = writer.AddStream(&outt)?;
            writer.SetInputMediaType(stream, &video_type(MFVideoFormat_NV12, w, h, REC_FPS)?, None)?;
            let audio = (|| -> Result<u32> {
                let a = writer.AddStream(&audio_type(true)?)?;
                writer.SetInputMediaType(a, &audio_type(false)?, None)?;
                Ok(a)
            })();
            if let Err(e) = &audio {
                log(&format!("запись: без звука ({e})"));
            }
            writer.BeginWriting()?;
            log(&format!("запись: {}×{}, {} Мбит/с → {}", w, h, bitrate / 1_000_000, path.display()));
            crate::audio::RECORDING.store(audio.is_ok(), std::sync::atomic::Ordering::Relaxed);
            Ok(Recorder {
                writer,
                stream,
                audio: audio.ok(),
                audio_frames: 0,
                w,
                h,
                start: Instant::now(),
                last: None,
                path: path.to_path_buf(),
                packed: Vec::new(),
            })
        }
    }

    fn now(&self) -> i64 {
        self.start.elapsed().as_nanos() as i64 / 100
    }

    fn audio_time(&self) -> i64 {
        (self.audio_frames * 10_000_000 / AUDIO_RATE) as i64
    }

    fn put_audio(&mut self, pcm: &[i16]) -> Result<()> {
        let Some(a) = self.audio else { return Ok(()) };
        let bytes = pcm.len() * 2;
        unsafe {
            let buf = MFCreateMemoryBuffer(bytes as u32)?;
            let mut p = std::ptr::null_mut();
            buf.Lock(&mut p, None, None)?;
            std::ptr::copy_nonoverlapping(pcm.as_ptr() as *const u8, p, bytes);
            buf.Unlock()?;
            buf.SetCurrentLength(bytes as u32)?;
            let s = MFCreateSample()?;
            s.AddBuffer(&buf)?;
            let frames = (pcm.len() / 2) as u64;
            s.SetSampleTime(self.audio_time())?;
            s.SetSampleDuration((frames * 10_000_000 / AUDIO_RATE) as i64)?;
            self.writer.WriteSample(a, &s)?;
            self.audio_frames += frames;
        }
        Ok(())
    }

    /// Тишина до момента until (в единицах 100 нс)
    fn silence_until(&mut self, until: i64) {
        while self.audio.is_some() && self.audio_time() < until {
            let left = ((until - self.audio_time()) as u64 * AUDIO_RATE / 10_000_000).clamp(1, 4410);
            if self.put_audio(&vec![0i16; left as usize * 2]).is_err() {
                break;
            }
        }
    }

    pub fn write_audio(&mut self, pcm: &[i16]) {
        let now = self.now();
        let dur = (pcm.len() / 2) as i64 * 10_000_000 / AUDIO_RATE as i64;
        // звук догоняет картинку: дырки заполняем тишиной, лишнее (сильно впереди) выбрасываем
        if self.audio_time() + dur < now - 2_000_000 {
            self.silence_until(now - dur);
        } else if self.audio_time() > now + 5_000_000 {
            return;
        }
        if let Err(e) = self.put_audio(pcm) {
            log(&format!("запись звука: {e}"));
        }
    }

    pub fn write(&mut self, pic: &Nv12) -> Result<()> {
        let now = self.now();
        let step = 10_000_000 / REC_FPS as i64;
        // чаще 30 кадров в секунду не пишем
        if self.last.is_some_and(|l| now - l < step - 20_000) {
            return Ok(());
        }
        // телефон молчит — звук всё равно идёт тишиной
        if !crate::audio::active() {
            self.silence_until(now - 3_000_000);
        }
        let (w, h) = (self.w as usize, self.h as usize);
        self.packed.clear();
        for y in 0..h {
            self.packed.extend_from_slice(&pic.y[y * pic.stride..y * pic.stride + w]);
        }
        for y in 0..h / 2 {
            self.packed.extend_from_slice(&pic.uv[y * pic.stride..y * pic.stride + w]);
        }
        unsafe {
            let buf = MFCreateMemoryBuffer(self.packed.len() as u32)?;
            let mut p = std::ptr::null_mut();
            buf.Lock(&mut p, None, None)?;
            std::ptr::copy_nonoverlapping(self.packed.as_ptr(), p, self.packed.len());
            buf.Unlock()?;
            buf.SetCurrentLength(self.packed.len() as u32)?;
            let s = MFCreateSample()?;
            s.AddBuffer(&buf)?;
            s.SetSampleTime(now)?;
            s.SetSampleDuration(step)?;
            self.writer.WriteSample(self.stream, &s)?;
        }
        self.last = Some(now);
        Ok(())
    }

    pub fn finish(mut self) -> PathBuf {
        crate::audio::RECORDING.store(false, std::sync::atomic::Ordering::Relaxed);
        let end = self.now();
        self.silence_until(end);
        unsafe {
            if let Err(e) = self.writer.Finalize() {
                log(&format!("запись: не дописалась ({e})"));
            }
        }
        self.path
    }
}

/// Проверка без телефона: пишем MP4 из синтетических кадров, читаем его обратно,
/// прогоняем через декодер и сохраняем кадр в PNG. mac-mirror.exe --selftest папка
pub fn selftest(dir: &std::path::Path) -> std::result::Result<String, String> {
    let e = |x: windows::core::Error| x.to_string();
    unsafe {
        let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
        MFStartup(MF_VERSION, MFSTARTUP_FULL).map_err(e)?;
    }
    let (w, h) = (590u32, 1280u32);
    let mp4 = dir.join("selftest.mp4");
    let _ = std::fs::remove_file(&mp4);
    {
        let mut rec = Recorder::new(&mp4, w, h).map_err(e)?;
        let stride = w as usize;
        let mut y = vec![0u8; stride * h as usize];
        let mut uv = vec![128u8; stride * h as usize / 2];
        for f in 0..45 {
            for row in 0..h as usize {
                for col in 0..w as usize {
                    // полосы с движущейся границей и цветные плашки
                    y[row * stride + col] = (16 + ((col + row + f * 8) % 220)) as u8;
                }
            }
            for row in 0..h as usize / 2 {
                for col in (0..w as usize).step_by(2) {
                    let band = row * 8 / (h as usize / 2);
                    uv[row * stride + col] = [90, 240, 54, 128, 200, 30, 160, 110][band];
                    uv[row * stride + col + 1] = [240, 110, 34, 128, 60, 200, 220, 140][band];
                }
            }
            let pic = Nv12 { w, h, stride, y: &y, uv: &uv };
            rec.start = Instant::now() - Duration::from_millis(f as u64 * 34);
            rec.write(&pic).map_err(e)?;
        }
        rec.finish();
    }
    let size = std::fs::metadata(&mp4).map(|m| m.len()).unwrap_or(0);
    // обратно: читаем сжатые кадры и декодируем своим декодером
    let mut frames = 0;
    let mut read = 0;
    let mut saved = String::new();
    unsafe {
        let reader = MFCreateSourceReaderFromURL(&HSTRING::from(mp4.as_os_str()), None).map_err(e)?;
        let stream = MF_SOURCE_READER_FIRST_VIDEO_STREAM.0 as u32;
        let native = reader.GetNativeMediaType(stream, 0).map_err(e)?;
        let mut header = vec![0u8; 512];
        let mut n = 0u32;
        let _ = native.GetBlob(&MF_MT_MPEG_SEQUENCE_HEADER, &mut header, Some(&mut n));
        header.truncate(n as usize);
        let mut dec = Decoder::new().map_err(e)?;
        let mut first = true;
        loop {
            let mut flags = 0u32;
            let mut sample = None;
            reader.ReadSample(stream, 0, None, Some(&mut flags), None, Some(&mut sample)).map_err(e)?;
            if flags & MF_SOURCE_READERF_ENDOFSTREAM.0 as u32 != 0 {
                break;
            }
            let Some(s) = sample else { continue };
            read += 1;
            let b = s.ConvertToContiguousBuffer().map_err(e)?;
            let mut p = std::ptr::null_mut();
            let mut len = 0u32;
            b.Lock(&mut p, None, Some(&mut len)).map_err(e)?;
            let mut au = if first { header.clone() } else { Vec::new() };
            first = false;
            au.extend_from_slice(std::slice::from_raw_parts(p, len as usize));
            b.Unlock().map_err(e)?;
            dec.push(&au, |pic| {
                frames += 1;
                if frames == 20 {
                    let img = crate::gfx::Img { w: pic.w, h: pic.h, px: pic.to_bgra() };
                    let out = dir.join("selftest-frame.png");
                    if let Some(png) = crate::win::encode_png(&img) {
                        let _ = std::fs::write(&out, png);
                        saved = format!("{} ({}×{})", out.display(), pic.w, pic.h);
                    }
                }
            })
            .map_err(e)?;
        }
    }
    Ok(format!("mp4 {size} байт, прочитано {read}, декодировано кадров: {frames}, кадр: {saved}"))
}
