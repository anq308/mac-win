//! Звук iPhone: RTP-пакеты по UDP, зашифрованные AES-128-CBC; внутри AAC-ELD (при повторе экрана)
//! или AAC-LC. Декодер — Fraunhofer FDK AAC, вывод — WASAPI в общем режиме (Windows сама
//! пересчитывает частоту под звуковую карту)

use std::collections::VecDeque;
use std::net::UdpSocket;
use std::sync::atomic::{AtomicBool, AtomicU32, Ordering};
use std::sync::mpsc::Sender;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use aes::cipher::{BlockDecryptMut, KeyIvInit};
use fdk_aac_sys as fdk;
use windows::core::w;
use windows::Win32::Foundation::{CloseHandle, WAIT_OBJECT_0};
use windows::Win32::Media::Audio::*;
use windows::Win32::System::Com::{CoCreateInstance, CoInitializeEx, CLSCTX_ALL, COINIT_MULTITHREADED};
use windows::Win32::System::Threading::{CreateEventW, WaitForSingleObject};

use crate::decode::Cmd;
use crate::log;

pub const RATE: u32 = 44_100;
/// держим в очереди около 120 мс: меньше — щелчки при задержках Wi-Fi, больше — звук отстаёт от картинки
const TARGET: usize = RATE as usize * 2 * 120 / 1000;
const MAX: usize = RATE as usize * 2 * 350 / 1000;

type Aes128CbcDec = cbc::Decryptor<aes::Aes128>;

/// Очередь отсчётов (стерео, i16) от приёмника к звуковой карте
static QUEUE: Mutex<VecDeque<i16>> = Mutex::new(VecDeque::new());
/// громкость с телефона (его кнопки громкости), 0…1 в виде битов f32
static PHONE_GAIN: AtomicU32 = AtomicU32::new(0x3f80_0000);
static MUTED: AtomicBool = AtomicBool::new(false);
static PLAYER: AtomicBool = AtomicBool::new(false);
/// идёт запись — копию звука отправляем в декодер видео
pub static RECORDING: AtomicBool = AtomicBool::new(false);
/// когда последний раз пришёл звук (для значка на панели)
static LAST: Mutex<Option<Instant>> = Mutex::new(None);

pub fn muted() -> bool {
    MUTED.load(Ordering::Relaxed)
}

pub fn set_muted(on: bool) {
    MUTED.store(on, Ordering::Relaxed);
}

/// Звук сейчас идёт
pub fn active() -> bool {
    LAST.lock().ok().and_then(|l| *l).is_some_and(|t| t.elapsed() < Duration::from_secs(2))
}

/// SET_PARAMETER «volume: -12.5»: от −30 дБ (тихо) до 0, −144 — без звука
pub fn set_phone_volume(db: f32) {
    let g = if db <= -30.0 { 0.0 } else { ((db + 30.0) / 30.0).clamp(0.0, 1.0).powi(2) };
    PHONE_GAIN.store(g.to_bits(), Ordering::Relaxed);
    log(&format!("звук: громкость телефона {db:.1} дБ → {:.0} %", g * 100.0));
}

struct Decoder(fdk::HANDLE_AACDECODER);

impl Decoder {
    /// ct = 8 — AAC-ELD 44.1 кГц стерео, 480 отсчётов на пакет; ct = 4 — AAC-LC
    fn new(ct: u64) -> Option<Decoder> {
        let mut asc: Vec<u8> = match ct {
            8 => vec![0xF8, 0xE8, 0x50, 0x00],
            4 => vec![0x12, 0x10],
            _ => return None,
        };
        unsafe {
            let h = fdk::aacDecoder_Open(fdk::TRANSPORT_TYPE_TT_MP4_RAW, 1);
            if h.is_null() {
                return None;
            }
            let mut p = asc.as_mut_ptr();
            let len = asc.len() as u32;
            if fdk::aacDecoder_ConfigRaw(h, &mut p, &len) != 0 {
                fdk::aacDecoder_Close(h);
                return None;
            }
            Some(Decoder(h))
        }
    }

    fn decode(&mut self, data: &[u8], out: &mut Vec<i16>) -> bool {
        unsafe {
            let mut buf = data.to_vec();
            let mut p = buf.as_mut_ptr();
            let size = buf.len() as u32;
            let mut valid = size;
            if fdk::aacDecoder_Fill(self.0, &mut p, &size, &mut valid) != 0 {
                return false;
            }
            let mut pcm = [0i16; 2048 * 2];
            if fdk::aacDecoder_DecodeFrame(self.0, pcm.as_mut_ptr(), pcm.len() as i32, 0) != 0 {
                return false;
            }
            let info = fdk::aacDecoder_GetStreamInfo(self.0);
            if info.is_null() {
                return false;
            }
            let (n, ch) = ((*info).frameSize as usize, (*info).numChannels as usize);
            match ch {
                2 => out.extend_from_slice(&pcm[..n * 2]),
                1 => {
                    for s in &pcm[..n] {
                        out.extend_from_slice(&[*s, *s]);
                    }
                }
                _ => return false,
            }
            true
        }
    }
}

impl Drop for Decoder {
    fn drop(&mut self) {
        unsafe { fdk::aacDecoder_Close(self.0) };
    }
}

/// Приём звукового потока, пока не выставлен stop
pub fn receive(sock: UdpSocket, ct: u64, key: [u8; 16], iv: [u8; 16], stop: Arc<AtomicBool>, video: Sender<Cmd>) {
    let Some(mut dec) = Decoder::new(ct) else {
        log(&format!("звук: формат {ct} не поддерживается"));
        drain(sock, stop);
        return;
    };
    let _ = sock.set_read_timeout(Some(Duration::from_millis(300)));
    let mut buf = vec![0u8; 8192];
    // каждый пакет AAC-ELD приходит трижды — играем по порядковому номеру один раз
    let mut last: Option<u16> = None;
    let mut pcm = Vec::with_capacity(4096);
    let mut packets = 0u64;
    log(&format!("звук: приём, формат {ct}"));
    while !stop.load(Ordering::SeqCst) {
        let Ok((n, _)) = sock.recv_from(&mut buf) else { continue };
        if n < 12 || buf[1] & 0x7f != 0x60 {
            continue;
        }
        let seq = u16::from_be_bytes([buf[2], buf[3]]);
        if let Some(l) = last {
            let d = seq.wrapping_sub(l) as i16;
            if d <= 0 {
                continue;
            }
        }
        last = Some(seq);
        let payload = &mut buf[12..n];
        // пакеты-заглушки в начале потока
        if payload.len() == 4 && payload == [0x00, 0x68, 0x34, 0x00] {
            continue;
        }
        let enc = payload.len() / 16 * 16;
        if enc > 0 {
            let mut c = Aes128CbcDec::new(&key.into(), &iv.into());
            for block in payload[..enc].chunks_exact_mut(16) {
                c.decrypt_block_mut(block.into());
            }
        }
        pcm.clear();
        if !dec.decode(payload, &mut pcm) {
            continue;
        }
        packets += 1;
        if let Ok(mut l) = LAST.lock() {
            *l = Some(Instant::now());
        }
        if RECORDING.load(Ordering::Relaxed) {
            let _ = video.send(Cmd::Audio(pcm.clone()));
        }
        push(&pcm);
    }
    log(&format!("звук: поток закрыт, пакетов {packets}"));
}

fn drain(sock: UdpSocket, stop: Arc<AtomicBool>) {
    let _ = sock.set_read_timeout(Some(Duration::from_millis(500)));
    let mut buf = vec![0u8; 4096];
    while !stop.load(Ordering::SeqCst) {
        let _ = sock.recv_from(&mut buf);
    }
}

fn push(pcm: &[i16]) {
    if let Ok(mut q) = QUEUE.lock() {
        q.extend(pcm.iter().copied());
        // отстали (Wi-Fi притормозил, а потом выдал пачку) — догоняем, выбрасывая старое
        if q.len() > MAX {
            let extra = q.len() - TARGET;
            q.drain(..extra & !1);
        }
    }
    if !PLAYER.swap(true, Ordering::SeqCst) {
        std::thread::spawn(|| {
            if let Err(e) = play() {
                log(&format!("звук: вывод не работает ({e})"));
            }
            PLAYER.store(false, Ordering::SeqCst);
        });
    }
}

/// Вывод на звуковую карту по умолчанию; сам заканчивается после 3 с тишины
fn play() -> windows::core::Result<()> {
    unsafe {
        let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
        let en: IMMDeviceEnumerator = CoCreateInstance(&MMDeviceEnumerator, None, CLSCTX_ALL)?;
        let dev = en.GetDefaultAudioEndpoint(eRender, eConsole)?;
        let client: IAudioClient = dev.Activate(CLSCTX_ALL, None)?;
        let wfx = WAVEFORMATEX {
            wFormatTag: WAVE_FORMAT_PCM as u16,
            nChannels: 2,
            nSamplesPerSec: RATE,
            nAvgBytesPerSec: RATE * 4,
            nBlockAlign: 4,
            wBitsPerSample: 16,
            cbSize: 0,
        };
        client.Initialize(
            AUDCLNT_SHAREMODE_SHARED,
            AUDCLNT_STREAMFLAGS_EVENTCALLBACK | AUDCLNT_STREAMFLAGS_AUTOCONVERTPCM | AUDCLNT_STREAMFLAGS_SRC_DEFAULT_QUALITY,
            400_000,
            0,
            &wfx,
            None,
        )?;
        let event = CreateEventW(None, false, false, None)?;
        client.SetEventHandle(event)?;
        let render: IAudioRenderClient = client.GetService()?;
        // так поток подписан в микшере громкости Windows (и в MacMixer)
        if let Ok(s) = client.GetService::<IAudioSessionControl>() {
            let _ = s.SetDisplayName(w!("Звук iPhone"), std::ptr::null());
        }
        let size = client.GetBufferSize()?;
        client.Start()?;
        log("звук: вывод начат");
        let mut started = false;
        let mut idle = Instant::now();
        loop {
            let _ = WaitForSingleObject(event, 200) == WAIT_OBJECT_0;
            let pad = client.GetCurrentPadding()?;
            let free = (size - pad) as usize;
            if free == 0 {
                continue;
            }
            let p = render.GetBuffer(free as u32)?;
            let out = std::slice::from_raw_parts_mut(p as *mut i16, free * 2);
            let gain = if muted() { 0.0 } else { f32::from_bits(PHONE_GAIN.load(Ordering::Relaxed)) };
            let mut got = 0;
            if let Ok(mut q) = QUEUE.lock() {
                // начинаем, когда накопился запас — иначе первые доли секунды трещат
                if !started && q.len() >= TARGET / 2 {
                    started = true;
                }
                if started {
                    got = q.len().min(out.len());
                    for (o, s) in out.iter_mut().zip(q.drain(..got)) {
                        *o = (s as f32 * gain) as i16;
                    }
                    if q.is_empty() {
                        started = false;
                    }
                }
            }
            out[got..].fill(0);
            render.ReleaseBuffer(free as u32, 0)?;
            if got > 0 {
                idle = Instant::now();
            } else if idle.elapsed() > Duration::from_secs(3) {
                break;
            }
        }
        client.Stop()?;
        let _ = CloseHandle(event);
        log("звук: вывод остановлен");
        Ok(())
    }
}

/// Проверка без телефона: тон 440 Гц кодируем в AAC-ELD с параметрами iPhone (44.1 кГц, стерео,
/// 480 отсчётов) кодировщиком FDK и декодируем тем же путём, что и звук с телефона
pub fn selftest() -> Result<String, String> {
    unsafe {
        let mut enc: fdk::HANDLE_AACENCODER = std::ptr::null_mut();
        if fdk::aacEncOpen(&mut enc, 0, 2) != 0 {
            return Err("кодировщик не открылся".into());
        }
        for (p, v) in [
            (fdk::AACENC_PARAM_AACENC_AOT, 39),
            (fdk::AACENC_PARAM_AACENC_SAMPLERATE, RATE),
            (fdk::AACENC_PARAM_AACENC_CHANNELMODE, 2),
            (fdk::AACENC_PARAM_AACENC_GRANULE_LENGTH, 480),
            (fdk::AACENC_PARAM_AACENC_TRANSMUX, 0),
            (fdk::AACENC_PARAM_AACENC_BITRATE, 128_000),
        ] {
            if fdk::aacEncoder_SetParam(enc, p, v) != 0 {
                return Err(format!("параметр {p} не принят"));
            }
        }
        if fdk::aacEncEncode(enc, std::ptr::null(), std::ptr::null(), std::ptr::null(), std::ptr::null_mut()) != 0 {
            return Err("кодировщик не настроился".into());
        }
        let mut info: fdk::AACENC_InfoStruct = std::mem::zeroed();
        fdk::aacEncInfo(enc, &mut info);
        let asc: Vec<u8> = info.confBuf[..info.confSize as usize].to_vec();
        let mut dec = Decoder::new(8).ok_or("декодер не открылся")?;
        let mut decoded = Vec::new();
        let mut packets = 0;
        let mut out = vec![0u8; 2048];
        for f in 0..40 {
            let mut pcm: Vec<i16> = (0..480)
                .flat_map(|i| {
                    let t = (f * 480 + i) as f32 / RATE as f32;
                    let v = ((t * 440.0 * std::f32::consts::TAU).sin() * 12000.0) as i16;
                    [v, v]
                })
                .collect();
            let mut in_ptr = pcm.as_mut_ptr() as *mut std::ffi::c_void;
            let mut in_id = fdk::AACENC_BufferIdentifier_IN_AUDIO_DATA as i32;
            let mut in_size = (pcm.len() * 2) as i32;
            let mut in_el = 2i32;
            let inb = fdk::AACENC_BufDesc { numBufs: 1, bufs: &mut in_ptr, bufferIdentifiers: &mut in_id, bufSizes: &mut in_size, bufElSizes: &mut in_el };
            let mut out_ptr = out.as_mut_ptr() as *mut std::ffi::c_void;
            let mut out_id = fdk::AACENC_BufferIdentifier_OUT_BITSTREAM_DATA as i32;
            let mut out_size = out.len() as i32;
            let mut out_el = 1i32;
            let outb = fdk::AACENC_BufDesc { numBufs: 1, bufs: &mut out_ptr, bufferIdentifiers: &mut out_id, bufSizes: &mut out_size, bufElSizes: &mut out_el };
            let mut ia: fdk::AACENC_InArgs = std::mem::zeroed();
            ia.numInSamples = pcm.len() as i32;
            let mut oa: fdk::AACENC_OutArgs = std::mem::zeroed();
            if fdk::aacEncEncode(enc, &inb, &outb, &ia, &mut oa) != 0 {
                return Err("кодирование не удалось".into());
            }
            if oa.numOutBytes > 0 {
                packets += 1;
                dec.decode(&out[..oa.numOutBytes as usize], &mut decoded);
            }
        }
        fdk::aacEncClose(&mut enc);
        let peak = decoded.iter().map(|s| s.unsigned_abs()).max().unwrap_or(0);
        Ok(format!(
            "ASC кодировщика {:02x?} (у iPhone f8 e8 50 00), пакетов {packets}, декодировано отсчётов {} (по 480 на пакет), пик {peak}",
            asc,
            decoded.len() / 2
        ))
    }
}