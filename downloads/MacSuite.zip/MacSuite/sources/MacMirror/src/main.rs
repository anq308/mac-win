#![windows_subsystem = "windows"]
//! MacMirror — экран iPhone на компьютере по Wi-Fi («Повтор экрана» / AirPlay), снимки и запись

mod airplay;
mod audio;
mod decode;
mod fairplay;
mod files;
mod gfx;
mod net;
mod share;
mod ui;
mod win;

use std::io::Write;
use std::net::Ipv4Addr;
use std::path::PathBuf;
use std::sync::{Arc, Mutex};

use ed25519_dalek::SigningKey;
use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::System::Com::{CoInitializeEx, COINIT_APARTMENTTHREADED};
use windows::Win32::System::SystemInformation::{ComputerNameDnsHostname, GetComputerNameExW};
use windows::Win32::System::Threading::CreateMutexW;
use windows::Win32::UI::HiDpi::{SetProcessDpiAwarenessContext, DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2};
use windows::Win32::UI::WindowsAndMessaging::*;

pub fn data_dir() -> PathBuf {
    let base = std::env::var("LOCALAPPDATA").unwrap_or_else(|_| ".".into());
    let d = PathBuf::from(base).join("MacMirror");
    let _ = std::fs::create_dir_all(&d);
    d
}

static LOG: Mutex<()> = Mutex::new(());

/// Журнал %LOCALAPPDATA%\MacMirror\mirror.log — по нему видно, на каком шаге телефон отвалился
pub fn log(s: &str) {
    let _g = LOG.lock();
    let t = unsafe { windows::Win32::System::SystemInformation::GetLocalTime() };
    let line = format!("{:02}.{:02} {:02}:{:02}:{:02}.{:03}  {s}\n", t.wDay, t.wMonth, t.wHour, t.wMinute, t.wSecond, t.wMilliseconds);
    if let Ok(mut f) = std::fs::OpenOptions::new().create(true).append(true).open(data_dir().join("mirror.log")) {
        let _ = f.write_all(line.as_bytes());
    }
}

/// Постоянный ключ приёмника: по нему iPhone узнаёт компьютер при следующих подключениях
fn load_key() -> SigningKey {
    let p = data_dir().join("key.bin");
    if let Ok(b) = std::fs::read(&p) {
        if let Ok(seed) = <[u8; 32]>::try_from(b.as_slice()) {
            return SigningKey::from_bytes(&seed);
        }
    }
    let k = SigningKey::generate(&mut rand::rngs::OsRng);
    let _ = std::fs::write(&p, k.to_bytes());
    k
}

/// Адрес-идентификатор устройства: MAC адаптера Wi-Fi, а без него — постоянный случайный
fn device_mac(adapters: &[net::Adapter]) -> [u8; 6] {
    if let Some(a) = adapters.iter().find(|a| a.mac != [0; 6]) {
        return a.mac;
    }
    let p = data_dir().join("mac.bin");
    if let Ok(b) = std::fs::read(&p) {
        if let Ok(m) = <[u8; 6]>::try_from(b.as_slice()) {
            return m;
        }
    }
    let mut m: [u8; 6] = rand::random();
    m[0] = (m[0] | 2) & !1;
    let _ = std::fs::write(&p, m);
    m
}

fn computer_name() -> String {
    let mut buf = [0u16; 256];
    let mut n = buf.len() as u32;
    let ok = unsafe { GetComputerNameExW(ComputerNameDnsHostname, Some(windows::core::PWSTR(buf.as_mut_ptr())), &mut n).is_ok() };
    if ok && n > 0 {
        String::from_utf16_lossy(&buf[..n as usize])
    } else {
        "Windows".into()
    }
}

struct Net {
    cfg: Arc<airplay::Config>,
    port: u16,
    ips: Vec<Ipv4Addr>,
    daemon: Option<mdns_sd::ServiceDaemon>,
}

static NET: Mutex<Option<Net>> = Mutex::new(None);

/// Проверить сеть (раз в 30 с): сменился адрес — объявляемся заново
pub fn refresh_network() {
    std::thread::spawn(|| {
        let adapters = net::adapters();
        let ips: Vec<Ipv4Addr> = adapters.iter().map(|a| a.ip).collect();
        let wifi = net::wifi_name();
        ui::set_network(wifi, ips.first().map(|i| i.to_string()));
        let Ok(mut g) = NET.lock() else { return };
        let Some(n) = g.as_mut() else { return };
        if n.ips == ips && n.daemon.is_some() {
            return;
        }
        if let Some(d) = n.daemon.take() {
            let _ = d.shutdown();
        }
        n.ips = ips;
        if n.ips.is_empty() {
            log("сеть: нет подключения");
            return;
        }
        match net::advertise(&n.cfg, &n.ips, n.port) {
            Ok(d) => {
                log(&format!("объявлен в сети как «{}» на {:?}:{}", n.cfg.name, n.ips, n.port));
                n.daemon = Some(d);
            }
            Err(e) => log(&format!("mDNS: {e}")),
        }
    });
}

fn main() {
    std::panic::set_hook(Box::new(|info| log(&format!("СБОЙ: {info}"))));
    unsafe {
        let _ = SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
        let _ = CoInitializeEx(None, COINIT_APARTMENTTHREADED);
    }
    let args: Vec<String> = std::env::args().skip(1).collect();
    match args.first().map(String::as_str) {
        Some("--preview") => return preview(&args[1..]),
        Some("--selftest-audio") => {
            let r = audio::selftest();
            let out = args.get(1).cloned().unwrap_or_else(|| "selftest-audio.txt".into());
            let _ = std::fs::write(out, format!("{r:#?}"));
            return;
        }
        Some("--selftest-airplay") => {
            let r = airplay::selftest();
            let out = args.get(1).cloned().unwrap_or_else(|| "selftest-airplay.txt".into());
            let _ = std::fs::write(out, format!("{r:#?}"));
            return;
        }
        Some("--selftest-share") => {
            let out = args.get(1).cloned().unwrap_or_else(|| "selftest-share.txt".into());
            let _ = std::fs::write(out, share::selftest());
            return;
        }
        Some("--selftest") => {
            let dir = PathBuf::from(args.get(1).cloned().unwrap_or_else(|| ".".into()));
            let r = decode::selftest(&dir);
            let _ = std::fs::write(dir.join("selftest.txt"), format!("{r:?}"));
            return;
        }
        _ => {}
    }
    unsafe {
        let _ = CreateMutexW(None, true, w!("Local\\MacMirror.Instance"));
        if GetLastError() == ERROR_ALREADY_EXISTS {
            if let Ok(h) = FindWindowW(w!("MacMirror.Main"), None) {
                let _ = ShowWindow(h, SW_RESTORE);
                let _ = SetForegroundWindow(h);
            }
            return;
        }
    }
    // журнал не растёт бесконечно
    let lp = data_dir().join("mirror.log");
    if std::fs::metadata(&lp).is_ok_and(|m| m.len() > 2_000_000) {
        let _ = std::fs::remove_file(&lp);
    }
    log("─── запуск");
    let Some(fonts) = gfx::Fonts::load() else { return };
    gfx::load_themes();
    gfx::use_theme(true);

    let adapters = net::adapters();
    log(&format!("адаптеры: {adapters:?}"));
    share::set_name(computer_name());
    let cfg = Arc::new(airplay::Config {
        name: computer_name(),
        mac: device_mac(&adapters),
        key: load_key(),
        width: 1920,
        height: 1920,
        fps: 60,
    });

    let (tx, rx) = std::sync::mpsc::channel();
    decode::start(rx, ui::video_event);
    let hooks = Arc::new(airplay::Hooks { note: Box::new(ui::note), video: tx.clone() });
    let port = match airplay::start(cfg.clone(), hooks) {
        Ok(p) => p,
        Err(e) => {
            log(&format!("порт не открыт: {e}"));
            0
        }
    };
    log(&format!("приёмник на порту {port}"));
    if let Ok(mut g) = NET.lock() {
        *g = Some(Net { cfg: cfg.clone(), port, ips: Vec::new(), daemon: None });
    }
    refresh_network();

    let st = ui::State {
        phase: ui::Phase::Waiting,
        live: false,
        video: None,
        hover: None,
        pressed: None,
        topmost: false,
        recording: None,
        toast: None,
        rotate: 0,
        muted: false,
        name: cfg.name.clone(),
        wifi: None,
        ip: adapters.first().map(|a| a.ip.to_string()),
    };
    let hidden = args.iter().any(|a| a == "--tray");
    ui::run(fonts, st, tx, hidden);
    if let Ok(mut g) = NET.lock() {
        if let Some(d) = g.as_mut().and_then(|n| n.daemon.take()) {
            let _ = d.shutdown();
        }
    }
    log("─── выход");
}

/// mac-mirror.exe --preview waiting|connecting|live|record|hover out.png
fn preview(args: &[String]) {
    let kind = args.first().map_or("waiting", String::as_str);
    let out = args.get(1).cloned().unwrap_or_else(|| "preview.png".into());
    let Some(fonts) = gfx::Fonts::load() else { return };
    gfx::load_themes();
    gfx::use_theme(true);
    if kind == "share" {
        share::preview(std::path::Path::new(&out), fonts);
        return;
    }
    let phase = match kind {
        "waiting" => ui::Phase::Waiting,
        "connecting" => ui::Phase::Connecting("iPhone".into()),
        _ => ui::Phase::Live("iPhone".into()),
    };
    let live = !matches!(kind, "waiting" | "connecting");
    let st = ui::State {
        phase,
        live,
        video: live.then_some((888, 1920)),
        hover: (kind == "hover").then_some(ui::Btn::Shot),
        pressed: None,
        topmost: kind == "record",
        recording: (kind == "record").then(|| std::time::Instant::now() - std::time::Duration::from_secs(73)),
        rotate: 0,
        muted: kind == "record",
        toast: (kind == "live").then(|| ("Снимок сохранён: Снимок iPhone 2026-11-06 14-03-22.png · уже в буфере обмена".to_string(), std::time::Instant::now())),
        name: "DESKTOP-ПК".into(),
        wifi: Some("Домашний Wi-Fi".into()),
        ip: Some("192.168.1.23".into()),
    };
    let img = ui::preview(kind, st, &fonts, 430, 880);
    if let Some(png) = win::encode_png(&img) {
        let _ = std::fs::write(out, png);
    }
}
