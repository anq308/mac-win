//! Файлы между iPhone и компьютером по Wi-Fi без приложений: на ПК окно с QR-кодом, на телефоне — страница в Safari.
//! Сервер работает, только пока окно открыто, пускает только из домашней сети и только по ссылке
//! с секретным кодом. Фото и видео ложатся в «Изображения\iPhone», остальное — в «Загрузки».

use std::cell::RefCell;
use std::io::{BufWriter, Read, Seek, SeekFrom, Write};
use std::net::{IpAddr, TcpListener, TcpStream};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicIsize, AtomicU16, Ordering};
use std::sync::{Mutex, OnceLock};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use qrcodegen::{QrCode, QrCodeEcc};
use tiny_skia::PixmapMut;
use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Dwm::DwmSetWindowAttribute;
use windows::Win32::Graphics::Dwm::DWMWINDOWATTRIBUTE;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Controls::WM_MOUSELEAVE;
use windows::Win32::UI::HiDpi::{AdjustWindowRectExForDpi, GetDpiForWindow};
use windows::Win32::UI::Input::KeyboardAndMouse::{TrackMouseEvent, TME_LEAVE, TRACKMOUSEEVENT};
use windows::Win32::UI::Shell::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::gfx::{self, Fonts, Img};
use crate::{files, log, net, win};

const WM_SHARE: u32 = WM_APP + 10;
const TIMER_SUMMARY: usize = 1;
const TIMER_COPIED: usize = 2;
/// ширина и высота окна в логических точках (без рамки)
const W: f32 = 400.0;
const H: f32 = 752.0;
const RECEIVED_ROWS: usize = 4;
const OFFER_ROWS: usize = 3;

#[derive(Clone, PartialEq)]
enum St {
    Active,
    Done,
    Failed,
}

#[derive(Clone)]
struct Transfer {
    name: String,
    size: u64,
    done: u64,
    state: St,
    path: Option<PathBuf>,
    at: SystemTime,
}

#[derive(Clone)]
struct Offer {
    id: u32,
    path: PathBuf,
    size: u64,
}

#[derive(Default)]
struct Shared {
    transfers: Vec<Transfer>,
    offers: Vec<Offer>,
    next_id: u32,
    /// получено с прошлой сводки в «островке»
    fresh: Vec<PathBuf>,
}

static SHARED: Mutex<Shared> = Mutex::new(Shared { transfers: Vec::new(), offers: Vec::new(), next_id: 1, fresh: Vec::new() });
static RUNNING: AtomicBool = AtomicBool::new(false);
static PORT: AtomicU16 = AtomicU16::new(0);
static WINDOW: AtomicIsize = AtomicIsize::new(0);
static NAME: OnceLock<String> = OnceLock::new();

/// Секретная часть адреса: без неё сервер отвечает «не найдено» — соседи по Wi-Fi файлы не увидят
fn token() -> &'static str {
    static T: OnceLock<String> = OnceLock::new();
    T.get_or_init(|| {
        use rand::Rng;
        const A: &[u8] = b"abcdefghijkmnpqrstuvwxyz23456789";
        let mut r = rand::thread_rng();
        (0..10).map(|_| A[r.gen_range(0..A.len())] as char).collect()
    })
}

pub fn set_name(name: String) {
    let _ = NAME.set(name);
}

fn post(wp: usize) {
    let h = WINDOW.load(Ordering::Relaxed);
    if h != 0 {
        unsafe {
            let _ = PostMessageW(Some(HWND(h as *mut _)), WM_SHARE, WPARAM(wp), LPARAM(0));
        }
    }
}

fn address() -> Option<String> {
    let ip = net::adapters().first()?.ip;
    let port = PORT.load(Ordering::Relaxed);
    (port != 0).then(|| format!("http://{ip}:{port}/{}", token()))
}

// ---------- сервер ----------

fn start_server() {
    if RUNNING.swap(true, Ordering::SeqCst) {
        return;
    }
    let listener = (7300..7320).find_map(|p| TcpListener::bind(("0.0.0.0", p)).ok());
    let Some(listener) = listener else {
        RUNNING.store(false, Ordering::SeqCst);
        log("файлы: порт не открыт");
        return;
    };
    let port = listener.local_addr().map(|a| a.port()).unwrap_or(0);
    PORT.store(port, Ordering::SeqCst);
    log(&format!("файлы: сервер на порту {port}"));
    let _ = listener.set_nonblocking(true);
    std::thread::spawn(move || {
        while RUNNING.load(Ordering::SeqCst) {
            match listener.accept() {
                Ok((s, addr)) => {
                    if !home(addr.ip()) {
                        continue;
                    }
                    let _ = s.set_nonblocking(false);
                    std::thread::spawn(move || {
                        let _ = handle(s);
                    });
                }
                Err(_) => std::thread::sleep(Duration::from_millis(120)),
            }
        }
        PORT.store(0, Ordering::SeqCst);
        log("файлы: сервер остановлен");
    });
}

fn stop_server() {
    RUNNING.store(false, Ordering::SeqCst);
}

/// Только домашняя сеть: 192.168.*, 10.*, 172.16–31.*, 169.254.* и сам компьютер
fn home(ip: IpAddr) -> bool {
    let v4 = match ip {
        IpAddr::V4(a) => a,
        IpAddr::V6(a) => match a.to_ipv4_mapped() {
            Some(a) => a,
            None => return a.is_loopback() || (a.segments()[0] & 0xffc0) == 0xfe80,
        },
    };
    v4.is_private() || v4.is_link_local() || v4.is_loopback()
}

struct Request {
    method: String,
    path: String,
    query: String,
    headers: Vec<(String, String)>,
    /// часть тела, прочитанная вместе с заголовками
    rest: Vec<u8>,
}

impl Request {
    fn header(&self, name: &str) -> Option<&str> {
        self.headers.iter().find(|(k, _)| k.eq_ignore_ascii_case(name)).map(|(_, v)| v.as_str())
    }

    fn param(&self, name: &str) -> Option<String> {
        self.query.split('&').find_map(|kv| {
            let (k, v) = kv.split_once('=')?;
            (k == name).then(|| percent_decode(v))
        })
    }
}

fn read_request(s: &mut TcpStream) -> Option<Request> {
    let mut buf = Vec::new();
    let mut chunk = [0u8; 4096];
    let end = loop {
        let n = s.read(&mut chunk).ok()?;
        if n == 0 {
            return None;
        }
        buf.extend_from_slice(&chunk[..n]);
        if let Some(i) = buf.windows(4).position(|w| w == b"\r\n\r\n") {
            break i;
        }
        if buf.len() > 32 * 1024 {
            return None;
        }
    };
    let head = String::from_utf8_lossy(&buf[..end]).to_string();
    let rest = buf[end + 4..].to_vec();
    let mut lines = head.split("\r\n");
    let mut first = lines.next()?.split(' ');
    let method = first.next()?.to_string();
    let target = first.next()?.to_string();
    let (path, query) = target.split_once('?').map_or((target.clone(), String::new()), |(p, q)| (p.to_string(), q.to_string()));
    let headers = lines.filter_map(|l| l.split_once(':')).map(|(k, v)| (k.trim().to_string(), v.trim().to_string())).collect();
    Some(Request { method, path, query, headers, rest })
}

fn percent_decode(s: &str) -> String {
    let b = s.as_bytes();
    let mut out = Vec::with_capacity(b.len());
    let mut i = 0;
    while i < b.len() {
        match b[i] {
            b'%' if i + 2 < b.len() => {
                let hex = std::str::from_utf8(&b[i + 1..i + 3]).ok().and_then(|h| u8::from_str_radix(h, 16).ok());
                match hex {
                    Some(v) => {
                        out.push(v);
                        i += 3;
                        continue;
                    }
                    None => out.push(b'%'),
                }
            }
            b'+' => out.push(b' '),
            c => out.push(c),
        }
        i += 1;
    }
    String::from_utf8_lossy(&out).to_string()
}

fn percent_encode(s: &str) -> String {
    s.bytes()
        .map(|c| if c.is_ascii_alphanumeric() || b"-_.~".contains(&c) { (c as char).to_string() } else { format!("%{c:02X}") })
        .collect()
}

fn respond(s: &mut TcpStream, status: &str, kind: &str, body: &[u8]) -> std::io::Result<()> {
    let head = format!(
        "HTTP/1.1 {status}\r\nContent-Type: {kind}\r\nContent-Length: {}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n",
        body.len()
    );
    s.write_all(head.as_bytes())?;
    s.write_all(body)
}

fn handle(mut s: TcpStream) -> std::io::Result<()> {
    let _ = s.set_read_timeout(Some(Duration::from_secs(60)));
    let _ = s.set_nodelay(true);
    let Some(req) = read_request(&mut s) else { return Ok(()) };
    let prefix = format!("/{}", token());
    let Some(rest) = req.path.strip_prefix(&prefix).map(str::to_string) else {
        return respond(&mut s, "404 Not Found", "text/plain; charset=utf-8", "Не найдено".as_bytes());
    };
    match (req.method.as_str(), rest.as_str()) {
        ("GET", "" | "/") => {
            let name = NAME.get().cloned().unwrap_or_else(|| "Компьютер".into());
            let safe = name.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;");
            let page = include_str!("share.html").replace("{{NAME}}", &safe);
            respond(&mut s, "200 OK", "text/html; charset=utf-8", page.as_bytes())
        }
        ("GET", "/list") => {
            let offers = SHARED.lock().map(|g| g.offers.clone()).unwrap_or_default();
            let items: Vec<String> = offers
                .iter()
                .map(|o| {
                    let name = o.path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
                    format!("{{\"id\":{},\"name\":\"{}\",\"size\":{}}}", o.id, json_escape(&name), o.size)
                })
                .collect();
            respond(&mut s, "200 OK", "application/json", format!("[{}]", items.join(",")).as_bytes())
        }
        ("GET", r) if r.starts_with("/get/") => {
            let id: u32 = r[5..].parse().unwrap_or(0);
            let offer = SHARED.lock().ok().and_then(|g| g.offers.iter().find(|o| o.id == id).cloned());
            match offer {
                Some(o) => send_file(&mut s, &req, &o.path),
                None => respond(&mut s, "404 Not Found", "text/plain; charset=utf-8", "Файла больше нет".as_bytes()),
            }
        }
        ("POST", "/up") => receive(&mut s, req),
        _ => respond(&mut s, "404 Not Found", "text/plain; charset=utf-8", "Не найдено".as_bytes()),
    }
}

fn json_escape(s: &str) -> String {
    let mut o = String::new();
    for c in s.chars() {
        match c {
            '"' => o.push_str("\\\""),
            '\\' => o.push_str("\\\\"),
            c if (c as u32) < 0x20 => o.push_str(&format!("\\u{:04x}", c as u32)),
            c => o.push(c),
        }
    }
    o
}

fn ext_of(name: &str) -> String {
    Path::new(name).extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default()
}

fn media(name: &str) -> bool {
    matches!(
        ext_of(name).as_str(),
        "jpg" | "jpeg" | "png" | "heic" | "heif" | "gif" | "webp" | "mov" | "mp4" | "m4v" | "hevc" | "avi" | "dng" | "tif" | "tiff"
    )
}

fn mime(name: &str) -> &'static str {
    match ext_of(name).as_str() {
        "jpg" | "jpeg" => "image/jpeg",
        "png" => "image/png",
        "gif" => "image/gif",
        "webp" => "image/webp",
        "heic" => "image/heic",
        "mp4" | "m4v" => "video/mp4",
        "mov" => "video/quicktime",
        "mp3" => "audio/mpeg",
        "m4a" => "audio/mp4",
        "pdf" => "application/pdf",
        "txt" => "text/plain; charset=utf-8",
        _ => "application/octet-stream",
    }
}

/// Имя файла от телефона: без папок и запрещённых в Windows знаков
fn clean_name(raw: &str, modified_ms: u64) -> String {
    let base = raw.rsplit(['/', '\\']).next().unwrap_or("");
    let mut n: String = base.chars().filter(|c| !"<>:\"/\\|?*".contains(*c) && !c.is_control()).collect();
    n = n.trim().trim_matches('.').to_string();
    if n.chars().count() > 150 {
        let ext = ext_of(&n);
        n = n.chars().take(140).collect::<String>() + if ext.is_empty() { "" } else { "." } + &ext;
    }
    // Safari иногда называет все снимки одинаково — «image.jpg»; даём имя по дате съёмки
    let lower = n.to_lowercase();
    let generic = lower.starts_with("image.") || lower.starts_with("video.") || n.is_empty();
    if generic {
        let ext = ext_of(&n);
        let kind = if matches!(ext.as_str(), "mov" | "mp4" | "m4v") { "Видео iPhone" } else { "Фото iPhone" };
        let t = if modified_ms > 0 { UNIX_EPOCH + Duration::from_millis(modified_ms) } else { SystemTime::now() };
        n = format!("{kind} {}{}{}", stamp(t), if ext.is_empty() { "" } else { "." }, ext);
    }
    n
}

fn stamp(t: SystemTime) -> String {
    use windows::Win32::System::Time::{FileTimeToSystemTime, SystemTimeToTzSpecificLocalTime};
    let d = t.duration_since(UNIX_EPOCH).unwrap_or_default();
    let ft = (d.as_nanos() / 100) as u64 + 116_444_736_000_000_000;
    let ft = FILETIME { dwLowDateTime: ft as u32, dwHighDateTime: (ft >> 32) as u32 };
    let (mut st, mut lt) = (SYSTEMTIME::default(), SYSTEMTIME::default());
    unsafe {
        let _ = FileTimeToSystemTime(&ft, &mut st);
        let _ = SystemTimeToTzSpecificLocalTime(None, &st, &mut lt);
    }
    format!("{:04}-{:02}-{:02} {:02}-{:02}-{:02}", lt.wYear, lt.wMonth, lt.wDay, lt.wHour, lt.wMinute, lt.wSecond)
}

fn downloads_dir() -> PathBuf {
    unsafe {
        SHGetKnownFolderPath(&FOLDERID_Downloads, KF_FLAG_DEFAULT, None)
            .ok()
            .map(|p| {
                let s = p.to_string().unwrap_or_default();
                windows::Win32::System::Com::CoTaskMemFree(Some(p.0 as *const _));
                PathBuf::from(s)
            })
            .unwrap_or_else(|| PathBuf::from(std::env::var("USERPROFILE").unwrap_or_default()).join("Downloads"))
    }
}

fn free_path(dir: &Path, name: &str) -> PathBuf {
    let p = dir.join(name);
    if !p.exists() {
        return p;
    }
    let stem = Path::new(name).file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
    let ext = ext_of(name);
    (2..).map(|n| dir.join(if ext.is_empty() { format!("{stem} ({n})") } else { format!("{stem} ({n}).{ext}") })).find(|p| !p.exists()).unwrap()
}

/// Приём файла: тело запроса — сам файл, пишем в «имя.part» и переименовываем, когда дошёл целиком
fn receive(s: &mut TcpStream, req: Request) -> std::io::Result<()> {
    let len: u64 = req.header("Content-Length").and_then(|v| v.parse().ok()).unwrap_or(0);
    let modified: u64 = req.param("t").and_then(|v| v.parse().ok()).unwrap_or(0);
    let name = clean_name(&req.param("name").unwrap_or_default(), modified);
    let dir = if media(&name) { files::pictures_dir() } else { downloads_dir() };
    let _ = std::fs::create_dir_all(&dir);
    let dest = free_path(&dir, &name);
    let part = PathBuf::from(format!("{}.part", dest.display()));
    let idx = {
        let Ok(mut g) = SHARED.lock() else { return Ok(()) };
        g.transfers.push(Transfer { name: name.clone(), size: len, done: 0, state: St::Active, path: None, at: SystemTime::now() });
        g.transfers.len() - 1
    };
    post(0);
    let set = |done: u64, state: Option<St>, path: Option<PathBuf>| {
        if let Ok(mut g) = SHARED.lock() {
            if let Some(t) = g.transfers.get_mut(idx) {
                t.done = done;
                if let Some(st) = state {
                    t.state = st;
                    t.at = SystemTime::now();
                }
                if path.is_some() {
                    t.path = path;
                }
            }
        }
    };
    let result = (|| -> std::io::Result<()> {
        let mut out = BufWriter::with_capacity(1 << 20, std::fs::File::create(&part)?);
        let mut got = req.rest.len().min(len as usize) as u64;
        out.write_all(&req.rest[..got as usize])?;
        let mut buf = vec![0u8; 256 * 1024];
        let mut shown = Instant::now();
        while got < len {
            let want = buf.len().min((len - got) as usize);
            let n = s.read(&mut buf[..want])?;
            if n == 0 {
                return Err(std::io::ErrorKind::UnexpectedEof.into());
            }
            out.write_all(&buf[..n])?;
            got += n as u64;
            if shown.elapsed() > Duration::from_millis(150) {
                shown = Instant::now();
                set(got, None, None);
                post(0);
            }
        }
        out.flush()?;
        let f = out.into_inner().map_err(|e| e.into_error())?;
        if modified > 0 {
            let _ = f.set_modified(UNIX_EPOCH + Duration::from_millis(modified));
        }
        drop(f);
        std::fs::rename(&part, &dest)
    })();
    match result {
        Ok(()) => {
            log(&format!("файлы: получен {} ({len} байт)", dest.display()));
            set(len, Some(St::Done), Some(dest.clone()));
            if let Ok(mut g) = SHARED.lock() {
                g.fresh.push(dest);
            }
            post(1);
            respond(s, "200 OK", "application/json", b"{\"ok\":true}")
        }
        Err(e) => {
            log(&format!("файлы: не дошёл {name}: {e}"));
            let _ = std::fs::remove_file(&part);
            set(0, Some(St::Failed), None);
            post(0);
            respond(s, "500 Internal Server Error", "application/json", b"{\"ok\":false}")
        }
    }
}

/// Отдать файл на телефон; с поддержкой Range — без неё Safari не проигрывает видео
fn send_file(s: &mut TcpStream, req: &Request, path: &Path) -> std::io::Result<()> {
    let mut f = std::fs::File::open(path)?;
    let len = f.metadata()?.len();
    let name = path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
    let range = req.header("Range").and_then(|r| r.strip_prefix("bytes=")).and_then(|r| {
        let (a, b) = r.split_once('-')?;
        let a: u64 = a.parse().ok()?;
        let b: u64 = if b.is_empty() { len.saturating_sub(1) } else { b.parse().ok()? };
        (a <= b && b < len).then_some((a, b))
    });
    let (start, end) = range.unwrap_or((0, len.saturating_sub(1)));
    let count = if len == 0 { 0 } else { end - start + 1 };
    let inline = media(&name) || ext_of(&name) == "pdf";
    let disp = format!("{}; filename*=UTF-8''{}", if inline { "inline" } else { "attachment" }, percent_encode(&name));
    let status = if range.is_some() { "206 Partial Content" } else { "200 OK" };
    let mut head = format!(
        "HTTP/1.1 {status}\r\nContent-Type: {}\r\nContent-Length: {count}\r\nAccept-Ranges: bytes\r\nContent-Disposition: {disp}\r\nConnection: close\r\n",
        mime(&name)
    );
    if range.is_some() {
        head += &format!("Content-Range: bytes {start}-{end}/{len}\r\n");
    }
    head += "\r\n";
    s.write_all(head.as_bytes())?;
    if req.method == "HEAD" || count == 0 {
        return Ok(());
    }
    f.seek(SeekFrom::Start(start))?;
    std::io::copy(&mut f.take(count), s)?;
    Ok(())
}

// ---------- окно ----------

#[derive(Clone, Copy, PartialEq, Debug)]
enum Hit {
    None,
    Address,
    Received(usize),
    Unoffer(usize),
    Folder,
}

struct Share {
    hwnd: HWND,
    fonts: Fonts,
    hover: Hit,
    copied: bool,
    qr: Option<(String, QrCode)>,
}

thread_local! {
    static SHARE: RefCell<Option<Share>> = const { RefCell::new(None) };
}

fn with<R>(f: impl FnOnce(&mut Share) -> R) -> Option<R> {
    SHARE.with(|s| s.try_borrow_mut().ok()?.as_mut().map(f))
}

/// Открыть окно «Файлы с iPhone» (или вывести уже открытое)
pub fn open() {
    start_server();
    let existing = with(|s| s.hwnd);
    if let Some(h) = existing {
        unsafe {
            let _ = ShowWindow(h, SW_RESTORE);
            let _ = SetForegroundWindow(h);
        }
        return;
    }
    let Some(fonts) = Fonts::load() else { return };
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacMirror.Share"),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            hIcon: LoadIconW(Some(inst.into()), windows::core::PCWSTR(1 as *const u16)).unwrap_or_default(),
            ..Default::default()
        };
        RegisterClassW(&wc);
        let style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
        let p = win::cursor();
        let m = win::monitor_at(p);
        let dpi = (m.scale * 96.0) as u32;
        let mut r = RECT { left: 0, top: 0, right: (W * m.scale) as i32, bottom: (H * m.scale) as i32 };
        let _ = AdjustWindowRectExForDpi(&mut r, style, false, WS_EX_ACCEPTFILES, dpi);
        let (w, h) = (r.right - r.left, r.bottom - r.top);
        let x = (m.work.left + m.work.right - w) / 2;
        let y = (m.work.top + m.work.bottom - h) / 2;
        let Ok(hwnd) = CreateWindowExW(WS_EX_ACCEPTFILES, w!("MacMirror.Share"), w!("Файлы с iPhone"), style, x, y, w, h, None, None, Some(inst.into()), None)
        else {
            return;
        };
        WINDOW.store(hwnd.0 as isize, Ordering::Relaxed);
        SHARE.with(|s| *s.borrow_mut() = Some(Share { hwnd, fonts, hover: Hit::None, copied: false, qr: None }));
        gfx::use_theme(true);
        let dark: u32 = gfx::theme().dark as u32;
        let _ = DwmSetWindowAttribute(hwnd, DWMWINDOWATTRIBUTE(20), &dark as *const u32 as *const _, 4);
        let _ = ShowWindow(hwnd, SW_SHOW);
        let _ = SetForegroundWindow(hwnd);
    }
}

fn scale(hwnd: HWND) -> f32 {
    unsafe { GetDpiForWindow(hwnd).max(96) as f32 / 96.0 }
}

/// Раскладка окна (логические точки): где QR, списки и кнопки
struct Layout {
    qr: (f32, f32, f32),
    address_y: f32,
    received_y: f32,
    offers_y: f32,
    drop: (f32, f32, f32, f32),
    folder: (f32, f32, f32, f32),
}

const PAD: f32 = 24.0;
const ROW: f32 = 46.0;

fn layout() -> Layout {
    let qr_size = 196.0;
    let qr_y = 88.0;
    let address_y = qr_y + qr_size + 22.0;
    let received_y = address_y + 36.0;
    let offers_y = received_y + 26.0 + RECEIVED_ROWS as f32 * ROW + 14.0;
    let drop = (PAD, offers_y + 26.0, W - 2.0 * PAD, 54.0);
    // «Открыть папку» — ссылкой справа от заголовка «С iPhone на компьютер»
    let folder = (W - PAD - 110.0, received_y, 110.0, 20.0);
    Layout { qr: ((W - qr_size) / 2.0, qr_y, qr_size), address_y, received_y, offers_y, drop, folder }
}

fn inside(r: (f32, f32, f32, f32), x: f32, y: f32) -> bool {
    x >= r.0 && x < r.0 + r.2 && y >= r.1 && y < r.1 + r.3
}

fn hit_at(s: f32, x: i32, y: i32) -> Hit {
    let (x, y) = (x as f32 / s, y as f32 / s);
    let l = layout();
    if (y - l.address_y).abs() < 12.0 && (x - W / 2.0).abs() < 160.0 {
        return Hit::Address;
    }
    if inside(l.folder, x, y) {
        return Hit::Folder;
    }
    let shared = SHARED.lock().map(|g| (g.transfers.len(), g.offers.len())).unwrap_or((0, 0));
    for i in 0..shared.0.min(RECEIVED_ROWS) {
        if inside((PAD - 8.0, l.received_y + 26.0 + i as f32 * ROW, W - 2.0 * PAD + 16.0, ROW), x, y) {
            return Hit::Received(i);
        }
    }
    let first = l.drop.1 + l.drop.3 + 6.0;
    for i in 0..shared.1.min(OFFER_ROWS) {
        if inside((W - PAD - 30.0, first + i as f32 * 30.0, 30.0, 30.0), x, y) {
            return Hit::Unoffer(i);
        }
    }
    Hit::None
}

fn received_list() -> Vec<Transfer> {
    SHARED.lock().map(|g| g.transfers.iter().rev().take(RECEIVED_ROWS).cloned().collect()).unwrap_or_default()
}

fn offer_list() -> Vec<Offer> {
    SHARED.lock().map(|g| g.offers.iter().rev().take(OFFER_ROWS).cloned().collect()).unwrap_or_default()
}

fn size_text(n: u64) -> String {
    let f = n as f64;
    let s = if n < 1024 {
        format!("{n} Б")
    } else if f < 1048576.0 {
        format!("{:.0} КБ", f / 1024.0)
    } else if f < 1073741824.0 {
        format!("{:.1} МБ", f / 1048576.0)
    } else {
        format!("{:.2} ГБ", f / 1073741824.0)
    };
    s.replace('.', ",")
}

fn compose(sh: &mut Share, pm: &mut PixmapMut, s: f32) {
    gfx::use_theme(true);
    let p = |v: f32| v * s;
    let f = &sh.fonts;
    pm.fill(gfx::panel_bg());
    let l = layout();
    let center = |pm: &mut PixmapMut, font: &ab_glyph::FontVec, t: &str, y: f32, px: f32, c: tiny_skia::Color| {
        let tw = gfx::measure(font, t, p(px));
        gfx::text(pm, font, t, (p(W) - tw) / 2.0, p(y), p(px), c);
    };
    center(pm, &f.semibold, "Файлы с iPhone", 40.0, 20.0, gfx::white(0.95));
    center(pm, &f.regular, "Наведите камеру iPhone на код и откройте ссылку", 64.0, 13.0, gfx::white(0.6));
    // QR-код на белой подложке: так его читает камера и в тёмной теме
    let (qx, qy, qs) = l.qr;
    let addr = address();
    match &addr {
        Some(url) => {
            if sh.qr.as_ref().is_none_or(|(u, _)| u != url) {
                sh.qr = QrCode::encode_text(url, QrCodeEcc::Medium).ok().map(|q| (url.clone(), q));
            }
            gfx::fill_rrect(pm, p(qx), p(qy), p(qs), p(qs), p(12.0), gfx::rgb(0xFF, 0xFF, 0xFF, 1.0));
            if !gfx::theme().dark {
                if let Some(path) = gfx::rrect(p(qx) + 0.5, p(qy) + 0.5, p(qs) - 1.0, p(qs) - 1.0, p(12.0)) {
                    let st = tiny_skia::Stroke { width: 1.0, ..Default::default() };
                    pm.stroke_path(&path, &gfx::solid(gfx::white(0.12)), &st, tiny_skia::Transform::identity(), None);
                }
            }
            if let Some((_, q)) = &sh.qr {
                let n = q.size();
                let cell = ((p(qs) - p(24.0)) / n as f32).floor().max(1.0);
                let total = cell * n as f32;
                let ox = (p(qx) + (p(qs) - total) / 2.0).round();
                let oy = (p(qy) + (p(qs) - total) / 2.0).round();
                let black = gfx::rgb(0, 0, 0, 1.0);
                for yy in 0..n {
                    for xx in 0..n {
                        if q.get_module(xx, yy) {
                            if let Some(r) = tiny_skia::Rect::from_xywh(ox + xx as f32 * cell, oy + yy as f32 * cell, cell, cell) {
                                let mut paint = gfx::solid(black);
                                paint.anti_alias = false;
                                pm.fill_rect(r, &paint, tiny_skia::Transform::identity(), None);
                            }
                        }
                    }
                }
            }
            let shown = if sh.copied { "Ссылка скопирована".to_string() } else { url.trim_start_matches("http://").to_string() };
            let col = if sh.hover == Hit::Address || sh.copied { gfx::accent(1.0) } else { gfx::white(0.55) };
            center(pm, &f.regular, &shown, l.address_y + 4.0, 12.5, col);
        }
        None => {
            gfx::fill_rrect(pm, p(qx), p(qy), p(qs), p(qs), p(12.0), gfx::white(0.05));
            gfx::glyph(pm, '\u{F384}', p(qx + qs / 2.0), p(qy + qs / 2.0 - 14.0), p(40.0), gfx::white(0.5));
            center(pm, &f.regular, "Нет подключения к сети", qy + qs / 2.0 + 36.0, 13.0, gfx::white(0.6));
            center(pm, &f.regular, "Компьютер и iPhone должны быть в одной сети Wi-Fi", l.address_y + 4.0, 12.5, gfx::white(0.55));
        }
    }
    // получено
    let section = |pm: &mut PixmapMut, t: &str, y: f32| {
        gfx::text(pm, &f.semibold, t, p(PAD), p(y + 14.0), p(13.0), gfx::white(0.85));
    };
    section(pm, "С iPhone на компьютер", l.received_y);
    let list = received_list();
    if list.is_empty() {
        gfx::text(pm, &f.regular, "Пока ничего не получено", p(PAD), p(l.received_y + 26.0 + 26.0), p(13.0), gfx::white(0.45));
    }
    for (i, t) in list.iter().enumerate() {
        let y = l.received_y + 26.0 + i as f32 * ROW;
        if sh.hover == Hit::Received(i) && t.state == St::Done {
            gfx::fill_rrect(pm, p(PAD - 8.0), p(y), p(W - 2.0 * PAD + 16.0), p(ROW - 4.0), p(4.0), gfx::white(0.06));
        }
        let glyph = if media(&t.name) {
            if matches!(ext_of(&t.name).as_str(), "mov" | "mp4" | "m4v") {
                '\u{E714}'
            } else {
                '\u{EB9F}'
            }
        } else {
            '\u{E8A5}'
        };
        gfx::glyph(pm, glyph, p(PAD + 10.0), p(y + ROW / 2.0 - 2.0), p(18.0), gfx::white(0.7));
        let tx = PAD + 32.0;
        let name = gfx::fit(&f.regular, &t.name, p(13.5), p(W - PAD - tx));
        gfx::text(pm, &f.regular, &name, p(tx), p(y + 18.0), p(13.5), gfx::white(0.92));
        match t.state {
            St::Active => {
                let k = if t.size > 0 { t.done as f32 / t.size as f32 } else { 0.0 };
                let bw = W - PAD - tx - 90.0;
                gfx::fill_rrect(pm, p(tx), p(y + 27.0), p(bw), p(4.0), p(2.0), gfx::white(0.12));
                gfx::fill_rrect(pm, p(tx), p(y + 27.0), p(bw * k.clamp(0.0, 1.0)).max(p(4.0)), p(4.0), p(2.0), gfx::accent(1.0));
                let pct = format!("{}%", (k * 100.0) as u32);
                gfx::text(pm, &f.regular, &pct, p(tx + bw + 10.0), p(y + 33.0), p(12.0), gfx::white(0.6));
            }
            St::Done => {
                let sub = format!("{} · получено", size_text(t.size));
                gfx::text(pm, &f.regular, &sub, p(tx), p(y + 35.0), p(12.0), gfx::white(0.55));
            }
            St::Failed => {
                gfx::text(pm, &f.regular, "Не получено — связь прервалась", p(tx), p(y + 35.0), p(12.0), gfx::rgb(0xE8, 0x11, 0x23, 1.0));
            }
        }
    }
    // на iPhone
    section(pm, "С компьютера на iPhone", l.offers_y);
    let (dx, dy, dw, dh) = l.drop;
    // пунктирная рамка — место, куда бросать файлы
    if let Some(rect) = tiny_skia::Rect::from_xywh(p(dx) + 0.5, p(dy) + 0.5, p(dw) - 1.0, p(dh) - 1.0) {
        let path = tiny_skia::PathBuilder::from_rect(rect);
        let st = tiny_skia::Stroke { width: 1.0, dash: tiny_skia::StrokeDash::new(vec![p(5.0), p(4.0)], 0.0), ..Default::default() };
        pm.stroke_path(&path, &gfx::solid(gfx::white(0.3)), &st, tiny_skia::Transform::identity(), None);
    }
    gfx::glyph(pm, '\u{E898}', p(dx + 26.0), p(dy + dh / 2.0), p(18.0), gfx::white(0.6));
    gfx::text(pm, &f.regular, "Перетащите файлы сюда —", p(dx + 50.0), p(dy + 23.0), p(13.0), gfx::white(0.8));
    gfx::text(pm, &f.regular, "на iPhone их можно будет загрузить", p(dx + 50.0), p(dy + 40.0), p(13.0), gfx::white(0.55));
    let offers = offer_list();
    let first = dy + dh + 6.0;
    for (i, o) in offers.iter().enumerate() {
        let y = first + i as f32 * 30.0;
        let name = o.path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
        let t = gfx::fit(&f.regular, &format!("{name}  ·  {}", size_text(o.size)), p(13.0), p(W - 2.0 * PAD - 40.0));
        gfx::text(pm, &f.regular, &t, p(PAD + 4.0), p(y + 20.0), p(13.0), gfx::white(0.85));
        let hot = sh.hover == Hit::Unoffer(i);
        if hot {
            gfx::fill_rrect(pm, p(W - PAD - 30.0), p(y), p(30.0), p(30.0), p(4.0), gfx::white(0.08));
        }
        gfx::glyph(pm, '\u{E711}', p(W - PAD - 15.0), p(y + 15.0), p(11.0), gfx::white(if hot { 0.9 } else { 0.5 }));
    }
    // папка — ссылкой у заголовка
    let (bx, by, bw, _) = l.folder;
    let t = "Открыть папку";
    let tw = gfx::measure(&f.regular, t, p(13.0));
    let col = if sh.hover == Hit::Folder { gfx::accent(0.75) } else { gfx::accent(1.0) };
    gfx::text(pm, &f.regular, t, p(bx + bw) - tw, p(by + 14.0), p(13.0), col);
}

fn paint(sh: &mut Share, hdc: HDC) {
    let mut r = RECT::default();
    unsafe {
        let _ = GetClientRect(sh.hwnd, &mut r);
    }
    let (w, h) = (r.right.max(1) as u32, r.bottom.max(1) as u32);
    let s = scale(sh.hwnd);
    let mut img = Img::new(w, h);
    if let Some(mut pm) = img.pixmap_mut() {
        compose(sh, &mut pm, s);
    }
    blit(hdc, &img);
}

fn blit(hdc: HDC, img: &Img) {
    let bi = BITMAPINFO {
        bmiHeader: BITMAPINFOHEADER {
            biSize: std::mem::size_of::<BITMAPINFOHEADER>() as u32,
            biWidth: img.w as i32,
            biHeight: -(img.h as i32),
            biPlanes: 1,
            biBitCount: 32,
            biCompression: BI_RGB.0,
            ..Default::default()
        },
        ..Default::default()
    };
    unsafe {
        SetDIBitsToDevice(hdc, 0, 0, img.w, img.h, 0, 0, 0, img.h, img.px.as_ptr() as *const _, &bi, DIB_RGB_COLORS);
    }
}

fn reveal(path: &Path) {
    let arg = win::wide(&format!("/select,\"{}\"", path.display()));
    unsafe {
        ShellExecuteW(None, w!("open"), w!("explorer.exe"), win::pcwstr(&arg), None, SW_SHOWNORMAL);
    }
}

fn copy_text(hwnd: HWND, s: &str) {
    use windows::Win32::System::DataExchange::*;
    use windows::Win32::System::Memory::*;
    let w: Vec<u16> = s.encode_utf16().chain(Some(0)).collect();
    unsafe {
        if OpenClipboard(Some(hwnd)).is_err() {
            return;
        }
        let _ = EmptyClipboard();
        if let Ok(h) = GlobalAlloc(GMEM_MOVEABLE, w.len() * 2) {
            let p = GlobalLock(h) as *mut u16;
            if !p.is_null() {
                std::ptr::copy_nonoverlapping(w.as_ptr(), p, w.len());
                let _ = GlobalUnlock(h);
                let _ = SetClipboardData(13, Some(HANDLE(h.0)));
            }
        }
        let _ = CloseClipboard();
    }
}

fn click(hit: Hit) {
    match hit {
        Hit::Address => {
            if let Some(url) = address() {
                let h = with(|s| {
                    s.copied = true;
                    s.hwnd
                });
                if let Some(h) = h {
                    copy_text(h, &url);
                    unsafe {
                        SetTimer(Some(h), TIMER_COPIED, 1600, None);
                    }
                }
            }
        }
        Hit::Received(i) => {
            if let Some(p) = received_list().get(i).and_then(|t| t.path.clone()) {
                reveal(&p);
            }
        }
        Hit::Unoffer(i) => {
            if let Some(o) = offer_list().get(i) {
                if let Ok(mut g) = SHARED.lock() {
                    g.offers.retain(|x| x.id != o.id);
                }
            }
        }
        Hit::Folder => {
            let dir = files::pictures_dir();
            let _ = std::fs::create_dir_all(&dir);
            let p = win::wide(&dir.to_string_lossy());
            unsafe {
                ShellExecuteW(None, w!("open"), win::pcwstr(&p), None, None, SW_SHOWNORMAL);
            }
        }
        Hit::None => {}
    }
    invalidate();
}

fn invalidate() {
    let h = WINDOW.load(Ordering::Relaxed);
    if h != 0 {
        unsafe {
            let _ = InvalidateRect(Some(HWND(h as *mut _)), None, false);
        }
    }
}

fn dropped(drop: HDROP) {
    unsafe {
        let n = DragQueryFileW(drop, u32::MAX, None);
        let Ok(mut g) = SHARED.lock() else { return };
        for i in 0..n {
            let len = DragQueryFileW(drop, i, None) as usize;
            let mut buf = vec![0u16; len + 1];
            DragQueryFileW(drop, i, Some(&mut buf));
            let path = PathBuf::from(String::from_utf16_lossy(&buf[..len]));
            let Ok(meta) = std::fs::metadata(&path) else { continue };
            if !meta.is_file() || g.offers.iter().any(|o| o.path == path) {
                continue;
            }
            let id = g.next_id;
            g.next_id += 1;
            g.offers.push(Offer { id, path, size: meta.len() });
        }
        DragFinish(drop);
    }
    invalidate();
}

/// Сводка в «островок» MacMixer: «Получено с iPhone · 3 файла»; щелчок по ней покажет файл в папке
fn summary() {
    let fresh = SHARED.lock().map(|mut g| std::mem::take(&mut g.fresh)).unwrap_or_default();
    let Some(last) = fresh.last() else { return };
    let name = last.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
    let body = if fresh.len() == 1 { name } else { format!("{} · {name}", files_text(fresh.len())) };
    tell_island("Получено с iPhone", &body, last);
}

fn files_text(n: usize) -> String {
    let word = match (n % 10, n % 100) {
        (1, x) if x != 11 => "файл",
        (2..=4, x) if !(12..=14).contains(&x) => "файла",
        _ => "файлов",
    };
    format!("{n} {word}")
}

fn tell_island(title: &str, body: &str, path: &Path) {
    use windows::Win32::System::DataExchange::COPYDATASTRUCT;
    let data: Vec<u16> = format!("{title}\0{body}\0{}", path.display()).encode_utf16().collect();
    let cd = COPYDATASTRUCT { dwData: 0x4D49, cbData: (data.len() * 2) as u32, lpData: data.as_ptr() as *mut _ };
    unsafe {
        if let Ok(mixer) = FindWindowW(w!("MacMixer.Main"), None) {
            let from = WINDOW.load(Ordering::Relaxed) as usize;
            let _ = SendMessageW(mixer, WM_COPYDATA, Some(WPARAM(from)), Some(LPARAM(&cd as *const _ as isize)));
        }
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_SHARE => {
            if wp.0 == 1 {
                // несколько файлов подряд — одна сводка
                SetTimer(Some(hwnd), TIMER_SUMMARY, 1500, None);
            }
            let _ = InvalidateRect(Some(hwnd), None, false);
            LRESULT(0)
        }
        WM_TIMER => {
            let _ = KillTimer(Some(hwnd), wp.0);
            match wp.0 {
                TIMER_SUMMARY => summary(),
                TIMER_COPIED => {
                    with(|s| s.copied = false);
                    invalidate();
                }
                _ => {}
            }
            LRESULT(0)
        }
        WM_DROPFILES => {
            dropped(HDROP(wp.0 as *mut _));
            LRESULT(0)
        }
        WM_MOUSEMOVE => {
            let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, (lp.0 >> 16 & 0xFFFF) as i16 as i32);
            let h = hit_at(scale(hwnd), x, y);
            let changed = with(|s| std::mem::replace(&mut s.hover, h) != h).unwrap_or(false);
            let mut tme = TRACKMOUSEEVENT { cbSize: std::mem::size_of::<TRACKMOUSEEVENT>() as u32, dwFlags: TME_LEAVE, hwndTrack: hwnd, dwHoverTime: 0 };
            let _ = TrackMouseEvent(&mut tme);
            let hand = !matches!(h, Hit::None);
            let _ = SetCursor(LoadCursorW(None, if hand { IDC_HAND } else { IDC_ARROW }).ok());
            if changed {
                invalidate();
            }
            LRESULT(0)
        }
        WM_SETCURSOR if (lp.0 & 0xFFFF) as u32 == HTCLIENT => LRESULT(1),
        WM_MOUSELEAVE => {
            with(|s| s.hover = Hit::None);
            invalidate();
            LRESULT(0)
        }
        WM_LBUTTONUP => {
            let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, (lp.0 >> 16 & 0xFFFF) as i16 as i32);
            click(hit_at(scale(hwnd), x, y));
            LRESULT(0)
        }
        WM_SETTINGCHANGE => {
            gfx::load_themes();
            gfx::use_theme(true);
            let dark: u32 = gfx::theme().dark as u32;
            let _ = DwmSetWindowAttribute(hwnd, DWMWINDOWATTRIBUTE(20), &dark as *const u32 as *const _, 4);
            invalidate();
            LRESULT(0)
        }
        WM_DPICHANGED => {
            let r = &*(lp.0 as *const RECT);
            let _ = SetWindowPos(hwnd, None, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE);
            LRESULT(0)
        }
        WM_ERASEBKGND => LRESULT(1),
        WM_PAINT => {
            let mut ps = PAINTSTRUCT::default();
            let hdc = BeginPaint(hwnd, &mut ps);
            let done = with(|s| paint(s, hdc)).is_some();
            let _ = EndPaint(hwnd, &ps);
            if !done {
                let _ = InvalidateRect(Some(hwnd), None, false);
            }
            LRESULT(0)
        }
        WM_DESTROY => {
            // сводку о только что полученном не теряем
            summary();
            WINDOW.store(0, Ordering::Relaxed);
            SHARE.with(|s| s.borrow_mut().take());
            stop_server();
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

// ---------- проверка ----------

/// --preview share out.png: окно с примерами строк (без сети и телефона)
pub fn preview(out: &Path, fonts: Fonts) {
    PORT.store(7300, Ordering::Relaxed);
    if let Ok(mut g) = SHARED.lock() {
        let now = SystemTime::now();
        let t = |name: &str, size: u64, done: u64, state: St| Transfer { name: name.into(), size, done, state, path: None, at: now };
        g.transfers = vec![
            t("Отчёт.pdf", 2_400_000, 2_400_000, St::Done),
            t("Видео iPhone 2026-11-11 18-40-02.mov", 84_000_000, 84_000_000, St::Done),
            t("IMG_2041.jpeg", 3_100_000, 1_200_000, St::Active),
        ];
        g.offers = vec![Offer { id: 1, path: PathBuf::from("C:\\Презентация.pptx"), size: 12_600_000 }];
    }
    let s = 1.0;
    let mut sh = Share { hwnd: HWND::default(), fonts, hover: Hit::None, copied: false, qr: None };
    let mut img = Img::new((W * s) as u32, (H * s) as u32);
    if let Some(mut pm) = img.pixmap_mut() {
        compose(&mut sh, &mut pm, s);
    }
    if let Some(png) = win::encode_png(&img) {
        let _ = std::fs::write(out, png);
    }
}

/// --selftest-share out.txt: поднять сервер и сходить к нему самому — страница, приём файла, список, отдача с Range
pub fn selftest() -> String {
    let mut out = String::new();
    start_server();
    std::thread::sleep(Duration::from_millis(200));
    let port = PORT.load(Ordering::Relaxed);
    out += &format!("порт: {port}\n");
    let ask = |raw: Vec<u8>| -> String {
        let Ok(mut s) = TcpStream::connect(("127.0.0.1", port)) else { return "нет соединения".into() };
        let _ = s.set_read_timeout(Some(Duration::from_secs(5)));
        let _ = s.write_all(&raw);
        let mut buf = Vec::new();
        let _ = s.read_to_end(&mut buf);
        String::from_utf8_lossy(&buf).to_string()
    };
    let first = |r: &str| r.lines().next().unwrap_or("").to_string();
    let r = ask(b"GET /wrong/ HTTP/1.1\r\nHost: x\r\n\r\n".to_vec());
    out += &format!("без кода: {}\n", first(&r));
    let r = ask(format!("GET /{}/ HTTP/1.1\r\nHost: x\r\n\r\n", token()).into_bytes());
    out += &format!("страница: {}, длина {}\n", first(&r), r.len());
    let body = b"hello from selftest".to_vec();
    let name = percent_encode("проверка передачи.txt");
    let mut req = format!("POST /{}/up?name={name}&size={}&t=0 HTTP/1.1\r\nHost: x\r\nContent-Length: {}\r\n\r\n", token(), body.len(), body.len()).into_bytes();
    req.extend_from_slice(&body);
    let r = ask(req);
    out += &format!("приём: {}\n", first(&r));
    let got = SHARED.lock().ok().and_then(|g| g.transfers.last().and_then(|t| t.path.clone()));
    if let Some(p) = &got {
        let same = std::fs::read(p).ok() == Some(body.clone());
        out += &format!("файл: {} совпадает: {same}\n", p.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default());
        if let Ok(mut g) = SHARED.lock() {
            g.offers.push(Offer { id: 77, path: p.clone(), size: body.len() as u64 });
        }
        let r = ask(format!("GET /{}/list HTTP/1.1\r\nHost: x\r\n\r\n", token()).into_bytes());
        out += &format!("список: {}\n", r.split("\r\n\r\n").nth(1).unwrap_or(""));
        let r = ask(format!("GET /{}/get/77 HTTP/1.1\r\nHost: x\r\nRange: bytes=6-9\r\n\r\n", token()).into_bytes());
        out += &format!("кусок: {} → «{}»\n", first(&r), r.split("\r\n\r\n").nth(1).unwrap_or(""));
        let _ = std::fs::remove_file(p);
        out += &format!("тестовый файл удалён: {}\n", !p.exists());
    }
    stop_server();
    out
}
