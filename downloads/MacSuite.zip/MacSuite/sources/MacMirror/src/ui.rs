//! Окно: панель кнопок сверху (как командная строка в приложениях Windows 10), под ней экран
//! телефона. Видео выводится через Direct2D, панель и подсказки рисуются tiny-skia

use std::cell::RefCell;
use std::sync::atomic::{AtomicBool, AtomicIsize, Ordering};
use std::sync::mpsc::Sender;
use std::sync::{Arc, Mutex};
use std::time::Instant;

use tiny_skia::PixmapMut;
use windows::core::{w, PCWSTR};
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Direct2D::Common::*;
use windows::Win32::Graphics::Direct2D::*;
use windows::Win32::Graphics::Dxgi::Common::DXGI_FORMAT_B8G8R8A8_UNORM;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Controls::WM_MOUSELEAVE;
use windows::Win32::UI::HiDpi::GetDpiForWindow;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::Shell::{ShellExecuteW, NIM_ADD, NIM_DELETE, NOTIFY_ICON_MESSAGE};
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::airplay::Note;
use crate::decode::{self, Cmd, Event};
use crate::gfx::{self, Fonts, Img};
use crate::{files, log, win};

pub const WM_NOTE: u32 = WM_APP + 1;
pub const WM_VIDEO: u32 = WM_APP + 2;
const WM_TRAY: u32 = WM_APP + 3;

const MENU_OPEN: usize = 1;
const MENU_TRAY: usize = 2;
const MENU_AUTOSTART: usize = 3;
const MENU_EXIT: usize = 4;
const MENU_SHARE: usize = 5;

static mut TASKBAR_CREATED: u32 = 0;

const BAR_H: f32 = 44.0;
const BTN: f32 = 36.0;
const TIMER_TICK: usize = 1;
const TIMER_NET: usize = 2;

static HWND_MAIN: AtomicIsize = AtomicIsize::new(0);
static NOTES: Mutex<Vec<Note>> = Mutex::new(Vec::new());
static VIDEO_EVENTS: Mutex<Vec<Event>> = Mutex::new(Vec::new());
/// кадр уже ждёт отрисовки — новые сообщения не шлём
static FRAME_PENDING: AtomicBool = AtomicBool::new(false);

fn post(msg: u32) {
    let h = HWND(HWND_MAIN.load(Ordering::SeqCst) as *mut _);
    if !h.is_invalid() {
        unsafe {
            let _ = PostMessageW(Some(h), msg, WPARAM(0), LPARAM(0));
        }
    }
}

/// Сообщение от приёмника (из его потоков)
pub fn note(n: Note) {
    if let Ok(mut q) = NOTES.lock() {
        q.push(n);
    }
    post(WM_NOTE);
}

/// Событие от декодера (из его потока)
pub fn video_event(e: Event) {
    if let Event::Frame = e {
        if FRAME_PENDING.swap(true, Ordering::SeqCst) {
            return;
        }
    } else if let Ok(mut q) = VIDEO_EVENTS.lock() {
        q.push(e);
    }
    post(WM_VIDEO);
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Btn {
    Share,
    Folder,
    Shot,
    Record,
    Sound,
    Rotate,
    Pin,
    Full,
}

const BUTTONS: [Btn; 8] = [Btn::Full, Btn::Pin, Btn::Rotate, Btn::Sound, Btn::Record, Btn::Shot, Btn::Folder, Btn::Share];

impl Btn {
    fn label(self, st: &State) -> &'static str {
        match self {
            Btn::Share => "Файлы с iPhone и на iPhone  (Ctrl+F)",
            Btn::Folder => "Папка со снимками и записями",
            Btn::Shot => "Снимок экрана  (Ctrl+S)",
            Btn::Record if st.recording.is_some() => "Остановить запись  (Ctrl+R)",
            Btn::Record => "Записать видео  (Ctrl+R)",
            Btn::Sound if st.muted => "Включить звук телефона  (Ctrl+M)",
            Btn::Sound => "Выключить звук телефона  (Ctrl+M)",
            Btn::Rotate => "Повернуть картинку  (Ctrl+← / Ctrl+→)",
            Btn::Pin if st.topmost => "Не поверх окон  (Ctrl+T)",
            Btn::Pin => "Поверх всех окон  (Ctrl+T)",
            Btn::Full => "Во весь экран  (F11)",
        }
    }

    fn glyph(self, st: &State) -> char {
        match self {
            Btn::Share => '\u{E8B5}',
            Btn::Folder => '\u{ED25}',
            Btn::Shot => '\u{E722}',
            Btn::Record if st.recording.is_some() => '\u{E71A}',
            Btn::Record => '\u{E7C8}',
            Btn::Sound if st.muted => '\u{E74F}',
            Btn::Sound => '\u{E767}',
            Btn::Rotate => '\u{E7AD}',
            Btn::Pin if st.topmost => '\u{E840}',
            Btn::Pin => '\u{E718}',
            Btn::Full => '\u{E740}',
        }
    }

    fn enabled(self, st: &State) -> bool {
        match self {
            Btn::Shot | Btn::Record => st.live || st.recording.is_some(),
            _ => true,
        }
    }
}

#[derive(Clone, PartialEq)]
pub enum Phase {
    Waiting,
    Connecting(String),
    Live(String),
}

/// Всё, что видно в окне, кроме самого видео
pub struct State {
    pub phase: Phase,
    pub live: bool,
    pub video: Option<(u32, u32)>,
    pub hover: Option<Btn>,
    pub pressed: Option<Btn>,
    pub topmost: bool,
    pub recording: Option<Instant>,
    pub toast: Option<(String, Instant)>,
    /// поворот картинки вручную, в четвертях оборота по часовой
    pub rotate: u8,
    pub muted: bool,
    /// имя ПК в списке «Повтор экрана», сеть Wi-Fi, адрес
    pub name: String,
    pub wifi: Option<String>,
    pub ip: Option<String>,
}

struct Ui {
    hwnd: HWND,
    st: State,
    fonts: Fonts,
    scale: f32,
    factory: ID2D1Factory,
    rt: Option<ID2D1HwndRenderTarget>,
    video: Option<(ID2D1Bitmap, u32, u32)>,
    last_frame: usize,
    /// кэш картинок: (ключ, растр)
    bar: Option<(String, ID2D1Bitmap)>,
    idle: Option<(String, ID2D1Bitmap)>,
    toast: Option<(String, ID2D1Bitmap, u32, u32)>,
    full: Option<(WINDOWPLACEMENT, u32)>,
    tracking: bool,
    tx: Sender<Cmd>,
    /// последний размер видео, под который подгоняли окно
    fitted: Option<(u32, u32)>,
    flash: Option<Instant>,
    settings: files::Settings,
}

thread_local! {
    static UI: RefCell<Option<Ui>> = const { RefCell::new(None) };
}

fn with<R>(f: impl FnOnce(&mut Ui) -> R) -> Option<R> {
    UI.with(|u| u.try_borrow_mut().ok()?.as_mut().map(f))
}

pub fn run(fonts: Fonts, mut st: State, tx: Sender<Cmd>, hidden: bool) {
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let icon = LoadIconW(Some(inst.into()), PCWSTR(1 as *const u16)).unwrap_or_default();
        let wc = WNDCLASSW {
            style: CS_DBLCLKS,
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacMirror.Main"),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            hIcon: icon,
            ..Default::default()
        };
        RegisterClassW(&wc);
        let Ok(factory) = D2D1CreateFactory::<ID2D1Factory>(D2D1_FACTORY_TYPE_SINGLE_THREADED, None) else {
            log("Direct2D недоступен");
            return;
        };
        // окно под телефон: узкое и высокое, по центру рабочей области
        let mon = win::monitor_at(win::cursor());
        let s = mon.scale;
        let wk = mon.work;
        let h = (((wk.bottom - wk.top) as f32) * 0.86).min(900.0 * s) as i32;
        let wdt = (h as f32 * 0.5) as i32;
        let x = wk.left + ((wk.right - wk.left) - wdt) / 2;
        let y = wk.top + ((wk.bottom - wk.top) - h) / 2;
        let settings = files::load_settings();
        st.topmost = settings.topmost;
        st.muted = settings.muted;
        crate::audio::set_muted(settings.muted);
        // окно там, где его оставили (если тот монитор ещё есть)
        let (x, y, wdt, h) = match settings.pos {
            Some((l, t, r, b)) if MonitorFromPoint(POINT { x: (l + r) / 2, y: t + 20 }, MONITOR_DEFAULTTONULL).0 as usize != 0 => (l, t, r - l, b - t),
            _ => (x, y, wdt, h),
        };
        let Ok(hwnd) = CreateWindowExW(
            WINDOW_EX_STYLE(0),
            w!("MacMirror.Main"),
            w!("MacMirror"),
            WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
            x,
            y,
            wdt,
            h,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        HWND_MAIN.store(hwnd.0 as isize, Ordering::SeqCst);
        let ui = Ui {
            hwnd,
            st,
            fonts,
            scale: GetDpiForWindow(hwnd) as f32 / 96.0,
            factory,
            rt: None,
            video: None,
            last_frame: 0,
            bar: None,
            idle: None,
            toast: None,
            full: None,
            tracking: false,
            tx,
            fitted: None,
            flash: None,
            settings,
        };
        let topmost = ui.st.topmost;
        UI.with(|u| *u.borrow_mut() = Some(ui));
        TASKBAR_CREATED = RegisterWindowMessageW(w!("TaskbarCreated"));
        tray(hwnd, NIM_ADD);
        if topmost {
            let _ = SetWindowPos(hwnd, Some(HWND_TOPMOST), 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
        }
        if !hidden {
            let _ = ShowWindow(hwnd, SW_SHOW);
        }
        SetTimer(Some(hwnd), TIMER_TICK, 250, None);
        SetTimer(Some(hwnd), TIMER_NET, 30_000, None);

        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).as_bool() {
            let _ = TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        tray(hwnd, NIM_DELETE);
        let tx = with(|u| u.tx.clone());
        if let Some(tx) = tx {
            let _ = tx.send(Cmd::Record(None));
        }
    }
}

// ---------- отрисовка панели и подсказок (tiny-skia) ----------

struct Ctx {
    s: f32,
}

impl Ctx {
    fn d(&self, v: f32) -> f32 {
        v * self.s
    }
}

fn btn_rect(i: usize, wl: f32) -> (f32, f32, f32, f32) {
    (wl - 6.0 - (i as f32 + 1.0) * BTN, (BAR_H - BTN) / 2.0, BTN, BTN)
}

fn status_text(st: &State) -> (String, String, bool) {
    if let Some(h) = st.hover {
        let title = match &st.phase {
            Phase::Live(n) | Phase::Connecting(n) => n.clone(),
            Phase::Waiting => "Ожидание iPhone".into(),
        };
        return (title, h.label(st).trim().to_string(), false);
    }
    if let Some(t) = st.recording {
        let s = t.elapsed().as_secs();
        let name = match &st.phase {
            Phase::Live(n) | Phase::Connecting(n) => n.clone(),
            Phase::Waiting => "iPhone".into(),
        };
        return (name, format!("Запись  {:02}:{:02}", s / 60, s % 60), true);
    }
    match &st.phase {
        Phase::Waiting => ("Ожидание iPhone".into(), format!("В списке «Повтор экрана»: {}", st.name), false),
        Phase::Connecting(n) => (n.clone(), "Подключается…".into(), false),
        Phase::Live(n) => {
            let sub = st.video.map_or("Показ экрана".into(), |(w, h)| format!("Показ экрана · {w}×{h}"));
            (n.clone(), sub, false)
        }
    }
}

fn bar_key(st: &State, w: u32, s: f32) -> String {
    let (a, b, r) = status_text(st);
    format!("{w}|{s}|{a}|{b}|{r}|{:?}|{:?}|{}|{}|{}", st.hover, st.pressed, st.topmost, st.live, gfx::theme().dark)
}

pub fn bar_img(st: &State, f: &Fonts, w: u32, s: f32) -> Img {
    let h = (BAR_H * s).round() as u32;
    let mut img = Img::new(w.max(1), h.max(1));
    let wl = w as f32 / s;
    if let Some(mut pm) = img.pixmap_mut() {
        let c = Ctx { s };
        pm.fill(gfx::surface(1.0));
        gfx::fill_rrect(&mut pm, 0.0, h as f32 - c.d(1.0).max(1.0), w as f32, c.d(1.0).max(1.0), 0.0, gfx::white(0.08));
        // кнопки справа
        for (i, b) in BUTTONS.iter().enumerate() {
            let r = btn_rect(i, wl);
            let on = b.enabled(st);
            let rec = *b == Btn::Record && st.recording.is_some();
            if rec {
                gfx::fill_rrect(&mut pm, c.d(r.0), c.d(r.1), c.d(r.2), c.d(r.3), 0.0, gfx::rgb(0xE8, 0x11, 0x23, 1.0));
            } else if on && st.hover == Some(*b) {
                let a = if st.pressed == Some(*b) { 0.16 } else { 0.08 };
                gfx::fill_rrect(&mut pm, c.d(r.0), c.d(r.1), c.d(r.2), c.d(r.3), 0.0, gfx::white(a));
            }
            let active = *b == Btn::Pin && st.topmost;
            let col = if rec {
                gfx::pure(1.0)
            } else if !on {
                gfx::white(0.3)
            } else if active {
                gfx::accent(1.0)
            } else if *b == Btn::Record {
                // запись — красная точка, как в камере
                gfx::rgb(0xE8, 0x11, 0x23, 1.0)
            } else {
                gfx::white(0.88)
            };
            gfx::glyph(&mut pm, b.glyph(st), c.d(r.0 + r.2 / 2.0), c.d(r.1 + r.3 / 2.0), c.d(16.0), col);
        }
        // слева: значок телефона, имя и состояние
        let left = 14.0;
        let ic = match st.phase {
            Phase::Live(_) => gfx::accent(1.0),
            _ => gfx::white(0.55),
        };
        gfx::glyph(&mut pm, '\u{E8EA}', c.d(left + 8.0), c.d(BAR_H / 2.0), c.d(18.0), ic);
        let tx = left + 26.0;
        let room = btn_rect(BUTTONS.len() - 1, wl).0 - tx - 8.0;
        let (title, sub, red) = status_text(st);
        if room > 30.0 {
            let t = gfx::fit(&f.semibold, &title, c.d(13.0), c.d(room));
            gfx::text(&mut pm, &f.semibold, &t, c.d(tx), c.d(20.0), c.d(13.0), gfx::white(0.92));
            let col = if red { gfx::rgb(0xE8, 0x11, 0x23, 1.0) } else { gfx::white(0.6) };
            let t = gfx::fit(&f.regular, &sub, c.d(11.5), c.d(room));
            gfx::text(&mut pm, &f.regular, &t, c.d(tx), c.d(35.0), c.d(11.5), col);
        }
    }
    img
}

/// Перенос строки по словам под ширину max (в пикселях)
fn wrap(f: &ab_glyph::FontVec, s: &str, px: f32, max: f32) -> Vec<String> {
    let mut lines = Vec::new();
    let mut cur = String::new();
    for word in s.split(' ') {
        let t = if cur.is_empty() { word.to_string() } else { format!("{cur} {word}") };
        if gfx::measure(f, &t, px) <= max || cur.is_empty() {
            cur = t;
        } else {
            lines.push(std::mem::take(&mut cur));
            cur = word.to_string();
        }
    }
    if !cur.is_empty() {
        lines.push(cur);
    }
    lines
}

fn idle_key(st: &State, w: u32, h: u32, s: f32) -> String {
    format!("{w}|{h}|{s}|{:?}|{}|{:?}|{:?}|{}", st.phase == Phase::Waiting, st.name, st.wifi, st.ip, gfx::theme().dark)
        + &match &st.phase {
            Phase::Connecting(n) | Phase::Live(n) => n.clone(),
            Phase::Waiting => String::new(),
        }
}

/// Экран, пока телефон не подключён: что сделать на iPhone
pub fn idle_img(st: &State, f: &Fonts, w: u32, h: u32, s: f32) -> Img {
    let mut img = Img::new(w.max(1), h.max(1));
    if let Some(mut pm) = img.pixmap_mut() {
        let c = Ctx { s };
        pm.fill(gfx::panel_bg());
        let wl = w as f32 / s;
        let col = (wl - 48.0).min(340.0);
        let x0 = (wl - col) / 2.0;
        let mut lines: Vec<(String, bool, f32, f32)> = Vec::new(); // текст, жирный, кегль, отступ сверху
        let connecting = match &st.phase {
            Phase::Connecting(n) | Phase::Live(n) => Some(n.clone()),
            Phase::Waiting => None,
        };
        match &connecting {
            Some(n) => {
                lines.push((format!("Подключается {n}"), true, 20.0, 0.0));
                lines.push(("Сейчас появится экран телефона".into(), false, 13.0, 10.0));
            }
            None => {
                lines.push(("Подключите iPhone".into(), true, 20.0, 0.0));
                let net = st.wifi.as_ref().map_or("в одной сети Wi-Fi".to_string(), |n| format!("в одной сети Wi-Fi «{n}»"));
                lines.push((format!("1.  iPhone и компьютер — {net}"), false, 13.0, 18.0));
                lines.push(("2.  На iPhone откройте Пункт управления (свайп из правого верхнего угла) и нажмите «Повтор экрана»".into(), false, 13.0, 10.0));
                lines.push((format!("3.  Выберите «{}»", st.name), false, 13.0, 10.0));
            }
        }
        // считаем высоту блока, чтобы поставить его по центру
        let mut wrapped = Vec::new();
        let mut total = 64.0 + 20.0;
        for (t, bold, px, gap) in &lines {
            let font = if *bold { &f.semibold } else { &f.regular };
            let ls = wrap(font, t, c.d(*px), c.d(col));
            total += gap + ls.len() as f32 * px * 1.45;
            wrapped.push((ls, *bold, *px, *gap));
        }
        let mut y = ((h as f32 / s) - total) / 2.0;
        let glyph = if connecting.is_some() { '\u{E8EA}' } else { '\u{E7F4}' };
        gfx::glyph(&mut pm, glyph, c.d(wl / 2.0), c.d(y + 30.0), c.d(56.0), gfx::accent(1.0));
        y += 64.0 + 20.0;
        for (ls, bold, px, gap) in wrapped {
            y += gap;
            let font = if bold { &f.semibold } else { &f.regular };
            for l in ls {
                let lw = gfx::measure(font, &l, c.d(px));
                let x = if bold { c.d(wl / 2.0) - lw / 2.0 } else { c.d(x0) };
                y += px * 1.45;
                let ink = if bold { gfx::white(0.92) } else { gfx::white(0.72) };
                gfx::text(&mut pm, font, &l, x, c.d(y - px * 0.35), c.d(px), ink);
            }
        }
        if connecting.is_none() {
            if let Some(ip) = &st.ip {
                let t = format!("Адрес компьютера: {ip}");
                let tw = gfx::measure(&f.regular, &t, c.d(11.0));
                gfx::text(&mut pm, &f.regular, &t, c.d(wl / 2.0) - tw / 2.0, h as f32 - c.d(18.0), c.d(11.0), gfx::white(0.4));
            }
        }
    }
    img
}

/// Подсказка внизу экрана; длинный текст переносится под ширину окна max
pub fn toast_img(text: &str, f: &Fonts, s: f32, max: f32) -> Img {
    let c = Ctx { s };
    let lines = wrap(&f.regular, text, c.d(13.0), (max - c.d(64.0)).max(c.d(120.0)));
    let tw = lines.iter().map(|l| gfx::measure(&f.regular, l, c.d(13.0))).fold(0.0, f32::max);
    let (w, h) = ((tw + c.d(32.0)).ceil() as u32, c.d(20.0 + 20.0 * lines.len() as f32).ceil() as u32);
    let mut img = Img::new(w, h);
    if let Some(mut pm) = img.pixmap_mut() {
        gfx::fill_rrect(&mut pm, 0.0, 0.0, w as f32, h as f32, 0.0, gfx::rgb(0x2B, 0x2B, 0x2B, 0.96));
        for (i, l) in lines.iter().enumerate() {
            gfx::text(&mut pm, &f.regular, l, c.d(16.0), c.d(25.0 + 20.0 * i as f32), c.d(13.0), gfx::rgb(0xFF, 0xFF, 0xFF, 0.95));
        }
    }
    img
}

// ---------- Direct2D ----------

fn upload(rt: &ID2D1HwndRenderTarget, img: &Img) -> Option<ID2D1Bitmap> {
    unsafe {
        let props = D2D1_BITMAP_PROPERTIES {
            pixelFormat: D2D1_PIXEL_FORMAT { format: DXGI_FORMAT_B8G8R8A8_UNORM, alphaMode: D2D1_ALPHA_MODE_PREMULTIPLIED },
            dpiX: 96.0,
            dpiY: 96.0,
        };
        rt.CreateBitmap(D2D_SIZE_U { width: img.w, height: img.h }, Some(img.px.as_ptr() as *const _), img.w * 4, &props).ok()
    }
}

fn client(hwnd: HWND) -> (u32, u32) {
    let mut r = RECT::default();
    unsafe {
        let _ = GetClientRect(hwnd, &mut r);
    }
    ((r.right - r.left).max(1) as u32, (r.bottom - r.top).max(1) as u32)
}

impl Ui {
    fn bar_h(&self) -> u32 {
        if self.full.is_some() {
            0
        } else {
            (BAR_H * self.scale).round() as u32
        }
    }

    fn target(&mut self) -> Option<ID2D1HwndRenderTarget> {
        if self.rt.is_none() {
            let (w, h) = client(self.hwnd);
            let props = D2D1_RENDER_TARGET_PROPERTIES {
                r#type: D2D1_RENDER_TARGET_TYPE_DEFAULT,
                pixelFormat: D2D1_PIXEL_FORMAT { format: DXGI_FORMAT_B8G8R8A8_UNORM, alphaMode: D2D1_ALPHA_MODE_PREMULTIPLIED },
                dpiX: 96.0,
                dpiY: 96.0,
                usage: D2D1_RENDER_TARGET_USAGE_NONE,
                minLevel: D2D1_FEATURE_LEVEL_DEFAULT,
            };
            let hp = D2D1_HWND_RENDER_TARGET_PROPERTIES {
                hwnd: self.hwnd,
                pixelSize: D2D_SIZE_U { width: w, height: h },
                presentOptions: D2D1_PRESENT_OPTIONS_NONE,
            };
            self.rt = unsafe { self.factory.CreateHwndRenderTarget(&props, &hp).ok() };
            // растры привязаны к цели — их тоже заново
            self.video = None;
            self.last_frame = 0;
            self.bar = None;
            self.idle = None;
            self.toast = None;
        }
        self.rt.clone()
    }

    /// Взять свежий кадр от декодера
    fn take_frame(&mut self) {
        let Some(f) = decode::latest() else { return };
        let id = Arc::as_ptr(&f) as usize;
        if id == self.last_frame {
            return;
        }
        let Some(rt) = self.target() else { return };
        unsafe {
            let same = self.video.as_ref().is_some_and(|v| v.1 == f.w && v.2 == f.h);
            if !same {
                let props = D2D1_BITMAP_PROPERTIES {
                    pixelFormat: D2D1_PIXEL_FORMAT { format: DXGI_FORMAT_B8G8R8A8_UNORM, alphaMode: D2D1_ALPHA_MODE_IGNORE },
                    dpiX: 96.0,
                    dpiY: 96.0,
                };
                self.video = rt.CreateBitmap(D2D_SIZE_U { width: f.w, height: f.h }, None, 0, &props).ok().map(|b| (b, f.w, f.h));
            }
            if let Some((b, _, _)) = &self.video {
                let _ = b.CopyFromMemory(None, f.bgra.as_ptr() as *const _, f.w * 4);
            }
        }
        self.last_frame = id;
        if self.st.video != Some((f.w, f.h)) {
            self.st.video = Some((f.w, f.h));
            self.fit_window();
        }
    }

    /// Подогнать окно под пропорции телефона (при первом кадре и повороте)
    /// Размер картинки на экране: после ручного поворота стороны меняются местами
    fn shown(&self) -> Option<(u32, u32)> {
        let (w, h) = self.st.video?;
        Some(if self.st.rotate % 2 == 1 { (h, w) } else { (w, h) })
    }

    fn fit_window(&mut self) {
        let Some((vw, vh)) = self.shown() else { return };
        if self.full.is_some() || unsafe { IsZoomed(self.hwnd).as_bool() } {
            return;
        }
        let portrait = vh >= vw;
        if self.fitted.is_some_and(|(fw, fh)| (fh >= fw) == portrait) {
            return;
        }
        self.fitted = Some((vw, vh));
        unsafe {
            let mut wr = RECT::default();
            let _ = GetWindowRect(self.hwnd, &mut wr);
            let (cw, ch) = client(self.hwnd);
            let frame_w = (wr.right - wr.left) - cw as i32;
            let frame_h = (wr.bottom - wr.top) - ch as i32;
            let mon = win::monitor_at(POINT { x: (wr.left + wr.right) / 2, y: (wr.top + wr.bottom) / 2 });
            let wk = mon.work;
            let bar = self.bar_h() as f32;
            // по высоте — как сейчас (для альбомной ориентации — по ширине), но не больше рабочей области
            let max_w = (wk.right - wk.left - frame_w) as f32 * 0.95;
            let max_h = (wk.bottom - wk.top - frame_h) as f32 * 0.95 - bar;
            let (mut w, mut h) = if portrait {
                let h = (ch as f32 - bar).max(400.0 * self.scale).min(max_h);
                (h * vw as f32 / vh as f32, h)
            } else {
                let w = (ch as f32 - bar).max(600.0 * self.scale).min(max_w);
                (w, w * vh as f32 / vw as f32)
            };
            if w > max_w {
                h *= max_w / w;
                w = max_w;
            }
            if h > max_h {
                w *= max_h / h;
                h = max_h;
            }
            let (nw, nh) = (w.round() as i32 + frame_w, (h + bar).round() as i32 + frame_h);
            let cx = (wr.left + wr.right) / 2;
            let cy = (wr.top + wr.bottom) / 2;
            let x = (cx - nw / 2).clamp(wk.left, (wk.right - nw).max(wk.left));
            let y = (cy - nh / 2).clamp(wk.top, (wk.bottom - nh).max(wk.top));
            let _ = SetWindowPos(self.hwnd, None, x, y, nw, nh, SWP_NOZORDER | SWP_NOACTIVATE);
        }
    }

    fn paint(&mut self) {
        let Some(rt) = self.target() else { return };
        let (w, h) = client(self.hwnd);
        let s = self.scale;
        let bar = self.bar_h();
        let live = self.st.live && self.video.is_some();
        unsafe {
            rt.BeginDraw();
            let bg = if live { D2D1_COLOR_F { r: 0.0, g: 0.0, b: 0.0, a: 1.0 } } else { d2d_color(gfx::panel_bg()) };
            rt.Clear(Some(&bg));
            let area = (0.0, bar as f32, w as f32, (h - bar.min(h)) as f32);
            if live {
                if let Some((b, vw, vh)) = &self.video {
                    let rot = self.st.rotate % 4;
                    // вписываем с учётом поворота: при четверти оборота стороны меняются
                    let (sw, sh) = if rot % 2 == 1 { (*vh as f32, *vw as f32) } else { (*vw as f32, *vh as f32) };
                    let k = (area.2 / sw).min(area.3 / sh);
                    let (dw, dh) = (*vw as f32 * k, *vh as f32 * k);
                    let (cx, cy) = (area.0 + area.2 / 2.0, area.1 + area.3 / 2.0);
                    let dst = D2D_RECT_F { left: cx - dw / 2.0, top: cy - dh / 2.0, right: cx + dw / 2.0, bottom: cy + dh / 2.0 };
                    rt.SetTransform(&rotation(rot, cx, cy));
                    rt.DrawBitmap(b, Some(&dst), 1.0, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR, None);
                    rt.SetTransform(&rotation(0, 0.0, 0.0));
                }
            } else {
                let key = idle_key(&self.st, w, h - bar.min(h), s);
                if self.idle.as_ref().is_none_or(|(k, _)| *k != key) {
                    let img = idle_img(&self.st, &self.fonts, w, h - bar.min(h), s);
                    self.idle = upload(&rt, &img).map(|b| (key, b));
                }
                if let Some((_, b)) = &self.idle {
                    let dst = D2D_RECT_F { left: 0.0, top: bar as f32, right: w as f32, bottom: h as f32 };
                    rt.DrawBitmap(b, Some(&dst), 1.0, D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR, None);
                }
            }
            // вспышка после снимка
            if let Some(t) = self.flash {
                let k = 1.0 - t.elapsed().as_millis() as f32 / 220.0;
                if k > 0.0 {
                    if let Ok(br) = rt.CreateSolidColorBrush(&D2D1_COLOR_F { r: 1.0, g: 1.0, b: 1.0, a: k * 0.55 }, None) {
                        rt.FillRectangle(&D2D_RECT_F { left: 0.0, top: area.1, right: w as f32, bottom: h as f32 }, &br);
                    }
                } else {
                    self.flash = None;
                }
            }
            if let Some((text, t)) = self.st.toast.clone() {
                if t.elapsed().as_millis() < 2600 {
                    if self.toast.as_ref().is_none_or(|x| x.0 != text) {
                        let img = toast_img(&text, &self.fonts, s, w as f32);
                        self.toast = upload(&rt, &img).map(|b| (text.clone(), b, img.w, img.h));
                    }
                    if let Some((_, b, tw, th)) = &self.toast {
                        let x = (w as f32 - *tw as f32) / 2.0;
                        let y = h as f32 - *th as f32 - 24.0 * s;
                        rt.DrawBitmap(b, Some(&D2D_RECT_F { left: x, top: y, right: x + *tw as f32, bottom: y + *th as f32 }), 1.0, D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR, None);
                    }
                } else {
                    self.st.toast = None;
                    self.toast = None;
                }
            }
            if bar > 0 {
                let key = bar_key(&self.st, w, s);
                if self.bar.as_ref().is_none_or(|(k, _)| *k != key) {
                    let img = bar_img(&self.st, &self.fonts, w, s);
                    self.bar = upload(&rt, &img).map(|b| (key, b));
                }
                if let Some((_, b)) = &self.bar {
                    let dst = D2D_RECT_F { left: 0.0, top: 0.0, right: w as f32, bottom: bar as f32 };
                    rt.DrawBitmap(b, Some(&dst), 1.0, D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR, None);
                }
            }
            if rt.EndDraw(None, None).is_err() {
                // видеокарту сбросили или поменяли — создадим всё заново
                self.rt = None;
            }
        }
    }

    fn hit(&self, x: i32, y: i32) -> Option<Btn> {
        if self.full.is_some() {
            return None;
        }
        let s = self.scale;
        let (w, _) = client(self.hwnd);
        let (lx, ly) = (x as f32 / s, y as f32 / s);
        BUTTONS.iter().enumerate().find_map(|(i, b)| {
            let r = btn_rect(i, w as f32 / s);
            (lx >= r.0 && lx < r.0 + r.2 && ly >= r.1 && ly < r.1 + r.3 && b.enabled(&self.st)).then_some(*b)
        })
    }

    fn toast(&mut self, text: String) {
        self.st.toast = Some((text, Instant::now()));
    }

    fn click(&mut self, b: Btn) {
        match b {
            Btn::Share => crate::share::open(),
            Btn::Folder => {
                let dir = files::pictures_dir();
                let _ = std::fs::create_dir_all(&dir);
                let p = win::wide(&dir.to_string_lossy());
                unsafe {
                    ShellExecuteW(None, w!("open"), win::pcwstr(&p), None, None, SW_SHOWNORMAL);
                }
            }
            Btn::Shot => self.screenshot(),
            Btn::Record => self.toggle_record(),
            Btn::Sound => {
                self.st.muted = !self.st.muted;
                crate::audio::set_muted(self.st.muted);
                self.settings.muted = self.st.muted;
                files::save_settings(&self.settings);
            }
            Btn::Rotate => self.rotate(1),
            Btn::Pin => {
                self.st.topmost = !self.st.topmost;
                let after = if self.st.topmost { HWND_TOPMOST } else { HWND_NOTOPMOST };
                unsafe {
                    let _ = SetWindowPos(self.hwnd, Some(after), 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
                }
                self.settings.topmost = self.st.topmost;
                files::save_settings(&self.settings);
            }
            Btn::Full => self.toggle_full(),
        }
    }

    fn screenshot(&mut self) {
        let Some(f) = decode::latest().filter(|_| self.st.live) else { return };
        let img = rotate_img(Img { w: f.w, h: f.h, px: f.bgra.clone() }, self.st.rotate);
        let path = files::shot_path();
        let saved = win::encode_png(&img).is_some_and(|png| std::fs::write(&path, png).is_ok());
        let copied = files::copy_image(self.hwnd, &img);
        self.flash = Some(Instant::now());
        let name = path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
        self.toast(match (saved, copied) {
            (true, true) => "Снимок сохранён и скопирован — Ctrl+V вставит его".into(),
            (true, false) => format!("Снимок сохранён: {name}"),
            _ => "Не удалось сохранить снимок".into(),
        });
        log(&format!("снимок {} ({saved})", path.display()));
    }

    fn rotate(&mut self, quarter: u8) {
        self.st.rotate = (self.st.rotate + quarter) % 4;
        self.fitted = None;
        self.fit_window();
        let deg = self.st.rotate as u32 * 90;
        self.toast(if deg == 0 { "Картинка без поворота".into() } else { format!("Картинка повёрнута на {deg}°") });
    }

    /// Запомнить, где окно (обычное положение, не развёрнутое)
    fn remember(&mut self) {
        if self.full.is_some() {
            return;
        }
        unsafe {
            let mut wp = WINDOWPLACEMENT { length: std::mem::size_of::<WINDOWPLACEMENT>() as u32, ..Default::default() };
            if GetWindowPlacement(self.hwnd, &mut wp).is_ok() {
                let r = wp.rcNormalPosition;
                self.settings.pos = Some((r.left, r.top, r.right, r.bottom));
                files::save_settings(&self.settings);
            }
        }
    }

    fn show(&mut self) {
        unsafe {
            let _ = ShowWindow(self.hwnd, if IsIconic(self.hwnd).as_bool() { SW_RESTORE } else { SW_SHOW });
            let _ = SetForegroundWindow(self.hwnd);
        }
    }

    fn hide_to_tray(&mut self) {
        self.remember();
        unsafe {
            let _ = ShowWindow(self.hwnd, SW_HIDE);
        }
        if !self.settings.hinted {
            self.settings.hinted = true;
            files::save_settings(&self.settings);
            balloon(self.hwnd, "Экран iPhone работает в трее", "iPhone может подключиться в любой момент — окно откроется само. Выход — правый клик по значку.");
        }
    }

    fn toggle_record(&mut self) {
        if self.st.recording.is_some() {
            let _ = self.tx.send(Cmd::Record(None));
            return;
        }
        if !self.st.live {
            return;
        }
        let path = files::video_path();
        let _ = self.tx.send(Cmd::Record(Some(path)));
        self.toast("Запись начнётся со следующего кадра".into());
    }

    fn toggle_full(&mut self) {
        unsafe {
            let hwnd = self.hwnd;
            if let Some((wp, style)) = self.full.take() {
                SetWindowLongW(hwnd, GWL_STYLE, style as i32);
                let _ = SetWindowPlacement(hwnd, &wp);
                let _ = SetWindowPos(hwnd, None, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
            } else {
                let mut wp = WINDOWPLACEMENT { length: std::mem::size_of::<WINDOWPLACEMENT>() as u32, ..Default::default() };
                let _ = GetWindowPlacement(hwnd, &mut wp);
                let style = GetWindowLongW(hwnd, GWL_STYLE) as u32;
                self.full = Some((wp, style));
                let mut r = RECT::default();
                let _ = GetWindowRect(hwnd, &mut r);
                let m = win::monitor_at(POINT { x: (r.left + r.right) / 2, y: (r.top + r.bottom) / 2 }).rect;
                SetWindowLongW(hwnd, GWL_STYLE, ((style & !WS_OVERLAPPEDWINDOW.0) | WS_POPUP.0) as i32);
                let _ = SetWindowPos(hwnd, Some(HWND_TOP), m.left, m.top, m.right - m.left, m.bottom - m.top, SWP_FRAMECHANGED);
            }
        }
    }

    fn title(&self) {
        let t = match &self.st.phase {
            Phase::Live(n) => format!("{n} — MacMirror"),
            Phase::Connecting(n) => format!("{n} подключается — MacMirror"),
            Phase::Waiting => "MacMirror".to_string(),
        };
        let wt = win::wide(&t);
        unsafe {
            let _ = SetWindowTextW(self.hwnd, win::pcwstr(&wt));
        }
    }
}

fn d2d_color(c: tiny_skia::Color) -> D2D1_COLOR_F {
    // в наших цветах R и B переставлены под порядок BGRA
    D2D1_COLOR_F { r: c.blue(), g: c.green(), b: c.red(), a: c.alpha() }
}

fn invalidate(hwnd: HWND) {
    unsafe {
        let _ = InvalidateRect(Some(hwnd), None, false);
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    let pt = || ((lp.0 & 0xFFFF) as i16 as i32, ((lp.0 >> 16) & 0xFFFF) as i16 as i32);
    match msg {
        WM_PAINT => {
            let mut ps = PAINTSTRUCT::default();
            BeginPaint(hwnd, &mut ps);
            with(|u| u.paint());
            let _ = EndPaint(hwnd, &ps);
            LRESULT(0)
        }
        WM_ERASEBKGND => LRESULT(1),
        WM_SIZE => {
            let (w, h) = ((lp.0 & 0xFFFF) as u32, ((lp.0 >> 16) & 0xFFFF) as u32);
            with(|u| {
                if let Some(rt) = &u.rt {
                    if rt.Resize(&D2D_SIZE_U { width: w.max(1), height: h.max(1) }).is_err() {
                        u.rt = None;
                    }
                }
            });
            invalidate(hwnd);
            LRESULT(0)
        }
        WM_DPICHANGED => {
            with(|u| {
                u.scale = (wp.0 & 0xFFFF) as f32 / 96.0;
                u.bar = None;
                u.idle = None;
                u.toast = None;
            });
            let r = &*(lp.0 as *const RECT);
            let _ = SetWindowPos(hwnd, None, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE);
            LRESULT(0)
        }
        WM_GETMINMAXINFO => {
            let mi = &mut *(lp.0 as *mut MINMAXINFO);
            let s = GetDpiForWindow(hwnd).max(96) as f32 / 96.0;
            mi.ptMinTrackSize = POINT { x: (300.0 * s) as i32, y: (320.0 * s) as i32 };
            LRESULT(0)
        }
        WM_VIDEO => {
            FRAME_PENDING.store(false, Ordering::SeqCst);
            let events: Vec<Event> = VIDEO_EVENTS.lock().map(|mut q| std::mem::take(&mut *q)).unwrap_or_default();
            with(|u| {
                for e in events {
                    match e {
                        Event::Recording => {
                            u.st.recording = Some(Instant::now());
                            u.toast("Идёт запись — Ctrl+R остановит".into());
                        }
                        Event::Recorded(p, why) => {
                            u.st.recording = None;
                            let name = p.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
                            u.toast(match why {
                                Some(w) if w.starts_with("ошибка") => format!("Запись не удалась: {w}"),
                                Some(w) => format!("Запись сохранена ({w}): {name}"),
                                None => format!("Запись сохранена: {name}"),
                            });
                        }
                        Event::Frame => {}
                    }
                }
                u.take_frame();
                u.paint();
            });
            LRESULT(0)
        }
        WM_NOTE => {
            let notes: Vec<Note> = NOTES.lock().map(|mut q| std::mem::take(&mut *q)).unwrap_or_default();
            with(|u| {
                for n in notes {
                    match n {
                        Note::Client { name, model } => {
                            let shown = if name.is_empty() { model } else { name };
                            u.st.phase = Phase::Connecting(shown);
                            u.st.live = false;
                            // телефон начал показ — окно выходит само, даже если было в трее
                            u.show();
                        }
                        Note::Streaming => {
                            let n = match &u.st.phase {
                                Phase::Connecting(n) | Phase::Live(n) => n.clone(),
                                Phase::Waiting => "iPhone".into(),
                            };
                            u.st.phase = Phase::Live(n);
                            u.st.live = true;
                            u.fitted = None;
                        }
                        Note::Stopped => {
                            u.st.phase = Phase::Waiting;
                            u.st.live = false;
                            u.st.video = None;
                            if u.st.recording.is_some() {
                                let _ = u.tx.send(Cmd::Record(None));
                            }
                        }
                    }
                }
                u.title();
            });
            invalidate(hwnd);
            LRESULT(0)
        }
        WM_TIMER => {
            if wp.0 == TIMER_NET {
                crate::refresh_network();
            }
            // таймер записи, исчезновение подсказки, вспышка
            let busy = with(|u| u.st.recording.is_some() || u.st.toast.is_some() || u.flash.is_some()).unwrap_or(false);
            if busy {
                invalidate(hwnd);
            }
            LRESULT(0)
        }
        WM_MOUSEMOVE => {
            let (x, y) = pt();
            let changed = with(|u| {
                if !u.tracking {
                    u.tracking = true;
                    let mut tme = TRACKMOUSEEVENT { cbSize: std::mem::size_of::<TRACKMOUSEEVENT>() as u32, dwFlags: TME_LEAVE, hwndTrack: hwnd, dwHoverTime: 0 };
                    let _ = TrackMouseEvent(&mut tme);
                }
                let h = u.hit(x, y);
                let ch = h != u.st.hover;
                u.st.hover = h;
                ch
            });
            if changed == Some(true) {
                invalidate(hwnd);
            }
            LRESULT(0)
        }
        WM_MOUSELEAVE => {
            with(|u| {
                u.tracking = false;
                u.st.hover = None;
                u.st.pressed = None;
            });
            invalidate(hwnd);
            LRESULT(0)
        }
        WM_LBUTTONDOWN => {
            let (x, y) = pt();
            with(|u| u.st.pressed = u.hit(x, y));
            SetCapture(hwnd);
            invalidate(hwnd);
            LRESULT(0)
        }
        WM_LBUTTONUP => {
            let (x, y) = pt();
            let _ = ReleaseCapture();
            with(|u| {
                let p = u.st.pressed.take();
                if let Some(b) = p.filter(|b| u.hit(x, y) == Some(*b)) {
                    u.click(b);
                }
            });
            invalidate(hwnd);
            LRESULT(0)
        }
        WM_LBUTTONDBLCLK => {
            let (x, y) = pt();
            with(|u| {
                let bar = u.bar_h() as i32;
                if y >= bar && u.hit(x, y).is_none() {
                    u.toggle_full();
                }
            });
            LRESULT(0)
        }
        WM_KEYDOWN | WM_SYSKEYDOWN => {
            let ctrl = GetKeyState(VK_CONTROL.0 as i32) < 0;
            let alt = (lp.0 >> 29) & 1 == 1;
            let k = VIRTUAL_KEY(wp.0 as u16);
            let handled = with(|u| {
                match k {
                    VK_F11 => u.toggle_full(),
                    VK_RETURN if alt => u.toggle_full(),
                    VK_ESCAPE if u.full.is_some() => u.toggle_full(),
                    _ if ctrl && k.0 == u16::from(b'S') => u.screenshot(),
                    _ if ctrl && k.0 == u16::from(b'F') => crate::share::open(),
                    _ if ctrl && k.0 == u16::from(b'R') => u.toggle_record(),
                    _ if ctrl && k.0 == u16::from(b'T') => u.click(Btn::Pin),
                    _ if ctrl && k.0 == u16::from(b'M') => u.click(Btn::Sound),
                    VK_RIGHT if ctrl => u.rotate(1),
                    VK_LEFT if ctrl => u.rotate(3),
                    _ => return false,
                }
                true
            });
            invalidate(hwnd);
            if handled == Some(true) {
                LRESULT(0)
            } else {
                DefWindowProcW(hwnd, msg, wp, lp)
            }
        }
        WM_SETTINGCHANGE => {
            gfx::load_themes();
            gfx::use_theme(true);
            with(|u| {
                u.bar = None;
                u.idle = None;
            });
            invalidate(hwnd);
            LRESULT(0)
        }
        WM_CLOSE => {
            let to_tray = with(|u| u.settings.tray).unwrap_or(false);
            if to_tray {
                with(|u| u.hide_to_tray());
            } else {
                with(|u| u.remember());
                let _ = DestroyWindow(hwnd);
            }
            LRESULT(0)
        }
        WM_TRAY => {
            match (lp.0 & 0xFFFF) as u32 {
                WM_LBUTTONUP => {
                    let visible = IsWindowVisible(hwnd).as_bool() && !IsIconic(hwnd).as_bool();
                    with(|u| if visible { u.hide_to_tray() } else { u.show() });
                }
                WM_RBUTTONUP => tray_menu(hwnd),
                _ => {}
            }
            LRESULT(0)
        }
        m if m == TASKBAR_CREATED && m != 0 => {
            tray(hwnd, NIM_ADD);
            LRESULT(0)
        }
        WM_DESTROY => {
            PostQuitMessage(0);
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

/// Обновить подсказку о сети (имя Wi-Fi и адрес), если сеть сменилась
pub fn set_network(wifi: Option<String>, ip: Option<String>) {
    let changed = with(|u| {
        let ch = u.st.wifi != wifi || u.st.ip != ip;
        u.st.wifi = wifi;
        u.st.ip = ip;
        ch
    });
    if changed == Some(true) {
        let h = HWND(HWND_MAIN.load(Ordering::SeqCst) as *mut _);
        invalidate(h);
    }
}

/// Готовая картинка окна без Direct2D — для проверки вёрстки (--preview)
pub fn preview(kind: &str, st: State, fonts: &Fonts, w: u32, h: u32) -> Img {
    let s = 1.0;
    let bar = bar_img(&st, fonts, w, s);
    let body_h = h - bar.h;
    let mut img = Img::new(w, h);
    if let Some(mut pm) = img.pixmap_mut() {
        pm.fill(gfx::rgb(0, 0, 0, 1.0));
        if kind == "live" {
            // вместо видео — градиент в пропорциях iPhone
            let (vw, vh) = st.video.unwrap_or((590, 1280));
            let mut v = Img::new(vw, vh);
            for (i, p) in v.px.chunks_exact_mut(4).enumerate() {
                let (x, y) = ((i as u32 % vw) as f32 / vw as f32, (i as u32 / vw) as f32 / vh as f32);
                p.copy_from_slice(&[(200.0 * (1.0 - y)) as u8 + 40, (120.0 * x) as u8 + 40, (180.0 * y) as u8 + 50, 255]);
            }
            let k = (w as f32 / vw as f32).min(body_h as f32 / vh as f32);
            let (dw, dh) = (vw as f32 * k, vh as f32 * k);
            draw_scaled(&mut pm, &v, (w as f32 - dw) / 2.0, bar.h as f32 + (body_h as f32 - dh) / 2.0, k);
        } else {
            let idle = idle_img(&st, fonts, w, body_h, s);
            draw_scaled(&mut pm, &idle, 0.0, bar.h as f32, 1.0);
        }
        if let Some((t, _)) = &st.toast {
            let ti = toast_img(t, fonts, s, w as f32);
            draw_scaled(&mut pm, &ti, (w as f32 - ti.w as f32) / 2.0, h as f32 - ti.h as f32 - 24.0, 1.0);
        }
        draw_scaled(&mut pm, &bar, 0.0, 0.0, 1.0);
    }
    img
}

fn draw_scaled(pm: &mut PixmapMut, img: &Img, x: f32, y: f32, k: f32) {
    let size = img.w.max(img.h) as f32 * k;
    gfx::image(pm, img, x, y, size, 1.0);
}

/// Поворот на rot четвертей оборота по часовой вокруг (cx, cy)
fn rotation(rot: u8, cx: f32, cy: f32) -> windows_numerics::Matrix3x2 {
    let (c, s) = match rot % 4 {
        1 => (0.0, 1.0),
        2 => (-1.0, 0.0),
        3 => (0.0, -1.0),
        _ => (1.0, 0.0),
    };
    windows_numerics::Matrix3x2 { M11: c, M12: s, M21: -s, M22: c, M31: cx - c * cx + s * cy, M32: cy - s * cx - c * cy }
}

/// Повернуть картинку на rot четвертей по часовой (для снимка)
fn rotate_img(img: Img, rot: u8) -> Img {
    let rot = rot % 4;
    if rot == 0 {
        return img;
    }
    let (w, h) = (img.w as usize, img.h as usize);
    let (nw, nh) = if rot % 2 == 1 { (h, w) } else { (w, h) };
    let mut out = vec![0u8; w * h * 4];
    for y in 0..h {
        for x in 0..w {
            let (nx, ny) = match rot {
                1 => (h - 1 - y, x),
                2 => (w - 1 - x, h - 1 - y),
                _ => (y, w - 1 - x),
            };
            let s = (y * w + x) * 4;
            let d = (ny * nw + nx) * 4;
            out[d..d + 4].copy_from_slice(&img.px[s..s + 4]);
        }
    }
    Img { w: nw as u32, h: nh as u32, px: out }
}

fn tip(dst: &mut [u16], s: &str) {
    let v: Vec<u16> = s.encode_utf16().collect();
    let n = v.len().min(dst.len() - 1);
    dst[..n].copy_from_slice(&v[..n]);
    dst[n] = 0;
}

/// Значок в трее: программа ждёт телефон и без окна
fn tray(hwnd: HWND, op: NOTIFY_ICON_MESSAGE) {
    use windows::Win32::UI::Shell::*;
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let mut nid = NOTIFYICONDATAW {
            cbSize: std::mem::size_of::<NOTIFYICONDATAW>() as u32,
            hWnd: hwnd,
            uID: 1,
            uFlags: NIF_ICON | NIF_MESSAGE | NIF_TIP,
            uCallbackMessage: WM_TRAY,
            hIcon: LoadIconW(Some(inst.into()), PCWSTR(1 as *const u16)).unwrap_or_default(),
            ..Default::default()
        };
        tip(&mut nid.szTip, "Экран iPhone — Пункт управления → «Повтор экрана»");
        let _ = Shell_NotifyIconW(op, &nid);
    }
}

fn balloon(hwnd: HWND, title: &str, text: &str) {
    use windows::Win32::UI::Shell::*;
    unsafe {
        let mut nid = NOTIFYICONDATAW {
            cbSize: std::mem::size_of::<NOTIFYICONDATAW>() as u32,
            hWnd: hwnd,
            uID: 1,
            uFlags: NIF_INFO,
            dwInfoFlags: NIIF_INFO,
            ..Default::default()
        };
        tip(&mut nid.szInfoTitle, title);
        tip(&mut nid.szInfo, text);
        let _ = Shell_NotifyIconW(NIM_MODIFY, &nid);
    }
}

fn tray_menu(hwnd: HWND) {
    unsafe {
        let Ok(m) = CreatePopupMenu() else { return };
        let (tray_on, auto) = (with(|u| u.settings.tray).unwrap_or(true), files::autostart_enabled());
        let check = |on: bool| if on { MF_STRING | MF_CHECKED } else { MF_STRING };
        let _ = AppendMenuW(m, MF_STRING, MENU_OPEN, w!("Открыть окно"));
        let _ = SetMenuDefaultItem(m, MENU_OPEN as u32, 0);
        let _ = AppendMenuW(m, MF_STRING, MENU_SHARE, w!("Файлы с iPhone…"));
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        let _ = AppendMenuW(m, check(tray_on), MENU_TRAY, w!("Крестик прячет в трей"));
        let _ = AppendMenuW(m, check(auto), MENU_AUTOSTART, w!("Запускать вместе с Windows"));
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        let _ = AppendMenuW(m, MF_STRING, MENU_EXIT, w!("Выход"));
        let p = win::cursor();
        let _ = SetForegroundWindow(hwnd);
        let cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, p.x, p.y, Some(0), hwnd, None).0 as usize;
        let _ = DestroyMenu(m);
        match cmd {
            MENU_OPEN => {
                with(|u| u.show());
            }
            MENU_TRAY => {
                with(|u| {
                    u.settings.tray = !u.settings.tray;
                    files::save_settings(&u.settings);
                });
            }
            MENU_AUTOSTART => files::set_autostart(!auto),
            MENU_SHARE => crate::share::open(),
            MENU_EXIT => {
                with(|u| u.remember());
                let _ = DestroyWindow(hwnd);
            }
            _ => {}
        }
    }
}
