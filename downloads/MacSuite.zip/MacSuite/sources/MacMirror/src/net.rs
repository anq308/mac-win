//! Сеть: адаптер, через который виден телефон, и объявление приёмника в сети (mDNS / Bonjour) —
//! по нему iPhone находит ПК в списке «Повтор экрана»

use std::net::Ipv4Addr;

use mdns_sd::{IfKind, ServiceDaemon, ServiceInfo};
use windows::Win32::NetworkManagement::IpHelper::*;
use windows::Win32::NetworkManagement::Ndis::IfOperStatusUp;
use windows::Win32::Networking::WinSock::{AF_INET, SOCKADDR_IN};

use crate::airplay::Config;

#[derive(Clone, Debug, PartialEq)]
pub struct Adapter {
    pub name: String,
    pub ip: Ipv4Addr,
    pub mac: [u8; 6],
    pub wifi: bool,
}

/// Настоящие сетевые адаптеры со шлюзом: Wi-Fi и Ethernet, без VPN и виртуальных
pub fn adapters() -> Vec<Adapter> {
    let mut out = Vec::new();
    unsafe {
        let mut size = 16 * 1024u32;
        let mut buf: Vec<u64> = Vec::new();
        for _ in 0..3 {
            buf = vec![0u64; size as usize / 8 + 1];
            let r = GetAdaptersAddresses(
                AF_INET.0 as u32,
                GAA_FLAG_INCLUDE_GATEWAYS | GAA_FLAG_SKIP_ANYCAST | GAA_FLAG_SKIP_MULTICAST | GAA_FLAG_SKIP_DNS_SERVER,
                None,
                Some(buf.as_mut_ptr() as *mut IP_ADAPTER_ADDRESSES_LH),
                &mut size,
            );
            if r == 0 {
                break;
            }
            if r != 111 {
                // не ERROR_BUFFER_OVERFLOW — адаптеров не узнать
                return out;
            }
        }
        let mut p = buf.as_ptr() as *const IP_ADAPTER_ADDRESSES_LH;
        while !p.is_null() {
            let a = &*p;
            p = a.Next;
            // 6 — Ethernet, 71 — Wi-Fi
            if a.OperStatus != IfOperStatusUp || !(a.IfType == 6 || a.IfType == 71) || a.FirstGatewayAddress.is_null() {
                continue;
            }
            let desc = a.Description.to_string().unwrap_or_default();
            let low = desc.to_lowercase();
            if ["virtual", "vpn", "tap-", "wintun", "wireguard", "hyper-v", "vmware", "virtualbox", "loopback"]
                .iter()
                .any(|k| low.contains(k))
            {
                continue;
            }
            let mut mac = [0u8; 6];
            if a.PhysicalAddressLength as usize >= 6 {
                mac.copy_from_slice(&a.PhysicalAddress[..6]);
            }
            let mut u = a.FirstUnicastAddress;
            while !u.is_null() {
                let sa = (*u).Address.lpSockaddr;
                if !sa.is_null() && (*sa).sa_family == AF_INET {
                    let sin = &*(sa as *const SOCKADDR_IN);
                    let ip = Ipv4Addr::from(u32::from_be(sin.sin_addr.S_un.S_addr));
                    if !ip.is_loopback() && !ip.is_link_local() {
                        out.push(Adapter {
                            name: a.FriendlyName.to_string().unwrap_or_default(),
                            ip,
                            mac,
                            wifi: a.IfType == 71,
                        });
                    }
                }
                u = (*u).Next;
            }
        }
    }
    // Wi-Fi первым: телефон почти наверняка там
    out.sort_by_key(|a| !a.wifi);
    out
}

/// Название сети Wi-Fi — для подсказки «телефон и ПК должны быть в одной сети»
pub fn wifi_name() -> Option<String> {
    let out = std::process::Command::new("netsh").args(["wlan", "show", "interfaces"]).creation_flags_hidden().output().ok()?;
    let text = String::from_utf8_lossy(&out.stdout).to_string();
    text.lines()
        .map(str::trim)
        .find(|l| l.starts_with("SSID") && !l.starts_with("BSSID"))
        .and_then(|l| l.split_once(':'))
        .map(|(_, v)| v.trim().to_string())
        .filter(|s| !s.is_empty())
}

trait Hidden {
    fn creation_flags_hidden(&mut self) -> &mut Self;
}

impl Hidden for std::process::Command {
    fn creation_flags_hidden(&mut self) -> &mut Self {
        use std::os::windows::process::CommandExt;
        // CREATE_NO_WINDOW: без мелькающего окна консоли
        self.creation_flags(0x0800_0000)
    }
}

fn txt(pairs: &[(&str, String)]) -> Vec<(String, String)> {
    pairs.iter().map(|(k, v)| (k.to_string(), v.clone())).collect()
}

/// Записи TXT службы _airplay._tcp
pub fn airplay_txt(cfg: &Config) -> Vec<(String, String)> {
    txt(&[
        ("deviceid", cfg.device_id()),
        ("features", cfg.features_txt()),
        ("pw", "false".into()),
        ("flags", "0x4".into()),
        ("model", crate::airplay::MODEL.into()),
        ("pk", cfg.pk_hex()),
        ("pi", crate::airplay::PI.into()),
        ("srcvers", crate::airplay::VERSION.into()),
        ("vv", "2".into()),
    ])
}

/// Записи TXT службы _raop._tcp (звук)
pub fn raop_txt(cfg: &Config) -> Vec<(String, String)> {
    txt(&[
        ("ch", "2".into()),
        ("cn", "0,1,2,3".into()),
        ("da", "true".into()),
        ("et", "0,3,5".into()),
        ("vv", "2".into()),
        ("ft", cfg.features_txt()),
        ("am", crate::airplay::MODEL.into()),
        ("md", "0,1,2".into()),
        ("rhd", "5.6.0.0".into()),
        ("pw", "false".into()),
        ("sf", "0x4".into()),
        ("sr", "44100".into()),
        ("ss", "16".into()),
        ("sv", "false".into()),
        ("tp", "UDP".into()),
        ("txtvers", "1".into()),
        ("vs", crate::airplay::VERSION.into()),
        ("vn", "65537".into()),
        ("pk", cfg.pk_hex()),
    ])
}

/// Те же записи в виде блока DNS TXT (длина + «ключ=значение») — его просит iPhone в GET /info
pub fn txt_bytes(pairs: &[(String, String)]) -> Vec<u8> {
    let mut out = Vec::new();
    for (k, v) in pairs {
        let s = format!("{k}={v}");
        let b = s.as_bytes();
        out.push(b.len().min(255) as u8);
        out.extend_from_slice(&b[..b.len().min(255)]);
    }
    out
}

/// Объявить приёмник на адресах ips. Демон живёт, пока жив возвращённый объект
pub fn advertise(cfg: &Config, ips: &[Ipv4Addr], port: u16) -> Result<ServiceDaemon, String> {
    let d = ServiceDaemon::new().map_err(|e| e.to_string())?;
    // только выбранные адаптеры: иначе iPhone может получить адрес VPN и не достучаться
    let _ = d.disable_interface(IfKind::All);
    for ip in ips {
        let _ = d.enable_interface(IfKind::Addr((*ip).into()));
    }
    let host = format!("MacMirror-{}.local.", hex(&cfg.mac[3..]));
    let addrs: Vec<String> = ips.iter().map(|i| i.to_string()).collect();
    let addrs = addrs.join(",");
    let props = airplay_txt(cfg);
    let props: Vec<(&str, &str)> = props.iter().map(|(k, v)| (k.as_str(), v.as_str())).collect();
    let info = ServiceInfo::new("_airplay._tcp.local.", &cfg.name, &host, addrs.as_str(), port, &props[..])
        .map_err(|e| e.to_string())?;
    d.register(info).map_err(|e| e.to_string())?;
    let raop = raop_txt(cfg);
    let raop: Vec<(&str, &str)> = raop.iter().map(|(k, v)| (k.as_str(), v.as_str())).collect();
    let name = format!("{}@{}", hex(&cfg.mac).to_uppercase(), cfg.name);
    let info = ServiceInfo::new("_raop._tcp.local.", &name, &host, addrs.as_str(), port, &raop[..]).map_err(|e| e.to_string())?;
    d.register(info).map_err(|e| e.to_string())?;
    Ok(d)
}

pub fn hex(b: &[u8]) -> String {
    b.iter().map(|x| format!("{x:02x}")).collect()
}
