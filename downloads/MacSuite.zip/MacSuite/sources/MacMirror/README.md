# MacMirror — исходники

Экран iPhone на Windows по Wi-Fi («Повтор экрана» / AirPlay), снимки и запись. Rust, чистый Win32,
Media Foundation (декодер и кодировщик H.264 из Windows), Direct2D для вывода видео, tiny-skia + ab_glyph для панели.

## Сборка

Нужны Rust (тулчейн `stable-x86_64-pc-windows-gnu`) и MinGW (gcc для playfair, windres для значка):

```
winget install BrechtSanders.WinLibs.POSIX.UCRT
.\build.ps1          # -> target\release\mac-mirror.exe
```

## Файлы

| Файл | Что внутри |
|---|---|
| `main.rs` | запуск, ключ и имя приёмника, журнал, перепроверка сети раз в 30 с |
| `airplay.rs` | приёмник AirPlay: RTSP на порту 7000, pair-setup/pair-verify (Ed25519 + X25519), SETUP, приём и расшифровка видео (AES-128-CTR) |
| `fairplay.rs` | ответы FairPlay и вызов `playfair_decrypt` |
| `playfair/` | расшифровка ключа FairPlay на C — из [UxPlay](https://github.com/FDH2/UxPlay) (GPL-3.0) |
| `net.rs` | адаптеры Wi-Fi/Ethernet без VPN, объявление `_airplay._tcp` и `_raop._tcp` (mDNS) |
| `decode.rs` | декодер H.264 (MF, режим низкой задержки), NV12 → BGRA в несколько потоков, запись MP4 |
| `ui.rs` | окно: панель кнопок, экран ожидания, видео через Direct2D, полноэкранный режим, поверх окон |
| `files.rs` | папка «Изображения\iPhone», имена файлов, снимок в буфер обмена |
| `share.rs`, `share.html` | файлы с iPhone и на iPhone: HTTP-сервер в домашней сети, окно с QR-кодом, страница для Safari |
| `gfx.rs`, `win.rs` | общий стиль с остальными программами: текст, значки Segoe MDL2, тема Windows |

Протокол повторяет UxPlay: `GET /info` (bplist), `/pair-setup`, `/pair-verify`, `/fp-setup`,
`SETUP` (ekey + eiv → ключ через playfair, смешанный с общим секретом сопряжения; потоки 110 — видео,
96 — звук), видео — 128-байтный заголовок + данные, ключ потока `SHA-512("AirPlayStreamKey<id>" + ключ)`.

## Проверка без телефона

```
mac-mirror.exe --selftest папка                                  # MP4 из тестовых кадров → обратно через декодер → PNG
mac-mirror.exe --preview waiting|connecting|live|record|hover out.png
```

## Лицензия

`playfair/` — GPL-3.0 (UxPlay/RPiPlay), поэтому и программа целиком распространяется на условиях GPL-3.0.
