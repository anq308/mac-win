//! Настройки между запусками: вид, сортировка, избранное, размер окна — %APPDATA%\MacFinder\settings.txt

use std::path::PathBuf;

pub struct Settings {
    pub list: bool,
    pub zoom: f32,
    pub sort: u8,
    pub asc: bool,
    pub hidden: bool,
    pub deep: bool,
    /// панель просмотра справа
    pub pane: bool,
    /// группировка: 0 — нет, 1 — тип, 2 — дата, 3 — размер, 4 — имя
    pub group: u8,
    /// фильтр по категории: 0 — все, иначе категория + 1
    pub filter: u8,
    /// None — стандартное избранное (системные папки)
    pub favorites: Option<Vec<PathBuf>>,
    /// размер области окна в логических пикселях
    pub size: Option<(i32, i32)>,
}

fn file() -> Option<PathBuf> {
    Some(PathBuf::from(std::env::var_os("APPDATA")?).join("MacFinder").join("settings.txt"))
}

impl Settings {
    pub fn load() -> Settings {
        let mut s = Settings {
            list: false,
            zoom: 72.0,
            sort: 0,
            asc: true,
            hidden: false,
            deep: false,
            pane: true,
            group: 0,
            filter: 0,
            favorites: None,
            size: None,
        };
        let Some(text) = file().and_then(|f| std::fs::read_to_string(f).ok()) else { return s };
        let mut favs = Vec::new();
        let mut custom = false;
        for line in text.lines() {
            let Some((k, v)) = line.split_once('=') else { continue };
            let v = v.trim();
            match k.trim() {
                "view" => s.list = v == "list",
                "zoom" => s.zoom = v.parse().unwrap_or(72.0),
                "sort" => s.sort = v.parse().unwrap_or(0),
                "asc" => s.asc = v == "1",
                "hidden" => s.hidden = v == "1",
                "deep" => s.deep = v == "1",
                "pane" => s.pane = v == "1",
                "group" => s.group = v.parse().unwrap_or(0),
                "filter" => s.filter = v.parse().unwrap_or(0),
                "size" => {
                    if let Some((w, h)) = v.split_once('x') {
                        if let (Ok(w), Ok(h)) = (w.parse(), h.parse()) {
                            s.size = Some((w, h));
                        }
                    }
                }
                "favorites" => custom = true,
                "fav" => {
                    custom = true;
                    favs.push(PathBuf::from(v));
                }
                _ => {}
            }
        }
        if custom {
            s.favorites = Some(favs);
        }
        s
    }

    pub fn save(&self) {
        let Some(f) = file() else { return };
        if let Some(d) = f.parent() {
            let _ = std::fs::create_dir_all(d);
        }
        let b = |v: bool| if v { 1 } else { 0 };
        let mut out = format!(
            "view={}\nzoom={}\nsort={}\nasc={}\nhidden={}\ndeep={}\npane={}\ngroup={}\nfilter={}\n",
            if self.list { "list" } else { "grid" },
            self.zoom,
            self.sort,
            b(self.asc),
            b(self.hidden),
            b(self.deep),
            b(self.pane),
            self.group,
            self.filter
        );
        if let Some((w, h)) = self.size {
            out += &format!("size={w}x{h}\n");
        }
        if let Some(fav) = &self.favorites {
            out += "favorites=\n";
            for p in fav {
                out += &format!("fav={}\n", p.display());
            }
        }
        let _ = std::fs::write(f, out);
    }
}
