//! Дерево «Анализа места» в одном векторе, как в SquirrelDisk: каждая папка — узел, а файл
//! становится узлом, только если он крупный; остальная мелочь папки — один узел «помельче».
//! Так даже диск с миллионами файлов занимает немного памяти.

use std::path::PathBuf;

pub const NONE: u32 = u32::MAX;
pub const ROOT: u32 = 0;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Kind {
    Dir,
    File,
    /// мелкие файлы одной папки одним куском; их можно раскрыть
    Small,
    /// занятое на диске, но не найденное в файлах: системные данные, папки без доступа
    Hidden,
}

/// папка прочитана целиком
pub const F_DONE: u8 = 1;
/// нет доступа
pub const F_DENIED: u8 = 2;
/// узел удалён из дерева
pub const F_GONE: u8 = 4;
/// «помельче», которое ещё можно раскрыть с диска
pub const F_EXPANDABLE: u8 = 8;

pub struct Node {
    pub name: Box<str>,
    /// сколько всё поддерево занимает на диске
    pub size: u64,
    pub files: u32,
    pub parent: u32,
    pub first: u32,
    pub next: u32,
    pub kind: Kind,
    pub flags: u8,
}

pub struct Tree {
    pub nodes: Vec<Node>,
    pub root_path: PathBuf,
    /// растёт при каждом изменении — по нему вид понимает, что пора перестроить диаграмму
    pub version: u64,
}

impl Tree {
    pub fn new(root_path: PathBuf, name: &str) -> Tree {
        let root = Node { name: name.into(), size: 0, files: 0, parent: NONE, first: NONE, next: NONE, kind: Kind::Dir, flags: 0 };
        Tree { nodes: vec![root], root_path, version: 1 }
    }

    pub fn get(&self, id: u32) -> &Node {
        &self.nodes[id as usize]
    }

    pub fn get_mut(&mut self, id: u32) -> &mut Node {
        &mut self.nodes[id as usize]
    }

    /// Узел на месте: ни он, ни его предки не удалены
    pub fn alive(&self, id: u32) -> bool {
        if id as usize >= self.nodes.len() {
            return false;
        }
        let mut cur = id;
        while cur != NONE {
            let n = self.get(cur);
            if n.flags & F_GONE != 0 {
                return false;
            }
            cur = n.parent;
        }
        true
    }

    /// Добавить ребёнка; размер предкам не прибавляется — для этого add_size
    pub fn add_child(&mut self, parent: u32, name: &str, kind: Kind, size: u64, files: u32) -> u32 {
        let id = self.nodes.len() as u32;
        let next = self.get(parent).first;
        self.nodes.push(Node { name: name.into(), size, files, parent, first: NONE, next, kind, flags: 0 });
        self.get_mut(parent).first = id;
        self.version += 1;
        id
    }

    /// Прибавить размер и число файлов узлу и всем его предкам
    pub fn add_size(&mut self, id: u32, size: i64, files: i64) {
        let mut cur = id;
        while cur != NONE {
            let n = &mut self.nodes[cur as usize];
            n.size = (n.size as i64 + size).max(0) as u64;
            n.files = (n.files as i64 + files).max(0) as u32;
            cur = n.parent;
        }
        self.version += 1;
    }

    pub fn add_child_sized(&mut self, parent: u32, name: &str, kind: Kind, size: u64, files: u32) -> u32 {
        let id = self.add_child(parent, name, kind, 0, 0);
        self.add_size(id, size as i64, files as i64);
        id
    }

    pub fn children(&self, id: u32) -> Children<'_> {
        Children { tree: self, cur: self.get(id).first }
    }

    /// Дети от больших к маленьким
    pub fn sorted(&self, id: u32) -> Vec<u32> {
        let mut v: Vec<u32> = self.children(id).collect();
        v.sort_unstable_by(|a, b| self.get(*b).size.cmp(&self.get(*a).size));
        v
    }

    /// Можно ли «войти» в узел на диаграмме
    pub fn can_enter(&self, id: u32) -> bool {
        let n = self.get(id);
        (n.kind == Kind::Dir || n.kind == Kind::Hidden) && n.first != NONE
    }

    /// Убрать узел (удалили с диска) и вычесть его размер из предков
    pub fn remove(&mut self, id: u32) {
        if id == ROOT || !self.alive(id) {
            return;
        }
        let (parent, size, files, next) = {
            let n = self.get(id);
            (n.parent, n.size, n.files, n.next)
        };
        self.add_size(parent, -(size as i64), -(files as i64));
        if self.get(parent).first == id {
            self.get_mut(parent).first = next;
        } else {
            let mut cur = self.get(parent).first;
            while cur != NONE {
                if self.get(cur).next == id {
                    self.get_mut(cur).next = next;
                    break;
                }
                cur = self.get(cur).next;
            }
        }
        let n = self.get_mut(id);
        n.flags |= F_GONE;
        n.next = NONE;
        self.version += 1;
    }

    /// Путь на диске; у «помельче» и скрытого места — папка, где они лежат
    pub fn path(&self, id: u32) -> PathBuf {
        let mut parts = Vec::new();
        let mut cur = id;
        while cur != NONE && cur != ROOT {
            let n = self.get(cur);
            if matches!(n.kind, Kind::Dir | Kind::File) {
                parts.push(&*n.name);
            }
            cur = n.parent;
        }
        let mut p = self.root_path.clone();
        for part in parts.iter().rev() {
            p.push(part);
        }
        p
    }

    /// Цепочка от корня до узла включительно
    pub fn ancestry(&self, id: u32) -> Vec<u32> {
        let mut v = Vec::new();
        let mut cur = id;
        while cur != NONE {
            v.push(cur);
            cur = self.get(cur).parent;
        }
        v.reverse();
        v
    }

    pub fn is_ancestor(&self, anc: u32, id: u32) -> bool {
        let mut cur = self.get(id).parent;
        while cur != NONE {
            if cur == anc {
                return true;
            }
            cur = self.get(cur).parent;
        }
        false
    }
}

pub struct Children<'a> {
    tree: &'a Tree,
    cur: u32,
}

impl Iterator for Children<'_> {
    type Item = u32;
    fn next(&mut self) -> Option<u32> {
        if self.cur == NONE {
            return None;
        }
        let id = self.cur;
        self.cur = self.tree.get(id).next;
        Some(id)
    }
}
