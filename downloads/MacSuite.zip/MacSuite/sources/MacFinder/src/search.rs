//! Поиск по имени во всех вложенных папках — в фоне, результаты приходят порциями

use std::collections::VecDeque;
use std::os::windows::fs::MetadataExt;
use std::path::PathBuf;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{channel, Receiver};
use std::sync::Arc;
use std::time::Instant;

use windows::Win32::Foundation::{HWND, LPARAM, WPARAM};
use windows::Win32::Storage::FileSystem::{FILE_ATTRIBUTE_HIDDEN, FILE_ATTRIBUTE_REPARSE_POINT, FILE_ATTRIBUTE_SYSTEM};
use windows::Win32::System::Com::{CoInitializeEx, COINIT_MULTITHREADED};
use windows::Win32::UI::WindowsAndMessaging::{PostMessageW, WM_APP};

use crate::fs::{Entry, Kinds};

pub const WM_FOUND: u32 = WM_APP + 23;
/// больше результатов человеку всё равно не просмотреть
const LIMIT: usize = 5000;

pub enum Batch {
    Found(Vec<Entry>),
    Done,
}

/// Запустить поиск; он сам остановится, как только gen сменится (новый запрос или другая папка)
pub fn start(hwnd: HWND, root: PathBuf, query: String, hidden: bool, gen: Arc<AtomicU64>) -> Receiver<Batch> {
    let (tx, rx) = channel();
    let my = gen.load(Ordering::Relaxed);
    let h = hwnd.0 as isize;
    std::thread::spawn(move || {
        unsafe {
            let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
        }
        let post = || unsafe {
            let _ = PostMessageW(Some(HWND(h as *mut _)), WM_FOUND, WPARAM(0), LPARAM(0));
        };
        let q = query.to_lowercase();
        let mut kinds = Kinds::new();
        let mut queue = VecDeque::from([root.clone()]);
        let mut batch = Vec::new();
        let mut total = 0;
        let mut last = Instant::now();
        while let Some(dir) = queue.pop_front() {
            if gen.load(Ordering::Relaxed) != my {
                return;
            }
            let Ok(rd) = std::fs::read_dir(&dir) else { continue };
            for e in rd.flatten() {
                let Ok(md) = e.metadata() else { continue };
                let attr = md.file_attributes();
                let name = e.file_name().to_string_lossy().to_string();
                let is_hidden = attr & (FILE_ATTRIBUTE_HIDDEN.0 | FILE_ATTRIBUTE_SYSTEM.0) != 0 || name.starts_with('.');
                if is_hidden && !hidden {
                    continue;
                }
                let dir_entry = md.is_dir();
                // ссылки на папки (junction) пропускаем — иначе можно уйти по кругу
                if dir_entry && attr & FILE_ATTRIBUTE_REPARSE_POINT.0 == 0 {
                    queue.push_back(e.path());
                }
                if !name.to_lowercase().contains(&q) {
                    continue;
                }
                let place = dir.strip_prefix(&root).ok().map(|p| p.to_string_lossy().to_string()).filter(|p| !p.is_empty());
                batch.push(Entry {
                    path: e.path(),
                    kind: if dir_entry { "Папка".into() } else { kinds.of(&name) },
                    name,
                    dir: dir_entry,
                    size: if dir_entry { 0 } else { md.file_size() },
                    modified: md.last_write_time(),
                    hidden: is_hidden,
                    space: None,
                    place: Some(place.unwrap_or_else(|| "—".into())),
                    sel: false,
                });
                total += 1;
            }
            if !batch.is_empty() && (batch.len() >= 200 || last.elapsed().as_millis() > 120) {
                if tx.send(Batch::Found(std::mem::take(&mut batch))).is_err() {
                    return;
                }
                post();
                last = Instant::now();
            }
            if total >= LIMIT {
                break;
            }
        }
        if !batch.is_empty() {
            let _ = tx.send(Batch::Found(batch));
        }
        let _ = tx.send(Batch::Done);
        post();
    });
    rx
}
