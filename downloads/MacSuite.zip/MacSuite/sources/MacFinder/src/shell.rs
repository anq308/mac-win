//! Оболочка Windows: родное контекстное меню, команды «копировать/вставить/удалить»,
//! перетаскивание файлов наружу и приём файлов, брошенных в окно

use std::cell::RefCell;
use std::path::{Path, PathBuf};

use windows::core::{implement, Interface, Ref, Result, PCSTR, PCWSTR, PSTR};
use windows::Win32::Foundation::*;
use windows::Win32::System::Com::*;
use windows::Win32::System::Ole::*;
use windows::Win32::System::SystemServices::{MK_CONTROL, MK_SHIFT, MODIFIERKEYS_FLAGS};
use windows::Win32::UI::Shell::Common::ITEMIDLIST;
use windows::Win32::UI::Shell::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::win::{pcwstr, wide, wide_path};

// из shobjidl.h: совпадают с SEE_MASK_UNICODE и SEE_MASK_ASYNCOK
const CMIC_MASK_UNICODE: u32 = 0x4000;
const CMIC_MASK_ASYNCOK: u32 = 0x0010_0000;
const FIRST: u32 = 1;
const LAST: u32 = 0x6FFF;
/// свои пункты в меню фона — выше диапазона оболочки
pub const ID_HIDDEN: u32 = 0x7F01;
pub const ID_NEW_FOLDER: u32 = 0x7F02;
pub const ID_NEW_TAB: u32 = 0x7F03;
pub const ID_ADD_FAV: u32 = 0x7F04;
pub const ID_REMOVE_FAV: u32 = 0x7F05;
pub const ID_COPY_PATH: u32 = 0x7F06;
pub const ID_TERMINAL: u32 = 0x7F07;
pub const ID_COPY_NAME: u32 = 0x7F08;
pub const ID_COPY_QUOTED: u32 = 0x7F09;
pub const ID_COPY_SLASH: u32 = 0x7F0A;
pub const ID_COPY_PARENT: u32 = 0x7F0B;
pub const ID_COPY_URI: u32 = 0x7F0C;
pub const ID_ANALYZE: u32 = 0x7F0D;
pub const ID_EXPLORER: u32 = 0x7F0E;

/// Свои пункты в начале меню: команда или подменю
pub enum MenuItem {
    Cmd(u32, String),
    Sub(String, Vec<(u32, String)>),
}

/// Варианты «Скопировать путь» для подменю
pub fn copy_items() -> Vec<(u32, String)> {
    vec![
        (ID_COPY_PATH, "Полный путь\tCtrl+Shift+C".into()),
        (ID_COPY_NAME, "Только имя".into()),
        (ID_COPY_QUOTED, "Путь в кавычках".into()),
        (ID_COPY_SLASH, "Путь через / (для кода)".into()),
        (ID_COPY_PARENT, "Путь к папке, где лежит".into()),
        (ID_COPY_URI, "Как ссылку file:///".into()),
    ]
}

/// Текст для буфера по выбранному варианту; несколько путей — каждый с новой строки
pub fn copy_text(paths: &[PathBuf], id: u32) -> String {
    let mut out: Vec<String> = Vec::new();
    for p in paths {
        let full = p.to_string_lossy().to_string();
        let t = match id {
            ID_COPY_NAME => p.file_name().map_or(full.clone(), |n| n.to_string_lossy().to_string()),
            ID_COPY_QUOTED => format!("\"{full}\""),
            ID_COPY_SLASH => full.replace('\\', "/"),
            ID_COPY_PARENT => p.parent().map_or(full.clone(), |d| d.to_string_lossy().to_string()),
            ID_COPY_URI => {
                let mut u = String::from("file:///");
                for c in full.replace('\\', "/").chars() {
                    match c {
                        ' ' => u.push_str("%20"),
                        '#' => u.push_str("%23"),
                        '%' => u.push_str("%25"),
                        _ => u.push(c),
                    }
                }
                u
            }
            _ => full,
        };
        if !out.contains(&t) {
            out.push(t);
        }
    }
    out.join("\r\n")
}

thread_local! {
    /// меню, открытое прямо сейчас: ему пересылаются сообщения подменю («Отправить», «Открыть с помощью»)
    static ACTIVE: RefCell<Option<IContextMenu>> = const { RefCell::new(None) };
}

fn items_menu(paths: &[PathBuf]) -> Option<IContextMenu> {
    unsafe {
        let pidls: Vec<*mut ITEMIDLIST> = paths.iter().map(|p| ILCreateFromPathW(pcwstr(&wide_path(p)))).filter(|p| !p.is_null()).collect();
        if pidls.is_empty() {
            return None;
        }
        let list: Vec<*const ITEMIDLIST> = pidls.iter().map(|p| *p as *const ITEMIDLIST).collect();
        let cm = SHCreateShellItemArrayFromIDLists(&list).ok().and_then(|a| a.BindToHandler::<_, IContextMenu>(None, &BHID_SFUIObject).ok());
        for p in pidls {
            ILFree(Some(p as *const ITEMIDLIST));
        }
        cm
    }
}

fn background_menu(hwnd: HWND, dir: &Path) -> Option<IContextMenu> {
    unsafe {
        let item: IShellItem = SHCreateItemFromParsingName(pcwstr(&wide_path(dir)), None).ok()?;
        let folder: IShellFolder = item.BindToHandler(None, &BHID_SFObject).ok()?;
        folder.CreateViewObject(hwnd).ok()
    }
}

pub enum Picked {
    None,
    /// «Переименовать» делаем сами: оболочке для этого нужно её собственное окно списка
    Rename,
    Own(u32),
}

fn verb_of(cm: &IContextMenu, id: u32) -> String {
    let mut buf = [0u16; 128];
    unsafe {
        if cm.GetCommandString((id - FIRST) as usize, GCS_VERBW, None, PSTR(buf.as_mut_ptr() as *mut u8), buf.len() as u32).is_err() {
            return String::new();
        }
    }
    let n = buf.iter().position(|&c| c == 0).unwrap_or(0);
    String::from_utf16_lossy(&buf[..n])
}

fn invoke(cm: &IContextMenu, hwnd: HWND, verb: Result<u32>, verb_str: Option<&str>, dir: Option<&Path>, pt: Option<POINT>, shift: bool) {
    let a = verb_str.map(|v| v.bytes().chain(Some(0)).collect::<Vec<u8>>());
    let w = verb_str.map(wide);
    let d = dir.map(wide_path);
    let mut info = CMINVOKECOMMANDINFOEX {
        cbSize: std::mem::size_of::<CMINVOKECOMMANDINFOEX>() as u32,
        fMask: CMIC_MASK_UNICODE | CMIC_MASK_ASYNCOK,
        hwnd,
        nShow: SW_SHOWNORMAL.0,
        ..Default::default()
    };
    match (verb, &a, &w) {
        (_, Some(a), Some(w)) => {
            info.lpVerb = PCSTR(a.as_ptr());
            info.lpVerbW = PCWSTR(w.as_ptr());
        }
        (Ok(id), _, _) => {
            info.lpVerb = PCSTR((id - FIRST) as usize as *const u8);
            info.lpVerbW = PCWSTR((id - FIRST) as usize as *const u16);
        }
        _ => return,
    }
    if let Some(d) = &d {
        info.lpDirectoryW = pcwstr(d);
    }
    if let Some(p) = pt {
        info.fMask |= CMIC_MASK_PTINVOKE;
        info.ptInvoke = p;
    }
    if shift {
        info.fMask |= CMIC_MASK_SHIFT_DOWN;
    }
    unsafe {
        let _ = cm.InvokeCommand(&info as *const _ as *const CMINVOKECOMMANDINFO);
    }
}

/// Родное меню Windows для выделенных файлов (paths) или для фона папки (paths пуст);
/// top — свои пункты сверху, hidden_on — галочка «Показывать скрытые» внизу
pub fn menu(hwnd: HWND, dir: Option<&Path>, paths: &[PathBuf], top: &[MenuItem], hidden_on: Option<bool>) -> Picked {
    let cm = if paths.is_empty() { dir.and_then(|d| background_menu(hwnd, d)) } else { items_menu(paths) };
    let Some(cm) = cm else { return Picked::None };
    unsafe {
        let Ok(m) = CreatePopupMenu() else { return Picked::None };
        let shift = windows::Win32::UI::Input::KeyboardAndMouse::GetKeyState(0x10) < 0;
        let mut flags = CMF_NORMAL | CMF_CANRENAME;
        if shift {
            flags |= CMF_EXTENDEDVERBS;
        }
        let _ = cm.QueryContextMenu(m, 0, FIRST, LAST, flags);
        for (k, item) in top.iter().enumerate() {
            match item {
                MenuItem::Cmd(id, label) => {
                    let t = wide(label);
                    let _ = InsertMenuW(m, k as u32, MF_BYPOSITION | MF_STRING, *id as usize, pcwstr(&t));
                }
                MenuItem::Sub(label, items) => {
                    let Ok(sub) = CreatePopupMenu() else { continue };
                    for (id, l) in items {
                        let t = wide(l);
                        let _ = AppendMenuW(sub, MF_STRING, *id as usize, pcwstr(&t));
                    }
                    let t = wide(label);
                    let _ = InsertMenuW(m, k as u32, MF_BYPOSITION | MF_POPUP, sub.0 as usize, pcwstr(&t));
                }
            }
        }
        if !top.is_empty() {
            let _ = InsertMenuW(m, top.len() as u32, MF_BYPOSITION | MF_SEPARATOR, 0, None);
        }
        if let Some(on) = hidden_on {
            let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
            let f = if on { MF_STRING | MF_CHECKED } else { MF_STRING };
            let _ = AppendMenuW(m, f, ID_HIDDEN as usize, windows::core::w!("Показывать скрытые файлы\tCtrl+H"));
        }
        ACTIVE.with(|a| *a.borrow_mut() = Some(cm.clone()));
        let p = crate::win::cursor();
        let id = TrackPopupMenuEx(m, (TPM_RETURNCMD | TPM_RIGHTBUTTON).0, p.x, p.y, hwnd, None).0 as u32;
        ACTIVE.with(|a| *a.borrow_mut() = None);
        let _ = DestroyMenu(m);
        if id == 0 {
            return Picked::None;
        }
        if id > LAST {
            return Picked::Own(id);
        }
        if verb_of(&cm, id).eq_ignore_ascii_case("rename") {
            return Picked::Rename;
        }
        invoke(&cm, hwnd, Ok(id), None, dir, Some(p), false);
        Picked::None
    }
}

/// Команда по имени без показа меню: "copy", "cut", "delete", "properties", "paste" (для фона)
pub fn verb(hwnd: HWND, dir: Option<&Path>, paths: &[PathBuf], verb: &str, shift: bool) {
    let cm = if paths.is_empty() { dir.and_then(|d| background_menu(hwnd, d)) } else { items_menu(paths) };
    let Some(cm) = cm else { return };
    unsafe {
        let Ok(m) = CreatePopupMenu() else { return };
        let _ = cm.QueryContextMenu(m, 0, FIRST, LAST, CMF_NORMAL);
        invoke(&cm, hwnd, Err(windows::core::Error::empty()), Some(verb), dir, None, shift);
        let _ = DestroyMenu(m);
    }
}

/// Пересылка сообщений меню в обработчики оболочки (подменю рисуют и наполняют они сами)
pub fn menu_message(msg: u32, wp: WPARAM, lp: LPARAM) -> Option<LRESULT> {
    if !matches!(msg, WM_INITMENUPOPUP | WM_DRAWITEM | WM_MEASUREITEM | WM_MENUCHAR) {
        return None;
    }
    ACTIVE.with(|a| {
        let a = a.borrow();
        let cm = a.as_ref()?;
        unsafe {
            if let Ok(cm3) = cm.cast::<IContextMenu3>() {
                let mut r = LRESULT(0);
                cm3.HandleMenuMsg2(msg, wp, lp, Some(&mut r)).ok()?;
                return Some(r);
            }
            if let Ok(cm2) = cm.cast::<IContextMenu2>() {
                cm2.HandleMenuMsg(msg, wp, lp).ok()?;
                return Some(LRESULT(0));
            }
        }
        None
    })
}

/// Терминал в папке: Windows Terminal, если есть, иначе PowerShell
pub fn terminal(dir: &Path) {
    let s = dir.to_string_lossy().trim_end_matches('\\').to_string();
    // «D:\» в кавычках сломал бы разбор аргументов — для корня диска пишем «D:\.»
    let s = if s.ends_with(':') { s + "\\." } else { s };
    let d = wide(&s);
    let wt = std::env::var_os("LOCALAPPDATA").map(|l| PathBuf::from(l).join("Microsoft\\WindowsApps\\wt.exe")).filter(|p| p.exists());
    unsafe {
        match wt {
            Some(wt) => {
                let a = wide(&format!("-d \"{s}\""));
                ShellExecuteW(None, windows::core::w!("open"), pcwstr(&wide_path(&wt)), pcwstr(&a), pcwstr(&d), SW_SHOWNORMAL);
            }
            None => {
                let ps = windows::core::w!("powershell.exe");
                ShellExecuteW(None, windows::core::w!("open"), ps, windows::core::w!("-NoExit"), pcwstr(&d), SW_SHOWNORMAL);
            }
        }
    }
}

/// Открыть в обычном Проводнике. Пока событие живо, мод Windhawk «MacFinder вместо Проводника»
/// не перехватывает его окно
pub fn explorer(path: &Path, select: bool) {
    use std::os::windows::process::CommandExt;
    let s = path.to_string_lossy().trim_end_matches('\\').to_string();
    let s = if s.ends_with(':') { s + "\\" } else { s };
    let arg = if select { format!("/select,\"{s}\"") } else { format!("\"{s}\"") };
    unsafe {
        let ev = windows::Win32::System::Threading::CreateEventW(None, true, true, windows::core::w!("Local\\MacFinder.OpenExplorer"));
        let _ = std::process::Command::new("explorer.exe").raw_arg(arg).spawn();
        if let Ok(h) = ev {
            let raw = h.0 as isize;
            std::thread::spawn(move || {
                std::thread::sleep(std::time::Duration::from_secs(5));
                let _ = CloseHandle(HANDLE(raw as *mut _));
            });
        }
    }
}

/// Выбрать папку обычным окном Windows
pub fn pick_folder(hwnd: HWND) -> Option<PathBuf> {
    unsafe {
        let dlg: IFileOpenDialog = CoCreateInstance(&FileOpenDialog, None, CLSCTX_INPROC_SERVER).ok()?;
        let _ = dlg.SetOptions(dlg.GetOptions().ok()? | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM);
        let _ = dlg.SetTitle(windows::core::w!("Какую папку проверить?"));
        dlg.Show(Some(hwnd)).ok()?;
        let p = dlg.GetResult().ok()?.GetDisplayName(SIGDN_FILESYSPATH).ok()?;
        let s = p.to_string().ok();
        CoTaskMemFree(Some(p.0 as *const _));
        s.map(PathBuf::from)
    }
}

pub fn open(path: &Path, dir: Option<&Path>) {
    let p = wide_path(path);
    let d = dir.map(wide_path);
    unsafe {
        ShellExecuteW(None, windows::core::w!("open"), pcwstr(&p), None, d.as_ref().map_or(PCWSTR::null(), |d| pcwstr(d)), SW_SHOWNORMAL);
    }
}

/// Перетаскивание файлов в другие окна: копировать, переместить или ярлык — решает получатель
pub fn drag(paths: &[PathBuf]) {
    unsafe {
        let pidls: Vec<*mut ITEMIDLIST> = paths.iter().map(|p| ILCreateFromPathW(pcwstr(&wide_path(p)))).filter(|p| !p.is_null()).collect();
        if pidls.is_empty() {
            return;
        }
        let list: Vec<*const ITEMIDLIST> = pidls.iter().map(|p| *p as *const ITEMIDLIST).collect();
        if let Ok(arr) = SHCreateShellItemArrayFromIDLists(&list) {
            if let Ok(data) = arr.BindToHandler::<_, IDataObject>(None, &BHID_DataObject) {
                let _ = SHDoDragDrop(None, &data, None, DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK);
            }
        }
        for p in pidls {
            ILFree(Some(p as *const ITEMIDLIST));
        }
    }
}

/// Копирование или перемещение с родным окном прогресса и возможностью отмены (Ctrl+Z в проводнике)
pub fn transfer(hwnd: HWND, paths: &[PathBuf], to: &Path, moving: bool) {
    let mut from: Vec<u16> = Vec::new();
    for p in paths {
        from.extend(p.to_string_lossy().encode_utf16());
        from.push(0);
    }
    from.push(0);
    let mut dst: Vec<u16> = to.to_string_lossy().encode_utf16().collect();
    dst.extend([0, 0]);
    let mut op = SHFILEOPSTRUCTW {
        hwnd,
        wFunc: if moving { FO_MOVE } else { FO_COPY },
        pFrom: PCWSTR(from.as_ptr()),
        pTo: PCWSTR(dst.as_ptr()),
        fFlags: FOF_ALLOWUNDO.0 as u16,
        ..Default::default()
    };
    unsafe {
        let _ = SHFileOperationW(&mut op);
    }
}

// ---------- приём перетаскивания ----------

pub const WM_DROPPED: u32 = WM_APP + 21;
pub const WM_DROP_HOVER: u32 = WM_APP + 22;

/// Что бросили в окно; забирается обработчиком WM_DROPPED
pub struct Dropped {
    pub paths: Vec<PathBuf>,
    pub x: i32,
    pub y: i32,
    pub moving: bool,
}

thread_local! {
    pub static DROPPED: RefCell<Option<Dropped>> = const { RefCell::new(None) };
    /// какие файлы сейчас тащат над окном — чтобы не бросить папку саму в себя
    static SOURCE: RefCell<Vec<PathBuf>> = const { RefCell::new(Vec::new()) };
}

fn hdrop_paths(data: &IDataObject) -> Vec<PathBuf> {
    let fmt = FORMATETC { cfFormat: CF_HDROP.0, ptd: std::ptr::null_mut(), dwAspect: DVASPECT_CONTENT.0, lindex: -1, tymed: TYMED_HGLOBAL.0 as u32 };
    let mut out = Vec::new();
    unsafe {
        let Ok(mut med) = data.GetData(&fmt) else { return out };
        let h = HDROP(med.u.hGlobal.0);
        let n = DragQueryFileW(h, u32::MAX, None);
        for i in 0..n {
            let len = DragQueryFileW(h, i, None) as usize;
            let mut buf = vec![0u16; len + 1];
            DragQueryFileW(h, i, Some(&mut buf));
            out.push(PathBuf::from(String::from_utf16_lossy(&buf[..len])));
        }
        ReleaseStgMedium(&mut med);
    }
    out
}

#[implement(IDropTarget)]
pub struct DropTarget {
    pub hwnd: HWND,
}

impl DropTarget {
    fn client(&self, pt: &POINTL) -> (i32, i32) {
        let mut p = POINT { x: pt.x, y: pt.y };
        unsafe {
            let _ = windows::Win32::Graphics::Gdi::ScreenToClient(self.hwnd, &mut p);
        }
        (p.x, p.y)
    }

    /// Переместить или скопировать: Shift — переместить, Ctrl — копировать, иначе как в проводнике по дискам
    fn effect(&self, keys: MODIFIERKEYS_FLAGS, pt: &POINTL) -> DROPEFFECT {
        let (x, y) = self.client(pt);
        let target = crate::finder::drop_target_at(x, y);
        let src = SOURCE.with(|s| s.borrow().clone());
        let Some(target) = target else { return DROPEFFECT_NONE };
        if src.is_empty() || src.iter().any(|p| p == &target || p.parent() == Some(target.as_path())) {
            return DROPEFFECT_NONE;
        }
        if keys.0 & MK_CONTROL.0 != 0 {
            DROPEFFECT_COPY
        } else if keys.0 & MK_SHIFT.0 != 0 {
            DROPEFFECT_MOVE
        } else {
            let root = |p: &Path| p.components().next().map(|c| c.as_os_str().to_ascii_lowercase());
            if src.first().map(|p| root(p)) == Some(root(&target)) {
                DROPEFFECT_MOVE
            } else {
                DROPEFFECT_COPY
            }
        }
    }

    fn hover(&self, pt: Option<&POINTL>) {
        let (x, y) = pt.map(|p| self.client(p)).unwrap_or((-1, -1));
        unsafe {
            let _ = SendMessageW(
                self.hwnd,
                WM_DROP_HOVER,
                Some(WPARAM(x as u16 as usize | ((y as u16 as usize) << 16))),
                Some(LPARAM(pt.is_some() as isize)),
            );
        }
    }
}

impl IDropTarget_Impl for DropTarget_Impl {
    fn DragEnter(&self, data: Ref<'_, IDataObject>, keys: MODIFIERKEYS_FLAGS, pt: &POINTL, effect: *mut DROPEFFECT) -> Result<()> {
        let paths = data.as_ref().map(hdrop_paths).unwrap_or_default();
        SOURCE.with(|s| *s.borrow_mut() = paths);
        unsafe { *effect = self.effect(keys, pt) };
        self.hover(Some(pt));
        Ok(())
    }

    fn DragOver(&self, keys: MODIFIERKEYS_FLAGS, pt: &POINTL, effect: *mut DROPEFFECT) -> Result<()> {
        unsafe { *effect = self.effect(keys, pt) };
        self.hover(Some(pt));
        Ok(())
    }

    fn DragLeave(&self) -> Result<()> {
        SOURCE.with(|s| s.borrow_mut().clear());
        self.hover(None);
        Ok(())
    }

    fn Drop(&self, data: Ref<'_, IDataObject>, keys: MODIFIERKEYS_FLAGS, pt: &POINTL, effect: *mut DROPEFFECT) -> Result<()> {
        let e = self.effect(keys, pt);
        unsafe { *effect = e };
        let paths = data.as_ref().map(hdrop_paths).unwrap_or_default();
        SOURCE.with(|s| s.borrow_mut().clear());
        self.hover(None);
        if e != DROPEFFECT_NONE && !paths.is_empty() {
            let (x, y) = self.client(pt);
            DROPPED.with(|d| *d.borrow_mut() = Some(Dropped { paths, x, y, moving: e == DROPEFFECT_MOVE }));
            // само копирование — после возврата, чтобы не держать окно-источник
            unsafe {
                let _ = PostMessageW(Some(self.hwnd), WM_DROPPED, WPARAM(0), LPARAM(0));
            }
        }
        Ok(())
    }
}

pub fn register_drop(hwnd: HWND) {
    let target: IDropTarget = DropTarget { hwnd }.into();
    unsafe {
        let _ = RegisterDragDrop(hwnd, &target);
    }
}

/// В корзину без вопросов Windows — подтверждение уже спросили мы
pub fn recycle(hwnd: HWND, paths: &[PathBuf]) {
    let mut from: Vec<u16> = Vec::new();
    for p in paths {
        from.extend(p.to_string_lossy().encode_utf16());
        from.push(0);
    }
    from.push(0);
    let mut op = SHFILEOPSTRUCTW {
        hwnd,
        wFunc: FO_DELETE,
        pFrom: PCWSTR(from.as_ptr()),
        fFlags: (FOF_ALLOWUNDO | FOF_NOCONFIRMATION).0 as u16,
        ..Default::default()
    };
    unsafe {
        let _ = SHFileOperationW(&mut op);
    }
}
