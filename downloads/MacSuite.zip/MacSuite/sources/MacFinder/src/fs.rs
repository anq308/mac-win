//! Содержимое папок, диски, места в боковой панели, сортировка и подписи

use std::cmp::Ordering;
use std::collections::HashMap;
use std::os::windows::fs::MetadataExt;
use std::path::{Path, PathBuf};

use windows::core::GUID;
use windows::Win32::Foundation::{FILETIME, SYSTEMTIME};
use windows::Win32::Storage::FileSystem::*;
use windows::Win32::System::SystemInformation::GetLocalTime;
use windows::Win32::System::Time::{FileTimeToSystemTime, SystemTimeToTzSpecificLocalTime};
use windows::Win32::UI::Shell::*;

use crate::gfx::Icon;
use crate::win::{self, pcwstr, wide};

#[derive(Clone, PartialEq, Eq, Debug)]
pub enum Loc {
    /// «Компьютер»: список дисков
    Computer,
    Dir(PathBuf),
}

impl Loc {
    pub fn title(&self) -> String {
        match self {
            Loc::Computer => "Компьютер".into(),
            Loc::Dir(p) => display_name(p),
        }
    }
}

#[derive(Clone, Copy)]
pub struct Space {
    pub total: u64,
    pub free: u64,
}

#[derive(Clone)]
pub struct Entry {
    pub name: String,
    pub path: PathBuf,
    pub dir: bool,
    pub size: u64,
    pub modified: u64,
    pub hidden: bool,
    pub kind: String,
    /// только у дисков в «Компьютере»
    pub space: Option<Space>,
    /// папка относительно места поиска — у результатов поиска по вложенным папкам
    pub place: Option<String>,
    pub sel: bool,
}

fn nice_kind(ext: &str) -> Option<&'static str> {
    Some(match ext {
        "rs" => "Код Rust",
        "py" | "pyw" => "Скрипт Python",
        "js" | "jsx" | "mjs" => "Код JavaScript",
        "ts" | "tsx" => "Код TypeScript",
        "json" => "Данные JSON",
        "md" => "Текст Markdown",
        "toml" => "Настройки TOML",
        "yaml" | "yml" => "Настройки YAML",
        "lock" => "Файл блокировки",
        "go" => "Код Go",
        "lua" => "Скрипт Lua",
        "sh" => "Скрипт оболочки",
        "sql" => "Запрос SQL",
        "log" => "Журнал",
        "env" => "Переменные окружения",
        "" => "Файл",
        _ => return None,
    })
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Sort {
    Name,
    Date,
    Size,
    Kind,
}

/// «D:\» → «D:», папка → её имя
pub fn display_name(p: &Path) -> String {
    match p.file_name() {
        Some(n) => n.to_string_lossy().to_string(),
        None => p.to_string_lossy().trim_end_matches('\\').to_string(),
    }
}

pub struct Kinds {
    names: HashMap<String, String>,
}

impl Kinds {
    pub fn new() -> Kinds {
        Kinds { names: HashMap::new() }
    }

    /// Тип по расширению из реестра, с кэшем: запрос к оболочке на каждый файл слишком дорог
    pub fn of(&mut self, name: &str) -> String {
        let ext = Path::new(name).extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default();
        self.names
            .entry(ext.clone())
            .or_insert_with(|| {
                let t = win::type_name(&format!("x.{ext}"));
                // для незарегистрированных типов Windows пишет «Файл "RS"» — даём имя получше
                if t.is_empty() || t.starts_with("Файл \"") {
                    nice_kind(&ext).map_or_else(|| format!("Файл {}", ext.to_uppercase()), str::to_string)
                } else {
                    t
                }
            })
            .clone()
    }
}

pub fn list(dir: &Path, kinds: &mut Kinds) -> Option<Vec<Entry>> {
    let rd = std::fs::read_dir(dir).ok()?;
    let mut out = Vec::new();
    for e in rd.flatten() {
        // на Windows метаданные приходят вместе с перечислением — отдельного обращения к диску нет
        let Ok(md) = e.metadata() else { continue };
        let attr = md.file_attributes();
        let name = e.file_name().to_string_lossy().to_string();
        let dir = md.is_dir();
        let hidden = attr & (FILE_ATTRIBUTE_HIDDEN.0 | FILE_ATTRIBUTE_SYSTEM.0) != 0 || name.starts_with('.');
        let kind = if dir { "Папка".to_string() } else { kinds.of(&name) };
        out.push(Entry {
            place: None,
            path: e.path(),
            name,
            dir,
            size: if dir { 0 } else { md.file_size() },
            modified: md.last_write_time(),
            hidden,
            kind,
            space: None,
            sel: false,
        });
    }
    Some(out)
}

pub fn space(root: &Path) -> Option<Space> {
    let w = wide(&root.to_string_lossy());
    let (mut free, mut total) = (0u64, 0u64);
    unsafe { GetDiskFreeSpaceExW(pcwstr(&w), Some(&mut free), Some(&mut total), None).ok()? };
    Some(Space { total, free })
}

pub struct Drive {
    pub root: PathBuf,
    pub label: String,
    pub space: Option<Space>,
}

pub fn drives() -> Vec<Drive> {
    let mut out = Vec::new();
    let mask = unsafe { GetLogicalDrives() };
    for i in 0..26 {
        if mask & (1 << i) == 0 {
            continue;
        }
        let letter = (b'A' + i as u8) as char;
        let root = format!("{letter}:\\");
        let w = wide(&root);
        let kind = unsafe { GetDriveTypeW(pcwstr(&w)) };
        let mut name = [0u16; 128];
        let got = unsafe { GetVolumeInformationW(pcwstr(&w), Some(&mut name), None, None, None, None).is_ok() };
        let n = name.iter().position(|&c| c == 0).unwrap_or(0);
        let mut label = String::from_utf16_lossy(&name[..n]);
        if label.is_empty() {
            label = match kind {
                2 => "USB-накопитель",
                4 => "Сетевой диск",
                5 => "CD-дисковод",
                _ => "Локальный диск",
            }
            .into();
        }
        let root = PathBuf::from(&root);
        let space = if got { space(&root) } else { None };
        out.push(Drive { label: format!("{label} ({letter}:)"), root, space });
    }
    out
}

pub fn drive_entries() -> Vec<Entry> {
    drives()
        .into_iter()
        .map(|d| Entry {
            name: d.label,
            path: d.root,
            dir: true,
            size: 0,
            modified: 0,
            hidden: false,
            kind: "Диск".into(),
            space: d.space,
            place: None,
            sel: false,
        })
        .collect()
}

pub struct Place {
    pub name: String,
    pub icon: Icon,
    pub loc: Loc,
    pub space: Option<Space>,
}

const KNOWN: [(&GUID, &str, Icon); 7] = [
    (&FOLDERID_Desktop, "Рабочий стол", Icon::Desktop),
    (&FOLDERID_Downloads, "Загрузки", Icon::Download),
    (&FOLDERID_Documents, "Документы", Icon::Document),
    (&FOLDERID_Pictures, "Изображения", Icon::Picture),
    (&FOLDERID_Videos, "Видео", Icon::Film),
    (&FOLDERID_Music, "Музыка", Icon::Music),
    (&FOLDERID_Profile, "", Icon::Home),
];

/// Системные папки: путь, русское имя и значок
pub fn known() -> Vec<(PathBuf, String, Icon)> {
    KNOWN
        .iter()
        .filter_map(|(id, name, icon)| {
            let p = win::known_folder(id)?;
            let name = if name.is_empty() { display_name(&p) } else { name.to_string() };
            Some((p, name, *icon))
        })
        .collect()
}

/// Боковая панель: избранное (своё или стандартное) и места
pub fn places(custom: Option<&[PathBuf]>) -> (Vec<Place>, Vec<Place>) {
    let known = known();
    let favorites = match custom {
        None => known.iter().map(|(p, n, i)| Place { name: n.clone(), icon: *i, loc: Loc::Dir(p.clone()), space: None }).collect(),
        Some(list) => list
            .iter()
            .map(|p| match known.iter().find(|(k, _, _)| k == p) {
                Some((_, n, i)) => Place { name: n.clone(), icon: *i, loc: Loc::Dir(p.clone()), space: None },
                None => Place { name: display_name(p), icon: Icon::Folder, loc: Loc::Dir(p.clone()), space: None },
            })
            .collect(),
    };
    let mut spots = vec![Place { name: "Компьютер".into(), icon: Icon::Desktop, loc: Loc::Computer, space: None }];
    for d in drives() {
        spots.push(Place { name: d.label, icon: Icon::Drive, loc: Loc::Dir(d.root), space: d.space });
    }
    (favorites, spots)
}

/// Естественный порядок: «файл 2» раньше «файл 10», без учёта регистра
pub fn natural(a: &str, b: &str) -> Ordering {
    let (mut x, mut y) = (a.chars().peekable(), b.chars().peekable());
    loop {
        match (x.peek().copied(), y.peek().copied()) {
            (None, None) => return Ordering::Equal,
            (None, _) => return Ordering::Less,
            (_, None) => return Ordering::Greater,
            (Some(c), Some(d)) if c.is_ascii_digit() && d.is_ascii_digit() => {
                let mut n = String::new();
                while let Some(c) = x.peek().copied().filter(char::is_ascii_digit) {
                    n.push(c);
                    x.next();
                }
                let mut m = String::new();
                while let Some(d) = y.peek().copied().filter(char::is_ascii_digit) {
                    m.push(d);
                    y.next();
                }
                let (n, m) = (n.trim_start_matches('0'), m.trim_start_matches('0'));
                let o = n.len().cmp(&m.len()).then_with(|| n.cmp(m));
                if o != Ordering::Equal {
                    return o;
                }
            }
            (Some(c), Some(d)) => {
                let o = c.to_lowercase().cmp(d.to_lowercase());
                if o != Ordering::Equal {
                    return o;
                }
                x.next();
                y.next();
            }
        }
    }
}

/// Папки всегда сверху, внутри — по выбранному полю
pub fn sort(items: &mut [Entry], by: Sort, asc: bool) {
    items.sort_by(|a, b| {
        let o = match by {
            Sort::Name => natural(&a.name, &b.name),
            Sort::Date => a.modified.cmp(&b.modified).then_with(|| natural(&a.name, &b.name)),
            Sort::Size => a.size.cmp(&b.size).then_with(|| natural(&a.name, &b.name)),
            Sort::Kind => a.kind.to_lowercase().cmp(&b.kind.to_lowercase()).then_with(|| natural(&a.name, &b.name)),
        };
        b.dir.cmp(&a.dir).then(if asc { o } else { o.reverse() })
    });
}

pub fn size_text(n: u64) -> String {
    if n < 1024 {
        return format!("{n} байт");
    }
    let units = ["КБ", "МБ", "ГБ", "ТБ"];
    let mut v = n as f64 / 1024.0;
    let mut u = 0;
    while v >= 1024.0 && u < units.len() - 1 {
        v /= 1024.0;
        u += 1;
    }
    let s = if v < 10.0 { format!("{v:.1}") } else { format!("{v:.0}") };
    format!("{} {}", s.replace('.', ","), units[u])
}

const MONTHS: [&str; 12] = ["янв.", "февр.", "мар.", "апр.", "мая", "июн.", "июл.", "авг.", "сент.", "окт.", "нояб.", "дек."];

fn local(ft: u64) -> Option<SYSTEMTIME> {
    let f = FILETIME { dwLowDateTime: ft as u32, dwHighDateTime: (ft >> 32) as u32 };
    unsafe {
        let mut utc = SYSTEMTIME::default();
        FileTimeToSystemTime(&f, &mut utc).ok()?;
        let mut loc = SYSTEMTIME::default();
        SystemTimeToTzSpecificLocalTime(None, &utc, &mut loc).ok()?;
        Some(loc)
    }
}

fn day_number(t: &SYSTEMTIME) -> i64 {
    // дни от условной эпохи — нужна только разница «сегодня/вчера»
    let (y, m, d) = (t.wYear as i64, t.wMonth as i64, t.wDay as i64);
    let (y, m) = if m <= 2 { (y - 1, m + 12) } else { (y, m) };
    365 * y + y / 4 - y / 100 + y / 400 + (153 * (m - 3) + 2) / 5 + d
}

/// «Сегодня, 14:32», «Вчера, 09:10», «12 окт. 2026 г., 18:00»
pub fn date_text(ft: u64) -> String {
    let Some(t) = local(ft) else { return "—".into() };
    let today = unsafe { GetLocalTime() };
    let diff = day_number(&today) - day_number(&t);
    let time = format!("{:02}:{:02}", t.wHour, t.wMinute);
    match diff {
        0 => format!("Сегодня, {time}"),
        1 => format!("Вчера, {time}"),
        _ => format!("{} {} {} г., {time}", t.wDay, MONTHS[(t.wMonth as usize).clamp(1, 12) - 1], t.wYear),
    }
}

pub fn plural(n: usize, forms: [&str; 3]) -> String {
    let (m10, m100) = (n % 10, n % 100);
    let f = if m10 == 1 && m100 != 11 {
        forms[0]
    } else if (2..=4).contains(&m10) && !(12..=14).contains(&m100) {
        forms[1]
    } else {
        forms[2]
    };
    format!("{n} {f}")
}

/// Свободное имя «Новая папка», «Новая папка 2», …
pub fn free_name(dir: &Path, base: &str) -> PathBuf {
    let mut p = dir.join(base);
    let mut n = 2;
    while p.exists() {
        p = dir.join(format!("{base} {n}"));
        n += 1;
    }
    p
}

/// Текст для предпросмотра, если файл похож на текстовый
pub fn text_preview(p: &Path) -> Option<Vec<String>> {
    const EXT: [&str; 34] = [
        "txt", "md", "log", "json", "rs", "py", "js", "ts", "tsx", "jsx", "html", "htm", "css", "xml", "ini", "cfg", "toml", "yaml", "yml", "csv",
        "bat", "cmd", "ps1", "c", "cpp", "h", "hpp", "cs", "java", "go", "sql", "sh", "lua", "conf",
    ];
    let ext = p.extension()?.to_string_lossy().to_lowercase();
    if !EXT.contains(&ext.as_str()) {
        return None;
    }
    use std::io::Read;
    let mut buf = vec![0u8; 64 * 1024];
    let n = std::fs::File::open(p).ok()?.read(&mut buf).ok()?;
    buf.truncate(n);
    let s = if buf.starts_with(&[0xFF, 0xFE]) {
        let u: Vec<u16> = buf[2..].chunks_exact(2).map(|c| u16::from_le_bytes([c[0], c[1]])).collect();
        String::from_utf16_lossy(&u)
    } else {
        String::from_utf8_lossy(buf.strip_prefix(&[0xEF, 0xBB, 0xBF]).unwrap_or(&buf)).to_string()
    };
    Some(s.lines().take(400).map(|l| l.replace('\t', "    ")).collect())
}

/// Категории для фильтра и группировки «по типу»
pub const CATS: [&str; 9] = ["Папки", "Изображения", "Видео", "Музыка", "Документы", "Архивы", "Программы", "Код", "Другое"];

pub fn category(e: &Entry) -> u8 {
    if e.dir {
        return 0;
    }
    let ext = Path::new(&e.name).extension().map(|x| x.to_string_lossy().to_lowercase()).unwrap_or_default();
    match ext.as_str() {
        "jpg" | "jpeg" | "png" | "gif" | "bmp" | "webp" | "heic" | "heif" | "tif" | "tiff" | "ico" | "svg" | "raw" | "cr2" | "nef" | "psd"
        | "avif" => 1,
        "mp4" | "mkv" | "avi" | "mov" | "wmv" | "webm" | "flv" | "m4v" | "mpg" | "mpeg" | "3gp" | "ts" if ext != "ts" || e.size > 10 << 20 => 2,
        "mp3" | "wav" | "flac" | "aac" | "ogg" | "m4a" | "wma" | "opus" => 3,
        "pdf" | "doc" | "docx" | "xls" | "xlsx" | "ppt" | "pptx" | "odt" | "ods" | "odp" | "rtf" | "txt" | "md" | "csv" | "epub" | "djvu" | "fb2" => {
            4
        }
        "zip" | "rar" | "7z" | "tar" | "gz" | "bz2" | "xz" | "iso" | "cab" | "tgz" | "zst" => 5,
        "exe" | "msi" | "lnk" | "bat" | "cmd" | "appx" | "msix" | "apk" | "jar" | "url" => 6,
        "rs" | "py" | "js" | "ts" | "tsx" | "jsx" | "html" | "htm" | "css" | "json" | "xml" | "yaml" | "yml" | "toml" | "c" | "cpp" | "h" | "hpp"
        | "cs" | "java" | "go" | "lua" | "sh" | "ps1" | "sql" | "ini" | "cfg" | "lock" => 7,
        _ => 8,
    }
}

/// Полночь сегодняшнего дня по местному времени, в единицах FILETIME
pub fn midnight() -> u64 {
    use windows::Win32::System::Time::{SystemTimeToFileTime, TzSpecificLocalTimeToSystemTime};
    unsafe {
        let mut t = GetLocalTime();
        (t.wHour, t.wMinute, t.wSecond, t.wMilliseconds) = (0, 0, 0, 0);
        let mut utc = SYSTEMTIME::default();
        if TzSpecificLocalTimeToSystemTime(None, &t, &mut utc).is_err() {
            return 0;
        }
        let mut ft = FILETIME::default();
        if SystemTimeToFileTime(&utc, &mut ft).is_err() {
            return 0;
        }
        (ft.dwHighDateTime as u64) << 32 | ft.dwLowDateTime as u64
    }
}

/// Группа элемента: порядок группы и её заголовок. mode: 1 — тип, 2 — дата, 3 — размер, 4 — первая буква
pub fn group_key(e: &Entry, mode: u8, midnight: u64) -> (u32, String) {
    const DAY: u64 = 864_000_000_000;
    match mode {
        1 => {
            let c = category(e);
            (c as u32, CATS[c as usize].to_string())
        }
        2 => {
            let t = e.modified;
            let (k, n) = if t >= midnight {
                (0, "Сегодня")
            } else if t >= midnight.saturating_sub(DAY) {
                (1, "Вчера")
            } else if t >= midnight.saturating_sub(7 * DAY) {
                (2, "Последние 7 дней")
            } else if t >= midnight.saturating_sub(30 * DAY) {
                (3, "Последние 30 дней")
            } else if t >= midnight.saturating_sub(365 * DAY) {
                (4, "За последний год")
            } else {
                (5, "Давно")
            };
            (k, n.to_string())
        }
        3 => {
            let (k, n) = match (e.dir, e.size) {
                (true, _) => (0, "Папки"),
                (_, s) if s >= 1 << 30 => (1, "Огромные — больше 1 ГБ"),
                (_, s) if s >= 100 << 20 => (2, "Большие — от 100 МБ до 1 ГБ"),
                (_, s) if s >= 1 << 20 => (3, "Средние — от 1 до 100 МБ"),
                (_, s) if s >= 10 << 10 => (4, "Маленькие — от 10 КБ до 1 МБ"),
                _ => (5, "Крошечные — меньше 10 КБ"),
            };
            (k, n.to_string())
        }
        _ => {
            let c = e.name.chars().next().and_then(|c| c.to_uppercase().next()).unwrap_or('#');
            if c.is_ascii_digit() {
                (1, "0–9".into())
            } else if c.is_alphabetic() {
                (c as u32 + 10, c.to_string())
            } else {
                (0, "#".into())
            }
        }
    }
}
