//! Защита от удаления того, без чего Windows или программы сломаются (правила SquirrelDisk):
//! «нельзя» — не удаляется никогда, «осторожно» — только после отдельного подтверждения

use std::path::Path;

#[derive(Clone, Debug, PartialEq)]
pub enum Verdict {
    Ok,
    Caution(String),
    Forbidden(String),
}

/// Косые вперёд, без хвостовой, в нижнем регистре; «c:» — это «c:/»
fn norm(p: &str) -> String {
    let mut s = p.replace('\\', "/").to_lowercase();
    while s.len() > 3 && s.ends_with('/') {
        s.pop();
    }
    if s.len() == 2 && s.ends_with(':') {
        s.push('/');
    }
    s
}

/// path — это base или что-то внутри неё
fn under(path: &str, base: &str) -> bool {
    path == base || (path.starts_with(base) && (base.ends_with('/') || path[base.len()..].starts_with('/')))
}

pub struct Rules {
    /// нельзя ни их, ни то, что внутри, ни папки, где они лежат
    trees: Vec<String>,
    /// нельзя их самих и папки, где они лежат; внутри — можно, но осторожно
    exact: Vec<String>,
    /// внутри — только с подтверждением
    caution: Vec<String>,
    exe: String,
}

impl Rules {
    pub fn current() -> Rules {
        let win = std::env::var("SystemRoot").unwrap_or_else(|_| "C:\\Windows".into());
        let sys = win.get(..2).unwrap_or("C:").to_string();
        let pf = std::env::var("ProgramFiles").unwrap_or_else(|_| format!("{sys}\\Program Files"));
        let pf86 = std::env::var("ProgramFiles(x86)").unwrap_or_else(|_| format!("{sys}\\Program Files (x86)"));
        let pd = std::env::var("ProgramData").unwrap_or_else(|_| format!("{sys}\\ProgramData"));
        let home = std::env::var("USERPROFILE").ok();
        let mut r = Rules { trees: Vec::new(), exact: Vec::new(), caution: Vec::new(), exe: String::new() };
        for t in [
            win.clone(),
            format!("{pf}\\WindowsApps"),
            format!("{sys}\\System Volume Information"),
            format!("{sys}\\Recovery"),
            format!("{sys}\\Boot"),
            format!("{sys}\\pagefile.sys"),
            format!("{sys}\\hiberfil.sys"),
            format!("{sys}\\swapfile.sys"),
            format!("{sys}\\bootmgr"),
            format!("{sys}\\$Recycle.Bin"),
            format!("{pd}\\Microsoft"),
        ] {
            r.trees.push(norm(&t));
        }
        for e in [format!("{sys}\\"), pf.clone(), pf86.clone(), pd.clone(), format!("{sys}\\Users"), format!("{sys}\\Users\\Public")] {
            r.exact.push(norm(&e));
        }
        for c in [pf, pf86, pd] {
            r.caution.push(norm(&c));
        }
        if let Some(h) = home {
            let h = norm(&h);
            r.exact.push(h.clone());
            for sub in ["AppData", "AppData/Local", "AppData/Roaming", "AppData/LocalLow", "Documents", "Desktop", "Downloads", "Pictures", "Music", "Videos"]
            {
                r.exact.push(norm(&format!("{h}/{sub}")));
            }
            r.trees.push(format!("{h}/ntuser.dat"));
            r.caution.push(format!("{h}/appdata"));
        }
        r.exe = std::env::current_exe().map(|e| norm(&e.to_string_lossy())).unwrap_or_default();
        r
    }

    pub fn check(&self, path: &Path) -> Verdict {
        let p = norm(&path.to_string_lossy());
        if p.len() <= 3 {
            return Verdict::Forbidden("это корень диска".into());
        }
        // и саму программу тоже не удаляем
        if !self.exe.is_empty() && under(&self.exe, &p) {
            return Verdict::Forbidden("здесь лежит сам Finder".into());
        }
        for t in &self.trees {
            if under(&p, t) || under(t, &p) {
                return Verdict::Forbidden("системная папка Windows".into());
            }
        }
        for e in &self.exact {
            if under(e, &p) {
                return Verdict::Forbidden("важная папка: в ней ваши файлы или программы".into());
            }
        }
        for c in &self.caution {
            if under(&p, c) {
                return Verdict::Caution("программы могут перестать работать".into());
            }
        }
        let name = p.rsplit('/').next().unwrap_or("");
        if name.starts_with('.') && p.matches('/').count() <= 3 {
            return Verdict::Caution("скрытые настройки программ".into());
        }
        Verdict::Ok
    }
}
