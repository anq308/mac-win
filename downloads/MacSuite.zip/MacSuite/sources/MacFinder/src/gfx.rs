use ab_glyph::{point, Font, FontVec, PxScale, ScaleFont};
use tiny_skia::*;

/// Картинка в формате GDI: BGRA, альфа премультиплицирована
#[derive(Clone)]
pub struct Img {
    pub w: u32,
    pub h: u32,
    pub px: Vec<u8>,
}

impl Img {
    pub fn new(w: u32, h: u32) -> Img {
        Img { w, h, px: vec![0; (w * h * 4) as usize] }
    }

    pub fn pixmap(&self) -> Option<PixmapRef<'_>> {
        PixmapRef::from_bytes(&self.px, self.w, self.h)
    }

    pub fn pixmap_mut(&mut self) -> Option<PixmapMut<'_>> {
        PixmapMut::from_bytes(&mut self.px, self.w, self.h)
    }

    /// Непрозрачные углы — значит, это миниатюра (фото, кадр видео), а не иконка с прозрачным фоном
    pub fn is_photo(&self) -> bool {
        if self.w < 4 || self.h < 4 {
            return false;
        }
        let a = |x: u32, y: u32| self.px[((y * self.w + x) * 4 + 3) as usize];
        [a(1, 1), a(self.w - 2, 1), a(1, self.h - 2), a(self.w - 2, self.h - 2)].iter().all(|&v| v > 250)
    }
}

/// Буферы у нас в порядке BGRA, а tiny-skia считает их RGBA — поэтому R и B меняем местами
pub fn rgb(r: u8, g: u8, b: u8, a: f32) -> Color {
    Color::from_rgba8(b, g, r, (a.clamp(0.0, 1.0) * 255.0).round() as u8)
}

pub fn solid(c: Color) -> Paint<'static> {
    let mut p = Paint::default();
    p.set_color(c);
    p.anti_alias = true;
    p
}

pub fn stroke(width: f32) -> Stroke {
    Stroke { width, line_cap: LineCap::Round, line_join: LineJoin::Round, ..Default::default() }
}

/// Углы как в Windows 10 — почти прямые
pub fn rrect(x: f32, y: f32, w: f32, h: f32, r: f32) -> Option<Path> {
    round_rect(x, y, w, h, corner(r, w, h))
}

pub fn round_rect(x: f32, y: f32, w: f32, h: f32, r: f32) -> Option<Path> {
    let r = r.min(w / 2.0).min(h / 2.0).max(0.0);
    let k = r * 0.552_284_8;
    let mut pb = PathBuilder::new();
    pb.move_to(x + r, y);
    pb.line_to(x + w - r, y);
    pb.cubic_to(x + w - r + k, y, x + w, y + r - k, x + w, y + r);
    pb.line_to(x + w, y + h - r);
    pb.cubic_to(x + w, y + h - r + k, x + w - r + k, y + h, x + w - r, y + h);
    pb.line_to(x + r, y + h);
    pb.cubic_to(x + r - k, y + h, x, y + h - r + k, x, y + h - r);
    pb.line_to(x, y + r);
    pb.cubic_to(x, y + r - k, x + r - k, y, x + r, y);
    pb.close();
    pb.finish()
}

pub fn fill_rrect(pm: &mut PixmapMut, x: f32, y: f32, w: f32, h: f32, r: f32, c: Color) {
    if let Some(p) = rrect(x, y, w, h, r) {
        pm.fill_path(&p, &solid(c), FillRule::Winding, Transform::identity(), None);
    }
}

pub fn stroke_rrect(pm: &mut PixmapMut, x: f32, y: f32, w: f32, h: f32, r: f32, width: f32, c: Color) {
    if let Some(p) = rrect(x, y, w, h, r) {
        pm.stroke_path(&p, &solid(c), &stroke(width), Transform::identity(), None);
    }
}

pub fn circle(pm: &mut PixmapMut, cx: f32, cy: f32, r: f32, c: Color) {
    if let Some(p) = PathBuilder::from_circle(cx, cy, r) {
        pm.fill_path(&p, &solid(c), FillRule::Winding, Transform::identity(), None);
    }
}

/// Картинка в прямоугольнике (x, y, w, h) со скруглением radius и прозрачностью opacity
pub fn image(pm: &mut PixmapMut, img: &Img, x: f32, y: f32, w: f32, h: f32, radius: f32, opacity: f32) {
    let Some(src) = img.pixmap() else { return };
    let (kx, ky) = (w / img.w as f32, h / img.h as f32);
    let exact = (kx - 1.0).abs() < 0.01 && (ky - 1.0).abs() < 0.01;
    let quality = if exact { FilterQuality::Nearest } else { FilterQuality::Bicubic };
    let paint = Paint {
        shader: Pattern::new(src, SpreadMode::Pad, quality, opacity, Transform::from_row(kx, 0.0, 0.0, ky, x, y)),
        anti_alias: true,
        ..Default::default()
    };
    if let Some(p) = rrect(x, y, w, h, radius) {
        pm.fill_path(&p, &paint, FillRule::Winding, Transform::identity(), None);
    }
}

/// Мягкая тень: размытый прямоугольник, записанный в альфу (цвет чёрный)
pub fn shadow(pm: &mut PixmapMut, x: f32, y: f32, w: f32, h: f32, blur: f32, opacity: f32) {
    let (pw, ph) = (pm.width() as i64, pm.height() as i64);
    // три прохода box blur ≈ гауссово размытие
    let r = (blur / 2.0).max(1.0) as usize;
    let m = 3 * r as i64 + 1;
    let (rx0, ry0) = ((x as i64 - m).max(0), (y as i64 - m).max(0));
    let (rx1, ry1) = (((x + w).ceil() as i64 + m).min(pw), ((y + h).ceil() as i64 + m).min(ph));
    if rx1 <= rx0 || ry1 <= ry0 {
        return;
    }
    let (rw, rh) = ((rx1 - rx0) as usize, (ry1 - ry0) as usize);
    let mut a = vec![0f32; rw * rh];
    let (x0, y0) = ((x.max(0.0) as i64 - rx0).max(0) as usize, (y.max(0.0) as i64 - ry0).max(0) as usize);
    let (x1, y1) = ((((x + w) as i64).min(pw) - rx0).max(0) as usize, (((y + h) as i64).min(ph) - ry0).max(0) as usize);
    for yy in y0..y1.min(rh) {
        a[yy * rw + x0..yy * rw + x1.min(rw)].fill(opacity);
    }
    for _ in 0..3 {
        box_blur(&mut a, rw, rh, r, 1, rw);
        box_blur(&mut a, rh, rw, r, rw, 1);
    }
    let data = pm.data_mut();
    for (j, v) in a.iter().enumerate() {
        let sa = v.clamp(0.0, 1.0);
        if sa <= 0.0 {
            continue;
        }
        let i = (ry0 as usize + j / rw) * pw as usize + rx0 as usize + j % rw;
        let inv = 1.0 - sa;
        let p = &mut data[i * 4..i * 4 + 4];
        p[0] = (p[0] as f32 * inv) as u8;
        p[1] = (p[1] as f32 * inv) as u8;
        p[2] = (p[2] as f32 * inv) as u8;
        p[3] = (sa * 255.0 + p[3] as f32 * inv).round().min(255.0) as u8;
    }
}

fn box_blur(a: &mut [f32], len: usize, lines: usize, r: usize, step: usize, next: usize) {
    let mut line = vec![0f32; len];
    let d = (2 * r + 1) as f32;
    for l in 0..lines {
        let base = l * next;
        for i in 0..len {
            line[i] = a[base + i * step];
        }
        let mut sum: f32 = line.iter().take(r + 1).sum();
        for i in 0..len {
            a[base + i * step] = sum / d;
            if i + r + 1 < len {
                sum += line[i + r + 1];
            }
            if i >= r {
                sum -= line[i - r];
            }
        }
    }
}

pub struct Fonts {
    pub regular: FontVec,
    pub semibold: FontVec,
    /// моноширинный для предпросмотра текста
    pub mono: FontVec,
}

impl Fonts {
    pub fn load() -> Option<Fonts> {
        let dir = std::env::var("WINDIR").unwrap_or_else(|_| "C:\\Windows".into());
        let load = |name: &str| -> Option<FontVec> { FontVec::try_from_vec(std::fs::read(format!("{dir}\\Fonts\\{name}")).ok()?).ok() };
        Some(Fonts {
            semibold: variable_font(600.0).or_else(|| load("seguisb.ttf")).or_else(|| load("segoeui.ttf"))?,
            mono: load("consola.ttf").or_else(|| load("cour.ttf")).or_else(|| load("segoeui.ttf"))?,
            regular: variable_font(400.0).or_else(|| load("segoeui.ttf"))?,
        })
    }
}

/// PxScale в ab_glyph задаётся по высоте ascent−descent, а нам нужен кегль по em
fn em_scale(font: &FontVec, px: f32) -> PxScale {
    let upm = font.units_per_em().unwrap_or(2048.0);
    PxScale::from(px * font.height_unscaled() / upm)
}

pub fn measure(font: &FontVec, s: &str, px: f32) -> f32 {
    let sf = font.as_scaled(em_scale(font, px));
    let mut w = 0.0;
    let mut prev = None;
    for c in s.chars() {
        let id = sf.glyph_id(c);
        if let Some(p) = prev {
            w += sf.kern(p, id);
        }
        w += sf.h_advance(id);
        prev = Some(id);
    }
    w
}

/// Строка, урезанная с многоточием в конце под ширину max
pub fn fit(font: &FontVec, s: &str, px: f32, max: f32) -> String {
    if measure(font, s, px) <= max {
        return s.to_string();
    }
    let mut chars: Vec<char> = s.chars().collect();
    while !chars.is_empty() {
        chars.pop();
        let t = chars.iter().collect::<String>().trim_end().to_string() + "…";
        if measure(font, &t, px) <= max {
            return t;
        }
    }
    "…".into()
}

/// Многоточие в середине, как в Finder: «длинное_им…ние.png» — расширение остаётся видно
pub fn fit_middle(font: &FontVec, s: &str, px: f32, max: f32) -> String {
    if measure(font, s, px) <= max {
        return s.to_string();
    }
    let chars: Vec<char> = s.chars().collect();
    let n = chars.len();
    for cut in 1..n {
        let head = (n - cut) / 2;
        let tail = n - cut - head;
        let t: String = chars[..head].iter().chain(['…'].iter()).chain(chars[n - tail..].iter()).collect();
        if measure(font, &t, px) <= max {
            return t;
        }
    }
    "…".into()
}

/// Имя в две строки под плиткой: перенос по пробелу/дефису/подчёркиванию, вторая строка — с многоточием в середине
pub fn wrap2(font: &FontVec, s: &str, px: f32, max: f32) -> Vec<String> {
    if measure(font, s, px) <= max {
        return vec![s.to_string()];
    }
    let chars: Vec<char> = s.chars().collect();
    let mut n = 0;
    while n < chars.len() && measure(font, &chars[..n + 1].iter().collect::<String>(), px) <= max {
        n += 1;
    }
    let n = n.max(1);
    let brk = chars[..n].iter().rposition(|c| matches!(c, ' ' | '-' | '_' | '.' | ',')).filter(|&i| i + 1 >= n / 2).map(|i| i + 1).unwrap_or(n);
    let first: String = chars[..brk].iter().collect::<String>().trim_end().to_string();
    let rest: String = chars[brk..].iter().collect::<String>().trim_start().to_string();
    vec![first, fit_middle(font, &rest, px, max)]
}

/// Текст с базовой линией в (x, baseline); смешивание src-over по покрытию глифа
pub fn text(pm: &mut PixmapMut, font: &FontVec, s: &str, x: f32, baseline: f32, px: f32, color: Color) {
    let (pw, ph) = (pm.width() as i32, pm.height() as i32);
    let c = color.premultiply();
    let (cr, cg, cb, ca) = (c.red(), c.green(), c.blue(), c.alpha());
    let data = pm.data_mut();
    let scale = em_scale(font, px);
    let sf = font.as_scaled(scale);
    let mut pen = x;
    let mut prev = None;
    for ch in s.chars() {
        let id = sf.glyph_id(ch);
        if let Some(p) = prev {
            pen += sf.kern(p, id);
        }
        let glyph = id.with_scale_and_position(scale, point(pen, baseline));
        if let Some(og) = font.outline_glyph(glyph) {
            let b = og.px_bounds();
            og.draw(|gx, gy, a| {
                let xx = b.min.x as i32 + gx as i32;
                let y = b.min.y as i32 + gy as i32;
                if a <= 0.0 || xx < 0 || xx >= pw || y < 0 || y >= ph {
                    return;
                }
                let a = a.min(1.0);
                let i = ((y * pw + xx) * 4) as usize;
                let sa = ca * a;
                let inv = 1.0 - sa;
                let blend = |dst: u8, src: f32| ((src * a * 255.0) + dst as f32 * inv).round().min(255.0) as u8;
                data[i] = blend(data[i], cr);
                data[i + 1] = blend(data[i + 1], cg);
                data[i + 2] = blend(data[i + 2], cb);
                data[i + 3] = ((sa * 255.0) + data[i + 3] as f32 * inv).round().min(255.0) as u8;
            });
        }
        pen += sf.h_advance(id);
        prev = Some(id);
    }
}

#[derive(Clone, Copy, PartialEq)]
pub enum Icon {
    ChevronLeft,
    ChevronRight,
    ChevronUp,
    ChevronDown,
    Grid,
    List,
    Search,
    Close,
    Desktop,
    Download,
    Document,
    Picture,
    Film,
    Music,
    Home,
    Drive,
    Folder,
    Plus,
    Back,
    Forward,
    Pie,
    Sparkle,
    Stack,
    Filter,
    Panel,
}

/// Линейные иконки в сетке 20×20, растянутые трансформацией; (x, y) — левый верхний угол
/// Значок в квадрате size×size с левым верхним углом (x, y): глиф Segoe MDL2, как в самой Windows
pub fn icon(pm: &mut PixmapMut, kind: Icon, x: f32, y: f32, size: f32, c: Color) {
    let ch = match kind {
        Icon::ChevronLeft => '\u{E76B}',
        Icon::ChevronRight => '\u{E76C}',
        Icon::ChevronUp => '\u{E70E}',
        Icon::ChevronDown => '\u{E70D}',
        Icon::Back => '\u{E72B}',
        Icon::Forward => '\u{E72A}',
        Icon::Grid => '\u{E8A9}',
        Icon::List => '\u{E8FD}',
        Icon::Search => '\u{E721}',
        Icon::Close => '\u{E711}',
        Icon::Desktop => '\u{EC4E}',
        Icon::Download => '\u{E896}',
        Icon::Document => '\u{E8A5}',
        Icon::Picture => '\u{E8B9}',
        Icon::Film => '\u{E714}',
        Icon::Music => '\u{EC4F}',
        Icon::Home => '\u{E80F}',
        Icon::Drive => '\u{EDA2}',
        Icon::Folder => '\u{F12B}',
        Icon::Plus => '\u{E710}',
        Icon::Pie => '\u{EB05}',
        Icon::Sparkle => '\u{EA99}',
        Icon::Stack => '\u{F168}',
        Icon::Filter => '\u{E71C}',
        Icon::Panel => '\u{E90D}',
    };
    let px = match kind {
        Icon::ChevronLeft | Icon::ChevronRight | Icon::ChevronUp | Icon::ChevronDown => size * 0.6,
        _ => size * 0.8,
    };
    if !glyph(pm, ch, x + size / 2.0, y + size / 2.0, px, c) {
        icon_drawn(pm, kind, x, y, size, c);
    }
}

fn icon_drawn(pm: &mut PixmapMut, kind: Icon, x: f32, y: f32, size: f32, c: Color) {
    let u = size / 20.0;
    let t = Transform::from_row(u, 0.0, 0.0, u, x, y);
    let p = solid(c);
    let st = stroke(1.5);
    let mut fill = PathBuilder::new();
    let mut pb = PathBuilder::new();
    let mut outline = |r: Option<Path>| {
        if let Some(r) = r {
            pm.stroke_path(&r, &p, &st, t, None);
        }
    };
    match kind {
        Icon::ChevronLeft | Icon::Back => {
            pb.move_to(12.0, 5.5);
            pb.line_to(7.5, 10.0);
            pb.line_to(12.0, 14.5);
        }
        Icon::ChevronRight | Icon::Forward => {
            pb.move_to(8.0, 5.5);
            pb.line_to(12.5, 10.0);
            pb.line_to(8.0, 14.5);
        }
        Icon::ChevronUp => {
            pb.move_to(6.0, 12.0);
            pb.line_to(10.0, 8.0);
            pb.line_to(14.0, 12.0);
        }
        Icon::ChevronDown => {
            pb.move_to(6.0, 8.0);
            pb.line_to(10.0, 12.0);
            pb.line_to(14.0, 8.0);
        }
        Icon::Grid => {
            for (gx, gy) in [(3.0, 3.0), (10.8, 3.0), (3.0, 10.8), (10.8, 10.8)] {
                outline(rrect(gx, gy, 6.2, 6.2, 1.6));
            }
        }
        Icon::List => {
            for y in [5.0f32, 10.0, 15.0] {
                pb.move_to(7.5, y);
                pb.line_to(17.0, y);
                fill.push_circle(3.6, y, 1.2);
            }
        }
        Icon::Search => {
            pb.push_circle(8.6, 8.6, 5.2);
            pb.move_to(12.5, 12.5);
            pb.line_to(16.8, 16.8);
        }
        Icon::Close => {
            pb.move_to(6.0, 6.0);
            pb.line_to(14.0, 14.0);
            pb.move_to(14.0, 6.0);
            pb.line_to(6.0, 14.0);
        }
        Icon::Desktop => {
            outline(rrect(2.2, 3.6, 15.6, 10.4, 1.8));
            pb.move_to(10.0, 14.2);
            pb.line_to(10.0, 16.6);
            pb.move_to(6.6, 16.6);
            pb.line_to(13.4, 16.6);
        }
        Icon::Download => {
            pb.push_circle(10.0, 10.0, 7.4);
            pb.move_to(10.0, 5.8);
            pb.line_to(10.0, 13.6);
            pb.move_to(6.9, 10.6);
            pb.line_to(10.0, 13.7);
            pb.line_to(13.1, 10.6);
        }
        Icon::Document => {
            pb.move_to(5.0, 2.8);
            pb.line_to(11.5, 2.8);
            pb.line_to(15.0, 6.3);
            pb.line_to(15.0, 17.2);
            pb.line_to(5.0, 17.2);
            pb.close();
            pb.move_to(11.5, 2.8);
            pb.line_to(11.5, 6.3);
            pb.line_to(15.0, 6.3);
        }
        Icon::Picture => {
            outline(rrect(2.5, 4.0, 15.0, 12.0, 2.2));
            pb.move_to(4.6, 14.0);
            pb.line_to(8.4, 9.8);
            pb.line_to(11.4, 12.6);
            pb.line_to(13.0, 11.1);
            pb.line_to(15.4, 13.6);
            fill.push_circle(13.0, 7.6, 1.3);
        }
        Icon::Film => {
            outline(rrect(3.0, 3.0, 14.0, 14.0, 2.2));
            pb.move_to(6.6, 3.0);
            pb.line_to(6.6, 17.0);
            pb.move_to(13.4, 3.0);
            pb.line_to(13.4, 17.0);
            pb.move_to(3.0, 10.0);
            pb.line_to(6.6, 10.0);
            pb.move_to(13.4, 10.0);
            pb.line_to(17.0, 10.0);
        }
        Icon::Music => {
            pb.move_to(8.0, 15.0);
            pb.line_to(8.0, 5.0);
            pb.line_to(14.6, 3.4);
            pb.line_to(14.6, 13.4);
            fill.push_circle(6.2, 15.0, 2.0);
            fill.push_circle(12.8, 13.4, 2.0);
        }
        Icon::Home => {
            pb.move_to(2.8, 9.6);
            pb.line_to(10.0, 3.4);
            pb.line_to(17.2, 9.6);
            pb.move_to(5.0, 8.0);
            pb.line_to(5.0, 16.6);
            pb.line_to(15.0, 16.6);
            pb.line_to(15.0, 8.0);
            pb.move_to(8.4, 16.6);
            pb.line_to(8.4, 12.0);
            pb.line_to(11.6, 12.0);
            pb.line_to(11.6, 16.6);
        }
        Icon::Drive => {
            outline(rrect(2.5, 6.0, 15.0, 8.0, 2.0));
            pb.move_to(5.2, 10.0);
            pb.line_to(9.0, 10.0);
            fill.push_circle(14.2, 10.0, 1.1);
        }
        Icon::Pie => {
            pb.push_circle(10.0, 10.0, 7.2);
            fill.move_to(10.0, 10.0);
            fill.line_to(10.0, 4.6);
            arc(&mut fill, 10.0, 10.0, 5.4, -std::f32::consts::FRAC_PI_2, 0.0);
            fill.close();
        }
        Icon::Sparkle => {
            fill.move_to(8.5, 3.5);
            fill.quad_to(9.2, 10.3, 15.5, 11.0);
            fill.quad_to(9.2, 11.7, 8.5, 18.5);
            fill.quad_to(7.8, 11.7, 1.5, 11.0);
            fill.quad_to(7.8, 10.3, 8.5, 3.5);
            fill.close();
            fill.move_to(15.0, 1.8);
            fill.quad_to(15.3, 4.7, 18.2, 5.0);
            fill.quad_to(15.3, 5.3, 15.0, 8.2);
            fill.quad_to(14.7, 5.3, 11.8, 5.0);
            fill.quad_to(14.7, 4.7, 15.0, 1.8);
            fill.close();
        }
        Icon::Stack => {
            outline(rrect(3.0, 3.0, 14.0, 5.6, 1.6));
            outline(rrect(3.0, 11.4, 14.0, 5.6, 1.6));
        }
        Icon::Filter => {
            pb.move_to(3.0, 4.2);
            pb.line_to(17.0, 4.2);
            pb.line_to(11.6, 10.6);
            pb.line_to(11.6, 16.2);
            pb.line_to(8.4, 14.6);
            pb.line_to(8.4, 10.6);
            pb.close();
        }
        Icon::Panel => {
            outline(rrect(2.5, 3.5, 15.0, 13.0, 2.2));
            pb.move_to(12.2, 3.5);
            pb.line_to(12.2, 16.5);
        }
        Icon::Plus => {
            pb.move_to(10.0, 4.5);
            pb.line_to(10.0, 15.5);
            pb.move_to(4.5, 10.0);
            pb.line_to(15.5, 10.0);
        }
        Icon::Folder => {
            pb.move_to(2.6, 15.2);
            pb.line_to(2.6, 5.2);
            pb.cubic_to(2.6, 4.6, 3.0, 4.2, 3.6, 4.2);
            pb.line_to(7.4, 4.2);
            pb.line_to(9.0, 6.0);
            pb.line_to(16.4, 6.0);
            pb.cubic_to(17.0, 6.0, 17.4, 6.4, 17.4, 7.0);
            pb.line_to(17.4, 15.2);
            pb.cubic_to(17.4, 15.8, 17.0, 16.2, 16.4, 16.2);
            pb.line_to(3.6, 16.2);
            pb.cubic_to(3.0, 16.2, 2.6, 15.8, 2.6, 15.2);
            pb.close();
        }
    }
    if let Some(path) = fill.finish() {
        pm.fill_path(&path, &p, FillRule::Winding, t, None);
    }
    if let Some(path) = pb.finish() {
        pm.stroke_path(&path, &p, &st, t, None);
    }
}

/// Дуга ломаной; углы в радианах, 0 — вправо, по часовой стрелке (ось y вниз)
pub fn arc(pb: &mut PathBuilder, cx: f32, cy: f32, r: f32, a0: f32, a1: f32) {
    let n = (((a1 - a0).abs() * r / 2.5).ceil() as usize).clamp(8, 720);
    for i in 0..=n {
        let a = a0 + (a1 - a0) * i as f32 / n as f32;
        let (x, y) = (cx + r * a.cos(), cy + r * a.sin());
        if i == 0 && pb.is_empty() {
            pb.move_to(x, y);
        } else {
            pb.line_to(x, y);
        }
    }
}

/// Кольцо заполненности: frac — доля от 0 до 1, начиная сверху по часовой стрелке
pub fn donut(pm: &mut PixmapMut, cx: f32, cy: f32, r: f32, width: f32, frac: f32, color: Color, track: Color) {
    let st = Stroke { width, line_cap: LineCap::Butt, ..Default::default() };
    if let Some(c) = PathBuilder::from_circle(cx, cy, r) {
        pm.stroke_path(&c, &solid(track), &st, Transform::identity(), None);
    }
    if frac > 0.002 {
        let mut pb = PathBuilder::new();
        let start = -std::f32::consts::FRAC_PI_2;
        arc(&mut pb, cx, cy, r, start, start + frac.min(1.0) * std::f32::consts::TAU);
        if let Some(p) = pb.finish() {
            pm.stroke_path(&p, &solid(color), &stroke(width), Transform::identity(), None);
        }
    }
}

/// Сектор кольца для «солнечной» диаграммы
pub fn sector(pm: &mut PixmapMut, cx: f32, cy: f32, r_in: f32, r_out: f32, a0: f32, a1: f32, fill: Color, edge: Color) {
    let mut pb = PathBuilder::new();
    arc(&mut pb, cx, cy, r_out, a0, a1);
    let n = (((a1 - a0) * r_in / 2.5).ceil() as usize).clamp(2, 720);
    for i in (0..=n).rev() {
        let a = a0 + (a1 - a0) * i as f32 / n as f32;
        pb.line_to(cx + r_in * a.cos(), cy + r_in * a.sin());
    }
    pb.close();
    if let Some(p) = pb.finish() {
        pm.fill_path(&p, &solid(fill), FillRule::Winding, Transform::identity(), None);
        pm.stroke_path(&p, &solid(edge), &Stroke { width: 1.0, ..Default::default() }, Transform::identity(), None);
    }
}

#[derive(Clone, Copy, PartialEq)]
pub enum Btn {
    Primary,
    Plain,
    Danger,
}

/// Кнопка-таблетка; всё в физических пикселях
pub fn button(pm: &mut PixmapMut, font: &FontVec, x: f32, y: f32, w: f32, h: f32, label: &str, px: f32, kind: Btn, hover: bool) {
    let (bg, fg) = match kind {
        Btn::Primary => (accent(if hover { 0.85 } else { 1.0 }), on_accent(1.0)),
        Btn::Danger => (danger(if hover { 0.85 } else { 1.0 }), pure(1.0)),
        Btn::Plain => (white(if hover { 0.2 } else { 0.12 }), white(0.92)),
    };
    fill_rrect(pm, x, y, w, h, h / 2.0, bg);
    let t = fit(font, label, px, w - h * 0.6);
    let tw = measure(font, &t, px);
    text(pm, font, &t, x + (w - tw) / 2.0, y + h / 2.0 + px * 0.36, px, fg);
}

pub fn checkbox(pm: &mut PixmapMut, x: f32, y: f32, size: f32, on: bool) {
    if on {
        fill_rrect(pm, x, y, size, size, size * 0.28, accent(1.0));
        let mut pb = PathBuilder::new();
        pb.move_to(x + size * 0.24, y + size * 0.52);
        pb.line_to(x + size * 0.42, y + size * 0.70);
        pb.line_to(x + size * 0.77, y + size * 0.31);
        if let Some(p) = pb.finish() {
            pm.stroke_path(&p, &solid(on_accent(1.0)), &stroke(size * 0.12), Transform::identity(), None);
        }
    } else {
        stroke_rrect(pm, x + 1.0, y + 1.0, size - 2.0, size - 2.0, 0.0, 2.0, white(0.75));
    }
}

/// Место под отрисовку вида внутри окна (логические пиксели) и всё нужное для рисования
pub struct Area<'a> {
    pub s: f32,
    pub fonts: &'a Fonts,
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
}

// ---------- тема Windows: цвета, акцент и значки берутся из системы ----------

#[derive(Clone, Copy)]
pub struct Theme {
    pub dark: bool,
    pub accent: (u8, u8, u8),
}

const DEFAULT_THEME: Theme = Theme { dark: true, accent: (0x00, 0x78, 0xD7) };

thread_local! {
    /// тема, которой рисуем прямо сейчас
    static THEME: std::cell::Cell<Theme> = const { std::cell::Cell::new(DEFAULT_THEME) };
    /// (окна программ, панель задач и всплывающие окна) — у Windows они настраиваются отдельно
    static SCHEMES: std::cell::Cell<(Theme, Theme)> = const { std::cell::Cell::new((DEFAULT_THEME, DEFAULT_THEME)) };
    /// системный шрифт значков Windows 10
    static ICONS: Option<FontVec> = {
        let dir = std::env::var("WINDIR").unwrap_or_else(|_| "C:\\Windows".into());
        fluent_icons().or_else(|| std::fs::read(format!("{dir}\\Fonts\\segmdl2.ttf")).ok().and_then(|v| FontVec::try_from_vec(v).ok()))
    };
}

fn reg_dword(path: &str, name: &str) -> Option<u32> {
    use windows::Win32::System::Registry::{RegGetValueW, HKEY_CURRENT_USER, RRF_RT_REG_DWORD};
    let (p, n) = (wide_z(path), wide_z(name));
    let mut v = 0u32;
    let mut size = 4u32;
    let r = unsafe {
        RegGetValueW(
            HKEY_CURRENT_USER,
            windows::core::PCWSTR(p.as_ptr()),
            windows::core::PCWSTR(n.as_ptr()),
            RRF_RT_REG_DWORD,
            None,
            Some(&mut v as *mut u32 as *mut std::ffi::c_void),
            Some(&mut size),
        )
    };
    r.is_ok().then_some(v)
}

fn wide_z(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(Some(0)).collect()
}

/// Перечитать тему и акцент из настроек Windows (при запуске и когда их поменяли)
pub fn load_themes() {
    const KEY: &str = "Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize";
    // AccentColorMenu хранится как 0xAABBGGRR
    let accent = reg_dword("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Accent", "AccentColorMenu")
        .map_or((0x00, 0x78, 0xD7), |v| ((v & 0xFF) as u8, (v >> 8 & 0xFF) as u8, (v >> 16 & 0xFF) as u8));
    let apps = Theme { dark: reg_dword(KEY, "AppsUseLightTheme") == Some(0), accent };
    let system = Theme { dark: reg_dword(KEY, "SystemUsesLightTheme") != Some(1), accent };
    let (apps, system) = fluent_accents(apps, system);
    SCHEMES.with(|s| s.set((apps, system)));
}

/// Рисовать дальше в теме окон программ (apps) или панели задач и всплывающих окон
pub fn use_theme(apps: bool) {
    let (a, s) = SCHEMES.with(|s| s.get());
    THEME.with(|t| t.set(if apps { a } else { s }));
}

pub fn theme() -> Theme {
    THEME.with(|t| t.get())
}

pub fn accent(a: f32) -> Color {
    let (r, g, b) = theme().accent;
    rgb(r, g, b, a)
}

/// «Чернила» темы: белые в тёмной, чёрные в светлой — для текста, линий и подсветки
pub fn white(a: f32) -> Color {
    if theme().dark {
        rgb(0xFF, 0xFF, 0xFF, a)
    } else {
        rgb(0x00, 0x00, 0x00, a)
    }
}

/// Настоящий белый — текст и значки на акцентном цвете
pub fn pure(a: f32) -> Color {
    rgb(0xFF, 0xFF, 0xFF, a)
}

/// Фон окна
pub fn base() -> Color {
    if theme().dark {
        rgb(0x19, 0x19, 0x19, 1.0)
    } else {
        rgb(0xFF, 0xFF, 0xFF, 1.0)
    }
}

/// Подсветка под курсором и выделение — как в проводнике
pub fn hover() -> Color {
    if theme().dark {
        rgb(0x33, 0x33, 0x33, 1.0)
    } else {
        rgb(0xE5, 0xF3, 0xFF, 1.0)
    }
}

pub fn selected() -> Color {
    if theme().dark {
        rgb(0x4D, 0x4D, 0x4D, 1.0)
    } else {
        rgb(0xCC, 0xE8, 0xFF, 1.0)
    }
}

pub fn selected_border() -> Color {
    if theme().dark {
        rgb(0x80, 0x80, 0x80, 1.0)
    } else {
        rgb(0x99, 0xD1, 0xFF, 1.0)
    }
}

/// Полоска заполненности диска из «Этого компьютера»
pub fn usage_fill(full: bool) -> Color {
    if full {
        rgb(0xDA, 0x26, 0x26, 1.0)
    } else {
        rgb(0x26, 0xA0, 0xDA, 1.0)
    }
}

pub fn usage_track() -> Color {
    if theme().dark {
        rgb(0x3C, 0x3C, 0x3C, 1.0)
    } else {
        rgb(0xE6, 0xE6, 0xE6, 1.0)
    }
}

pub fn danger(a: f32) -> Color {
    rgb(0xE8, 0x11, 0x23, a)
}

/// Значок из шрифта Segoe MDL2 Assets, отцентрованный в точке (cx, cy); false — шрифта нет
pub fn glyph(pm: &mut PixmapMut, ch: char, cx: f32, cy: f32, px: f32, color: Color) -> bool {
    ICONS.with(|f| {
        let Some(font) = f else { return false };
        let scale = em_scale(font, px);
        let g = font.glyph_id(ch).with_scale_and_position(scale, point(0.0, 0.0));
        let Some(og) = font.outline_glyph(g) else { return false };
        let b = og.px_bounds();
        let dx = (cx - (b.min.x + b.max.x) / 2.0).round();
        let dy = (cy - (b.min.y + b.max.y) / 2.0).round();
        blit(pm, &og, dx, dy, color);
        true
    })
}

/// Смешивание покрытия глифа с картинкой (src-over)
fn blit(pm: &mut PixmapMut, og: &ab_glyph::OutlinedGlyph, dx: f32, dy: f32, color: Color) {
    let (pw, ph) = (pm.width() as i32, pm.height() as i32);
    let c = color.premultiply();
    let (cr, cg, cb, ca) = (c.red(), c.green(), c.blue(), c.alpha());
    let data = pm.data_mut();
    let b = og.px_bounds();
    og.draw(|gx, gy, a| {
        let xx = (b.min.x + dx) as i32 + gx as i32;
        let y = (b.min.y + dy) as i32 + gy as i32;
        if a <= 0.0 || xx < 0 || xx >= pw || y < 0 || y >= ph {
            return;
        }
        let a = a.min(1.0);
        let i = ((y * pw + xx) * 4) as usize;
        let sa = ca * a;
        let inv = 1.0 - sa;
        let blend = |dst: u8, src: f32| ((src * a * 255.0) + dst as f32 * inv).round().min(255.0) as u8;
        data[i] = blend(data[i], cr);
        data[i + 1] = blend(data[i + 1], cg);
        data[i + 2] = blend(data[i + 2], cb);
        data[i + 3] = ((sa * 255.0) + data[i + 3] as f32 * inv).round().min(255.0) as u8;
    });
}

// ---------- Windows 11: одна и та же программа сама подстраивается под систему ----------

/// Windows 11 (сборка 22000 и новее). MAC_STYLE=10 или 11 — принудительно, для проверки вёрстки
pub fn win11() -> bool {
    static V: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *V.get_or_init(|| match std::env::var("MAC_STYLE").ok().as_deref() {
        Some("11") => true,
        Some("10") => false,
        _ => windows_build() >= 22000,
    })
}

fn windows_build() -> u32 {
    use windows::Win32::System::Registry::{RegGetValueW, HKEY_LOCAL_MACHINE, RRF_RT_REG_SZ};
    let (p, n) = (wide_z("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion"), wide_z("CurrentBuildNumber"));
    let mut buf = [0u16; 32];
    let mut size = 64u32;
    let r = unsafe {
        RegGetValueW(
            HKEY_LOCAL_MACHINE,
            windows::core::PCWSTR(p.as_ptr()),
            windows::core::PCWSTR(n.as_ptr()),
            RRF_RT_REG_SZ,
            None,
            Some(buf.as_mut_ptr() as *mut std::ffi::c_void),
            Some(&mut size),
        )
    };
    if r.is_err() {
        return 0;
    }
    String::from_utf16_lossy(&buf).trim_matches('\0').parse().unwrap_or(0)
}

/// Масштаб экрана: радиусы задаются в пикселях, а скругление должно быть одинаковым на глаз
fn ui_scale() -> f32 {
    static V: std::sync::OnceLock<f32> = std::sync::OnceLock::new();
    *V.get_or_init(|| unsafe { windows::Win32::UI::HiDpi::GetDpiForSystem() }.max(96) as f32 / 96.0)
}

/// Windows 10 — почти прямые углы; Windows 11 — 8 у окон и панелей, 4 у кнопок и строк
fn corner(r: f32, w: f32, h: f32) -> f32 {
    if !win11() {
        return r.min(2.0);
    }
    let k = ui_scale();
    if r > 0.0 {
        r.min(8.0 * k)
    } else if w.min(h) <= 3.0 * k {
        0.0
    } else {
        4.0 * k
    }
}

/// Радиус всплывающей панели (в логических пикселях)
#[allow(dead_code)]
pub fn window_radius() -> f32 {
    if win11() {
        8.0
    } else {
        0.0
    }
}

/// Цвет текста и значков на акцентной заливке: в тёмной теме Windows 11 акцент светлый и текст на нём чёрный
#[allow(dead_code)]
pub fn on_accent(a: f32) -> Color {
    if win11() && theme().dark {
        rgb(0x00, 0x00, 0x00, a * 0.9)
    } else {
        rgb(0xFF, 0xFF, 0xFF, a)
    }
}

fn fonts_dir() -> String {
    std::env::var("MAC_FONT_DIR").unwrap_or_else(|_| std::env::var("WINDIR").unwrap_or_else(|_| "C:\\Windows".into()) + "\\Fonts")
}

/// Segoe UI Variable — шрифт Windows 11, насыщенность задаётся осью wght
fn variable_font(weight: f32) -> Option<FontVec> {
    use ab_glyph::VariableFont;
    if !win11() {
        return None;
    }
    let mut f = FontVec::try_from_vec(std::fs::read(format!("{}\\SegUIVar.ttf", fonts_dir())).ok()?).ok()?;
    f.set_variation(b"wght", weight);
    f.set_variation(b"opsz", 10.5);
    Some(f)
}

/// Segoe Fluent Icons — значки Windows 11, коды те же, что у MDL2
fn fluent_icons() -> Option<FontVec> {
    if !win11() {
        return None;
    }
    let d = fonts_dir();
    let data = std::fs::read(format!("{d}\\SegoeIcons.ttf")).or_else(|_| std::fs::read(format!("{d}\\Segoe Fluent Icons.ttf"))).ok()?;
    FontVec::try_from_vec(data).ok()
}

/// Акцент Windows 11: в тёмной теме светлый оттенок из системной палитры, в светлой — тёмный
fn fluent_accents(apps: Theme, system: Theme) -> (Theme, Theme) {
    use windows::Win32::System::Registry::{RegGetValueW, HKEY_CURRENT_USER, RRF_RT_REG_BINARY};
    if !win11() {
        return (apps, system);
    }
    let (p, n) = (wide_z("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Accent"), wide_z("AccentPalette"));
    let mut b = [0u8; 32];
    let mut size = 32u32;
    let ok = unsafe {
        RegGetValueW(
            HKEY_CURRENT_USER,
            windows::core::PCWSTR(p.as_ptr()),
            windows::core::PCWSTR(n.as_ptr()),
            RRF_RT_REG_BINARY,
            None,
            Some(b.as_mut_ptr() as *mut std::ffi::c_void),
            Some(&mut size),
        )
        .is_ok()
    } && size == 32;
    let pick = |dark: bool| {
        let i = if dark { 4 } else { 16 };
        match (ok, dark) {
            (true, _) => (b[i], b[i + 1], b[i + 2]),
            (false, true) => (0x4C, 0xC2, 0xFF),
            (false, false) => (0x00, 0x67, 0xC0),
        }
    };
    (Theme { accent: pick(apps.dark), ..apps }, Theme { accent: pick(system.dark), ..system })
}
