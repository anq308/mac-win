//! Окно Finder: боковая панель, панель инструментов, сетка или список, строка пути и предпросмотр по Пробелу

use std::cell::RefCell;
use std::collections::{HashMap, HashSet};
use std::ffi::c_void;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::mpsc::{channel, Receiver};
use std::sync::Arc;
use std::time::{Instant, SystemTime, UNIX_EPOCH};

use tiny_skia::PixmapMut;
use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Dwm::{
    DwmSetWindowAttribute, DWMWA_BORDER_COLOR, DWMWA_CAPTION_COLOR, DWMWA_TEXT_COLOR, DWMWA_USE_IMMERSIVE_DARK_MODE, DWMWINDOWATTRIBUTE,
};
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::Storage::FileSystem::{
    FindCloseChangeNotification, FindFirstChangeNotificationW, FindNextChangeNotification, FILE_NOTIFY_CHANGE_DIR_NAME, FILE_NOTIFY_CHANGE_FILE_NAME,
    FILE_NOTIFY_CHANGE_LAST_WRITE, FILE_NOTIFY_CHANGE_SIZE,
};
use windows::Win32::System::Diagnostics::Debug::MessageBeep;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::System::Threading::WaitForSingleObject;
use windows::Win32::UI::Controls::{EM_SETMARGINS, EM_SETSEL, WM_MOUSELEAVE};
use windows::Win32::UI::HiDpi::AdjustWindowRectExForDpi;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::analyze::{self, Disk, Out};
use crate::clean::{CHit, Clean};
use crate::fs::{self, Entry, Kinds, Loc, Place, Sort};
use crate::gfx::{self, Area, Btn, Fonts, Icon, Img};
use crate::search::{self, Batch};
use crate::settings::Settings;
use crate::shell::{self, Picked};
use crate::thumbs::{self, Pool};
use crate::win::{self, pcwstr, wide, Surface};

const SIDEBAR: f32 = 212.0;
const TOOLBAR: f32 = 52.0;
/// полоса вкладок под панелью инструментов — видна, когда вкладок больше одной
const TABBAR: f32 = 32.0;
const DEEP_LABEL: &str = "Во вложенных папках";
/// панель просмотра справа
const PANE: f32 = 300.0;
const PANE_PREVIEW: f32 = 190.0;
const GROUP_H: f32 = 36.0;
const STATUS: f32 = 30.0;
const PAD: f32 = 18.0;
const LIST_HEAD: f32 = 30.0;
const ROW: f32 = 28.0;
const ZOOM: (f32, f32) = (48.0, 176.0);
const LOOK_PX: u32 = 1024;
/// сколько готовых картинок держим в памяти, прежде чем выгружать невидимые
const KEEP: usize = 500;

const TIMER_SCROLL: usize = 1;
const TIMER_WATCH: usize = 2;
/// кадры анимации диаграммы в «Анализе места»
const TIMER_ANIM: usize = 3;
const WM_EDIT_DONE: u32 = WM_APP + 30;
const WM_DIRSIZE: u32 = WM_APP + 31;

#[derive(Clone, Copy, PartialEq)]
enum Mode {
    Grid,
    List,
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum Hit {
    None,
    Side(usize),
    Back,
    Fwd,
    Grid,
    List,
    Search,
    SearchClear,
    Item(usize),
    Empty,
    Head(Sort),
    Crumb(usize),
    Status,
    Bar,
    Look,
    LookClose,
    LookOpen,
    Tab(usize),
    TabClose(usize),
    TabNew,
    ScopeHere,
    ScopeDeep,
    /// «Анализ места» и «Очистка» в боковой панели
    Tool(u8),
    /// область инструмента в центре окна
    Area,
    Pane,
    PaneBtn(u8),
    PaneToggle,
    FilterBtn,
    GroupBtn,
}

struct Press {
    hit: Hit,
    x: i32,
    y: i32,
    collapse: bool,
}

enum Thumb {
    Pending,
    Ready(Img),
    Failed,
}

#[derive(Clone, PartialEq)]
enum EditKind {
    Search,
    Path,
    Rename(PathBuf),
}

struct Look {
    idx: usize,
    text: Option<Vec<String>>,
    scroll: f32,
}

struct Band {
    /// начало рамки в координатах содержимого (с учётом прокрутки)
    x0: f32,
    y0: f32,
    x1: f32,
    y1: f32,
    base: Vec<bool>,
}

/// Что показано в центре окна
enum View {
    Files,
    Disk(Box<Disk>),
    Clean(Box<Clean>),
}

/// Сведения о выделенном файле для панели справа
struct Info {
    path: PathBuf,
    created: u64,
    accessed: u64,
    count: Option<usize>,
    size: Option<u64>,
    text: Option<Vec<String>>,
}

/// Вкладка: своя папка, история и прокрутка
struct Tab {
    loc: Loc,
    back: Vec<Loc>,
    fwd: Vec<Loc>,
    scroll: f32,
}

struct Finder {
    view: View,
    pane: bool,
    /// 0 — без групп, 1 — тип, 2 — дата, 3 — размер, 4 — первая буква
    group: u8,
    /// 0 — все, иначе категория из fs::CATS + 1
    filter: u8,
    /// начало каждой группы в items и её заголовок
    groups: Vec<(usize, String)>,
    info: Option<Info>,
    size_gen: Arc<AtomicU64>,
    size_rx: Option<Receiver<(PathBuf, u64)>>,
    tabs: Vec<Tab>,
    cur: usize,
    /// поиск по вложенным папкам: найденное, идёт ли ещё, номер запроса для отмены
    deep: bool,
    found: Vec<Entry>,
    searching: bool,
    search_gen: Arc<AtomicU64>,
    search_rx: Option<Receiver<Batch>>,
    /// своё избранное; None — стандартные системные папки
    fav_paths: Option<Vec<PathBuf>>,
    /// русские имена системных папок — проводник тоже показывает их так, а не «Downloads»
    names: Vec<(PathBuf, String)>,
    hwnd: HWND,
    s: f32,
    cw: i32,
    ch: i32,
    fonts: Fonts,
    loc: Loc,
    back: Vec<Loc>,
    fwd: Vec<Loc>,
    all: Vec<Entry>,
    items: Vec<Entry>,
    error: Option<String>,
    mode: Mode,
    zoom: f32,
    sort: Sort,
    asc: bool,
    show_hidden: bool,
    scroll: f32,
    target: f32,
    hover: Hit,
    press: Option<Press>,
    anchor: Option<usize>,
    band: Option<Band>,
    bar_drag: Option<(i32, f32)>,
    query: String,
    thumbs: HashMap<(PathBuf, u32), Thumb>,
    lines: HashMap<PathBuf, (u32, Vec<String>)>,
    pool: Pool,
    look: Option<Look>,
    edit: Option<EditKind>,
    edit_hwnd: HWND,
    edit_font: (f32, HFONT),
    edit_brush: (u32, HBRUSH),
    watch: Option<HANDLE>,
    frame: Option<Surface>,
    favorites: Vec<Place>,
    spots: Vec<Place>,
    kinds: Kinds,
    drop_at: Option<(i32, i32)>,
    typed: (String, Instant),
}

thread_local! {
    static FINDER: RefCell<Option<Finder>> = const { RefCell::new(None) };
}

fn with<R>(f: impl FnOnce(&mut Finder) -> R) -> Option<R> {
    FINDER.with(|s| s.try_borrow_mut().ok()?.as_mut().map(f))
}

/// Фон окна тремя байтами — для полей ввода Windows
fn base_rgb() -> (u8, u8, u8) {
    if gfx::theme().dark {
        (0x19, 0x19, 0x19)
    } else {
        (0xFF, 0xFF, 0xFF)
    }
}

fn side_px(f: &Finder) -> u32 {
    (16.0 * f.s).round() as u32
}

/// Путь для значка места: у «Компьютера» — его системный идентификатор
fn place_path(loc: &Loc) -> PathBuf {
    match loc {
        Loc::Dir(p) => p.clone(),
        Loc::Computer => PathBuf::from("::{20D04FE0-3AEA-1069-A2D8-08002B30309D}"),
    }
}

fn inside(r: &[f32; 4], x: f32, y: f32) -> bool {
    x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]
}

fn colorref(c: (u8, u8, u8)) -> COLORREF {
    COLORREF(c.0 as u32 | (c.1 as u32) << 8 | (c.2 as u32) << 16)
}

// ---------- геометрия (всё в логических пикселях) ----------

impl Finder {
    fn wl(&self) -> f32 {
        self.cw as f32 / self.s
    }
    fn hl(&self) -> f32 {
        self.ch as f32 / self.s
    }
    /// верх области файлов: панель инструментов и, если вкладок несколько, их полоса
    fn top(&self) -> f32 {
        TOOLBAR + if self.tabs.len() > 1 { TABBAR } else { 0.0 }
    }
    fn files(&self) -> bool {
        matches!(self.view, View::Files)
    }
    fn pane_w(&self) -> f32 {
        if self.pane && self.files() {
            PANE
        } else {
            0.0
        }
    }
    /// ширина и высота области файлов
    fn content(&self) -> (f32, f32) {
        ((self.wl() - SIDEBAR - self.pane_w()).max(1.0), (self.hl() - self.top() - STATUS).max(1.0))
    }
    fn dir(&self) -> Option<&Path> {
        match &self.loc {
            Loc::Dir(p) => Some(p),
            Loc::Computer => None,
        }
    }
}

struct Grid {
    cols: usize,
    tw: f32,
    th: f32,
    /// прямоугольники всех элементов в координатах содержимого
    rects: Vec<[f32; 4]>,
    /// заголовки групп: y и номер группы
    heads: Vec<(f32, usize)>,
    total: f32,
}

fn title_of(f: &Finder, loc: &Loc) -> String {
    match loc {
        Loc::Dir(p) => f.names.iter().find(|(k, _)| k == p).map_or_else(|| loc.title(), |(_, n)| n.clone()),
        Loc::Computer => loc.title(),
    }
}

/// Имя на экране: у системных папок — русское
fn shown_name<'a>(f: &'a Finder, e: &'a Entry) -> &'a str {
    if e.dir {
        if let Some((_, n)) = f.names.iter().find(|(k, _)| *k == e.path) {
            return n;
        }
    }
    &e.name
}

fn grid(f: &Finder) -> Grid {
    // у дисков под иконкой ещё строка про свободное место — плитки шире
    let tw = if f.loc == Loc::Computer { (f.zoom + 44.0).max(180.0) } else { f.zoom + 44.0 };
    let th = f.zoom + 8.0 + 40.0;
    let w = f.content().0;
    let avail = w - PAD * 2.0;
    let cols = (((avail + 8.0) / (tw + 8.0)).floor() as usize).max(1);
    let cell = avail / cols as f32;
    let n = f.items.len();
    let grouped = !f.groups.is_empty();
    let starts: Vec<usize> = if grouped { f.groups.iter().map(|g| g.0).collect() } else { vec![0] };
    let mut rects = Vec::with_capacity(n);
    let mut heads = Vec::new();
    let mut y = match f.mode {
        Mode::Grid => 12.0,
        Mode::List => LIST_HEAD + 4.0,
    };
    for (gi, &start) in starts.iter().enumerate() {
        let end = starts.get(gi + 1).copied().unwrap_or(n);
        let k = end.saturating_sub(start);
        if grouped {
            heads.push((y, gi));
            y += GROUP_H;
        }
        match f.mode {
            Mode::Grid => {
                for j in 0..k {
                    let (col, row) = ((j % cols) as f32, (j / cols) as f32);
                    rects.push([PAD + col * cell + (cell - tw) / 2.0, y + row * (th + 10.0), tw, th]);
                }
                y += k.div_ceil(cols) as f32 * (th + 10.0) + if grouped { 6.0 } else { 0.0 };
            }
            Mode::List => {
                for j in 0..k {
                    rects.push([PAD - 8.0, y + j as f32 * ROW, w - PAD * 2.0 + 16.0, ROW]);
                }
                y += k as f32 * ROW + if grouped { 10.0 } else { 0.0 };
            }
        }
    }
    let total = y + if f.mode == Mode::Grid { PAD } else { 12.0 };
    Grid { cols, tw, th, rects, heads, total }
}

/// Прямоугольник элемента в координатах содержимого (y без вычета прокрутки)
fn item_rect(_f: &Finder, g: &Grid, i: usize) -> [f32; 4] {
    g.rects.get(i).copied().unwrap_or_default()
}

fn total_h(_f: &Finder, g: &Grid) -> f32 {
    g.total
}

fn max_scroll(f: &Finder) -> f32 {
    (total_h(f, &grid(f)) - f.content().1).max(0.0)
}

fn clamp_scroll(f: &mut Finder) {
    let m = max_scroll(f);
    f.target = f.target.clamp(0.0, m);
    f.scroll = f.scroll.clamp(0.0, m);
}

/// Видимые элементы (с запасом сверху и снизу); прямоугольники идут сверху вниз — ищем двоичным поиском
fn visible(f: &Finder, g: &Grid, margin: f32) -> std::ops::Range<usize> {
    let (_, h) = f.content();
    let (lo, hi) = (f.scroll - margin, f.scroll + h + margin);
    let a = g.rects.partition_point(|r| r[1] + r[3] < lo);
    let b = g.rects.partition_point(|r| r[1] <= hi);
    a..b.max(a)
}

fn group_len(f: &Finder, gi: usize) -> usize {
    let start = f.groups[gi].0;
    f.groups.get(gi + 1).map_or(f.items.len(), |g| g.0) - start
}

struct Cols {
    date: Option<f32>,
    size: f32,
    kind: Option<f32>,
    right: f32,
}

fn list_cols(f: &Finder) -> Cols {
    let w = f.content().0;
    let right = w - PAD;
    let kind = (w > 760.0).then_some(right - 160.0);
    let size_r = kind.unwrap_or(right) - 18.0;
    let size = size_r - 76.0;
    let date = (w > 520.0).then_some(size - 178.0);
    Cols { date, size, kind, right }
}

const BTN_BACK: [f32; 4] = [SIDEBAR + 12.0, 11.0, 30.0, 30.0];
const BTN_FWD: [f32; 4] = [SIDEBAR + 44.0, 11.0, 30.0, 30.0];

fn search_rect(f: &Finder) -> [f32; 4] {
    let w = 220.0f32.min((f.wl() - SIDEBAR - 560.0).max(140.0));
    [f.wl() - 16.0 - w, 11.0, w, 30.0]
}

fn pane_btn(f: &Finder) -> [f32; 4] {
    let s = search_rect(f);
    [s[0] - 10.0 - 34.0, 11.0, 34.0, 30.0]
}

fn view_rects(f: &Finder) -> ([f32; 4], [f32; 4]) {
    let x = pane_btn(f)[0] - 8.0 - 72.0;
    ([x, 11.0, 36.0, 30.0], [x + 36.0, 11.0, 36.0, 30.0])
}

fn filter_btn(f: &Finder) -> [f32; 4] {
    [view_rects(f).0[0] - 8.0 - 34.0, 11.0, 34.0, 30.0]
}

fn group_btn(f: &Finder) -> [f32; 4] {
    [filter_btn(f)[0] - 4.0 - 34.0, 11.0, 34.0, 30.0]
}

enum SideRow {
    Title(&'static str),
    Place(usize),
    Tool(u8),
}

fn side_rows(f: &Finder) -> Vec<(SideRow, f32, f32)> {
    let mut out = Vec::new();
    let mut y = 14.0;
    out.push((SideRow::Title("Избранное"), y, 26.0));
    y += 26.0;
    for i in 0..f.favorites.len() {
        out.push((SideRow::Place(i), y, 30.0));
        y += 30.0;
    }
    y += 12.0;
    out.push((SideRow::Title("Места"), y, 26.0));
    y += 26.0;
    for (k, p) in f.spots.iter().enumerate() {
        let h = if p.space.is_some() { 42.0 } else { 30.0 };
        out.push((SideRow::Place(f.favorites.len() + k), y, h));
        y += h;
    }
    y += 12.0;
    out.push((SideRow::Title("Инструменты"), y, 26.0));
    y += 26.0;
    for k in 0..2 {
        out.push((SideRow::Tool(k), y, 30.0));
        y += 30.0;
    }
    out
}

fn place(f: &Finder, i: usize) -> Option<&Place> {
    if i < f.favorites.len() {
        f.favorites.get(i)
    } else {
        f.spots.get(i - f.favorites.len())
    }
}

/// Сегменты строки пути: подпись и куда ведёт
fn crumbs(f: &Finder) -> Vec<(String, Loc)> {
    let mut out = vec![("Компьютер".to_string(), Loc::Computer)];
    if let Loc::Dir(p) = &f.loc {
        let mut parts: Vec<&Path> = p.ancestors().collect();
        parts.reverse();
        for a in parts {
            out.push((fs::display_name(a), Loc::Dir(a.to_path_buf())));
        }
    }
    out
}

/// Где нарисован каждый сегмент пути; первые прячутся за «…», если не влезают
fn crumb_rects(f: &Finder) -> Vec<(usize, [f32; 4])> {
    let c = crumbs(f);
    let px = 12.0 * f.s;
    let widths: Vec<f32> = c.iter().map(|(t, _)| 18.0 + gfx::measure(&f.fonts.regular, t, px) / f.s + 8.0).collect();
    let sep = 16.0;
    let avail = f.wl() - SIDEBAR - 24.0 - 260.0;
    let mut first = 0;
    while first + 1 < c.len() && widths[first..].iter().sum::<f32>() + sep * (c.len() - first) as f32 > avail {
        first += 1;
    }
    let mut x = SIDEBAR + 12.0 + if first > 0 { 24.0 } else { 0.0 };
    let y = f.hl() - STATUS + 4.0;
    let mut out = Vec::new();
    for (i, w) in widths.iter().enumerate().skip(first) {
        out.push((i, [x, y, *w, STATUS - 8.0]));
        x += w + sep;
    }
    out
}

fn scrollbar(f: &Finder) -> Option<[f32; 4]> {
    let (w, vh) = f.content();
    let total = total_h(f, &grid(f));
    if total <= vh {
        return None;
    }
    let top = f.top() + 4.0 + if f.mode == Mode::List { LIST_HEAD } else { 0.0 };
    let track = vh - 8.0 - if f.mode == Mode::List { LIST_HEAD } else { 0.0 };
    let len = (vh / total * track).max(36.0);
    let pos = top + (track - len) * (f.scroll / (total - vh)).clamp(0.0, 1.0);
    Some([SIDEBAR + w - 11.0, pos, 8.0, len])
}

fn tab_rects(f: &Finder) -> Vec<[f32; 4]> {
    let n = f.tabs.len().max(1);
    let (x0, x1) = (SIDEBAR + 8.0, f.wl() - 8.0 - 36.0);
    let w = (x1 - x0) / n as f32;
    (0..n).map(|i| [x0 + i as f32 * w + 2.0, TOOLBAR + 1.0, w - 4.0, TABBAR - 6.0]).collect()
}

fn tab_plus(f: &Finder) -> [f32; 4] {
    [f.wl() - 8.0 - 30.0, TOOLBAR + 1.0, 30.0, TABBAR - 6.0]
}

/// Во время поиска строка пути внизу превращается в выбор: «эта папка» или «во вложенных»
fn scope_ui(f: &Finder) -> bool {
    !f.query.is_empty() && f.dir().is_some()
}

fn scope_here(f: &Finder) -> String {
    format!("«{}»", title_of(f, &f.loc))
}

fn scope_rects(f: &Finder) -> ([f32; 4], [f32; 4]) {
    let px = 12.0 * f.s;
    let w1 = gfx::measure(&f.fonts.regular, &scope_here(f), px) / f.s + 22.0;
    let w2 = gfx::measure(&f.fonts.regular, DEEP_LABEL, px) / f.s + 22.0;
    let (x, y, h) = (SIDEBAR + 64.0, f.hl() - STATUS + 5.0, STATUS - 10.0);
    ([x, y, w1, h], [x + w1 + 6.0, y, w2, h])
}

fn look_rect(f: &Finder) -> [f32; 4] {
    let (w, h) = ((f.wl() * 0.8).min(960.0), (f.hl() * 0.86).min(760.0));
    [(f.wl() - w) / 2.0, (f.hl() - h) / 2.0, w, h]
}

fn hit(f: &Finder, x: i32, y: i32) -> Hit {
    let (x, y) = (x as f32 / f.s, y as f32 / f.s);
    if f.look.is_some() {
        let r = look_rect(f);
        if inside(&[r[0] + 10.0, r[1] + 8.0, 30.0, 30.0], x, y) {
            return Hit::LookClose;
        }
        let ow = 96.0;
        if inside(&[r[0] + r[2] - ow - 12.0, r[1] + 8.0, ow, 30.0], x, y) {
            return Hit::LookOpen;
        }
        return Hit::Look;
    }
    if x < SIDEBAR {
        for (row, ry, rh) in side_rows(f) {
            let on = inside(&[8.0, ry, SIDEBAR - 16.0, rh], x, y);
            match row {
                SideRow::Place(i) if on => return Hit::Side(i),
                SideRow::Tool(k) if on => return Hit::Tool(k),
                _ => {}
            }
        }
        return Hit::None;
    }
    if y < TOOLBAR {
        if inside(&BTN_BACK, x, y) {
            return Hit::Back;
        }
        if inside(&BTN_FWD, x, y) {
            return Hit::Fwd;
        }
        if !f.files() {
            return Hit::None;
        }
        for (r, h) in [(pane_btn(f), Hit::PaneToggle), (filter_btn(f), Hit::FilterBtn), (group_btn(f), Hit::GroupBtn)] {
            if inside(&r, x, y) {
                return h;
            }
        }
        let (g, l) = view_rects(f);
        if inside(&g, x, y) {
            return Hit::Grid;
        }
        if inside(&l, x, y) {
            return Hit::List;
        }
        let s = search_rect(f);
        if !f.query.is_empty() && inside(&[s[0] + s[2] - 28.0, s[1], 28.0, s[3]], x, y) {
            return Hit::SearchClear;
        }
        if inside(&s, x, y) {
            return Hit::Search;
        }
        return Hit::None;
    }
    if y < f.top() {
        for (i, r) in tab_rects(f).into_iter().enumerate() {
            if inside(&r, x, y) {
                if inside(&[r[0] + 4.0, r[1] + 4.0, 20.0, r[3] - 8.0], x, y) {
                    return Hit::TabClose(i);
                }
                return Hit::Tab(i);
            }
        }
        if inside(&tab_plus(f), x, y) {
            return Hit::TabNew;
        }
        return Hit::None;
    }
    if y >= f.hl() - STATUS {
        if !f.files() {
            return Hit::Status;
        }
        if scope_ui(f) {
            let (a, b) = scope_rects(f);
            if inside(&a, x, y) {
                return Hit::ScopeHere;
            }
            if inside(&b, x, y) {
                return Hit::ScopeDeep;
            }
            return Hit::Status;
        }
        for (i, r) in crumb_rects(f) {
            if inside(&r, x, y) {
                return Hit::Crumb(i);
            }
        }
        return Hit::Status;
    }
    if !f.files() {
        return Hit::Area;
    }
    if f.pane && x >= f.wl() - PANE {
        for (h, r, _) in pane_buttons(f) {
            if inside(&r, x, y) {
                return h;
            }
        }
        return Hit::Pane;
    }
    if let Some(b) = scrollbar(f) {
        if x >= b[0] - 4.0 {
            return Hit::Bar;
        }
    }
    let (cx, cy) = (x - SIDEBAR, y - f.top());
    if f.mode == Mode::List && cy < LIST_HEAD {
        let c = list_cols(f);
        let col = if c.kind.is_some_and(|k| cx >= k) {
            Sort::Kind
        } else if cx >= c.size - 10.0 && cx < c.kind.unwrap_or(c.right) {
            Sort::Size
        } else if c.date.is_some_and(|d| cx >= d) {
            Sort::Date
        } else {
            Sort::Name
        };
        return Hit::Head(col);
    }
    let cy = cy + f.scroll;
    let g = grid(f);
    for i in visible(f, &g, 0.0) {
        let r = item_rect(f, &g, i);
        if inside(&r, cx, cy) {
            return Hit::Item(i);
        }
    }
    Hit::Empty
}

/// Куда положить файлы, брошенные в точку окна (клиентские пиксели)
pub fn drop_target_at(x: i32, y: i32) -> Option<PathBuf> {
    with(|f| match hit(f, x, y) {
        Hit::Item(i) if f.items[i].dir => Some(f.items[i].path.clone()),
        Hit::Side(i) => match &place(f, i)?.loc {
            Loc::Dir(p) => Some(p.clone()),
            Loc::Computer => None,
        },
        _ => f.dir().map(Path::to_path_buf),
    })
    .flatten()
}

// ---------- содержимое папки ----------

fn load(f: &mut Finder) {
    let keep: HashSet<PathBuf> = f.items.iter().filter(|e| e.sel).map(|e| e.path.clone()).collect();
    f.error = None;
    f.all = match &f.loc {
        Loc::Computer => fs::drive_entries(),
        Loc::Dir(p) => match fs::list(p, &mut f.kinds) {
            Some(v) => v,
            None => {
                f.error =
                    Some(if p.exists() { "Нет доступа к этой папке".into() } else { "Папка не найдена".into() });
                Vec::new()
            }
        },
    };
    apply(f, &keep);
    watch(f);
}

/// Фильтр (скрытые, поиск) и сортировка; keep — пути, которые остаются выделенными
fn apply(f: &mut Finder, keep: &HashSet<PathBuf>) {
    let q = f.query.to_lowercase();
    let deep = deep_active(f);
    let src = if deep { &f.found } else { &f.all };
    f.items = src
        .iter()
        .filter(|e| f.show_hidden || !e.hidden)
        .filter(|e| deep || q.is_empty() || e.name.to_lowercase().contains(&q))
        .filter(|e| f.filter == 0 || fs::category(e) + 1 == f.filter)
        .cloned()
        .map(|mut e| {
            e.sel = keep.contains(&e.path);
            e
        })
        .collect();
    if f.loc != Loc::Computer {
        fs::sort(&mut f.items, f.sort, f.asc);
    }
    // группы: устойчивая сортировка по группе сохраняет порядок внутри неё
    f.groups.clear();
    if f.group != 0 && f.loc != Loc::Computer && !f.items.is_empty() {
        let mid = fs::midnight();
        let keys: Vec<(u32, String)> = f.items.iter().map(|e| fs::group_key(e, f.group, mid)).collect();
        let mut order: Vec<usize> = (0..f.items.len()).collect();
        order.sort_by_key(|&i| keys[i].0);
        f.items = order.iter().map(|&i| f.items[i].clone()).collect();
        let mut last = None;
        for (k, &i) in order.iter().enumerate() {
            if last != Some(keys[i].0) {
                f.groups.push((k, keys[i].1.clone()));
                last = Some(keys[i].0);
            }
        }
    }
    f.anchor = f.items.iter().position(|e| e.sel);
    clamp_scroll(f);
}

fn deep_active(f: &Finder) -> bool {
    f.deep && !f.query.is_empty() && f.dir().is_some()
}

/// Новый запрос или другая папка: старый поиск бросаем, при необходимости запускаем новый
fn restart_search(f: &mut Finder) {
    f.search_gen.fetch_add(1, Ordering::Relaxed);
    f.found.clear();
    f.search_rx = None;
    f.searching = false;
    if deep_active(f) {
        if let Some(d) = f.dir().map(Path::to_path_buf) {
            f.search_rx = Some(search::start(f.hwnd, d, f.query.clone(), f.show_hidden, f.search_gen.clone()));
            f.searching = true;
        }
    }
}

fn take_found(f: &mut Finder) {
    let Some(rx) = &f.search_rx else { return };
    let got: Vec<Batch> = rx.try_iter().collect();
    for b in got {
        match b {
            Batch::Found(v) => f.found.extend(v),
            Batch::Done => f.searching = false,
        }
    }
    reapply(f);
}

fn selection(f: &Finder) -> HashSet<PathBuf> {
    f.items.iter().filter(|e| e.sel).map(|e| e.path.clone()).collect()
}

fn reapply(f: &mut Finder) {
    let keep = selection(f);
    apply(f, &keep);
}

fn watch(f: &mut Finder) {
    unsafe {
        if let Some(h) = f.watch.take() {
            let _ = FindCloseChangeNotification(h);
        }
        if let Some(d) = f.dir() {
            let w = wide(&d.to_string_lossy());
            let flags = FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME | FILE_NOTIFY_CHANGE_SIZE | FILE_NOTIFY_CHANGE_LAST_WRITE;
            f.watch = FindFirstChangeNotificationW(pcwstr(&w), false, flags).ok().filter(|h| !h.is_invalid());
        }
    }
}

fn go(f: &mut Finder, loc: Loc, push: bool) {
    if loc == f.loc {
        return;
    }
    if push {
        f.back.push(f.loc.clone());
        f.fwd.clear();
    }
    enter(f, loc, true);
}

/// Перейти без записи в историю; select_prev — выделить папку, из которой пришли
fn enter(f: &mut Finder, loc: Loc, select_prev: bool) {
    let prev = f.loc.clone();
    f.loc = loc;
    f.query.clear();
    restart_search(f);
    f.look = None;
    f.pool.reset();
    f.thumbs.clear();
    f.lines.clear();
    f.items.clear();
    f.scroll = 0.0;
    f.target = 0.0;
    load(f);
    // поднялись на уровень выше — выделяем папку, из которой пришли
    if let (Loc::Dir(p), true) = (&prev, select_prev) {
        if let Some(i) = f.items.iter().position(|e| p.starts_with(&e.path)) {
            select_only(f, i);
            reveal(f, i);
        }
    }
    update_title(f);
}

fn view_title(f: &Finder) -> String {
    match &f.view {
        View::Files => title_of(f, &f.loc),
        View::Disk(_) => "Анализ места".into(),
        View::Clean(_) => "Очистка".into(),
    }
}

fn update_title(f: &Finder) {
    let t = wide(&view_title(f));
    unsafe {
        let _ = SetWindowTextW(f.hwnd, pcwstr(&t));
    }
}

fn save_tab(f: &mut Finder) {
    let t = Tab { loc: f.loc.clone(), back: f.back.clone(), fwd: f.fwd.clone(), scroll: f.scroll };
    if let Some(slot) = f.tabs.get_mut(f.cur) {
        *slot = t;
    }
}

fn restore_tab(f: &mut Finder) {
    let Some(t) = f.tabs.get(f.cur) else { return };
    let (loc, back, fwd, sc) = (t.loc.clone(), t.back.clone(), t.fwd.clone(), t.scroll);
    f.back = back;
    f.fwd = fwd;
    enter(f, loc, false);
    f.scroll = sc;
    f.target = sc;
    clamp_scroll(f);
}

fn switch_tab(f: &mut Finder, i: usize) {
    if i == f.cur || i >= f.tabs.len() {
        return;
    }
    save_tab(f);
    f.cur = i;
    restore_tab(f);
}

/// Новая вкладка рядом с текущей; focus — сразу перейти в неё
fn new_tab(f: &mut Finder, loc: Loc, focus: bool) {
    save_tab(f);
    let at = f.cur + 1;
    f.tabs.insert(at, Tab { loc, back: Vec::new(), fwd: Vec::new(), scroll: 0.0 });
    if focus {
        f.cur = at;
        restore_tab(f);
    }
    clamp_scroll(f);
}

/// Закрыть вкладку; true — это была последняя, закрываем окно
fn close_tab(f: &mut Finder, i: usize) -> bool {
    if f.tabs.len() <= 1 {
        return true;
    }
    save_tab(f);
    f.tabs.remove(i);
    if i < f.cur {
        f.cur -= 1;
    } else if i == f.cur {
        f.cur = f.cur.min(f.tabs.len() - 1);
        restore_tab(f);
    }
    clamp_scroll(f);
    false
}

fn go_back(f: &mut Finder) {
    if let Some(l) = f.back.pop() {
        f.fwd.push(f.loc.clone());
        go(f, l, false);
    }
}

fn go_fwd(f: &mut Finder) {
    if let Some(l) = f.fwd.pop() {
        f.back.push(f.loc.clone());
        go(f, l, false);
    }
}

fn go_up(f: &mut Finder) {
    let up = match &f.loc {
        Loc::Dir(p) => Some(p.parent().map_or(Loc::Computer, |p| Loc::Dir(p.to_path_buf()))),
        Loc::Computer => None,
    };
    if let Some(l) = up {
        go(f, l, true);
    }
}

// ---------- выделение ----------

fn select_only(f: &mut Finder, i: usize) {
    for (k, e) in f.items.iter_mut().enumerate() {
        e.sel = k == i;
    }
    f.anchor = Some(i);
}

fn clear_sel(f: &mut Finder) {
    for e in &mut f.items {
        e.sel = false;
    }
    f.anchor = None;
}

fn selected(f: &Finder) -> Vec<PathBuf> {
    f.items.iter().filter(|e| e.sel).map(|e| e.path.clone()).collect()
}

fn reveal(f: &mut Finder, i: usize) {
    let g = grid(f);
    let r = item_rect(f, &g, i);
    let (_, vh) = f.content();
    let top = if f.mode == Mode::List { LIST_HEAD } else { 0.0 };
    if r[1] - top - 6.0 < f.target {
        f.target = r[1] - top - 6.0;
    } else if r[1] + r[3] + 8.0 > f.target + vh {
        f.target = r[1] + r[3] + 8.0 - vh;
    }
    clamp_scroll(f);
    animate(f);
}

fn animate(f: &Finder) {
    unsafe {
        SetTimer(Some(f.hwnd), TIMER_SCROLL, 15, None);
    }
}

fn redraw(f: &Finder) {
    unsafe {
        let _ = InvalidateRect(Some(f.hwnd), None, false);
    }
}

fn move_sel(f: &mut Finder, d: i32, extend: bool) {
    let n = f.items.len() as i32;
    if n == 0 {
        return;
    }
    let cur = f.items.iter().rposition(|e| e.sel).map(|i| i as i32);
    let i = match cur {
        Some(c) => (c + d).clamp(0, n - 1),
        None => 0,
    } as usize;
    if extend {
        let a = f.anchor.unwrap_or(i);
        for (k, e) in f.items.iter_mut().enumerate() {
            e.sel = (a.min(i)..=a.max(i)).contains(&k);
        }
    } else {
        select_only(f, i);
    }
    reveal(f, i);
    if let Some(l) = &mut f.look {
        l.idx = i;
        l.text = None;
        l.scroll = 0.0;
        prepare_look(f);
    }
}

// ---------- картинки ----------

fn icon_px(f: &Finder) -> u32 {
    match f.mode {
        Mode::Grid => (f.zoom * f.s).round() as u32,
        Mode::List => (18.0 * f.s).round().max(16.0) as u32,
    }
}

fn take_thumbs(f: &mut Finder) {
    let got: Vec<_> = f.pool.done.try_iter().collect();
    for d in got {
        let t = match d.img {
            Some(i) => Thumb::Ready(i),
            None => Thumb::Failed,
        };
        f.thumbs.insert((d.path, d.px), t);
    }
}

fn prepare_look(f: &mut Finder) {
    let Some(l) = &mut f.look else { return };
    let Some(e) = f.items.get(l.idx) else { return };
    if e.dir {
        return;
    }
    if l.text.is_none() {
        l.text = fs::text_preview(&e.path);
    }
    if l.text.is_none() {
        let key = (e.path.clone(), LOOK_PX);
        if !f.thumbs.contains_key(&key) {
            f.thumbs.insert(key.clone(), Thumb::Pending);
            f.pool.request(key.0, key.1);
        }
    }
}

/// Перед кадром: заказать недостающие картинки и перенос имён для видимых плиток
fn prepare(f: &mut Finder) {
    take_thumbs(f);
    let g = grid(f);
    let px = icon_px(f);
    let range = visible(f, &g, f.content().1);
    let wkey = (g.tw * f.s) as u32;
    for i in range.clone() {
        let e = &f.items[i];
        {
            let key = (e.path.clone(), px);
            if !f.thumbs.contains_key(&key) {
                f.thumbs.insert(key.clone(), Thumb::Pending);
                f.pool.request(key.0, key.1);
            }
        }
        if f.mode == Mode::Grid && f.lines.get(&e.path).is_none_or(|l| l.0 != wkey) {
            let lines = tile_lines(f, e, &g);
            f.lines.insert(e.path.clone(), (wkey, lines));
        }
    }
    let spx = side_px(f);
    let places: Vec<PathBuf> = f.favorites.iter().chain(f.spots.iter()).map(|p| place_path(&p.loc)).collect();
    for p in places {
        let key = (p, spx);
        if !f.thumbs.contains_key(&key) {
            f.thumbs.insert(key.clone(), Thumb::Pending);
            f.pool.request(key.0, key.1);
        }
    }
    prepare_pane(f);
    prepare_look(f);
    let ready = f.thumbs.values().filter(|t| matches!(t, Thumb::Ready(_))).count();
    if ready > KEEP {
        let near: HashSet<PathBuf> = f.items[range].iter().map(|e| e.path.clone()).collect();
        let look = f.look.as_ref().and_then(|l| f.items.get(l.idx)).map(|e| e.path.clone());
        let spx = side_px(f);
        f.thumbs.retain(|(p, k), t| !matches!(t, Thumb::Ready(_)) || near.contains(p) || Some(p) == look.as_ref() || *k == spx);
    }
}

/// Подпись под плиткой: имя диска в одну строку, остальное — в две
fn tile_lines(f: &Finder, e: &Entry, g: &Grid) -> Vec<String> {
    if e.space.is_some() || f.loc == Loc::Computer {
        vec![gfx::fit(&f.fonts.regular, &e.name, 12.5 * f.s, g.tw * f.s)]
    } else {
        gfx::wrap2(&f.fonts.regular, shown_name(f, e), 12.5 * f.s, g.tw * f.s)
    }
}

fn thumb<'a>(f: &'a Finder, p: &Path, px: u32) -> Option<&'a Img> {
    match f.thumbs.get(&(p.to_path_buf(), px)) {
        Some(Thumb::Ready(i)) if i.w > 1 => Some(i),
        _ => None,
    }
}

fn fit_in(w: u32, h: u32, bw: f32, bh: f32) -> (f32, f32) {
    let k = (bw / w as f32).min(bh / h as f32);
    ((w as f32 * k).round().max(1.0), (h as f32 * k).round().max(1.0))
}

// ---------- отрисовка ----------

/// Иконка файла в квадрате (x, y, size) — всё в физических пикселях
fn draw_icon(f: &Finder, pm: &mut PixmapMut, e: &Entry, x: f32, y: f32, size: f32, px: u32, op: f32) {
    match thumb(f, &e.path, px) {
        Some(img) => {
            let (w, h) = fit_in(img.w, img.h, size, size);
            let (ix, iy) = ((x + (size - w) / 2.0).round(), (y + (size - h) / 2.0).round());
            gfx::image(pm, img, ix, iy, w, h, 0.0, op);
            if img.is_photo() {
                gfx::stroke_rrect(pm, ix + 0.5, iy + 0.5, w - 1.0, h - 1.0, 0.0, 1.0, gfx::white(0.12));
            }
        }
        None => {
            // пока Windows не отдала значок — бледный контур
            let ic = if e.dir { Icon::Folder } else { Icon::Document };
            let k = size * 0.7;
            gfx::icon(pm, ic, x + (size - k) / 2.0, y + (size - k) / 2.0, k, gfx::white(0.18 * op));
        }
    }
}

fn drop_index(f: &Finder) -> Option<usize> {
    let (x, y) = f.drop_at?;
    match hit(f, x, y) {
        Hit::Item(i) if f.items[i].dir => Some(i),
        _ => None,
    }
}

fn compose(f: &Finder, pm: &mut PixmapMut) {
    let s = f.s;
    let (wl, hl) = (f.wl(), f.hl());
    let p = |v: f32| v * s;
    pm.fill(gfx::base());
    let files = f.files();
    if !files {
        let a = Area { s, fonts: &f.fonts, x: SIDEBAR, y: f.top(), w: wl - SIDEBAR, h: hl - f.top() - STATUS };
        match &f.view {
            View::Disk(d) => d.compose(pm, &a),
            View::Clean(c) => c.compose(pm, &a),
            View::Files => {}
        }
    }

    // ----- файлы -----
    let (cw, chh) = f.content();
    let g = grid(f);
    let dropi = drop_index(f);
    let ox = SIDEBAR;
    let oy = f.top() - f.scroll;
    if !files {
    } else if let Some(err) = &f.error {
        center_note(f, pm, err, "Проверьте путь или права доступа");
    } else if f.items.is_empty() {
        if f.query.is_empty() {
            center_note(f, pm, "Папка пуста", "");
        } else if f.searching {
            center_note(f, pm, "Ищем…", &format!("«{}» во всех вложенных папках", f.query));
        } else {
            center_note(f, pm, "Ничего не найдено", &format!("По запросу «{}» в этой папке", f.query));
        }
    }
    let px = icon_px(f);
    let cols = list_cols(f);
    for i in if files { visible(f, &g, 0.0) } else { 0..0 } {
        let e = &f.items[i];
        let r = item_rect(f, &g, i);
        let (x, y) = (ox + r[0], oy + r[1]);
        let hover = f.hover == Hit::Item(i);
        let op = if e.hidden { 0.5 } else { 1.0 };
        match f.mode {
            Mode::Grid => {
                let isz = f.zoom;
                let (ix, iy) = (x + (g.tw - isz) / 2.0, y + 4.0);
                let hl_bg = if dropi == Some(i) {
                    Some(gfx::accent(0.35))
                } else if e.sel {
                    Some(gfx::selected())
                } else if hover {
                    Some(gfx::hover())
                } else {
                    None
                };
                if let Some(c) = hl_bg {
                    gfx::fill_rrect(pm, p(x), p(y), p(g.tw), p(g.th), 0.0, c);
                    if e.sel {
                        gfx::stroke_rrect(pm, p(x) + 0.5, p(y) + 0.5, p(g.tw) - 1.0, p(g.th) - 1.0, 0.0, 1.0, gfx::selected_border());
                    }
                }
                draw_icon(f, pm, e, p(ix), p(iy), p(isz), px, op);
                let base = iy + isz + 19.0;
                if let Some(sp) = e.space {
                    // полоска занятого места под диском
                    let used = 1.0 - sp.free as f32 / sp.total.max(1) as f32;
                    let (bx, by, bw) = (ix + isz * 0.1, iy + isz * 0.92, isz * 0.8);
                    gfx::fill_rrect(pm, p(bx), p(by), p(bw), p(5.0), 0.0, gfx::usage_track());
                    gfx::fill_rrect(pm, p(bx), p(by), p(bw * used).max(p(2.0)), p(5.0), 0.0, gfx::usage_fill(used > 0.9));
                }
                let lines = f.lines.get(&e.path).map(|l| l.1.clone()).unwrap_or_else(|| vec![e.name.clone()]);
                let tpx = 12.5 * s;
                for (k, line) in lines.iter().enumerate() {
                    let tw = gfx::measure(&f.fonts.regular, line, tpx);
                    let lx = p(x + g.tw / 2.0) - tw / 2.0;
                    let ly = p(base + k as f32 * 16.0);
                    let col = gfx::white(0.9 * op);
                    gfx::text(pm, &f.fonts.regular, line, lx, ly, tpx, col);
                }
                if let Some(sp) = e.space {
                    let t = format!("свободно {} из {}", fs::size_text(sp.free), fs::size_text(sp.total));
                    let t = gfx::fit(&f.fonts.regular, &t, 11.5 * s, p(g.tw));
                    let tw = gfx::measure(&f.fonts.regular, &t, 11.5 * s);
                    gfx::text(pm, &f.fonts.regular, &t, p(x + g.tw / 2.0) - tw / 2.0, p(base + 16.0), 11.5 * s, gfx::white(0.45));
                }
            }
            Mode::List => {
                let rowc = if dropi == Some(i) {
                    Some(gfx::accent(0.4))
                } else if e.sel {
                    Some(gfx::selected())
                } else if hover {
                    Some(gfx::hover())
                } else {
                    None
                };
                if let Some(c) = rowc {
                    gfx::fill_rrect(pm, p(x), p(y), p(r[2]), p(ROW), p(6.0), c);
                }
                let isz = 18.0;
                draw_icon(f, pm, e, p(ox + PAD), p(y + (ROW - isz) / 2.0), p(isz), px, op);
                let base = p(y + ROW / 2.0 + 4.6);
                let main = if e.sel { gfx::white(1.0) } else { gfx::white(0.9 * op) };
                let dim = if e.sel { gfx::white(0.85) } else { gfx::white(0.5 * op) };
                let name_r = cols.date.unwrap_or(cols.size) - 12.0;
                let name = gfx::fit(&f.fonts.regular, shown_name(f, e), 13.0 * s, p(name_r - PAD - 26.0));
                gfx::text(pm, &f.fonts.regular, &name, p(ox + PAD + 26.0), base, 13.0 * s, main);
                let small = 12.5 * s;
                if let Some(d) = cols.date {
                    let t = if e.modified == 0 { "—".to_string() } else { fs::date_text(e.modified) };
                    gfx::text(pm, &f.fonts.regular, &t, p(ox + d), base, small, dim);
                }
                let size = match e.space {
                    Some(sp) => format!("{} своб.", fs::size_text(sp.free)),
                    None if e.dir => "—".into(),
                    None => fs::size_text(e.size),
                };
                let sw = gfx::measure(&f.fonts.regular, &size, small);
                gfx::text(pm, &f.fonts.regular, &size, p(ox + cols.size + 76.0) - sw, base, small, dim);
                if let Some(k) = cols.kind {
                    let t = gfx::fit(&f.fonts.regular, e.place.as_deref().unwrap_or(&e.kind), small, p(cols.right - k));
                    gfx::text(pm, &f.fonts.regular, &t, p(ox + k), base, small, dim);
                }
            }
        }
    }
    if files {
        for (hy, gi) in &g.heads {
            let y = oy + hy;
            if y > hl || y + GROUP_H < f.top() {
                continue;
            }
            let title = &f.groups[*gi].1;
            gfx::text(pm, &f.fonts.semibold, title, p(ox + PAD), p(y + 23.0), 13.5 * s, gfx::white(0.88));
            let tw = gfx::measure(&f.fonts.semibold, title, 13.5 * s);
            let n = group_len(f, *gi).to_string();
            gfx::text(pm, &f.fonts.regular, &n, p(ox + PAD) + tw + p(8.0), p(y + 23.0), 12.5 * s, gfx::white(0.38));
            gfx::fill_rrect(pm, p(ox + PAD), p(y + GROUP_H - 5.0), p(cw - PAD * 2.0), 1.0, 0.0, gfx::white(0.07));
        }
    }
    if files && f.mode == Mode::List {
        // шапка таблицы закреплена над строками
        gfx::fill_rrect(pm, p(ox), p(f.top()), p(cw), p(LIST_HEAD), 0.0, gfx::base());
        let hy = p(f.top() + LIST_HEAD / 2.0 + 4.2);
        let mut head = |label: &str, x: f32, col: Sort, right: Option<f32>| {
            let active = f.sort == col;
            let hov = f.hover == Hit::Head(col);
            let c = gfx::white(if active || hov { 0.8 } else { 0.45 });
            let px = 11.5 * s;
            let tw = gfx::measure(&f.fonts.semibold, label, px);
            let tx = match right {
                Some(r) => p(ox + r) - tw,
                None => p(ox + x),
            };
            gfx::text(pm, &f.fonts.semibold, label, tx, hy, px, c);
            if active {
                let ic = if f.asc { Icon::ChevronUp } else { Icon::ChevronDown };
                let ax = if right.is_some() { tx - p(16.0) } else { tx + tw + p(2.0) };
                gfx::icon(pm, ic, ax, hy - p(11.0), p(14.0), gfx::white(0.6));
            }
        };
        head("Имя", PAD + 26.0, Sort::Name, None);
        if let Some(d) = cols.date {
            head("Дата изменения", d, Sort::Date, None);
        }
        head("Размер", 0.0, Sort::Size, Some(cols.size + 76.0));
        if let Some(k) = cols.kind {
            head(if deep_active(f) { "Папка" } else { "Тип" }, k, Sort::Kind, None);
        }
        gfx::fill_rrect(pm, p(ox + PAD - 8.0), p(f.top() + LIST_HEAD) - 1.0, p(cw - PAD * 2.0 + 16.0), 1.0, 0.0, gfx::white(0.07));
    }
    if let Some(b) = &f.band {
        let (x0, x1) = (b.x0.min(b.x1), b.x0.max(b.x1));
        let (y0, y1) = (b.y0.min(b.y1), b.y0.max(b.y1));
        let (rx, ry) = (p(ox + x0), p(oy + y0));
        gfx::fill_rrect(pm, rx, ry, p(x1 - x0), p(y1 - y0), p(2.0), gfx::accent(0.16));
        gfx::stroke_rrect(pm, rx + 0.5, ry + 0.5, p(x1 - x0) - 1.0, p(y1 - y0) - 1.0, p(2.0), 1.0, gfx::accent(0.8));
    }
    if let Some(bar) = scrollbar(f).filter(|_| files) {
        let active = f.hover == Hit::Bar || f.bar_drag.is_some();
        let bw = if active { 8.0 } else { 5.0 };
        gfx::fill_rrect(pm, p(bar[0] + bar[2] - bw), p(bar[1]), p(bw), p(bar[3]), p(bw / 2.0), gfx::white(if active { 0.34 } else { 0.16 }));
    }
    if files && f.drop_at.is_some() && dropi.is_none() && f.dir().is_some() {
        // файлы упадут в текущую папку — обводим всю область
        gfx::stroke_rrect(pm, p(ox + 4.0), p(f.top() + 4.0), p(cw - 8.0), p(chh - 8.0), p(10.0), p(2.0), gfx::accent(0.8));
    }

    if files && f.pane {
        compose_pane(f, pm);
    }

    // ----- панель инструментов -----
    gfx::fill_rrect(pm, p(ox), 0.0, p(wl - ox), p(f.top()), 0.0, gfx::base());
    if f.scroll > 1.0 || f.mode == Mode::List || f.tabs.len() > 1 || !files || f.pane {
        gfx::fill_rrect(pm, p(ox), p(f.top()) - 1.0, p(wl - ox), 1.0, 0.0, gfx::white(0.07));
    }
    if f.tabs.len() > 1 {
        compose_tabs(f, pm);
    }
    let tool = |pm: &mut PixmapMut, r: &[f32; 4], h: Hit, icon: Icon, enabled: bool| {
        if enabled && f.hover == h {
            let pressed = f.press.as_ref().is_some_and(|pr| pr.hit == h);
            gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), p(8.0), gfx::white(if pressed { 0.14 } else { 0.08 }));
        }
        let isz = 20.0;
        let c = gfx::white(if enabled { 0.85 } else { 0.22 });
        gfx::icon(pm, icon, p(r[0] + (r[2] - isz) / 2.0), p(r[1] + (r[3] - isz) / 2.0), p(isz), c);
    };
    tool(pm, &BTN_BACK, Hit::Back, Icon::Back, !f.back.is_empty() || !files);
    tool(pm, &BTN_FWD, Hit::Fwd, Icon::Forward, !f.fwd.is_empty());
    let (vg, vl) = view_rects(f);
    let title_end = if files { group_btn(f)[0] - 16.0 } else { wl - 20.0 };
    if files {
        // группировка, фильтр и панель справа: включённые подсвечены акцентом
        let toggles = [
            (group_btn(f), Hit::GroupBtn, Icon::Stack, f.group != 0),
            (filter_btn(f), Hit::FilterBtn, Icon::Filter, f.filter != 0),
            (pane_btn(f), Hit::PaneToggle, Icon::Panel, f.pane),
        ];
        for (r, h, ic, on) in toggles {
            let c = if on {
                Some(gfx::selected())
            } else if f.hover == h {
                Some(gfx::hover())
            } else {
                None
            };
            if let Some(c) = c {
                gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), 0.0, c);
            }
            if on {
                gfx::stroke_rrect(pm, p(r[0]) + 0.5, p(r[1]) + 0.5, p(r[2]) - 1.0, p(r[3]) - 1.0, 0.0, 1.0, gfx::selected_border());
            }
            gfx::icon(pm, ic, p(r[0] + (r[2] - 18.0) / 2.0), p(r[1] + 6.0), p(18.0), gfx::white(0.85));
        }
        gfx::fill_rrect(pm, p(vg[0]), p(vg[1]), p(72.0), p(30.0), p(8.0), gfx::white(0.06));
        let act = if f.mode == Mode::Grid { vg } else { vl };
        gfx::fill_rrect(pm, p(act[0]), p(act[1]), p(act[2]), p(act[3]), 0.0, gfx::selected());
        for (r, h, ic) in [(vg, Hit::Grid, Icon::Grid), (vl, Hit::List, Icon::List)] {
            let on = (h == Hit::Grid) == (f.mode == Mode::Grid);
            let c = gfx::white(if on || f.hover == h { 0.9 } else { 0.5 });
            gfx::icon(pm, ic, p(r[0] + 9.0), p(r[1] + 6.0), p(18.0), c);
        }
        let sr = search_rect(f);
        let focus = f.edit == Some(EditKind::Search);
        // поле поиска как в проводнике: светлое, с рамкой, при вводе рамка акцентная
        gfx::fill_rrect(pm, p(sr[0]), p(sr[1]), p(sr[2]), p(sr[3]), 0.0, gfx::base());
        let border = if focus { gfx::accent(1.0) } else { gfx::white(0.22) };
        gfx::stroke_rrect(pm, p(sr[0]) + 0.5, p(sr[1]) + 0.5, p(sr[2]) - 1.0, p(sr[3]) - 1.0, 0.0, if focus { p(2.0) } else { 1.0 }, border);
        gfx::icon(pm, Icon::Search, p(sr[0] + 10.0), p(sr[1] + 7.0), p(16.0), gfx::white(0.5));
        if !focus {
            let (t, c) = if f.query.is_empty() { ("Поиск".to_string(), gfx::white(0.35)) } else { (f.query.clone(), gfx::white(0.9)) };
            let t = gfx::fit(&f.fonts.regular, &t, 13.0 * s, p(sr[2] - 66.0));
            gfx::text(pm, &f.fonts.regular, &t, p(sr[0] + 32.0), p(sr[1] + 19.5), 13.0 * s, c);
        }
        if !f.query.is_empty() {
            let c = gfx::white(if f.hover == Hit::SearchClear { 0.9 } else { 0.5 });
            gfx::icon(pm, Icon::Close, p(sr[0] + sr[2] - 24.0), p(sr[1] + 7.0), p(16.0), c);
        }
    }
    let title_x = SIDEBAR + 86.0;
    let title = gfx::fit(&f.fonts.semibold, &view_title(f), 15.0 * s, p(title_end - title_x));
    gfx::text(pm, &f.fonts.semibold, &title, p(title_x), p(31.5), 15.0 * s, gfx::white(0.95));

    // ----- строка пути и счётчик -----
    let sy = hl - STATUS;
    gfx::fill_rrect(pm, p(ox), p(sy), p(wl - ox), p(STATUS), 0.0, gfx::base());
    gfx::fill_rrect(pm, p(ox), p(sy), p(wl - ox), 1.0, 0.0, gfx::white(0.06));
    let cr = if !files {
        compose_tool_status(f, pm);
        Vec::new()
    } else if scope_ui(f) {
        compose_scope(f, pm);
        Vec::new()
    } else {
        crumb_rects(f)
    };
    let list = crumbs(f);
    if cr.first().is_some_and(|(i, _)| *i > 0) {
        gfx::text(pm, &f.fonts.regular, "…", p(SIDEBAR + 14.0), p(sy + 19.5), 12.0 * s, gfx::white(0.4));
    }
    for (k, (i, r)) in cr.iter().enumerate() {
        if f.hover == Hit::Crumb(*i) {
            gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), 0.0, gfx::hover());
        }
        let ic = match &list[*i].1 {
            Loc::Computer => Icon::Desktop,
            Loc::Dir(p) if p.parent().is_none() => Icon::Drive,
            _ => Icon::Folder,
        };
        let last = k + 1 == cr.len();
        let c = gfx::white(if last { 0.85 } else { 0.55 });
        gfx::icon(pm, ic, p(r[0] + 4.0), p(r[1] + 4.0), p(14.0), c);
        gfx::text(pm, &f.fonts.regular, &list[*i].0, p(r[0] + 22.0), p(sy + 19.5), 12.0 * s, c);
        if !last {
            gfx::icon(pm, Icon::ChevronRight, p(r[0] + r[2] + 1.0), p(sy + 8.0), p(14.0), gfx::white(0.3));
        }
    }
    let n = f.items.len();
    let k = f.items.iter().filter(|e| e.sel).count();
    let mut info =
        if k > 0 { format!("выбрано {} из {}", k, n) } else { fs::plural(n, ["объект", "объекта", "объектов"]) };
    let bytes: u64 = f.items.iter().filter(|e| e.sel && !e.dir).map(|e| e.size).sum();
    if bytes > 0 {
        info += &format!(" · {}", fs::size_text(bytes));
    }
    if f.searching {
        info = format!("поиск…  {info}");
    }
    if let Some(sp) = f.dir().and_then(|d| d.ancestors().last()).and_then(fs::space) {
        info += &format!(", свободно {}", fs::size_text(sp.free));
    }
    if files {
        let iw = gfx::measure(&f.fonts.regular, &info, 12.0 * s);
        gfx::text(pm, &f.fonts.regular, &info, p(wl - 14.0) - iw, p(sy + 19.5), 12.0 * s, gfx::white(0.45));
    }

    // ----- боковая панель -----
    gfx::fill_rrect(pm, 0.0, 0.0, p(SIDEBAR), p(hl), 0.0, gfx::base());
    gfx::fill_rrect(pm, p(SIDEBAR) - 1.0, 0.0, 1.0, p(hl), 0.0, gfx::white(0.06));
    for (row, ry, rh) in side_rows(f) {
        match row {
            SideRow::Title(t) => {
                gfx::text(pm, &f.fonts.semibold, t, p(20.0), p(ry + 18.0), 11.5 * s, gfx::white(0.38));
            }
            SideRow::Place(i) => {
                let Some(pl) = place(f, i) else { continue };
                let cur = pl.loc == f.loc;
                let drop_here = f.drop_at.is_some() && f.hover == Hit::Side(i);
                let c = if drop_here {
                    Some(gfx::accent(0.4))
                } else if cur {
                    Some(gfx::selected())
                } else if f.hover == Hit::Side(i) {
                    Some(gfx::hover())
                } else {
                    None
                };
                if let Some(c) = c {
                    gfx::fill_rrect(pm, p(8.0), p(ry), p(SIDEBAR - 16.0), p(rh), p(8.0), c);
                }
                let ty = ry + 15.0;
                // значок места — тот же, что в проводнике
                match thumb(f, &place_path(&pl.loc), side_px(f)) {
                    Some(img) => gfx::image(pm, img, p(19.0), p(ty - 8.0), p(16.0), p(16.0), 0.0, 1.0),
                    None => gfx::icon(pm, pl.icon, p(18.0), p(ty - 9.0), p(18.0), gfx::white(0.6)),
                }
                let name = gfx::fit(&f.fonts.regular, &pl.name, 13.0 * s, p(SIDEBAR - 64.0));
                gfx::text(pm, &f.fonts.regular, &name, p(44.0), p(ty + 4.6), 13.0 * s, gfx::white(if cur { 0.98 } else { 0.85 }));
                if let Some(sp) = pl.space {
                    let used = 1.0 - sp.free as f32 / sp.total.max(1) as f32;
                    let (bx, by, bw) = (44.0, ry + 30.0, SIDEBAR - 44.0 - 22.0);
                    gfx::fill_rrect(pm, p(bx), p(by), p(bw), p(4.0), 0.0, gfx::usage_track());
                    gfx::fill_rrect(pm, p(bx), p(by), p(bw * used).max(p(2.0)), p(4.0), 0.0, gfx::usage_fill(used > 0.9));
                }
            }
            SideRow::Tool(k) => {
                let cur = matches!((&f.view, k), (View::Disk(_), 0) | (View::Clean(_), 1));
                let c = if cur {
                    Some(gfx::selected())
                } else if f.hover == Hit::Tool(k) {
                    Some(gfx::hover())
                } else {
                    None
                };
                if let Some(c) = c {
                    gfx::fill_rrect(pm, p(8.0), p(ry), p(SIDEBAR - 16.0), p(rh), p(8.0), c);
                }
                let ty = ry + 15.0;
                let (ic, name) = if k == 0 { (Icon::Pie, "Анализ места") } else { (Icon::Sparkle, "Очистка") };
                gfx::icon(pm, ic, p(18.0), p(ty - 9.0), p(18.0), gfx::accent(1.0));
                gfx::text(pm, &f.fonts.regular, name, p(44.0), p(ty + 4.6), 13.0 * s, gfx::white(if cur { 0.98 } else { 0.85 }));
            }
        }
    }

    if f.look.is_some() {
        compose_look(f, pm);
    }
}

fn compose_tabs(f: &Finder, pm: &mut PixmapMut) {
    let s = f.s;
    let p = |v: f32| v * s;
    let rects = tab_rects(f);
    for (i, r) in rects.iter().enumerate() {
        let active = i == f.cur;
        let hov = matches!(f.hover, Hit::Tab(k) | Hit::TabClose(k) if k == i);
        if active {
            gfx::stroke_rrect(pm, p(r[0]) + 0.5, p(r[1]) + 0.5, p(r[2]) - 1.0, p(r[3]) - 1.0, 0.0, 1.0, gfx::white(0.15));
            gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(2.0), 0.0, gfx::accent(1.0));
        } else if hov {
            gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), 0.0, gfx::hover());
        } else if i + 1 < rects.len() && i + 1 != f.cur {
            gfx::fill_rrect(pm, p(r[0] + r[2] + 1.5), p(r[1] + 7.0), 1.0, p(r[3] - 14.0), 0.0, gfx::white(0.08));
        }
        let title = if active { title_of(f, &f.loc) } else { title_of(f, &f.tabs[i].loc) };
        let font = if active { &f.fonts.semibold } else { &f.fonts.regular };
        let px = 12.5 * s;
        let t = gfx::fit(font, &title, px, p(r[2] - 56.0));
        let tw = gfx::measure(font, &t, px);
        gfx::text(pm, font, &t, p(r[0] + r[2] / 2.0) - tw / 2.0, p(r[1] + r[3] / 2.0 + 4.4), px, gfx::white(if active { 0.95 } else { 0.6 }));
        if hov || active {
            let (cx, cy) = (r[0] + 6.0, r[1] + (r[3] - 16.0) / 2.0);
            if f.hover == Hit::TabClose(i) {
                gfx::fill_rrect(pm, p(cx - 1.0), p(cy - 1.0), p(18.0), p(18.0), p(5.0), gfx::white(0.12));
            }
            gfx::icon(pm, Icon::Close, p(cx), p(cy), p(16.0), gfx::white(0.6));
        }
    }
    let r = tab_plus(f);
    if f.hover == Hit::TabNew {
        gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), p(7.0), gfx::white(0.08));
    }
    gfx::icon(pm, Icon::Plus, p(r[0] + 7.0), p(r[1] + (r[3] - 16.0) / 2.0), p(16.0), gfx::white(0.65));
}

fn compose_scope(f: &Finder, pm: &mut PixmapMut) {
    let s = f.s;
    let p = |v: f32| v * s;
    let sy = f.hl() - STATUS;
    gfx::text(pm, &f.fonts.regular, "Искать:", p(SIDEBAR + 14.0), p(sy + 19.5), 12.0 * s, gfx::white(0.45));
    let (a, b) = scope_rects(f);
    let here = scope_here(f);
    for (r, label, on, h) in [(a, here.as_str(), !f.deep, Hit::ScopeHere), (b, DEEP_LABEL, f.deep, Hit::ScopeDeep)] {
        let c = if on {
            gfx::accent(1.0)
        } else if f.hover == h {
            gfx::white(0.12)
        } else {
            gfx::white(0.07)
        };
        gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), p(r[3] / 2.0), c);
        let tw = gfx::measure(&f.fonts.regular, label, 12.0 * s);
        let col = if on { gfx::on_accent(1.0) } else { gfx::white(0.75) };
        gfx::text(pm, &f.fonts.regular, label, p(r[0] + r[2] / 2.0) - tw / 2.0, p(sy + 19.5), 12.0 * s, col);
    }
}

fn compose_tool_status(f: &Finder, pm: &mut PixmapMut) {
    let s = f.s;
    let t = match &f.view {
        View::Disk(d) => d.status(),
        View::Clean(_) => "Двойной клик по файлу — показать в папке · правый клик — меню Windows · Esc — назад".into(),
        View::Files => String::new(),
    };
    let t = gfx::fit(&f.fonts.regular, &t, 12.0 * s, (f.wl() - SIDEBAR - 28.0) * s);
    gfx::text(pm, &f.fonts.regular, &t, (SIDEBAR + 14.0) * s, (f.hl() - STATUS + 19.5) * s, 12.0 * s, gfx::white(0.45));
}

fn pane_px(f: &Finder) -> u32 {
    (256.0 * f.s).round() as u32
}

/// Кнопки внизу панели справа — зависят от того, сколько выделено
fn pane_buttons(f: &Finder) -> Vec<(Hit, [f32; 4], &'static str)> {
    let x0 = f.wl() - PANE + 20.0;
    let full = PANE - 40.0;
    let half = (full - 10.0) / 2.0;
    let y = f.hl() - STATUS - 18.0 - 32.0;
    match f.items.iter().filter(|e| e.sel).count() {
        0 => vec![(Hit::PaneBtn(2), [x0, y, half, 32.0], "Анализ места"), (Hit::PaneBtn(3), [x0 + half + 10.0, y, half, 32.0], "Очистка")],
        1 => vec![(Hit::PaneBtn(0), [x0, y, half, 32.0], "Открыть"), (Hit::PaneBtn(1), [x0 + half + 10.0, y, half, 32.0], "Копировать путь")],
        _ => vec![(Hit::PaneBtn(1), [x0, y, full, 32.0], "Копировать пути")],
    }
}

/// Перенос длинной строки (пути) по символам, не больше max_lines строк
fn wrap_chars(font: &ab_glyph::FontVec, text: &str, px: f32, max: f32, max_lines: usize) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    for c in text.chars() {
        cur.push(c);
        if gfx::measure(font, &cur, px) > max {
            cur.pop();
            out.push(std::mem::take(&mut cur));
            cur.push(c);
            if out.len() == max_lines {
                break;
            }
        }
    }
    if out.len() < max_lines && !cur.is_empty() {
        out.push(cur);
    } else if out.len() == max_lines {
        let last = out.pop().unwrap_or_default() + &cur;
        out.push(gfx::fit_middle(font, &last, px, max));
    }
    out
}

/// Панель справа: превью, сведения о файле, путь; без выделения — занятость диска
fn compose_pane(f: &Finder, pm: &mut PixmapMut) {
    let s = f.s;
    let p = |v: f32| v * s;
    let x0 = f.wl() - PANE;
    let (top, bot) = (f.top(), f.hl() - STATUS);
    gfx::fill_rrect(pm, p(x0), p(top), p(PANE), p(bot - top), 0.0, gfx::base());
    gfx::fill_rrect(pm, p(x0), p(top), 1.0, p(bot - top), 0.0, gfx::white(0.06));
    let (bx, bw) = (x0 + 20.0, PANE - 40.0);
    let mid = x0 + PANE / 2.0;
    let center = |pm: &mut PixmapMut, font: &ab_glyph::FontVec, t: &str, px: f32, y: f32, c: tiny_skia::Color| {
        let t = gfx::fit(font, t, px, p(bw));
        let tw = gfx::measure(font, &t, px);
        gfx::text(pm, font, &t, p(mid) - tw / 2.0, p(y), px, c);
    };
    let sel: Vec<&Entry> = f.items.iter().filter(|e| e.sel).collect();
    let mut y = top + 20.0;
    match sel.as_slice() {
        [] => {
            // занятость диска, на котором текущая папка
            let root = f.dir().and_then(|d| d.ancestors().last()).map(Path::to_path_buf).unwrap_or_else(|| PathBuf::from("C:\\"));
            if let Some(sp) = fs::space(&root) {
                let used = 1.0 - sp.free as f32 / sp.total.max(1) as f32;
                let cy = y + 88.0;
                gfx::donut(pm, p(mid), p(cy), p(68.0), p(15.0), used, gfx::usage_fill(used > 0.9), gfx::usage_track());
                center(pm, &f.fonts.semibold, &format!("{}%", (used * 100.0).round()), 24.0 * s, cy + 6.0, gfx::white(0.95));
                center(pm, &f.fonts.regular, "занято", 11.5 * s, cy + 24.0, gfx::white(0.45));
                y = cy + 68.0 + 36.0;
                center(pm, &f.fonts.semibold, &format!("Диск {}", fs::display_name(&root)), 15.0 * s, y, gfx::white(0.92));
                y += 22.0;
                let t = format!("Свободно {} из {}", fs::size_text(sp.free), fs::size_text(sp.total));
                center(pm, &f.fonts.regular, &t, 12.5 * s, y, gfx::white(0.55));
                y += 34.0;
            }
            gfx::fill_rrect(pm, p(bx), p(y), p(bw), 1.0, 0.0, gfx::white(0.07));
            y += 26.0;
            center(pm, &f.fonts.semibold, &title_of(f, &f.loc), 14.0 * s, y, gfx::white(0.9));
            y += 20.0;
            let dirs = f.items.iter().filter(|e| e.dir).count();
            let bytes: u64 = f.items.iter().map(|e| e.size).sum();
            let t = format!("{} · папок {} · файлы {}", fs::plural(f.items.len(), ["объект", "объекта", "объектов"]), dirs, fs::size_text(bytes));
            center(pm, &f.fonts.regular, &t, 12.0 * s, y, gfx::white(0.5));
        }
        [e] => {
            let info = f.info.as_ref().filter(|i| i.path == e.path);
            let ph = PANE_PREVIEW;
            let photo = if e.dir { None } else { thumb(f, &e.path, pane_px(f)).filter(|i| i.is_photo()) };
            if let Some(lines) = info.and_then(|i| i.text.as_ref()) {
                gfx::fill_rrect(pm, p(bx), p(y), p(bw), p(ph), 0.0, gfx::white(0.04));
                for (k, l) in lines.iter().take(((ph - 14.0) / 15.0) as usize).enumerate() {
                    let t = gfx::fit(&f.fonts.mono, l, 10.5 * s, p(bw - 18.0));
                    gfx::text(pm, &f.fonts.mono, &t, p(bx + 9.0), p(y + 19.0 + k as f32 * 15.0), 10.5 * s, gfx::white(0.75));
                }
            } else if let Some(img) = photo {
                let (w, h) = fit_in(img.w, img.h, p(bw), p(ph));
                let (ix, iy) = ((p(bx) + (p(bw) - w) / 2.0).round(), (p(y) + (p(ph) - h) / 2.0).round());
                gfx::shadow(pm, ix, iy + p(3.0), w, h, p(12.0), 0.45);
                gfx::image(pm, img, ix, iy, w, h, p(6.0), 1.0);
            } else {
                let isz = 128.0;
                draw_icon(f, pm, e, p(mid - isz / 2.0), p(y + (ph - isz) / 2.0), p(isz), pane_px(f), 1.0);
            }
            y += ph + 26.0;
            for line in gfx::wrap2(&f.fonts.semibold, shown_name(f, e), 14.5 * s, p(bw)) {
                center(pm, &f.fonts.semibold, &line, 14.5 * s, y, gfx::white(0.95));
                y += 19.0;
            }
            center(pm, &f.fonts.regular, &e.kind, 12.0 * s, y + 1.0, gfx::white(0.5));
            y += 20.0;
            gfx::fill_rrect(pm, p(bx), p(y), p(bw), 1.0, 0.0, gfx::white(0.07));
            y += 24.0;
            gfx::text(pm, &f.fonts.semibold, "Информация", p(bx), p(y), 12.0 * s, gfx::white(0.45));
            y += 24.0;
            let mut rows: Vec<(&str, String)> = Vec::new();
            match (e.space, e.dir) {
                (Some(sp), _) => {
                    rows.push(("Занято", fs::size_text(sp.total - sp.free)));
                    rows.push(("Свободно", fs::size_text(sp.free)));
                    rows.push(("Всего", fs::size_text(sp.total)));
                }
                (None, true) => {
                    rows.push(("Размер", info.and_then(|i| i.size).map_or("считаем…".into(), fs::size_text)));
                    if let Some(n) = info.and_then(|i| i.count) {
                        rows.push(("Внутри", fs::plural(n, ["объект", "объекта", "объектов"])));
                    }
                }
                (None, false) => rows.push(("Размер", fs::size_text(e.size))),
            }
            if let Some(i) = info {
                if i.created > 0 {
                    rows.push(("Создан", fs::date_text(i.created)));
                }
            }
            if e.modified > 0 {
                rows.push(("Изменён", fs::date_text(e.modified)));
            }
            if let Some(i) = info.filter(|i| i.accessed > 0) {
                rows.push(("Открыт", fs::date_text(i.accessed)));
            }
            for (label, value) in rows {
                gfx::text(pm, &f.fonts.regular, label, p(bx), p(y), 12.5 * s, gfx::white(0.45));
                let v = gfx::fit(&f.fonts.regular, &value, 12.5 * s, p(bw - 80.0));
                let vw = gfx::measure(&f.fonts.regular, &v, 12.5 * s);
                gfx::text(pm, &f.fonts.regular, &v, p(bx + bw) - vw, p(y), 12.5 * s, gfx::white(0.88));
                y += 22.0;
            }
            y += 6.0;
            gfx::text(pm, &f.fonts.regular, "Путь", p(bx), p(y), 12.5 * s, gfx::white(0.45));
            y += 19.0;
            let room = ((bot - 18.0 - 32.0 - 14.0 - y) / 16.0).floor().max(1.0) as usize;
            for line in wrap_chars(&f.fonts.regular, &e.path.to_string_lossy(), 11.5 * s, p(bw), room.min(4)) {
                gfx::text(pm, &f.fonts.regular, &line, p(bx), p(y), 11.5 * s, gfx::white(0.62));
                y += 16.0;
            }
        }
        many => {
            // стопка из первых трёх значков
            let isz = 96.0;
            for (k, e) in many.iter().take(3).enumerate().rev() {
                let off = k as f32 * 14.0 - 14.0;
                draw_icon(f, pm, e, p(mid - isz / 2.0 + off), p(y + 30.0 + off * 0.6), p(isz), icon_px(f), 1.0 - k as f32 * 0.2);
            }
            y += PANE_PREVIEW + 26.0;
            center(
                pm,
                &f.fonts.semibold,
                &format!("Выбрано {}", fs::plural(many.len(), ["объект", "объекта", "объектов"])),
                15.0 * s,
                y,
                gfx::white(0.95),
            );
            y += 22.0;
            let dirs = many.iter().filter(|e| e.dir).count();
            let bytes: u64 = many.iter().filter(|e| !e.dir).map(|e| e.size).sum();
            let t = if dirs > 0 {
                format!("файлы {} · папок {}", fs::size_text(bytes), dirs)
            } else {
                format!("всего {}", fs::size_text(bytes))
            };
            center(pm, &f.fonts.regular, &t, 12.5 * s, y, gfx::white(0.55));
        }
    }
    for (h, r, label) in pane_buttons(f) {
        let primary = matches!(h, Hit::PaneBtn(0) | Hit::PaneBtn(2));
        let kind = if primary { Btn::Primary } else { Btn::Plain };
        gfx::button(pm, &f.fonts.regular, p(r[0]), p(r[1]), p(r[2]), p(r[3]), label, 12.5 * s, kind, f.hover == h);
    }
}

fn center_note(f: &Finder, pm: &mut PixmapMut, title: &str, sub: &str) {
    let s = f.s;
    let (cw, ch) = f.content();
    let cx = (SIDEBAR + cw / 2.0) * s;
    let cy = (f.top() + ch / 2.0) * s;
    let isz = 64.0 * s;
    gfx::icon(pm, Icon::Folder, cx - isz / 2.0, cy - isz - 18.0 * s, isz, gfx::white(0.2));
    let tw = gfx::measure(&f.fonts.semibold, title, 17.0 * s);
    gfx::text(pm, &f.fonts.semibold, title, cx - tw / 2.0, cy + 10.0 * s, 17.0 * s, gfx::white(0.8));
    if !sub.is_empty() {
        let sw = gfx::measure(&f.fonts.regular, sub, 13.0 * s);
        gfx::text(pm, &f.fonts.regular, sub, cx - sw / 2.0, cy + 34.0 * s, 13.0 * s, gfx::white(0.45));
    }
}

fn compose_look(f: &Finder, pm: &mut PixmapMut) {
    let s = f.s;
    let p = |v: f32| v * s;
    let Some(l) = &f.look else { return };
    let Some(e) = f.items.get(l.idx) else { return };
    gfx::fill_rrect(pm, 0.0, 0.0, f.cw as f32, f.ch as f32, 0.0, gfx::rgb(0, 0, 0, 0.35));
    let r = look_rect(f);
    gfx::shadow(pm, p(r[0]), p(r[1] + 10.0), p(r[2]), p(r[3]), p(40.0), 0.55);
    gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), 0.0, gfx::base());
    gfx::stroke_rrect(pm, p(r[0]) + 0.5, p(r[1]) + 0.5, p(r[2]) - 1.0, p(r[3]) - 1.0, p(14.0), 1.0, gfx::white(0.10));
    // шапка: закрыть, имя, «Открыть»
    let close = [r[0] + 10.0, r[1] + 8.0, 30.0, 30.0];
    if f.hover == Hit::LookClose {
        gfx::fill_rrect(pm, p(close[0]), p(close[1]), p(30.0), p(30.0), p(8.0), gfx::white(0.10));
    }
    gfx::icon(pm, Icon::Close, p(close[0] + 6.0), p(close[1] + 6.0), p(18.0), gfx::white(0.8));
    let ow = 96.0;
    let open = [r[0] + r[2] - ow - 12.0, r[1] + 8.0, ow, 30.0];
    gfx::fill_rrect(pm, p(open[0]), p(open[1]), p(ow), p(30.0), p(15.0), gfx::white(if f.hover == Hit::LookOpen { 0.16 } else { 0.09 }));
    let ot = "Открыть";
    let otw = gfx::measure(&f.fonts.regular, ot, 13.0 * s);
    gfx::text(pm, &f.fonts.regular, ot, p(open[0] + ow / 2.0) - otw / 2.0, p(open[1] + 19.5), 13.0 * s, gfx::white(0.92));
    let name = gfx::fit_middle(&f.fonts.semibold, &e.name, 14.0 * s, p(r[2] - 2.0 * (ow + 30.0)));
    let nw = gfx::measure(&f.fonts.semibold, &name, 14.0 * s);
    gfx::text(pm, &f.fonts.semibold, &name, p(r[0] + r[2] / 2.0) - nw / 2.0, p(r[1] + 28.5), 14.0 * s, gfx::white(0.95));
    gfx::fill_rrect(pm, p(r[0]), p(r[1] + 46.0), p(r[2]), 1.0, 0.0, gfx::white(0.07));
    // подвал: тип, размер, дата
    let mut parts = vec![e.kind.clone()];
    if !e.dir {
        parts.push(fs::size_text(e.size));
    }
    if e.modified != 0 {
        parts.push(format!("изменён {}", fs::date_text(e.modified).to_lowercase()));
    }
    let foot = parts.join("  ·  ");
    let fw = gfx::measure(&f.fonts.regular, &foot, 12.0 * s);
    gfx::text(pm, &f.fonts.regular, &foot, p(r[0] + r[2] / 2.0) - fw / 2.0, p(r[1] + r[3] - 14.0), 12.0 * s, gfx::white(0.5));
    // содержимое
    let body = [r[0] + 20.0, r[1] + 58.0, r[2] - 40.0, r[3] - 58.0 - 36.0];
    if let Some(lines) = &l.text {
        gfx::fill_rrect(pm, p(body[0] - 8.0), p(body[1] - 4.0), p(body[2] + 16.0), p(body[3] + 8.0), 0.0, gfx::white(0.04));
        let lh = 18.0;
        let first = (l.scroll / lh) as usize;
        let rows = (body[3] / lh) as usize;
        for (k, line) in lines.iter().skip(first).take(rows).enumerate() {
            let t = gfx::fit(&f.fonts.mono, line, 12.5 * s, p(body[2] - 8.0));
            gfx::text(pm, &f.fonts.mono, &t, p(body[0] + 4.0), p(body[1] + 14.0 + k as f32 * lh), 12.5 * s, gfx::white(0.85));
        }
        return;
    }
    let big = if e.dir { None } else { thumb(f, &e.path, LOOK_PX) };
    match big {
        Some(img) if img.is_photo() => {
            let (w, h) = fit_in(img.w, img.h, p(body[2]), p(body[3]));
            let (w, h) = (w.min(img.w as f32 * 2.0), h.min(img.h as f32 * 2.0));
            let (x, y) = ((p(body[0]) + (p(body[2]) - w) / 2.0).round(), (p(body[1]) + (p(body[3]) - h) / 2.0).round());
            gfx::image(pm, img, x, y, w, h, p(6.0), 1.0);
        }
        _ => {
            let isz = (body[3] * 0.55).min(220.0);
            let (x, y) = (body[0] + (body[2] - isz) / 2.0, body[1] + (body[3] - isz) / 2.0 - 20.0);
            match big {
                Some(img) => {
                    let (w, h) = fit_in(img.w, img.h, p(isz), p(isz));
                    gfx::image(pm, img, p(x) + (p(isz) - w) / 2.0, p(y) + (p(isz) - h) / 2.0, w, h, 0.0, 1.0);
                }
                None => draw_icon(f, pm, e, p(x), p(y), p(isz), icon_px(f), 1.0),
            }
            if e.dir {
                let t = "Папка — Enter или «Открыть», чтобы зайти";
                let tw = gfx::measure(&f.fonts.regular, t, 13.0 * s);
                gfx::text(pm, &f.fonts.regular, t, p(body[0] + body[2] / 2.0) - tw / 2.0, p(y + isz + 34.0), 13.0 * s, gfx::white(0.5));
            }
        }
    }
}

fn paint(f: &mut Finder, hdc: HDC) {
    if f.cw <= 0 || f.ch <= 0 {
        return;
    }
    if f.frame.as_ref().is_none_or(|fr| fr.w != f.cw || fr.h != f.ch) {
        f.frame = Surface::new(f.cw, f.ch);
    }
    prepare(f);
    let (s, top, wl, hl) = (f.s, f.top(), f.wl(), f.hl());
    if let View::Disk(d) = &mut f.view {
        let a = Area { s, fonts: &f.fonts, x: SIDEBAR, y: top, w: wl - SIDEBAR, h: hl - top - STATUS };
        d.prepare(&a);
        if d.animating() {
            unsafe {
                SetTimer(Some(f.hwnd), TIMER_ANIM, 15, None);
            }
        }
    }
    let Some(frame) = f.frame.as_ref() else { return };
    let data = unsafe { frame.pixels() };
    if let Some(mut pm) = PixmapMut::from_bytes(data, f.cw as u32, f.ch as u32) {
        compose(f, &mut pm);
    }
    unsafe {
        let _ = BitBlt(hdc, 0, 0, f.cw, f.ch, Some(frame.dc), 0, 0, SRCCOPY);
    }
}

// ---------- поле ввода (поиск, путь, имя) ----------

static mut EDIT_OLD: isize = 0;

unsafe extern "system" fn edit_proc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    let parent = GetParent(hwnd).unwrap_or_default();
    let done = |code: usize| {
        let _ = PostMessageW(Some(parent), WM_EDIT_DONE, WPARAM(code), LPARAM(0));
    };
    match msg {
        WM_KEYDOWN if wp.0 == VK_RETURN.0 as usize => {
            done(1);
            return LRESULT(0);
        }
        WM_KEYDOWN if wp.0 == VK_ESCAPE.0 as usize => {
            done(0);
            return LRESULT(0);
        }
        WM_KEYDOWN if wp.0 == VK_DOWN.0 as usize => {
            // из поиска стрелкой вниз — к результатам
            done(3);
            return LRESULT(0);
        }
        WM_CHAR if matches!(wp.0, 0x0D | 0x1B | 0x09) => return LRESULT(0),
        // Ctrl+A в однострочном поле Windows по умолчанию не работает
        WM_CHAR if wp.0 == 0x01 => {
            SendMessageW(hwnd, EM_SETSEL, Some(WPARAM(0)), Some(LPARAM(-1)));
            return LRESULT(0);
        }
        WM_KILLFOCUS => done(2),
        _ => {}
    }
    let old: WNDPROC = std::mem::transmute(EDIT_OLD);
    CallWindowProcW(old, hwnd, msg, wp, lp)
}

fn edit_text(h: HWND) -> String {
    unsafe {
        let n = GetWindowTextLengthW(h) as usize;
        let mut buf = vec![0u16; n + 1];
        let got = GetWindowTextW(h, &mut buf) as usize;
        String::from_utf16_lossy(&buf[..got])
    }
}

/// Показать поле ввода поверх прямоугольника r (логические пиксели); sel — что выделить
fn start_edit(f: &mut Finder, kind: EditKind, r: [f32; 4], text: &str, sel: (usize, usize), color: (u8, u8, u8)) {
    unsafe {
        if f.edit_hwnd.is_invalid() || f.edit_hwnd.0.is_null() {
            let inst = GetModuleHandleW(None).unwrap_or_default();
            let Ok(h) = CreateWindowExW(
                WINDOW_EX_STYLE(0),
                w!("EDIT"),
                None,
                WS_CHILD | WINDOW_STYLE(ES_AUTOHSCROLL as u32),
                0,
                0,
                10,
                10,
                Some(f.hwnd),
                None,
                Some(inst.into()),
                None,
            ) else {
                return;
            };
            EDIT_OLD = SetWindowLongPtrW(h, GWLP_WNDPROC, edit_proc as *const () as isize);
            f.edit_hwnd = h;
        }
        if f.edit_font.0 != f.s {
            if !f.edit_font.1.is_invalid() {
                let _ = DeleteObject(f.edit_font.1.into());
            }
            let font = CreateFontW(
                -(13.0 * f.s).round() as i32,
                0,
                0,
                0,
                FW_NORMAL.0 as i32,
                0,
                0,
                0,
                DEFAULT_CHARSET,
                OUT_DEFAULT_PRECIS,
                CLIP_DEFAULT_PRECIS,
                CLEARTYPE_QUALITY,
                0,
                w!("Segoe UI"),
            );
            f.edit_font = (f.s, font);
        }
        let cref = colorref(color).0;
        if f.edit_brush.0 != cref || f.edit_brush.1.is_invalid() {
            if !f.edit_brush.1.is_invalid() {
                let _ = DeleteObject(f.edit_brush.1.into());
            }
            f.edit_brush = (cref, CreateSolidBrush(COLORREF(cref)));
        }
        let h = f.edit_hwnd;
        SendMessageW(h, WM_SETFONT, Some(WPARAM(f.edit_font.1 .0 as usize)), Some(LPARAM(1)));
        SendMessageW(h, EM_SETMARGINS, Some(WPARAM((EC_LEFTMARGIN | EC_RIGHTMARGIN) as usize)), Some(LPARAM(0)));
        let t = wide(text);
        let _ = SetWindowTextW(h, pcwstr(&t));
        let eh = (19.0 * f.s).round();
        let (x, y) = ((r[0] * f.s).round(), (r[1] * f.s + (r[3] * f.s - eh) / 2.0).round());
        let _ = SetWindowPos(h, Some(HWND_TOP), x as i32, y as i32, (r[2] * f.s) as i32, eh as i32, SWP_SHOWWINDOW);
        let to_u16 = |n: usize| text.chars().take(n).map(char::len_utf16).sum::<usize>();
        SendMessageW(h, EM_SETSEL, Some(WPARAM(to_u16(sel.0))), Some(LPARAM(to_u16(sel.1) as isize)));
        f.edit = Some(kind);
        let _ = SetFocus(Some(h));
    }
}

fn hide_edit(f: &mut Finder) {
    f.edit = None;
    unsafe {
        let _ = ShowWindow(f.edit_hwnd, SW_HIDE);
        let _ = SetFocus(Some(f.hwnd));
    }
}

fn start_search(f: &mut Finder) {
    let r = search_rect(f);
    let q = f.query.clone();
    let n = q.chars().count();
    start_edit(f, EditKind::Search, [r[0] + 32.0, r[1], r[2] - 60.0, r[3]], &q, (0, n), base_rgb());
    redraw(f);
}

fn start_path(f: &mut Finder) {
    let Some(d) = f.dir().map(|d| d.to_string_lossy().to_string()) else { return };
    let y = f.hl() - STATUS;
    let n = d.chars().count();
    start_edit(f, EditKind::Path, [SIDEBAR + 14.0, y + 3.0, f.wl() - SIDEBAR - 220.0, STATUS - 6.0], &d, (0, n), base_rgb());
    redraw(f);
}

fn start_rename(f: &mut Finder) {
    let Some(i) = f.items.iter().position(|e| e.sel) else { return };
    if f.loc == Loc::Computer {
        return;
    }
    select_only(f, i);
    reveal(f, i);
    f.scroll = f.target;
    let e = f.items[i].clone();
    let g = grid(f);
    let r = item_rect(f, &g, i);
    let (x, y) = (SIDEBAR + r[0], f.top() + r[1] - f.scroll);
    let rect = match f.mode {
        Mode::Grid => [x - 8.0, y + 4.0 + f.zoom + 5.0, g.tw + 16.0, 20.0],
        Mode::List => [SIDEBAR + PAD + 24.0, y + 3.0, list_cols(f).date.unwrap_or(list_cols(f).size) - PAD - 36.0, ROW - 6.0],
    };
    // выделяем имя без расширения, как в Finder
    let n = e.name.chars().count();
    let stem = if e.dir { n } else { e.name.rfind('.').filter(|&p| p > 0).map(|p| e.name[..p].chars().count()).unwrap_or(n) };
    start_edit(f, EditKind::Rename(e.path.clone()), rect, &e.name, (0, stem), base_rgb());
    redraw(f);
}

/// Поле ввода закрылось: 1 — Enter, 0 — Esc, 2 — ушёл фокус, 3 — стрелка вниз из поиска
fn edit_done(f: &mut Finder, code: usize) -> Act {
    let Some(kind) = f.edit.clone() else { return Act::None };
    let text = edit_text(f.edit_hwnd);
    let mut act = Act::None;
    match kind {
        EditKind::Search => {
            if code == 0 {
                f.query.clear();
                restart_search(f);
                reapply(f);
            }
            if code == 3 && !f.items.is_empty() && !f.items.iter().any(|e| e.sel) {
                select_only(f, 0);
            }
        }
        EditKind::Path if code == 1 => {
            let p = PathBuf::from(text.trim().trim_matches('"'));
            let p = if p.as_os_str().len() == 2 && text.ends_with(':') { PathBuf::from(format!("{}\\", text.trim())) } else { p };
            if p.is_dir() {
                hide_edit(f);
                go(f, Loc::Dir(p), true);
                return Act::None;
            } else if p.exists() {
                act = Act::Open(p);
            } else {
                unsafe {
                    let _ = MessageBeep(MB_ICONWARNING);
                }
            }
        }
        EditKind::Rename(old) if code == 1 || code == 2 => {
            let name = text.trim();
            if !name.is_empty() && Some(name) != old.file_name().and_then(|n| n.to_str()) {
                let new = old.with_file_name(name);
                if new.exists() || std::fs::rename(&old, &new).is_err() {
                    unsafe {
                        let _ = MessageBeep(MB_ICONWARNING);
                    }
                } else {
                    hide_edit(f);
                    let keep: HashSet<PathBuf> = [new.clone()].into_iter().collect();
                    f.items.clear();
                    load(f);
                    apply(f, &keep);
                    if let Some(i) = f.items.iter().position(|e| e.path == new) {
                        reveal(f, i);
                    }
                    return Act::None;
                }
            }
        }
        _ => {}
    }
    hide_edit(f);
    act
}

// ---------- действия ----------

/// То, что нужно сделать уже после выхода из обработчика: эти вызовы крутят свой цикл сообщений
enum Act {
    None,
    Open(PathBuf),
    Drag(Vec<PathBuf>),
    /// меню для файлов; второе — индекс в избранном, если щёлкнули по боковой панели
    Menu(Vec<PathBuf>, Option<usize>),
    CopyPath(Vec<PathBuf>),
    Terminal(Option<PathBuf>),
    CloseWindow,
    ConfirmJunk,
    ConfirmTrash,
    DriveMenu,
    GroupMenu,
    FilterMenu,
    Verb(Vec<PathBuf>, &'static str, bool),
    Paste,
    NewFolder,
    Rename,
    NewWindow,
    /// меню по правому клику на диаграмме «Анализа места»
    DiskMenu(u32),
    DiskPick,
    DiskEmptyBin(PathBuf),
}

fn open_item(f: &mut Finder, i: usize) -> Act {
    let Some(e) = f.items.get(i) else { return Act::None };
    if e.dir {
        let p = e.path.clone();
        go(f, Loc::Dir(p), true);
        Act::None
    } else {
        Act::Open(e.path.clone())
    }
}

fn save_cfg(f: &Finder) {
    Settings {
        list: f.mode == Mode::List,
        zoom: f.zoom,
        sort: f.sort as u8,
        asc: f.asc,
        hidden: f.show_hidden,
        deep: f.deep,
        pane: f.pane,
        group: f.group,
        filter: f.filter,
        favorites: f.fav_paths.clone(),
        size: Some(((f.cw as f32 / f.s) as i32, (f.ch as f32 / f.s) as i32)),
    }
    .save();
}

/// Добавить папку в избранное или убрать оттуда
fn set_favorite(f: &mut Finder, p: &Path, on: bool) {
    let mut list: Vec<PathBuf> = f
        .favorites
        .iter()
        .filter_map(|pl| match &pl.loc {
            Loc::Dir(d) => Some(d.clone()),
            Loc::Computer => None,
        })
        .collect();
    if on {
        if !list.iter().any(|x| x == p) {
            list.push(p.to_path_buf());
        }
    } else {
        list.retain(|x| x != p);
    }
    f.fav_paths = Some(list);
    let (fav, spots) = fs::places(f.fav_paths.as_deref());
    f.favorites = fav;
    f.spots = spots;
    save_cfg(f);
}

/// Выделенная папка, а если её нет — текущая
fn target_dir(f: &Finder) -> Option<PathBuf> {
    let sel: Vec<&Entry> = f.items.iter().filter(|e| e.sel).collect();
    match sel.as_slice() {
        [e] if e.dir => Some(e.path.clone()),
        _ => f.dir().map(Path::to_path_buf),
    }
}

fn copy_paths(hwnd: HWND, paths: &[PathBuf]) {
    let text: Vec<String> = paths.iter().map(|p| p.to_string_lossy().to_string()).collect();
    if !text.is_empty() {
        win::set_clipboard_text(hwnd, &text.join("\r\n"));
    }
}

fn set_mode(f: &mut Finder, m: Mode) {
    if f.mode != m {
        f.mode = m;
        f.lines.clear();
        f.target = 0.0;
        f.scroll = 0.0;
        if let Some(i) = f.items.iter().position(|e| e.sel) {
            reveal(f, i);
        }
        save_cfg(f);
    }
}

fn toggle_hidden(f: &mut Finder) {
    f.show_hidden = !f.show_hidden;
    if deep_active(f) {
        restart_search(f);
    }
    reapply(f);
    save_cfg(f);
}

fn band_select(f: &mut Finder) {
    let Some(b) = &f.band else { return };
    let (x0, x1) = (b.x0.min(b.x1), b.x0.max(b.x1));
    let (y0, y1) = (b.y0.min(b.y1), b.y0.max(b.y1));
    let base = b.base.clone();
    let g = grid(f);
    let n = f.items.len();
    for i in 0..n {
        let r = item_rect(f, &g, i);
        let hit = r[0] < x1 && r[0] + r[2] > x0 && r[1] < y1 && r[1] + r[3] > y0;
        f.items[i].sel = base.get(i).copied().unwrap_or(false) ^ hit;
    }
}

fn filetime(t: std::io::Result<SystemTime>) -> u64 {
    t.ok().and_then(|t| t.duration_since(UNIX_EPOCH).ok()).map_or(0, |d| (d.as_nanos() / 100) as u64 + 116_444_736_000_000_000)
}

/// Размер папки; бросаем, как только выделение сменилось
fn dir_size_until(p: &Path, gen: &AtomicU64, my: u64) -> Option<u64> {
    let mut total = 0;
    let mut stack = vec![p.to_path_buf()];
    while let Some(d) = stack.pop() {
        if gen.load(Ordering::Relaxed) != my {
            return None;
        }
        let Ok(rd) = std::fs::read_dir(&d) else { continue };
        for e in rd.flatten() {
            let Ok(md) = e.metadata() else { continue };
            if md.is_dir() {
                use std::os::windows::fs::MetadataExt;
                if md.file_attributes() & 0x400 == 0 {
                    stack.push(e.path());
                }
            } else {
                total += md.len();
            }
        }
    }
    Some(total)
}

/// Сведения для панели справа: даты, содержимое папки, начало текста; размер папки — в фоне
fn prepare_pane(f: &mut Finder) {
    if !f.pane || !f.files() {
        return;
    }
    let sel: Vec<usize> = f.items.iter().enumerate().filter(|(_, e)| e.sel).map(|(i, _)| i).collect();
    let [i] = sel.as_slice() else {
        if f.info.take().is_some() {
            f.size_gen.fetch_add(1, Ordering::Relaxed);
        }
        return;
    };
    let e = f.items[*i].clone();
    if f.info.as_ref().is_none_or(|info| info.path != e.path) {
        f.size_gen.fetch_add(1, Ordering::Relaxed);
        let md = std::fs::metadata(&e.path).ok();
        let (created, accessed) = md.as_ref().map_or((0, 0), |m| (filetime(m.created()), filetime(m.accessed())));
        let mut count = None;
        if e.dir && e.space.is_none() {
            count = std::fs::read_dir(&e.path).ok().map(|r| r.count());
            let (tx, rx) = channel();
            let gen = f.size_gen.clone();
            let my = gen.load(Ordering::Relaxed);
            let (path, h) = (e.path.clone(), f.hwnd.0 as isize);
            std::thread::spawn(move || {
                if let Some(n) = dir_size_until(&path, &gen, my) {
                    let _ = tx.send((path, n));
                    unsafe {
                        let _ = PostMessageW(Some(HWND(h as *mut c_void)), WM_DIRSIZE, WPARAM(0), LPARAM(0));
                    }
                }
            });
            f.size_rx = Some(rx);
        }
        let text = if e.dir {
            None
        } else {
            fs::text_preview(&e.path).map(|mut l| {
                l.truncate(20);
                l
            })
        };
        f.info = Some(Info { path: e.path.clone(), created, accessed, count, size: None, text });
    }
    let has_text = f.info.as_ref().is_some_and(|i| i.text.is_some());
    if !has_text {
        let key = (e.path.clone(), pane_px(f));
        if !f.thumbs.contains_key(&key) {
            f.thumbs.insert(key.clone(), Thumb::Pending);
            f.pool.request(key.0, key.1);
        }
    }
}

/// Открыть «Анализ места» (k = 0) или «Очистку» (k = 1)
fn open_tool(f: &mut Finder, k: u8, root: Option<PathBuf>) {
    // «Анализ места» уже открыт — к списку дисков, сканирование не бросаем
    if let (0, None, View::Disk(d)) = (k, &root, &mut f.view) {
        d.show_home();
        return;
    }
    close_tool(f);
    let drive = f.dir().and_then(|d| d.ancestors().last()).map(Path::to_path_buf).unwrap_or_else(|| PathBuf::from("C:\\"));
    let here = f.dir().map(Path::to_path_buf);
    f.view = if k == 0 {
        View::Disk(Box::new(Disk::new(f.hwnd, root, here)))
    } else {
        View::Clean(Box::new(Clean::new(f.hwnd, root.unwrap_or(drive))))
    };
    f.look = None;
    f.hover = Hit::None;
    if f.edit.is_some() {
        hide_edit(f);
    }
    update_title(f);
}

fn close_tool(f: &mut Finder) {
    match &f.view {
        View::Disk(d) => d.stop(),
        View::Clean(c) => c.stop(),
        View::Files => return,
    }
    f.view = View::Files;
    update_title(f);
}

fn same_path(a: &Path, b: &Path) -> bool {
    let n = |p: &Path| p.to_string_lossy().trim_end_matches('\\').to_lowercase();
    n(a) == n(b)
}

fn same_loc(a: &Loc, b: &Loc) -> bool {
    match (a, b) {
        (Loc::Computer, Loc::Computer) => true,
        (Loc::Dir(x), Loc::Dir(y)) => same_path(x, y),
        _ => false,
    }
}

/// Выделить файл текущей папки и сразу, без анимации, прокрутить к нему
fn select_now(f: &mut Finder, path: &Path) {
    let mut at = f.items.iter().position(|e| same_path(&e.path, path));
    if at.is_none() {
        // файл только что появился (скачался), а папку ещё не перечитали
        load(f);
        at = f.items.iter().position(|e| same_path(&e.path, path));
    }
    if let Some(i) = at {
        select_only(f, i);
        reveal(f, i);
        f.scroll = f.target;
    }
}

/// Запрос от нового запуска: эта папка у нас уже открыта — переключаемся на неё; false — такой нет
fn show_open(f: &mut Finder, loc: &Loc, select: Option<&Path>) -> bool {
    // окно занято анализом или очисткой — не отбираем его
    if !f.files() {
        return false;
    }
    if !same_loc(&f.loc, loc) {
        let Some(i) = f.tabs.iter().enumerate().position(|(k, t)| k != f.cur && same_loc(&t.loc, loc)) else { return false };
        switch_tab(f, i);
    }
    if let Some(p) = select {
        select_now(f, p);
    }
    redraw(f);
    true
}

const COPY_OPEN: usize = 0x4D46_4F50;

/// Папка уже открыта в другом окне Finder — поднять его и выделить файл; true — нашлось
pub fn reuse(loc: &Loc, select: Option<&Path>) -> bool {
    use windows::Win32::System::DataExchange::COPYDATASTRUCT;
    let msg = format!("{}\n{}", place_path(loc).display(), select.map(|p| p.display().to_string()).unwrap_or_default());
    let data: Vec<u16> = msg.encode_utf16().collect();
    let cds = COPYDATASTRUCT { dwData: COPY_OPEN, cbData: (data.len() * 2) as u32, lpData: data.as_ptr() as *mut c_void };
    unsafe {
        let mut prev = None;
        while let Ok(h) = FindWindowExW(None, prev, w!("MacFinder.Window"), None) {
            prev = Some(h);
            let mut pid = 0;
            GetWindowThreadProcessId(h, Some(&mut pid));
            // разрешаем тому окну выйти на передний план — иначе оно только мигнёт на панели задач
            let _ = AllowSetForegroundWindow(pid);
            let mut res = 0usize;
            let sent = SendMessageTimeoutW(h, WM_COPYDATA, WPARAM(0), LPARAM(&cds as *const _ as isize), SMTO_ABORTIFHUNG, 1500, Some(&mut res));
            if sent.0 != 0 && res == 1 {
                return true;
            }
        }
    }
    false
}

/// Показать файл в его папке и выделить
fn reveal_path(f: &mut Finder, path: &Path) {
    close_tool(f);
    let Some(parent) = path.parent() else { return };
    go(f, Loc::Dir(parent.to_path_buf()), true);
    if let Some(i) = f.items.iter().position(|e| e.path == path) {
        select_only(f, i);
        reveal(f, i);
    }
}

/// Стрелки вверх/вниз в сетке с группами: ищем соседа по геометрии, а не по номеру
fn move_vertical(f: &mut Finder, down: bool, extend: bool) {
    let g = grid(f);
    let Some(c) = f.items.iter().rposition(|e| e.sel) else {
        move_sel(f, 0, extend);
        return;
    };
    let r = g.rects[c];
    let cx = r[0] + r[2] / 2.0;
    let rows = g.rects.iter().map(|q| q[1]).filter(|&y| if down { y > r[1] + 1.0 } else { y < r[1] - 1.0 });
    let next = if down { rows.fold(f32::MAX, f32::min) } else { rows.fold(f32::MIN, f32::max) };
    if next == f32::MAX || next == f32::MIN {
        return;
    }
    let best = (0..g.rects.len()).filter(|&i| (g.rects[i][1] - next).abs() < 1.0).min_by(|&a, &b| {
        let d = |i: usize| (g.rects[i][0] + g.rects[i][2] / 2.0 - cx).abs();
        d(a).total_cmp(&d(b))
    });
    if let Some(b) = best {
        move_sel(f, b as i32 - c as i32, extend);
    }
}

enum ToolDo {
    Nothing,
    Go(PathBuf),
    Reveal(PathBuf),
    Act(Act),
}

fn disk_out(o: Out) -> ToolDo {
    match o {
        Out::None => ToolDo::Nothing,
        Out::Reveal(p) => ToolDo::Reveal(p),
        Out::Go(p) => ToolDo::Go(p),
        Out::Menu(n) => ToolDo::Act(Act::DiskMenu(n)),
        Out::Pick => ToolDo::Act(Act::DiskPick),
        Out::EmptyBin(root) => ToolDo::Act(Act::DiskEmptyBin(root)),
    }
}

/// Мышь в «Анализе места» и «Очистке»; None — событие не их, обрабатываем как обычно
fn tool_event(f: &mut Finder, msg: u32, wp: WPARAM, x: i32, y: i32) -> Option<Act> {
    let (mut x, mut y) = (x, y);
    if msg == WM_MOUSEWHEEL {
        let mut pt = POINT { x, y };
        unsafe {
            let _ = ScreenToClient(f.hwnd, &mut pt);
        }
        (x, y) = (pt.x, pt.y);
    }
    let (ax, ay, aw, ah) = (SIDEBAR, f.top(), f.wl() - SIDEBAR, f.hl() - f.top() - STATUS);
    let (lx, ly) = (x as f32 / f.s, y as f32 / f.s);
    let over = lx >= ax && ly >= ay && ly < ay + ah;
    let hwnd = f.hwnd;
    let dragging = matches!(&f.view, View::Disk(d) if d.dragging());
    let consumed = (over || dragging) && matches!(msg, WM_LBUTTONUP | WM_LBUTTONDBLCLK | WM_RBUTTONUP | WM_MOUSEWHEEL);
    let todo = {
        let a = Area { s: f.s, fonts: &f.fonts, x: ax, y: ay, w: aw, h: ah };
        match (&mut f.view, msg) {
            (View::Disk(d), WM_MOUSEMOVE) => {
                if over || d.dragging() {
                    d.mouse_move(lx, ly);
                } else {
                    d.leave();
                }
                ToolDo::Nothing
            }
            (View::Disk(d), WM_LBUTTONDOWN) if over => {
                d.down(lx, ly);
                ToolDo::Nothing
            }
            (View::Clean(c), WM_MOUSEMOVE) => {
                c.hover = if over { c.hit(&a, lx, ly) } else { CHit::None };
                ToolDo::Nothing
            }
            (View::Disk(d), WM_LBUTTONUP) if over || d.dragging() => disk_out(d.up(lx, ly)),
            (View::Disk(d), WM_LBUTTONDBLCLK) if over => disk_out(d.double(lx, ly)),
            (View::Disk(d), WM_RBUTTONUP) if over => disk_out(d.right(lx, ly)),
            (View::Clean(c), WM_LBUTTONUP) if over => match c.hit(&a, lx, ly) {
                CHit::CleanJunk if !c.cleaning => ToolDo::Act(Act::ConfirmJunk),
                CHit::Drive => ToolDo::Act(Act::DriveMenu),
                CHit::Scan => {
                    c.scan(hwnd);
                    ToolDo::Nothing
                }
                CHit::Trash => ToolDo::Act(Act::ConfirmTrash),
                h => {
                    c.click(h);
                    ToolDo::Nothing
                }
            },
            (View::Clean(c), WM_LBUTTONDBLCLK) if over => match c.hit(&a, lx, ly) {
                CHit::Item(i) => c.items.get(i).map_or(ToolDo::Nothing, |it| ToolDo::Reveal(it.path.clone())),
                _ => ToolDo::Nothing,
            },
            (View::Clean(c), WM_RBUTTONUP) if over => match c.hit(&a, lx, ly) {
                CHit::Item(i) => c.items.get(i).map_or(ToolDo::Nothing, |it| ToolDo::Act(Act::Menu(vec![it.path.clone()], None))),
                _ => ToolDo::Nothing,
            },
            (View::Clean(c), WM_MOUSEWHEEL) if over => {
                c.wheel(&a, ((wp.0 >> 16) & 0xFFFF) as i16 as f32 / 120.0);
                c.hover = c.hit(&a, lx, ly);
                ToolDo::Nothing
            }
            _ => ToolDo::Nothing,
        }
    };
    if consumed && msg == WM_LBUTTONUP {
        unsafe {
            let _ = ReleaseCapture();
        }
        f.press = None;
    }
    let act = match todo {
        ToolDo::Nothing => Act::None,
        ToolDo::Go(p) => {
            close_tool(f);
            go(f, Loc::Dir(p), true);
            Act::None
        }
        ToolDo::Reveal(p) => {
            reveal_path(f, &p);
            Act::None
        }
        ToolDo::Act(a) => a,
    };
    redraw(f);
    match act {
        Act::None if !consumed => None,
        a => Some(a),
    }
}

/// Выпадающее меню с галочкой у текущего пункта; вернёт номер выбранного
fn popup(hwnd: HWND, items: &[(String, bool)]) -> Option<usize> {
    unsafe {
        let m = CreatePopupMenu().ok()?;
        for (i, (label, on)) in items.iter().enumerate() {
            let t = wide(label);
            let flags = if *on { MF_STRING | MF_CHECKED } else { MF_STRING };
            let _ = AppendMenuW(m, flags, i + 1, pcwstr(&t));
        }
        let p = win::cursor();
        let id = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, p.x, p.y, Some(0), hwnd, None).0 as usize;
        let _ = DestroyMenu(m);
        id.checked_sub(1)
    }
}

fn confirm(hwnd: HWND, text: &str) -> bool {
    let t = wide(text);
    unsafe { MessageBoxW(Some(hwnd), pcwstr(&t), w!("Finder"), MB_YESNO | MB_ICONQUESTION) == IDYES }
}

fn handle(f: &mut Finder, msg: u32, wp: WPARAM, lp: LPARAM) -> Act {
    let (x, y) = ((lp.0 & 0xFFFF) as i16 as i32, ((lp.0 >> 16) & 0xFFFF) as i16 as i32);
    let ctrl = unsafe { GetKeyState(VK_CONTROL.0 as i32) < 0 };
    let shift = unsafe { GetKeyState(VK_SHIFT.0 as i32) < 0 };
    let s = f.s;
    if !f.files() && matches!(msg, WM_MOUSEMOVE | WM_LBUTTONDOWN | WM_LBUTTONUP | WM_LBUTTONDBLCLK | WM_RBUTTONUP | WM_MOUSEWHEEL) {
        if let Some(a) = tool_event(f, msg, wp, x, y) {
            return a;
        }
    }
    match msg {
        WM_MOUSEMOVE => {
            if let Some((y0, s0)) = f.bar_drag {
                if let Some(bar) = scrollbar(f) {
                    let track = f.content().1 - 8.0 - bar[3];
                    let k = (y - y0) as f32 / s / track.max(1.0);
                    f.scroll = s0 + k * max_scroll(f);
                    f.target = f.scroll;
                    clamp_scroll(f);
                }
                redraw(f);
                return Act::None;
            }
            let by = y as f32 / s - f.top() + f.scroll;
            if let Some(b) = &mut f.band {
                b.x1 = x as f32 / s - SIDEBAR;
                b.y1 = by;
                band_select(f);
                redraw(f);
                return Act::None;
            }
            if let Some(p) = &f.press {
                let far = unsafe { (x - p.x).abs() > GetSystemMetrics(SM_CXDRAG) || (y - p.y).abs() > GetSystemMetrics(SM_CYDRAG) };
                if far && matches!(p.hit, Hit::Item(_)) {
                    f.press = None;
                    return Act::Drag(selected(f));
                }
            }
            let h = hit(f, x, y);
            if h != f.hover {
                f.hover = h;
                unsafe {
                    let mut tme = TRACKMOUSEEVENT {
                        cbSize: std::mem::size_of::<TRACKMOUSEEVENT>() as u32,
                        dwFlags: TME_LEAVE,
                        hwndTrack: f.hwnd,
                        dwHoverTime: 0,
                    };
                    let _ = TrackMouseEvent(&mut tme);
                }
                redraw(f);
            }
            Act::None
        }
        WM_LBUTTONDOWN => {
            unsafe {
                let _ = SetFocus(Some(f.hwnd));
                SetCapture(f.hwnd);
            }
            let h = hit(f, x, y);
            let mut collapse = false;
            match h {
                Hit::Bar => f.bar_drag = Some((y, f.scroll)),
                Hit::Item(i) => {
                    if ctrl {
                        f.items[i].sel = !f.items[i].sel;
                        f.anchor = Some(i);
                    } else if shift {
                        let a = f.anchor.unwrap_or(i);
                        for (k, e) in f.items.iter_mut().enumerate() {
                            e.sel = (a.min(i)..=a.max(i)).contains(&k);
                        }
                    } else if f.items[i].sel {
                        collapse = true;
                    } else {
                        select_only(f, i);
                    }
                }
                Hit::Empty => {
                    if !ctrl && !shift {
                        clear_sel(f);
                    }
                    let (bx, by) = (x as f32 / s - SIDEBAR, y as f32 / s - f.top() + f.scroll);
                    let base = f.items.iter().map(|e| e.sel).collect();
                    f.band = Some(Band { x0: bx, y0: by, x1: bx, y1: by, base });
                }
                Hit::Look => {}
                _ => {}
            }
            f.press = Some(Press { hit: h, x, y, collapse });
            redraw(f);
            Act::None
        }
        WM_LBUTTONUP => {
            unsafe {
                let _ = ReleaseCapture();
            }
            f.bar_drag = None;
            f.band = None;
            let Some(p) = f.press.take() else { return Act::None };
            let h = hit(f, x, y);
            let mut act = Act::None;
            if h == p.hit {
                match h {
                    Hit::Back => {
                        if f.files() {
                            go_back(f)
                        } else {
                            close_tool(f)
                        }
                    }
                    Hit::Fwd => go_fwd(f),
                    Hit::Grid => set_mode(f, Mode::Grid),
                    Hit::List => set_mode(f, Mode::List),
                    Hit::Search => start_search(f),
                    Hit::SearchClear => {
                        f.query.clear();
                        restart_search(f);
                        reapply(f);
                    }
                    Hit::Tab(i) => switch_tab(f, i),
                    Hit::TabClose(i) => {
                        if close_tab(f, i) {
                            act = Act::CloseWindow;
                        }
                    }
                    Hit::TabNew => {
                        let l = f.loc.clone();
                        new_tab(f, l, true);
                    }
                    Hit::ScopeHere | Hit::ScopeDeep => {
                        f.deep = h == Hit::ScopeDeep;
                        restart_search(f);
                        reapply(f);
                        save_cfg(f);
                    }
                    Hit::Head(col) => {
                        if f.sort == col {
                            f.asc = !f.asc;
                        } else {
                            f.sort = col;
                            f.asc = col == Sort::Name || col == Sort::Kind;
                        }
                        reapply(f);
                        save_cfg(f);
                    }
                    Hit::Crumb(i) => {
                        if let Some((_, l)) = crumbs(f).into_iter().nth(i) {
                            go(f, l, true);
                        }
                    }
                    Hit::Side(i) => {
                        if let Some(l) = place(f, i).map(|p| p.loc.clone()) {
                            close_tool(f);
                            go(f, l, true);
                        }
                    }
                    Hit::Tool(k) => open_tool(f, k, None),
                    Hit::PaneToggle => {
                        f.pane = !f.pane;
                        f.lines.clear();
                        clamp_scroll(f);
                        save_cfg(f);
                    }
                    Hit::GroupBtn => act = Act::GroupMenu,
                    Hit::FilterBtn => act = Act::FilterMenu,
                    Hit::PaneBtn(b) => match b {
                        0 => {
                            if let Some(i) = f.items.iter().position(|e| e.sel) {
                                act = open_item(f, i);
                            }
                        }
                        1 => act = Act::CopyPath(selected(f)),
                        2 => {
                            let d = f.dir().map(Path::to_path_buf);
                            open_tool(f, 0, d);
                        }
                        _ => open_tool(f, 1, None),
                    },
                    Hit::LookClose => f.look = None,
                    Hit::LookOpen => {
                        if let Some(i) = f.look.take().map(|l| l.idx) {
                            act = open_item(f, i);
                        }
                    }
                    Hit::Item(i) if p.collapse => select_only(f, i),
                    _ => {}
                }
            }
            f.hover = hit(f, x, y);
            redraw(f);
            act
        }
        WM_LBUTTONDBLCLK => match hit(f, x, y) {
            Hit::Item(i) => {
                let a = open_item(f, i);
                redraw(f);
                a
            }
            Hit::Status => {
                start_path(f);
                Act::None
            }
            _ => Act::None,
        },
        WM_RBUTTONUP => match hit(f, x, y) {
            Hit::Item(i) => {
                if !f.items[i].sel {
                    select_only(f, i);
                }
                redraw(f);
                Act::Menu(selected(f), None)
            }
            Hit::Empty if f.dir().is_some() => {
                clear_sel(f);
                redraw(f);
                Act::Menu(Vec::new(), None)
            }
            Hit::Side(i) => match place(f, i).map(|p| p.loc.clone()) {
                Some(Loc::Dir(p)) => Act::Menu(vec![p], (i < f.favorites.len()).then_some(i)),
                _ => Act::None,
            },
            _ => Act::None,
        },
        WM_MBUTTONUP => {
            // средняя кнопка: папку — в новую вкладку, вкладку — закрыть
            match hit(f, x, y) {
                Hit::Tab(i) | Hit::TabClose(i) => {
                    if close_tab(f, i) {
                        return Act::CloseWindow;
                    }
                }
                Hit::Item(i) if f.items[i].dir => {
                    let p = f.items[i].path.clone();
                    new_tab(f, Loc::Dir(p), false);
                }
                Hit::Side(i) => {
                    if let Some(l) = place(f, i).map(|p| p.loc.clone()) {
                        new_tab(f, l, false);
                    }
                }
                _ => {}
            }
            redraw(f);
            Act::None
        }
        WM_XBUTTONUP => {
            match ((wp.0 >> 16) & 0xFFFF) as u16 {
                1 => go_back(f),
                2 => go_fwd(f),
                _ => {}
            }
            redraw(f);
            Act::None
        }
        WM_MOUSEWHEEL => {
            let delta = ((wp.0 >> 16) & 0xFFFF) as i16 as f32 / 120.0;
            if let Some(l) = &mut f.look {
                l.scroll = (l.scroll - delta * 54.0).max(0.0);
                redraw(f);
            } else if ctrl {
                if f.mode == Mode::Grid {
                    f.zoom = (f.zoom + delta * 16.0).clamp(ZOOM.0, ZOOM.1);
                    f.lines.clear();
                    clamp_scroll(f);
                    save_cfg(f);
                    redraw(f);
                }
            } else {
                f.target -= delta * 110.0;
                clamp_scroll(f);
                animate(f);
            }
            Act::None
        }
        WM_SYSKEYDOWN => {
            match VIRTUAL_KEY(wp.0 as u16) {
                VK_LEFT => go_back(f),
                VK_RIGHT => go_fwd(f),
                VK_UP => go_up(f),
                VK_RETURN => {
                    let sel = selected(f);
                    return Act::Verb(sel, "properties", false);
                }
                _ => return Act::None,
            }
            redraw(f);
            Act::None
        }
        WM_KEYDOWN => {
            let vk = VIRTUAL_KEY(wp.0 as u16);
            if !f.files() {
                if vk == VK_ESCAPE || vk == VK_BACK {
                    // в «Анализе места» Esc сначала закрывает окна и отдаляет диаграмму
                    let handled = match &mut f.view {
                        View::Disk(d) => d.escape(),
                        _ => false,
                    };
                    if !handled {
                        close_tool(f);
                    }
                    redraw(f);
                }
                return Act::None;
            }
            if f.look.is_some() {
                match vk {
                    VK_SPACE | VK_ESCAPE => f.look = None,
                    VK_LEFT | VK_UP => move_sel(f, -1, false),
                    VK_RIGHT | VK_DOWN => move_sel(f, 1, false),
                    VK_RETURN => {
                        if let Some(i) = f.look.take().map(|l| l.idx) {
                            let a = open_item(f, i);
                            redraw(f);
                            return a;
                        }
                    }
                    _ => return Act::None,
                }
                redraw(f);
                return Act::None;
            }
            let cols = if f.mode == Mode::Grid { grid(f).cols as i32 } else { 1 };
            let page = (f.content().1 / if f.mode == Mode::Grid { grid(f).th + 10.0 } else { ROW }) as i32 * cols;
            let n = f.items.len() as i32;
            if f.mode == Mode::Grid && !ctrl && matches!(vk, VK_UP | VK_DOWN) {
                move_vertical(f, vk == VK_DOWN, shift);
                redraw(f);
                return Act::None;
            }
            let mv = match vk {
                VK_LEFT if f.mode == Mode::Grid => Some(-1),
                VK_RIGHT if f.mode == Mode::Grid => Some(1),
                VK_UP => Some(-cols),
                VK_DOWN => Some(cols),
                VK_PRIOR => Some(-page.max(1)),
                VK_NEXT => Some(page.max(1)),
                VK_HOME => Some(-n),
                VK_END => Some(n),
                _ => None,
            };
            if let Some(d) = mv {
                move_sel(f, d, shift);
                redraw(f);
                return Act::None;
            }
            let act = match vk {
                VK_C if ctrl && shift => {
                    let mut p = selected(f);
                    if p.is_empty() {
                        p.extend(f.dir().map(Path::to_path_buf));
                    }
                    Act::CopyPath(p)
                }
                VK_T if ctrl => {
                    let l = f.loc.clone();
                    new_tab(f, l, true);
                    Act::None
                }
                VK_W if ctrl => {
                    let c = f.cur;
                    if close_tab(f, c) {
                        Act::CloseWindow
                    } else {
                        Act::None
                    }
                }
                VK_TAB if ctrl => {
                    let n = f.tabs.len();
                    if n > 1 {
                        let i = if shift { (f.cur + n - 1) % n } else { (f.cur + 1) % n };
                        switch_tab(f, i);
                    }
                    Act::None
                }
                VK_OEM_3 if ctrl => Act::Terminal(target_dir(f)),
                VK_I if ctrl => {
                    f.pane = !f.pane;
                    f.lines.clear();
                    save_cfg(f);
                    Act::None
                }
                VK_D if ctrl => {
                    if let Some(p) = target_dir(f) {
                        set_favorite(f, &p, true);
                    }
                    Act::None
                }
                VK_RETURN => match f.items.iter().position(|e| e.sel) {
                    Some(i) if f.items.iter().filter(|e| e.sel).count() == 1 => open_item(f, i),
                    // несколько файлов — открываем каждый
                    Some(_) => {
                        let paths: Vec<PathBuf> = f.items.iter().filter(|e| e.sel && !e.dir).map(|e| e.path.clone()).collect();
                        for p in &paths {
                            shell::open(p, f.dir());
                        }
                        Act::None
                    }
                    None => Act::None,
                },
                VK_SPACE => {
                    if let Some(i) = f.items.iter().position(|e| e.sel) {
                        f.look = Some(Look { idx: i, text: None, scroll: 0.0 });
                        prepare_look(f);
                    }
                    Act::None
                }
                VK_BACK => {
                    go_back(f);
                    Act::None
                }
                VK_ESCAPE => {
                    if !f.query.is_empty() {
                        f.query.clear();
                        restart_search(f);
                        reapply(f);
                    } else {
                        clear_sel(f);
                    }
                    Act::None
                }
                VK_F2 => Act::Rename,
                VK_F5 => {
                    load(f);
                    Act::None
                }
                VK_DELETE => Act::Verb(selected(f), "delete", shift),
                VK_A if ctrl => {
                    for e in &mut f.items {
                        e.sel = true;
                    }
                    Act::None
                }
                VK_C if ctrl => Act::Verb(selected(f), "copy", false),
                VK_X if ctrl => Act::Verb(selected(f), "cut", false),
                VK_V if ctrl => Act::Paste,
                VK_N if ctrl && shift => Act::NewFolder,
                VK_N if ctrl => Act::NewWindow,
                VK_F if ctrl => {
                    start_search(f);
                    Act::None
                }
                VK_L if ctrl => {
                    start_path(f);
                    Act::None
                }
                VK_H if ctrl => {
                    toggle_hidden(f);
                    Act::None
                }
                VK_1 if ctrl => {
                    set_mode(f, Mode::Grid);
                    Act::None
                }
                VK_2 if ctrl => {
                    set_mode(f, Mode::List);
                    Act::None
                }
                VK_UP if ctrl => {
                    go_up(f);
                    Act::None
                }
                VK_OEM_PLUS | VK_ADD if ctrl => {
                    f.zoom = (f.zoom + 16.0).min(ZOOM.1);
                    f.lines.clear();
                    Act::None
                }
                VK_OEM_MINUS | VK_SUBTRACT if ctrl => {
                    f.zoom = (f.zoom - 16.0).max(ZOOM.0);
                    f.lines.clear();
                    Act::None
                }
                _ => return Act::None,
            };
            clamp_scroll(f);
            redraw(f);
            act
        }
        WM_CHAR => {
            // набор букв — переход к файлу с таким началом имени, как в Finder
            let Some(c) = char::from_u32(wp.0 as u32).filter(|c| !c.is_control() && *c != ' ') else { return Act::None };
            if ctrl {
                return Act::None;
            }
            if f.typed.1.elapsed().as_millis() > 900 {
                f.typed.0.clear();
            }
            f.typed.0.extend(c.to_lowercase());
            f.typed.1 = Instant::now();
            let pre = f.typed.0.clone();
            if let Some(i) = f.items.iter().position(|e| e.name.to_lowercase().starts_with(&pre)) {
                select_only(f, i);
                reveal(f, i);
                redraw(f);
            }
            Act::None
        }
        _ => Act::None,
    }
}

fn new_folder(f: &mut Finder) {
    let Some(d) = f.dir().map(Path::to_path_buf) else { return };
    let p = fs::free_name(&d, "Новая папка");
    if std::fs::create_dir(&p).is_err() {
        unsafe {
            let _ = MessageBeep(MB_ICONWARNING);
        }
        return;
    }
    f.query.clear();
    let keep: HashSet<PathBuf> = [p.clone()].into_iter().collect();
    f.items.clear();
    load(f);
    apply(f, &keep);
    start_rename(f);
}

fn run_act(hwnd: HWND, act: Act) {
    match act {
        Act::None => {}
        Act::Open(p) => {
            let dir = with(|f| f.dir().map(Path::to_path_buf)).flatten();
            shell::open(&p, dir.as_deref());
        }
        Act::Drag(paths) => {
            if paths.is_empty() {
                return;
            }
            unsafe {
                let _ = ReleaseCapture();
            }
            shell::drag(&paths);
            with(|f| {
                load(f);
                redraw(f);
            });
        }
        Act::Menu(paths, fav) => {
            let Some((dir, hidden, in_fav)) = with(|f| {
                let in_fav = paths.len() == 1 && f.favorites.iter().any(|p| p.loc == Loc::Dir(paths[0].clone()));
                (f.dir().map(Path::to_path_buf), f.show_hidden, in_fav)
            }) else {
                return;
            };
            use shell::MenuItem::{Cmd, Sub};
            let mut top: Vec<shell::MenuItem> = Vec::new();
            if paths.is_empty() {
                top.push(Cmd(shell::ID_NEW_FOLDER, "Новая папка\tCtrl+Shift+N".into()));
                top.push(Cmd(shell::ID_TERMINAL, "Открыть терминал здесь\tCtrl+`".into()));
                top.push(Cmd(shell::ID_ANALYZE, "Анализ места в этой папке".into()));
                if dir.is_some() {
                    top.push(Cmd(shell::ID_EXPLORER, "Открыть в Проводнике".into()));
                }
                top.push(Sub("Скопировать путь к папке".into(), shell::copy_items()));
            } else {
                if paths.len() == 1 && !paths[0].is_dir() {
                    top.push(Cmd(shell::ID_EXPLORER, "Показать в Проводнике".into()));
                }
                if paths.len() == 1 && paths[0].is_dir() {
                    top.push(Cmd(shell::ID_NEW_TAB, "Открыть в новой вкладке".into()));
                    top.push(Cmd(shell::ID_TERMINAL, "Открыть терминал здесь".into()));
                    top.push(Cmd(shell::ID_ANALYZE, "Анализ места".into()));
                    top.push(Cmd(shell::ID_EXPLORER, "Открыть в Проводнике".into()));
                    if fav.is_some() || in_fav {
                        top.push(Cmd(shell::ID_REMOVE_FAV, "Убрать из избранного".into()));
                    } else {
                        top.push(Cmd(shell::ID_ADD_FAV, "Добавить в избранное\tCtrl+D".into()));
                    }
                }
                top.push(Sub("Скопировать путь".into(), shell::copy_items()));
            }
            let hidden_on = paths.is_empty().then_some(hidden);
            match shell::menu(hwnd, dir.as_deref(), &paths, &top, hidden_on) {
                Picked::Rename => {
                    with(start_rename);
                }
                Picked::Own(id) => {
                    let target = paths.first().cloned().or(dir.clone());
                    match id {
                        shell::ID_HIDDEN => {
                            with(|f| {
                                toggle_hidden(f);
                                redraw(f);
                            });
                        }
                        shell::ID_NEW_FOLDER => {
                            with(new_folder);
                        }
                        shell::ID_NEW_TAB => {
                            if let Some(p) = target {
                                with(|f| {
                                    new_tab(f, Loc::Dir(p), true);
                                    redraw(f);
                                });
                            }
                        }
                        shell::ID_TERMINAL => {
                            if let Some(p) = target {
                                shell::terminal(&p);
                            }
                        }
                        shell::ID_EXPLORER => {
                            if let Some(p) = target {
                                shell::explorer(&p, !p.is_dir());
                            }
                        }
                        shell::ID_COPY_PATH
                        | shell::ID_COPY_NAME
                        | shell::ID_COPY_QUOTED
                        | shell::ID_COPY_SLASH
                        | shell::ID_COPY_PARENT
                        | shell::ID_COPY_URI => {
                            let list: Vec<PathBuf> = if paths.is_empty() { dir.into_iter().collect() } else { paths.clone() };
                            win::set_clipboard_text(hwnd, &shell::copy_text(&list, id));
                        }
                        shell::ID_ANALYZE => {
                            if let Some(p) = target {
                                with(|f| {
                                    open_tool(f, 0, Some(p));
                                    redraw(f);
                                });
                            }
                        }
                        shell::ID_ADD_FAV | shell::ID_REMOVE_FAV => {
                            if let Some(p) = target {
                                with(|f| {
                                    set_favorite(f, &p, id == shell::ID_ADD_FAV);
                                    redraw(f);
                                });
                            }
                        }
                        _ => {}
                    }
                }
                Picked::None => {}
            }
        }
        Act::CopyPath(paths) => copy_paths(hwnd, &paths),
        Act::Terminal(dir) => {
            if let Some(d) = dir {
                shell::terminal(&d);
            }
        }
        Act::ConfirmJunk => {
            let Some(total) = with(|f| match &f.view {
                View::Clean(c) => c.junk_total(),
                _ => 0,
            }) else {
                return;
            };
            let text = format!(
                "Удалить мусор — {}?\n\nВременные файлы и кэш удаляются насовсем, отмеченная корзина будет очищена. Документы, фото и программы не затрагиваются.",
                fs::size_text(total)
            );
            if confirm(hwnd, &text) {
                with(|f| {
                    if let View::Clean(c) = &mut f.view {
                        c.clean_junk(hwnd);
                    }
                    redraw(f);
                });
            }
        }
        Act::ConfirmTrash => {
            let Some((paths, size)) = with(|f| match &f.view {
                View::Clean(c) => (c.selected(), c.selected_size()),
                _ => (Vec::new(), 0),
            }) else {
                return;
            };
            // системное и важные папки не трогаем, даже если отмечены
            let rules = crate::safety::Rules::current();
            let total = paths.len();
            let paths: Vec<PathBuf> = paths.into_iter().filter(|p| !matches!(rules.check(p), crate::safety::Verdict::Forbidden(_))).collect();
            if paths.is_empty() {
                return;
            }
            let skipped = if total > paths.len() {
                format!("\n\nЗащищённые системные файлы пропущены: {}.", total - paths.len())
            } else {
                String::new()
            };
            let text = format!(
                "Переместить в корзину {} ({})?\n\nИх можно будет вернуть из корзины.{skipped}",
                fs::plural(paths.len(), ["файл", "файла", "файлов"]),
                fs::size_text(size)
            );
            if confirm(hwnd, &text) {
                shell::recycle(hwnd, &paths);
                with(|f| {
                    if let View::Clean(c) = &mut f.view {
                        c.forget_missing();
                    }
                    redraw(f);
                });
            }
        }
        Act::DriveMenu => {
            let drives = fs::drives();
            let items: Vec<(String, bool)> = drives.iter().map(|d| (d.label.clone(), false)).collect();
            if let Some(i) = popup(hwnd, &items) {
                let root = drives[i].root.clone();
                with(|f| {
                    if let View::Clean(c) = &mut f.view {
                        c.stop();
                        c.drive = root;
                        c.items.clear();
                        c.scanned = false;
                        c.progress = None;
                    }
                    redraw(f);
                });
            }
        }
        Act::GroupMenu => {
            let cur = with(|f| f.group).unwrap_or(0);
            let names = ["Без группировки", "По типу", "По дате изменения", "По размеру", "По первой букве"];
            let items: Vec<(String, bool)> = names.iter().enumerate().map(|(k, n)| (n.to_string(), k as u8 == cur)).collect();
            if let Some(i) = popup(hwnd, &items) {
                with(|f| {
                    f.group = i as u8;
                    f.target = 0.0;
                    f.scroll = 0.0;
                    reapply(f);
                    save_cfg(f);
                    redraw(f);
                });
            }
        }
        Act::FilterMenu => {
            let cur = with(|f| f.filter).unwrap_or(0);
            let mut items = vec![("Все файлы".to_string(), cur == 0)];
            items.extend(fs::CATS.iter().enumerate().map(|(k, n)| (n.to_string(), k as u8 + 1 == cur)));
            if let Some(i) = popup(hwnd, &items) {
                with(|f| {
                    f.filter = i as u8;
                    f.target = 0.0;
                    f.scroll = 0.0;
                    reapply(f);
                    save_cfg(f);
                    redraw(f);
                });
            }
        }
        Act::CloseWindow => unsafe {
            let _ = PostMessageW(Some(hwnd), WM_CLOSE, WPARAM(0), LPARAM(0));
        },
        Act::Verb(paths, verb, shift) => {
            if paths.is_empty() {
                return;
            }
            let dir = with(|f| f.dir().map(Path::to_path_buf)).flatten();
            shell::verb(hwnd, dir.as_deref(), &paths, verb, shift);
        }
        Act::Paste => {
            let Some(dir) = with(|f| f.dir().map(Path::to_path_buf)).flatten() else { return };
            shell::verb(hwnd, Some(&dir), &[], "paste", false);
        }
        Act::NewFolder => {
            with(new_folder);
        }
        Act::Rename => {
            with(start_rename);
        }
        Act::DiskMenu(node) => {
            let Some(Some((path, dir, name, collected))) = with(|f| match &f.view {
                View::Disk(d) => d.node_info(node).map(|(p, dir, name)| (p, dir, name, d.is_collected(node))),
                _ => None,
            }) else {
                return;
            };
            let items = vec![
                ((if dir { "Открыть в Finder" } else { "Показать в Finder" }).to_string(), false),
                ((if dir { "Открыть в Проводнике" } else { "Открыть" }).to_string(), false),
                ((if collected { "Убрать из сборщика" } else { "Собрать для удаления" }).to_string(), false),
                (format!("Удалить «{name}»…"), false),
                ("Скопировать путь".to_string(), false),
            ];
            match popup(hwnd, &items) {
                Some(0) => {
                    with(|f| {
                        if dir {
                            close_tool(f);
                            go(f, Loc::Dir(path.clone()), true);
                        } else {
                            reveal_path(f, &path);
                        }
                        redraw(f);
                    });
                }
                Some(1) if dir => shell::explorer(&path, false),
                Some(1) => shell::open(&path, path.parent()),
                Some(k @ (2 | 3)) => {
                    with(|f| {
                        if let View::Disk(d) = &mut f.view {
                            match (k, collected) {
                                (2, true) => d.uncollect(node),
                                (2, false) => d.collect(node),
                                _ => d.confirm_node(node),
                            }
                        }
                        redraw(f);
                    });
                }
                Some(4) => win::set_clipboard_text(hwnd, &path.to_string_lossy()),
                _ => {}
            }
        }
        Act::DiskPick => {
            if let Some(p) = shell::pick_folder(hwnd) {
                with(|f| {
                    if let View::Disk(d) = &mut f.view {
                        d.start(p);
                    }
                    redraw(f);
                });
            }
        }
        Act::DiskEmptyBin(root) => {
            let text = format!(
                "Очистить корзину на диске {}?\n\nФайлы из неё удалятся насовсем, и место освободится.",
                root.to_string_lossy().trim_end_matches('\\')
            );
            if confirm(hwnd, &text) {
                use windows::Win32::UI::Shell::{SHEmptyRecycleBinW, SHERB_NOCONFIRMATION, SHERB_NOSOUND};
                let r = win::wide_path(&root);
                unsafe {
                    let _ = SHEmptyRecycleBinW(Some(hwnd), pcwstr(&r), SHERB_NOCONFIRMATION | SHERB_NOSOUND);
                }
                with(|f| {
                    if let View::Disk(d) = &mut f.view {
                        d.emptied_bin();
                    }
                    redraw(f);
                });
            }
        }
        Act::NewWindow => {
            let dir = with(|f| f.dir().map(Path::to_path_buf)).flatten();
            if let Ok(exe) = std::env::current_exe() {
                let mut c = std::process::Command::new(exe);
                if let Some(d) = dir {
                    c.arg(d);
                }
                let _ = c.spawn();
            }
        }
    }
}

// ---------- окно ----------

fn new_finder(hwnd: HWND, s: f32, loc: Loc, cfg: &Settings) -> Option<Finder> {
    let fonts = Fonts::load()?;
    let (favorites, spots) = fs::places(cfg.favorites.as_deref());
    let sort = match cfg.sort {
        1 => Sort::Date,
        2 => Sort::Size,
        3 => Sort::Kind,
        _ => Sort::Name,
    };
    Some(Finder {
        view: View::Files,
        pane: cfg.pane,
        group: cfg.group.min(4),
        filter: cfg.filter.min(fs::CATS.len() as u8),
        groups: Vec::new(),
        info: None,
        size_gen: Arc::new(AtomicU64::new(0)),
        size_rx: None,
        tabs: vec![Tab { loc: loc.clone(), back: Vec::new(), fwd: Vec::new(), scroll: 0.0 }],
        cur: 0,
        deep: cfg.deep,
        found: Vec::new(),
        searching: false,
        search_gen: Arc::new(AtomicU64::new(0)),
        search_rx: None,
        fav_paths: cfg.favorites.clone(),
        names: fs::known().into_iter().map(|(p, n, _)| (p, n)).collect(),
        hwnd,
        s,
        cw: 0,
        ch: 0,
        fonts,
        loc,
        back: Vec::new(),
        fwd: Vec::new(),
        all: Vec::new(),
        items: Vec::new(),
        error: None,
        mode: if cfg.list { Mode::List } else { Mode::Grid },
        zoom: cfg.zoom.clamp(ZOOM.0, ZOOM.1),
        sort,
        asc: cfg.asc,
        show_hidden: cfg.hidden,
        scroll: 0.0,
        target: 0.0,
        hover: Hit::None,
        press: None,
        anchor: None,
        band: None,
        bar_drag: None,
        query: String::new(),
        thumbs: HashMap::new(),
        lines: HashMap::new(),
        pool: Pool::new(hwnd),
        look: None,
        edit: None,
        edit_hwnd: HWND::default(),
        edit_font: (0.0, HFONT::default()),
        edit_brush: (0, HBRUSH::default()),
        watch: None,
        frame: None,
        favorites,
        spots,
        kinds: Kinds::new(),
        drop_at: None,
        typed: (String::new(), Instant::now()),
    })
}

/// Заголовок в цвет окна и без рамки — даже если в Windows включён цвет акцента на заголовках
fn frame_colors(hwnd: HWND) {
    let dark = gfx::theme().dark;
    // COLORREF: 0x00BBGGRR; фон — как gfx::base()
    let (caption, text) = if dark { (0x0019_1919u32, 0x00F2_F2F2u32) } else { (0x00FF_FFFF, 0x001A_1A1A) };
    let set = |attr: DWMWINDOWATTRIBUTE, v: u32| unsafe {
        let _ = DwmSetWindowAttribute(hwnd, attr, &v as *const u32 as *const c_void, 4);
    };
    set(DWMWA_USE_IMMERSIVE_DARK_MODE, dark as u32);
    set(DWMWA_CAPTION_COLOR, caption);
    set(DWMWA_TEXT_COLOR, text);
    // DWMWA_COLOR_NONE — рамки нет совсем
    set(DWMWA_BORDER_COLOR, 0xFFFF_FFFE);
}

pub fn run(start: Loc, select: Option<PathBuf>) {
    let mon = win::monitor_at(win::cursor());
    let s = mon.scale;
    let cfg = Settings::load();
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            style: CS_DBLCLKS,
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacFinder.Window"),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            ..Default::default()
        };
        RegisterClassW(&wc);
        let work = mon.work;
        let (ww, wh) = ((work.right - work.left) as f32, (work.bottom - work.top) as f32);
        let (lw, lh) = cfg.size.map_or((1120.0, 720.0), |(w, h)| (w.max(720) as f32, h.max(440) as f32));
        let (cw, ch) = ((lw * s).min(ww * 0.96), (lh * s).min(wh * 0.94));
        let mut r = RECT { left: 0, top: 0, right: cw as i32, bottom: ch as i32 };
        let _ = AdjustWindowRectExForDpi(&mut r, WS_OVERLAPPEDWINDOW, false, WINDOW_EX_STYLE(0), (s * 96.0) as u32);
        let (rw, rh) = (r.right - r.left, r.bottom - r.top);
        // каждое следующее окно чуть сдвинуто, чтобы не легло ровно поверх
        let shift = (std::process::id() % 5) as i32 * (24.0 * s) as i32;
        let x = work.left + ((ww as i32 - rw) / 2).max(0) + shift;
        let y = work.top + ((wh as i32 - rh) / 2).max(0) + shift;
        let Ok(hwnd) = CreateWindowExW(
            WINDOW_EX_STYLE(0),
            w!("MacFinder.Window"),
            w!("Finder"),
            WS_OVERLAPPEDWINDOW,
            x,
            y,
            rw,
            rh,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        frame_colors(hwnd);
        win::dark_menus(hwnd);
        SendMessageW(hwnd, WM_SETICON, Some(WPARAM(ICON_BIG as usize)), Some(LPARAM(crate::app_icon(false).0 as isize)));
        SendMessageW(hwnd, WM_SETICON, Some(WPARAM(ICON_SMALL as usize)), Some(LPARAM(crate::app_icon(true).0 as isize)));
        let Some(mut f) = new_finder(hwnd, s, start, &cfg) else { return };
        let mut rc = RECT::default();
        let _ = GetClientRect(hwnd, &mut rc);
        f.cw = rc.right;
        f.ch = rc.bottom;
        load(&mut f);
        if let Some(p) = &select {
            select_now(&mut f, p);
        }
        update_title(&f);
        FINDER.with(|st| *st.borrow_mut() = Some(f));
        shell::register_drop(hwnd);
        SetTimer(Some(hwnd), TIMER_WATCH, 500, None);
        let _ = ShowWindow(hwnd, SW_SHOW);
        // открыли из другой программы («Показать в папке») — окно должно оказаться сверху
        let _ = SetForegroundWindow(hwnd);

        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).as_bool() {
            let _ = TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    if let Some(r) = shell::menu_message(msg, wp, lp) {
        return r;
    }
    match msg {
        WM_PAINT => {
            let mut ps = PAINTSTRUCT::default();
            let hdc = BeginPaint(hwnd, &mut ps);
            with(|f| paint(f, hdc));
            let _ = EndPaint(hwnd, &ps);
            LRESULT(0)
        }
        WM_ERASEBKGND => LRESULT(1),
        WM_SETTINGCHANGE => {
            // сменили светлую/тёмную тему или цвет акцента — перекрашиваемся
            gfx::load_themes();
            gfx::use_theme(true);
            frame_colors(hwnd);
            with(|f| redraw(f));
            DefWindowProcW(hwnd, msg, wp, lp)
        }
        WM_SIZE => {
            with(|f| {
                f.cw = (lp.0 & 0xFFFF) as i32;
                f.ch = ((lp.0 >> 16) & 0xFFFF) as i32;
                f.lines.clear();
                clamp_scroll(f);
                if f.edit.is_some() {
                    hide_edit(f);
                }
                redraw(f);
            });
            LRESULT(0)
        }
        WM_GETMINMAXINFO => {
            if let Some(s) = with(|f| f.s) {
                let mmi = &mut *(lp.0 as *mut MINMAXINFO);
                mmi.ptMinTrackSize.x = (720.0 * s) as i32;
                mmi.ptMinTrackSize.y = (440.0 * s) as i32;
            }
            LRESULT(0)
        }
        WM_DPICHANGED => {
            with(|f| {
                f.s = ((wp.0 >> 16) & 0xFFFF) as f32 / 96.0;
                f.thumbs.clear();
                f.lines.clear();
            });
            let r = &*(lp.0 as *const RECT);
            let _ = SetWindowPos(hwnd, None, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE);
            LRESULT(0)
        }
        analyze::WM_SCAN => {
            with(|f| {
                let changed = match &mut f.view {
                    View::Disk(d) => d.pump(),
                    View::Clean(c) => c.pump(hwnd),
                    View::Files => false,
                };
                if changed {
                    redraw(f);
                }
            });
            LRESULT(0)
        }
        WM_COPYDATA => {
            let cds = &*(lp.0 as *const windows::Win32::System::DataExchange::COPYDATASTRUCT);
            if cds.dwData != COPY_OPEN || cds.lpData.is_null() {
                return DefWindowProcW(hwnd, msg, wp, lp);
            }
            let text = String::from_utf16_lossy(std::slice::from_raw_parts(cds.lpData as *const u16, cds.cbData as usize / 2));
            let (place, sel) = text.split_once('\n').unwrap_or((&text, ""));
            let loc = if place.starts_with("::") { Loc::Computer } else { Loc::Dir(PathBuf::from(place)) };
            let sel = (!sel.is_empty()).then(|| PathBuf::from(sel));
            let found = with(|f| show_open(f, &loc, sel.as_deref())).unwrap_or(false);
            if found {
                if IsIconic(hwnd).as_bool() {
                    let _ = ShowWindow(hwnd, SW_RESTORE);
                }
                let _ = SetForegroundWindow(hwnd);
            }
            LRESULT(found as isize)
        }
        WM_DIRSIZE => {
            with(|f| {
                if let Some(rx) = &f.size_rx {
                    let got: Vec<(PathBuf, u64)> = rx.try_iter().collect();
                    for (p, n) in got {
                        if let Some(i) = f.info.as_mut().filter(|i| i.path == p) {
                            i.size = Some(n);
                        }
                    }
                }
                redraw(f);
            });
            LRESULT(0)
        }
        search::WM_FOUND => {
            with(|f| {
                take_found(f);
                redraw(f);
            });
            LRESULT(0)
        }
        thumbs::WM_THUMB => {
            with(|f| redraw(f));
            LRESULT(0)
        }
        WM_TIMER if wp.0 == TIMER_SCROLL => {
            with(|f| {
                let d = f.target - f.scroll;
                if d.abs() < 0.5 {
                    f.scroll = f.target;
                    let _ = KillTimer(Some(hwnd), TIMER_SCROLL);
                } else {
                    f.scroll += d * 0.3;
                }
                redraw(f);
            });
            LRESULT(0)
        }
        WM_TIMER if wp.0 == TIMER_ANIM => {
            with(|f| {
                let more = match &mut f.view {
                    View::Disk(d) => d.tick(),
                    _ => false,
                };
                if !more {
                    let _ = KillTimer(Some(hwnd), TIMER_ANIM);
                }
                redraw(f);
            });
            LRESULT(0)
        }
        WM_TIMER if wp.0 == TIMER_WATCH => {
            // папку поменяли снаружи (скачался файл, распаковался архив) — перечитываем
            with(|f| {
                let Some(h) = f.watch else { return };
                if WaitForSingleObject(h, 0) == WAIT_OBJECT_0 {
                    let _ = FindNextChangeNotification(h);
                    if f.edit.as_ref().is_none_or(|k| *k == EditKind::Search) {
                        load(f);
                        redraw(f);
                    }
                }
            });
            LRESULT(0)
        }
        WM_DEVICECHANGE => {
            // вставили или вынули флешку — обновляем список дисков
            with(|f| {
                let (fav, spots) = fs::places(f.fav_paths.as_deref());
                f.favorites = fav;
                f.spots = spots;
                if f.loc == Loc::Computer {
                    load(f);
                }
                redraw(f);
            });
            LRESULT(1)
        }
        WM_ACTIVATE => {
            if (wp.0 & 0xFFFF) as u32 != WA_INACTIVE {
                with(|f| {
                    if f.edit.is_none() {
                        let _ = SetFocus(Some(hwnd));
                    }
                });
            }
            LRESULT(0)
        }
        WM_MOUSELEAVE => {
            with(|f| {
                f.hover = Hit::None;
                redraw(f);
            });
            LRESULT(0)
        }
        WM_SETCURSOR => {
            let over_edit = with(|f| {
                let p = win::cursor();
                let mut c = p;
                let _ = ScreenToClient(hwnd, &mut c);
                matches!(hit(f, c.x, c.y), Hit::Search) && f.edit.is_none()
            });
            if over_edit == Some(true) {
                SetCursor(LoadCursorW(None, IDC_IBEAM).ok());
                return LRESULT(1);
            }
            DefWindowProcW(hwnd, msg, wp, lp)
        }
        WM_COMMAND => {
            // EN_CHANGE из поля поиска: фильтруем на лету
            if ((wp.0 >> 16) & 0xFFFF) as u32 == EN_CHANGE {
                with(|f| {
                    if f.edit == Some(EditKind::Search) {
                        f.query = edit_text(f.edit_hwnd);
                        f.target = 0.0;
                        f.scroll = 0.0;
                        restart_search(f);
                        reapply(f);
                        redraw(f);
                    }
                });
            }
            LRESULT(0)
        }
        WM_CTLCOLOREDIT => {
            let hdc = HDC(wp.0 as *mut c_void);
            if let Some(b) = with(|f| f.edit_brush) {
                SetTextColor(hdc, COLORREF(if gfx::theme().dark { 0x00F2F2F2 } else { 0x00000000 }));
                SetBkColor(hdc, COLORREF(b.0));
                return LRESULT(b.1 .0 as isize);
            }
            DefWindowProcW(hwnd, msg, wp, lp)
        }
        WM_EDIT_DONE => {
            if let Some(act) = with(|f| {
                let a = edit_done(f, wp.0);
                redraw(f);
                a
            }) {
                run_act(hwnd, act);
            }
            LRESULT(0)
        }
        shell::WM_DROP_HOVER => {
            with(|f| {
                f.drop_at = (lp.0 != 0).then(|| ((wp.0 & 0xFFFF) as i16 as i32, ((wp.0 >> 16) & 0xFFFF) as i16 as i32));
                if let Some((x, y)) = f.drop_at {
                    f.hover = hit(f, x, y);
                }
                redraw(f);
            });
            LRESULT(0)
        }
        shell::WM_DROPPED => {
            if let Some(d) = shell::DROPPED.with(|d| d.borrow_mut().take()) {
                if let Some(to) = drop_target_at(d.x, d.y) {
                    shell::transfer(hwnd, &d.paths, &to, d.moving);
                }
                with(|f| {
                    load(f);
                    redraw(f);
                });
            }
            LRESULT(0)
        }
        WM_MOUSEMOVE | WM_LBUTTONDOWN | WM_LBUTTONUP | WM_LBUTTONDBLCLK | WM_RBUTTONUP | WM_MOUSEWHEEL | WM_KEYDOWN | WM_SYSKEYDOWN | WM_CHAR
        | WM_XBUTTONUP | WM_MBUTTONUP => {
            if let Some(act) = with(|f| handle(f, msg, wp, lp)) {
                run_act(hwnd, act);
                return LRESULT(0);
            }
            DefWindowProcW(hwnd, msg, wp, lp)
        }
        WM_CLOSE => {
            with(|f| {
                if !IsIconic(hwnd).as_bool() && !IsZoomed(hwnd).as_bool() {
                    save_cfg(f);
                }
            });
            let _ = windows::Win32::System::Ole::RevokeDragDrop(hwnd);
            FINDER.with(|s| s.borrow_mut().take());
            let _ = DestroyWindow(hwnd);
            PostQuitMessage(0);
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

/// Кадр окна без показа — для проверки вёрстки; картинки грузятся сразу
pub fn preview(start: Loc, mode: &str, w: i32, h: i32) -> Option<Img> {
    let m = win::monitor_at(win::cursor());
    let mut f = new_finder(HWND::default(), m.scale, start, &Settings::load())?;
    f.cw = w;
    f.ch = h;
    load(&mut f);
    f.mode = if mode.contains("list") { Mode::List } else { Mode::Grid };
    if mode.contains("tabs") {
        for p in fs::known().into_iter().take(2) {
            f.tabs.push(Tab { loc: Loc::Dir(p.0), back: Vec::new(), fwd: Vec::new(), scroll: 0.0 });
        }
    }
    // «find=слово» — поиск по вложенным папкам, ждём его конца
    if let Some(q) = mode.split(',').find_map(|m| m.strip_prefix("find=")) {
        f.query = q.to_string();
        f.deep = true;
        restart_search(&mut f);
        if let Some(rx) = f.search_rx.take() {
            for b in rx.iter() {
                match b {
                    Batch::Found(v) => f.found.extend(v),
                    Batch::Done => break,
                }
            }
        }
        f.searching = false;
        reapply(&mut f);
    }
    if !f.items.is_empty() {
        let k = f.items.len().min(3);
        f.items[k - 1].sel = true;
    }
    let opt = |key: &str| mode.split(',').find_map(|m| m.strip_prefix(key)).and_then(|v| v.parse::<u8>().ok());
    if let Some(g) = opt("group=") {
        f.group = g;
        reapply(&mut f);
    }
    if let Some(v) = opt("filter=") {
        f.filter = v;
        reapply(&mut f);
    }
    if mode.contains("nopane") {
        f.pane = false;
    } else if mode.contains("pane") {
        f.pane = true;
    }
    if mode.contains("none") {
        clear_sel(&mut f);
    }
    if mode.contains("disk") {
        // disk,home — список дисков; disk[,seg=N][,collect[,confirm]] — диаграмма папки
        let here = f.dir().map(Path::to_path_buf);
        let root = here.clone().unwrap_or_else(|| PathBuf::from("C:\\"));
        let mut d = Disk::new(HWND::default(), (!mode.contains("home")).then_some(root), here);
        let a = Area { s: f.s, fonts: &f.fonts, x: SIDEBAR, y: f.top(), w: f.wl() - SIDEBAR, h: f.hl() - f.top() - STATUS };
        d.finish_for_preview(&a);
        if let Some(k) = opt("seg=") {
            d.preview_hover_seg(k as usize);
        }
        if mode.contains("collect") {
            d.preview_collect(3, mode.contains("confirm"));
        }
        f.view = View::Disk(Box::new(d));
    }
    if mode.contains("clean") {
        let mut c = Clean::new(HWND::default(), PathBuf::from("C:\\"));
        for _ in 0..1500 {
            c.pump(HWND::default());
            if c.junk.iter().all(|j| j.size.is_some()) {
                break;
            }
            std::thread::sleep(std::time::Duration::from_millis(40));
        }
        // «scan» — сразу проверить текущую папку на лишние файлы
        if let (true, Some(d)) = (mode.contains("scan"), f.dir()) {
            c.drive = d.to_path_buf();
            c.scan(HWND::default());
            for _ in 0..3000 {
                c.pump(HWND::default());
                if c.scanned {
                    break;
                }
                std::thread::sleep(std::time::Duration::from_millis(40));
            }
            c.scroll = 380.0;
        }
        f.view = View::Clean(Box::new(c));
    }
    prepare_pane(&mut f);
    if let Some(e) = f.items.iter().find(|e| e.sel).cloned() {
        if let Some(img) = win::shell_image(&e.path, pane_px(&f), false) {
            f.thumbs.insert((e.path, pane_px(&f)), Thumb::Ready(img));
        }
    }
    let spx = side_px(&f);
    let places: Vec<PathBuf> = f.favorites.iter().chain(f.spots.iter()).map(|p| place_path(&p.loc)).collect();
    for p in places {
        if let Some(img) = win::small_icon(&p, spx) {
            f.thumbs.insert((p, spx), Thumb::Ready(img));
        }
    }
    let g = grid(&f);
    let px = icon_px(&f);
    for i in visible(&f, &g, 0.0) {
        let e = f.items[i].clone();
        {
            let t = if px <= 40 { win::small_icon(&e.path, px) } else { win::shell_image(&e.path, px, false) };
            let t = t.map_or(Thumb::Failed, Thumb::Ready);
            f.thumbs.insert((e.path, px), t);
        }
    }
    if mode.contains("look") {
        if let Some(i) = f.items.iter().position(|e| !e.dir) {
            f.look = Some(Look { idx: i, text: fs::text_preview(&f.items[i].path), scroll: 0.0 });
            let p = f.items[i].path.clone();
            if let Some(img) = win::shell_image(&p, LOOK_PX, false) {
                f.thumbs.insert((p, LOOK_PX), Thumb::Ready(img));
            }
        }
    }
    // перенос имён без запроса миниатюр в пул
    let wkey = (g.tw * f.s) as u32;
    for i in visible(&f, &g, 0.0) {
        let lines = tile_lines(&f, &f.items[i], &g);
        f.lines.insert(f.items[i].path.clone(), (wkey, lines));
    }
    let mut img = Img::new(w as u32, h as u32);
    if let Some(mut pm) = img.pixmap_mut() {
        compose(&f, &mut pm);
    }
    Some(img)
}
