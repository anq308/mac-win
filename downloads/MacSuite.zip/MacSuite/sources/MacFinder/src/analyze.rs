//! «Анализ места» по образцу SquirrelDisk: выбираем диск или папку, диаграмма растёт прямо во время
//! сканирования, клик по сегменту плавно приближает его, справа — что внутри, внизу — сборщик:
//! перетащите туда сегменты или строки и удалите всё разом, в корзину или насовсем.
//! Системное и важные папки защищены (safety.rs).

use std::collections::{HashMap, HashSet};
use std::f32::consts::{FRAC_PI_2, TAU};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Instant;

use tiny_skia::{Color, PixmapMut};
use windows::core::PCWSTR;
use windows::Win32::Foundation::{HWND, LPARAM, WPARAM};
use windows::Win32::System::Com::{CoInitializeEx, COINIT_APARTMENTTHREADED};
use windows::Win32::UI::Shell::{SHFileOperationW, FOF_ALLOWUNDO, FOF_NOCONFIRMATION, FOF_NOERRORUI, FOF_SILENT, FO_DELETE, SHFILEOPSTRUCTW};
use windows::Win32::UI::WindowsAndMessaging::{PostMessageW, WM_APP};

use crate::fs;
use crate::gfx::{self, Area, Btn, Icon};
use crate::safety::{Rules, Verdict};
use crate::scan::{self, Scan};
use crate::tree::{Kind, Tree, NONE, ROOT};

pub const WM_SCAN: u32 = WM_APP + 24;
/// колец вокруг центра
const RINGS: usize = 5;
/// сегменты уже этого (в пикселях посередине кольца) собираются в «ещё N»
const MIN_PX: f32 = 4.0;
const MAX_SEGS: usize = 6000;
const GROUP: u64 = 1 << 40;
const FREE: u64 = u64::MAX - 1;
const TOP: f32 = 56.0;
const BIN_H: f32 = 56.0;
const ROW: f32 = 30.0;

/// Цветовой круг SquirrelDisk: цвет сегмента — по его месту на круге, вглубь светлее
const WHEEL: [(u8, u8, u8); 11] = [
    (0x39, 0x6B, 0xFF),
    (0x8B, 0x4D, 0xFF),
    (0xD9, 0x46, 0xEF),
    (0xFF, 0x4F, 0x9A),
    (0xFF, 0x70, 0x5A),
    (0xFF, 0xB3, 0x47),
    (0xFF, 0xE4, 0x5C),
    (0xB8, 0xF0, 0x4A),
    (0x4C, 0xE0, 0x6A),
    (0x2F, 0xD8, 0xC0),
    (0x3A, 0xC8, 0xFF),
];

type Rgb = (f32, f32, f32);

fn rgb8(c: (u8, u8, u8)) -> Rgb {
    (c.0 as f32 / 255.0, c.1 as f32 / 255.0, c.2 as f32 / 255.0)
}

fn color(c: Rgb, a: f32) -> Color {
    Color::from_rgba(c.0.clamp(0.0, 1.0), c.1.clamp(0.0, 1.0), c.2.clamp(0.0, 1.0), a.clamp(0.0, 1.0)).unwrap_or(Color::BLACK)
}

fn mix(a: Rgb, b: Rgb, t: f32) -> Rgb {
    (a.0 + (b.0 - a.0) * t, a.1 + (b.1 - a.1) * t, a.2 + (b.2 - a.2) * t)
}

fn to_hsl(c: Rgb) -> (f32, f32, f32) {
    let (mx, mn) = (c.0.max(c.1).max(c.2), c.0.min(c.1).min(c.2));
    let l = (mx + mn) / 2.0;
    if mx == mn {
        return (0.0, 0.0, l);
    }
    let d = mx - mn;
    let s = if l > 0.5 { d / (2.0 - mx - mn) } else { d / (mx + mn) };
    let h = if mx == c.0 {
        (c.1 - c.2) / d + if c.1 < c.2 { 6.0 } else { 0.0 }
    } else if mx == c.1 {
        (c.2 - c.0) / d + 2.0
    } else {
        (c.0 - c.1) / d + 4.0
    };
    (h / 6.0, s, l)
}

fn from_hsl(h: f32, s: f32, l: f32) -> Rgb {
    if s == 0.0 {
        return (l, l, l);
    }
    let q = if l < 0.5 { l * (1.0 + s) } else { l + s - l * s };
    let p = 2.0 * l - q;
    let f = |t: f32| {
        let t = t.rem_euclid(1.0);
        if t < 1.0 / 6.0 {
            p + (q - p) * 6.0 * t
        } else if t < 0.5 {
            q
        } else if t < 2.0 / 3.0 {
            p + (q - p) * (2.0 / 3.0 - t) * 6.0
        } else {
            p
        }
    };
    (f(h + 1.0 / 3.0), f(h), f(h - 1.0 / 3.0))
}

fn wheel_at(t: f32) -> Rgb {
    let x = t.rem_euclid(1.0) * WHEEL.len() as f32;
    let i = x.floor() as usize % WHEEL.len();
    mix(rgb8(WHEEL[i]), rgb8(WHEEL[(i + 1) % WHEEL.len()]), x.fract())
}

/// Цвет сегмента по середине его дуги (0..1) и глубине; файлы чуть бледнее папок
fn seg_color(mid: f32, depth: u8, file: bool) -> Rgb {
    let (h, s, l) = to_hsl(wheel_at(mid));
    let d = depth.saturating_sub(1) as f32;
    let step = if gfx::theme().dark { 0.03 } else { -0.025 };
    let (mut l2, mut s2) = (l + d * step, s * (1.0 - d * 0.025));
    if file {
        l2 += 0.04 * step.signum();
        s2 *= 0.85;
    }
    from_hsl(h, s2, l2.clamp(0.12, 0.88))
}

fn bg() -> Rgb {
    if gfx::theme().dark {
        rgb8((0x19, 0x19, 0x19))
    } else {
        rgb8((0xFF, 0xFF, 0xFF))
    }
}

/// «помельче» и «ещё N» — чуть темнее фона
fn aggregate() -> Rgb {
    if gfx::theme().dark {
        rgb8((0x3A, 0x38, 0x42))
    } else {
        rgb8((0xD9, 0xD7, 0xDF))
    }
}

fn free_color() -> Rgb {
    if gfx::theme().dark {
        rgb8((0x2C, 0x2C, 0x31))
    } else {
        rgb8((0xEE, 0xEE, 0xF1))
    }
}

fn hidden_color() -> Rgb {
    mix(rgb8((0x6E, 0x60, 0x82)), bg(), 0.35)
}

fn green() -> Color {
    if gfx::theme().dark {
        gfx::rgb(0x6C, 0xCB, 0x5F, 1.0)
    } else {
        gfx::rgb(0x10, 0x7C, 0x10, 1.0)
    }
}

fn amber() -> Color {
    gfx::rgb(0xFF, 0xB3, 0x47, 1.0)
}

/// 1 234 567 — или коротко, пока число быстро растёт: 125 тыс., 1,25 млн
fn count_text(n: u64, compact: bool) -> String {
    if compact && n >= 1_000_000 {
        format!("{:.2} млн", n as f64 / 1e6).replace('.', ",")
    } else if compact && n >= 10_000 {
        format!("{} тыс.", n / 1000)
    } else {
        let s = n.to_string();
        let mut out = String::new();
        for (i, c) in s.chars().enumerate() {
            if i > 0 && (s.len() - i) % 3 == 0 {
                out.push('\u{202F}');
            }
            out.push(c);
        }
        out
    }
}

fn files_word(n: u64) -> String {
    fs::plural(n as usize, ["файл", "файла", "файлов"]).replacen(&n.to_string(), &count_text(n, false), 1)
}

pub fn node_label(t: &Tree, id: u32) -> String {
    let n = t.get(id);
    match n.kind {
        Kind::Small => format!("{} помельче", files_word(n.files as u64)),
        _ => n.name.to_string(),
    }
}

fn ease(t: f32) -> f32 {
    let t = t.clamp(0.0, 1.0);
    1.0 - (1.0 - t).powi(3)
}

// ---------- раскладка диаграммы ----------

/// Что в центре диаграммы: узел или «ещё N» — его дети начиная с номера skip
#[derive(Clone, Copy, PartialEq, Debug)]
struct ViewAt {
    node: u32,
    skip: usize,
}

impl ViewAt {
    fn of(node: u32) -> ViewAt {
        ViewAt { node, skip: 0 }
    }
    fn key(&self) -> u64 {
        if self.skip > 0 {
            group_key(self.node, self.skip)
        } else {
            self.node as u64
        }
    }
}

fn group_key(parent: u32, skip: usize) -> u64 {
    GROUP | (skip as u64) << 42 | parent as u64
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum SegKind {
    Node(Kind),
    Group { parent: u32, skip: usize, count: usize },
    Free,
}

struct Seg {
    key: u64,
    node: u32,
    kind: SegKind,
    a0: f32,
    a1: f32,
    depth: u8,
    color: Rgb,
    size: u64,
}

#[derive(Clone, Copy, PartialEq)]
struct Geo {
    cx: f32,
    cy: f32,
    r0: f32,
    ring: f32,
}

impl Geo {
    fn new(cx: f32, cy: f32, radius: f32) -> Geo {
        let r0 = radius * 0.2;
        Geo { cx, cy, r0, ring: (radius - r0) / RINGS as f32 }
    }
    /// Внутренний и внешний радиус для глубины d (дробной — во время анимации):
    /// 0 — центральный круг, 1 — первое кольцо
    fn radii(&self, d: f32) -> (f32, f32) {
        let d = d.max(0.0);
        let inner = self.r0 * d.min(1.0) + (d - 1.0).max(0.0) * self.ring;
        let thick = self.r0 + (self.ring - self.r0) * d.min(1.0);
        (inner, inner + thick)
    }
    /// Расстояние от центра и угол по часовой от «12 часов»
    fn polar(&self, x: f32, y: f32) -> (f32, f32) {
        let (dx, dy) = (x - self.cx, y - self.cy);
        ((dx * dx + dy * dy).sqrt(), dx.atan2(-dy).rem_euclid(TAU))
    }
}

fn view_children(t: &Tree, v: ViewAt) -> (Vec<u32>, u64) {
    let mut kids = t.sorted(v.node);
    if v.skip > 0 {
        kids = kids.split_off(v.skip.min(kids.len()));
        let total = kids.iter().map(|k| t.get(*k).size).sum();
        (kids, total)
    } else {
        let sum: u64 = kids.iter().map(|k| t.get(*k).size).sum();
        (kids, t.get(v.node).size.max(sum))
    }
}

/// Сегменты для вида; free — свободное место последним куском первого кольца (у корня диска)
fn layout(t: &Tree, v: ViewAt, g: &Geo, free: u64) -> Vec<Seg> {
    let mut out = Vec::with_capacity(512);
    if !t.alive(v.node) {
        return out;
    }
    let (kids, total) = view_children(t, v);
    let center = if v.skip > 0 { SegKind::Group { parent: v.node, skip: v.skip, count: kids.len() } } else { SegKind::Node(t.get(v.node).kind) };
    out.push(Seg { key: v.key(), node: v.node, kind: center, a0: 0.0, a1: TAU, depth: 0, color: aggregate(), size: total });
    if total == 0 {
        return out;
    }
    let whole = total + free;
    if free > 0 {
        let a0 = TAU * (total as f64 / whole as f64) as f32;
        out.push(Seg { key: FREE, node: v.node, kind: SegKind::Free, a0, a1: TAU, depth: 1, color: free_color(), size: free });
    }
    // обход в глубину без рекурсии: (дети, с какого номера, размер родителя, начало, ширина, глубина)
    let mut stack: Vec<(Vec<u32>, usize, u64, f32, f32, u8)> = vec![(kids, v.skip, whole, 0.0, TAU, 1)];
    while let Some((items, base, parent_size, a0, span, depth)) = stack.pop() {
        if out.len() > MAX_SEGS {
            break;
        }
        let (r_in, r_out) = g.radii(depth as f32);
        let min_angle = MIN_PX / ((r_in + r_out) * 0.5).max(1.0);
        let parent = items.first().map_or(NONE, |c| t.get(*c).parent);
        let mut a = a0;
        for (i, &c) in items.iter().enumerate() {
            let n = t.get(c);
            let ang = span * (n.size as f64 / parent_size.max(1) as f64) as f32;
            if ang < min_angle && i + 1 < items.len() {
                // хвост из мелочи — одним сегментом «ещё N»
                let rest: u64 = items[i..].iter().map(|k| t.get(*k).size).sum();
                let ang_rest = span * (rest as f64 / parent_size.max(1) as f64) as f32;
                if ang_rest >= min_angle * 0.6 {
                    let skip = base + i;
                    out.push(Seg {
                        key: group_key(parent, skip),
                        node: parent,
                        kind: SegKind::Group { parent, skip, count: items.len() - i },
                        a0: a,
                        a1: a + ang_rest,
                        depth,
                        color: aggregate(),
                        size: rest,
                    });
                }
                break;
            }
            if ang < min_angle * 0.25 {
                break;
            }
            let mid = (a + ang * 0.5) / TAU;
            let col = match n.kind {
                Kind::Dir => seg_color(mid, depth, false),
                Kind::File => seg_color(mid, depth, true),
                Kind::Small => aggregate(),
                Kind::Hidden => hidden_color(),
            };
            out.push(Seg { key: c as u64, node: c, kind: SegKind::Node(n.kind), a0: a, a1: a + ang, depth, color: col, size: n.size });
            if t.can_enter(c) && (depth as usize) < RINGS && ang > min_angle * 1.5 {
                stack.push((t.sorted(c), 0, n.size.max(1), a, ang, depth + 1));
            }
            a += ang;
        }
    }
    out
}

// ---------- анимация: каждый сегмент плавно перетекает к новому месту ----------

struct Anim {
    key: u64,
    node: u32,
    kind: SegKind,
    a0: f32,
    a1: f32,
    d: f32,
    color: Rgb,
    alpha: f32,
    grow: f32,
    hover: f32,
    alive: bool,
    size: u64,
    to: (f32, f32, f32, Rgb),
}

#[derive(Default)]
struct Animator {
    anims: HashMap<u64, Anim>,
    /// порядок рисования: внутренние кольца раньше
    order: Vec<u64>,
    moving: bool,
}

impl Animator {
    fn set_target(&mut self, segs: &[Seg], intro: bool) {
        for a in self.anims.values_mut() {
            a.alive = false;
        }
        self.order.clear();
        for s in segs {
            self.order.push(s.key);
            if let Some(a) = self.anims.get_mut(&s.key) {
                a.alive = true;
                a.kind = s.kind;
                a.node = s.node;
                a.size = s.size;
                a.to = (s.a0, s.a1, s.depth as f32, s.color);
            } else {
                // при первом показе кольца вырастают по очереди, от центра наружу и по часовой
                let delay = if intro { -0.12 * s.depth as f32 - 0.25 * (s.a0 / TAU) } else { 0.0 };
                self.anims.insert(
                    s.key,
                    Anim {
                        key: s.key,
                        node: s.node,
                        kind: s.kind,
                        a0: s.a0,
                        a1: s.a1,
                        d: s.depth as f32,
                        color: s.color,
                        alpha: 0.0,
                        grow: delay,
                        hover: 0.0,
                        alive: true,
                        size: s.size,
                        to: (s.a0, s.a1, s.depth as f32, s.color),
                    },
                );
            }
        }
        self.moving = true;
    }

    /// Шаг анимации; true — что-то ещё движется
    fn step(&mut self, dt: f32, hovered: Option<u64>) -> bool {
        let k = 1.0 - (-dt * 11.0).exp();
        let kh = 1.0 - (-dt * 18.0).exp();
        let mut moving = false;
        self.anims.retain(|_, a| a.alive || a.alpha > 0.01);
        for a in self.anims.values_mut() {
            let h = if Some(a.key) == hovered { 1.0 } else { 0.0 };
            a.hover += (h - a.hover) * kh;
            if (a.hover - h).abs() > 0.01 {
                moving = true;
            }
            if a.alive {
                let (t0, t1, td, tc) = a.to;
                a.a0 += (t0 - a.a0) * k;
                a.a1 += (t1 - a.a1) * k;
                a.d += (td - a.d) * k;
                a.color = mix(a.color, tc, (k * 1.2).min(1.0));
                a.alpha += (1.0 - a.alpha) * k;
                a.grow = (a.grow + dt * 2.6).min(1.0);
                if (t0 - a.a0).abs() > 1e-4 || (t1 - a.a1).abs() > 1e-4 || (td - a.d).abs() > 1e-3 || a.alpha < 0.995 || a.grow < 1.0 {
                    moving = true;
                }
            } else {
                a.alpha = (a.alpha - a.alpha * k * 1.4 - dt * 0.5).max(0.0);
                moving = true;
            }
        }
        self.moving = moving;
        moving
    }

    /// Сразу в конечное состояние — для картинки --preview
    fn settle(&mut self) {
        self.anims.retain(|_, a| a.alive);
        for a in self.anims.values_mut() {
            (a.a0, a.a1, a.d, a.color) = a.to;
            a.alpha = 1.0;
            a.grow = 1.0;
        }
        self.moving = false;
    }

    fn draw_list(&self) -> Vec<&Anim> {
        let mut v: Vec<&Anim> = self.anims.values().filter(|a| !a.alive && a.alpha > 0.01).collect();
        v.extend(self.order.iter().filter_map(|k| self.anims.get(k)));
        v
    }

    fn hit(&self, g: &Geo, x: f32, y: f32) -> Option<&Anim> {
        let (r, ang) = g.polar(x, y);
        for key in self.order.iter().rev() {
            let Some(a) = self.anims.get(key) else { continue };
            if a.alpha < 0.3 {
                continue;
            }
            let (r0, r1) = g.radii(a.d);
            let r1 = r0 + (r1 - r0) * ease(a.grow);
            if r < r0 || r > r1 {
                continue;
            }
            if a.d < 0.5 || (ang >= a.a0 && ang < a.a1) {
                return Some(a);
            }
        }
        None
    }
}

// ---------- удаление ----------

struct Deleting {
    trash: bool,
    total: usize,
    done: AtomicUsize,
    freed: AtomicU64,
    current: Mutex<String>,
    /// узел и получилось ли
    results: Mutex<Vec<(u32, bool, u64)>>,
    finished: AtomicBool,
}

/// В корзину одним объектом, без окон Windows (подтверждение уже спросили мы)
fn recycle_one(p: &Path) -> bool {
    let mut from: Vec<u16> = p.to_string_lossy().encode_utf16().collect();
    from.extend([0, 0]);
    let mut op = SHFILEOPSTRUCTW {
        wFunc: FO_DELETE,
        pFrom: PCWSTR(from.as_ptr()),
        fFlags: (FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI).0 as u16,
        ..Default::default()
    };
    let r = unsafe { SHFileOperationW(&mut op) };
    r == 0 && !op.fAnyOperationsAborted.as_bool() && !p.exists()
}

/// Удалить насовсем; «только чтение» снимаем, ссылки удаляем, а не то, куда они ведут
fn remove_all(p: &Path) -> bool {
    let Ok(md) = std::fs::symlink_metadata(p) else { return !p.exists() };
    let clear = |p: &Path, md: &std::fs::Metadata| {
        let mut perm = md.permissions();
        if perm.readonly() {
            #[allow(clippy::permissions_set_readonly_false)]
            perm.set_readonly(false);
            let _ = std::fs::set_permissions(p, perm);
        }
    };
    if md.is_dir() && !md.file_type().is_symlink() {
        if let Ok(rd) = std::fs::read_dir(p) {
            for e in rd.flatten() {
                remove_all(&e.path());
            }
        }
        clear(p, &md);
        std::fs::remove_dir(p).is_ok()
    } else {
        clear(p, &md);
        std::fs::remove_file(p).is_ok() || (md.is_dir() && std::fs::remove_dir(p).is_ok())
    }
}

// ---------- сам вид ----------

#[derive(Clone, PartialEq, Debug)]
pub enum DHit {
    None,
    /// карточка диска на стартовом экране
    Drive(usize),
    Pick,
    Here,
    Back,
    Crumb(u32),
    Rescan,
    Reveal,
    Seg(u64),
    Row(u32),
    More(u32, usize),
    Bin,
    BinDelete,
    BinClear,
    BinRemove(u32),
    EmptyBin,
    ModalMode(bool),
    ModalAck,
    ModalCancel,
    ModalOk,
    Modal,
}

/// Что окну сделать после события
pub enum Out {
    None,
    Reveal(PathBuf),
    Go(PathBuf),
    Menu(u32),
    Pick,
    EmptyBin(PathBuf),
}

struct ConfirmItem {
    node: u32,
    name: String,
    size: u64,
    verdict: Verdict,
}

struct Confirm {
    items: Vec<ConfirmItem>,
    trash: bool,
    ack: bool,
}

impl Confirm {
    fn caution(&self) -> bool {
        self.items.iter().any(|i| matches!(i.verdict, Verdict::Caution(_)))
    }
    fn allowed(&self) -> impl Iterator<Item = &ConfirmItem> {
        self.items.iter().filter(|i| !matches!(i.verdict, Verdict::Forbidden(_)))
    }
    fn ready(&self) -> bool {
        self.allowed().next().is_some() && (self.ack || !self.caution())
    }
}

struct Session {
    root: PathBuf,
    title: String,
    scan: Scan,
    view: ViewAt,
    back: Vec<ViewAt>,
    /// что показывает список справа: вид или то, что под курсором на диаграмме
    panel: ViewAt,
    anim: Animator,
    laid: Option<(u64, ViewAt, u64, [i32; 3])>,
    collected: Vec<u32>,
    deleting: Option<Arc<Deleting>>,
    /// итог удаления: текст, получилось ли, сколько ушло в корзину
    note: Option<(String, bool, u64)>,
}

struct Drag {
    node: u32,
    color: Rgb,
    label: String,
    size: u64,
}

pub struct Disk {
    hwnd: isize,
    drives: Vec<fs::Drive>,
    here: Option<PathBuf>,
    sess: Option<Session>,
    home: bool,
    pub hover: DHit,
    press: Option<(f32, f32, DHit)>,
    drag: Option<Drag>,
    mouse: (f32, f32),
    bin_open: bool,
    modal: Option<Confirm>,
    geo: Geo,
    area: [f32; 4],
    /// хлебные крошки с прошлой отрисовки — для попадания мышью
    crumbs: Vec<(u32, String, [f32; 4])>,
    last: Instant,
    rules: Rules,
}

fn inside(r: [f32; 4], x: f32, y: f32) -> bool {
    x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]
}

impl Disk {
    /// root — сразу сканировать эту папку; иначе — стартовый экран с дисками
    pub fn new(hwnd: HWND, root: Option<PathBuf>, here: Option<PathBuf>) -> Disk {
        let mut d = Disk {
            hwnd: hwnd.0 as isize,
            drives: fs::drives().into_iter().filter(|d| d.space.is_some()).collect(),
            here,
            sess: None,
            home: true,
            hover: DHit::None,
            press: None,
            drag: None,
            mouse: (0.0, 0.0),
            bin_open: false,
            modal: None,
            geo: Geo::new(0.0, 0.0, 100.0),
            area: [0.0; 4],
            crumbs: Vec::new(),
            last: Instant::now(),
            rules: Rules::current(),
        };
        if let Some(r) = root {
            d.start(r);
        }
        d
    }

    fn hwnd(&self) -> HWND {
        HWND(self.hwnd as *mut _)
    }

    /// Сканировать диск или папку; прошлое сканирование бросаем
    pub fn start(&mut self, root: PathBuf) {
        self.stop();
        let title = match self.drives.iter().find(|d| d.root == root) {
            Some(d) => d.label.clone(),
            None => fs::display_name(&root),
        };
        let scan = scan::start(self.hwnd(), root.clone(), &title);
        let v = ViewAt::of(ROOT);
        self.sess = Some(Session {
            root,
            title,
            scan,
            view: v,
            back: Vec::new(),
            panel: v,
            anim: Animator::default(),
            laid: None,
            collected: Vec::new(),
            deleting: None,
            note: None,
        });
        self.home = false;
        self.bin_open = false;
        self.modal = None;
        self.hover = DHit::None;
    }

    pub fn show_home(&mut self) {
        self.home = true;
        self.drives = fs::drives().into_iter().filter(|d| d.space.is_some()).collect();
        self.hover = DHit::None;
    }

    pub fn stop(&self) {
        if let Some(s) = &self.sess {
            s.scan.stop();
        }
    }

    pub fn scanning(&self) -> bool {
        self.sess.as_ref().is_some_and(|s| !s.scan.progress.done())
    }

    /// Папка в центре диаграммы — для «Открыть в Finder»
    pub fn focus_path(&self) -> Option<PathBuf> {
        let s = self.sess.as_ref()?;
        let t = s.scan.tree.read().ok()?;
        Some(t.path(s.view.node))
    }

    pub fn status(&self) -> String {
        if self.home {
            return "Выберите диск или папку — посмотрим, что занимает место".into();
        }
        let Some(s) = &self.sess else { return String::new() };
        if !s.scan.progress.done() {
            let p = &s.scan.progress;
            return format!(
                "Сканируем… {} · {} · диаграмма растёт прямо сейчас",
                files_word(p.files.load(Ordering::Relaxed)),
                fs::size_text(p.bytes.load(Ordering::Relaxed))
            );
        }
        "Клик — внутрь, по центру — назад · перетащите сегмент или строку в сборщик внизу · правый клик — меню · Esc — назад".into()
    }

    /// Забрать то, что прислали сканер и удаление; true — перерисовать
    pub fn pump(&mut self) -> bool {
        let Some(s) = &mut self.sess else { return false };
        if let Some(del) = s.deleting.clone() {
            if del.finished.load(Ordering::Relaxed) {
                let results = std::mem::take(&mut *del.results.lock().unwrap());
                let (mut ok, mut bytes, mut failed) = (0, 0, 0);
                {
                    let mut t = s.scan.tree.write().unwrap();
                    for (node, good, size) in &results {
                        if *good {
                            t.remove(*node);
                            ok += 1;
                            bytes += size;
                        } else {
                            failed += 1;
                        }
                    }
                }
                let gone: HashSet<u32> = results.iter().filter(|r| r.1).map(|r| r.0).collect();
                s.collected.retain(|n| !gone.contains(n));
                let what = fs::plural(ok, ["объект", "объекта", "объектов"]);
                let mut text = if del.trash {
                    format!("В корзине {what} · {} — место освободится, когда очистите её", fs::size_text(bytes))
                } else {
                    format!("Удалено {what} — освобождено {}", fs::size_text(bytes))
                };
                if failed > 0 {
                    text += &format!(" · не удалось: {failed}");
                }
                s.note = Some((text, failed == 0, if del.trash { bytes } else { 0 }));
                s.deleting = None;
                // вид мог указывать на удалённое — поднимаемся до живого
                let t = s.scan.tree.read().unwrap();
                while !t.alive(s.view.node) {
                    s.view = s.back.pop().unwrap_or(ViewAt::of(ROOT));
                }
                s.back.retain(|v| t.alive(v.node));
                s.panel = s.view;
            }
        }
        true
    }

    /// Пересчитать раскладку под размер области; зовётся перед каждой отрисовкой
    pub fn prepare(&mut self, a: &Area) {
        self.area = [a.x, a.y, a.w, a.h];
        self.crumbs = self.crumbs(a);
        let c = self.chart_rect();
        let radius = (c[2].min(c[3]) / 2.0 - 6.0).max(40.0);
        self.geo = Geo::new(c[0] + c[2] / 2.0, c[1] + c[3] / 2.0, radius);
        let g = self.geo;
        let Some(s) = &mut self.sess else { return };
        let t = s.scan.tree.read().unwrap();
        let free = if s.scan.volume && s.view == ViewAt::of(ROOT) && s.scan.progress.done() {
            scan::volume_space(&s.root).map_or(0, |(_, avail)| avail)
        } else {
            0
        };
        let key = (t.version, s.view, free, [g.cx as i32, g.cy as i32, radius as i32]);
        if s.laid != Some(key) {
            let segs = layout(&t, s.view, &g, free);
            let intro = s.anim.anims.is_empty();
            s.anim.set_target(&segs, intro);
            s.laid = Some(key);
        }
    }

    pub fn animating(&self) -> bool {
        self.sess.as_ref().is_some_and(|s| s.anim.moving) && !self.home
    }

    /// Кадр анимации; true — ещё не закончилась
    pub fn tick(&mut self) -> bool {
        let dt = self.last.elapsed().as_secs_f32().clamp(0.001, 0.05);
        self.last = Instant::now();
        let hl = self.highlight();
        let Some(s) = &mut self.sess else { return false };
        s.anim.step(dt, hl)
    }

    /// Подготовить кадр для --preview: досканировать и убрать анимацию
    pub fn finish_for_preview(&mut self, a: &Area) {
        while self.scanning() {
            std::thread::sleep(std::time::Duration::from_millis(30));
        }
        self.prepare(a);
        if let Some(s) = &mut self.sess {
            s.anim.settle();
        }
    }

    /// Для --preview: собрать n самых крупных объектов в центре и, если нужно, спросить об удалении
    pub fn preview_collect(&mut self, n: usize, confirm: bool) {
        let kids = match &self.sess {
            Some(s) => s.scan.tree.read().unwrap().sorted(s.view.node),
            None => return,
        };
        for k in kids.into_iter().take(n) {
            self.collect(k);
        }
        if confirm {
            self.open_confirm();
        }
    }

    pub fn preview_hover_seg(&mut self, i: usize) {
        if let Some(s) = &mut self.sess {
            let kids = s.scan.tree.read().unwrap().sorted(s.view.node);
            if let Some(&k) = kids.get(i) {
                self.hover = DHit::Seg(k as u64);
                self.update_panel();
            }
        }
    }

    // ---------- геометрия областей ----------

    fn bin_rect(&self) -> [f32; 4] {
        let [x, y, w, h] = self.area;
        [x + 16.0, y + h - BIN_H - 12.0, w - 32.0, BIN_H]
    }

    fn panel_rect(&self) -> [f32; 4] {
        let [x, y, w, _] = self.area;
        let pw = (w * 0.36).clamp(250.0, 340.0);
        let b = self.bin_rect();
        [x + w - 16.0 - pw, y + TOP + 4.0, pw, b[1] - 12.0 - (y + TOP + 4.0)]
    }

    fn chart_rect(&self) -> [f32; 4] {
        let [x, y, _, _] = self.area;
        let p = self.panel_rect();
        let b = self.bin_rect();
        [x + 16.0, y + TOP, p[0] - 24.0 - (x + 16.0), b[1] - 8.0 - (y + TOP)]
    }

    fn top_buttons(&self) -> Vec<(DHit, [f32; 4], &'static str)> {
        let [x, y, w, _] = self.area;
        let right = x + w - 16.0;
        let mut out = vec![(DHit::Back, [x + 14.0, y + 13.0, 30.0, 30.0], "")];
        if self.sess.as_ref().is_some_and(|s| s.scan.progress.done()) {
            out.push((DHit::Rescan, [right - 130.0, y + 13.0, 130.0, 30.0], "Пересканировать"));
            out.push((DHit::Reveal, [right - 130.0 - 10.0 - 140.0, y + 13.0, 140.0, 30.0], "Открыть в Finder"));
        }
        out
    }

    /// Хлебные крошки: узел и его прямоугольник
    fn crumbs(&self, a: &Area) -> Vec<(u32, String, [f32; 4])> {
        let Some(s) = &self.sess else { return Vec::new() };
        let t = s.scan.tree.read().unwrap();
        if !t.alive(s.view.node) {
            return Vec::new();
        }
        let chain = t.ancestry(s.view.node);
        let mut names: Vec<(u32, String)> =
            chain.iter().map(|&id| (id, if id == ROOT { s.title.clone() } else { node_label(&t, id) })).collect();
        if s.view.skip > 0 {
            let count = t.children(s.view.node).count().saturating_sub(s.view.skip);
            names.push((NONE, format!("ещё {}", fs::plural(count, ["объект", "объекта", "объектов"]))));
        }
        let px = 13.5 * a.s;
        let [x, y, w, _] = self.area;
        let room = (w - 54.0 - 310.0 - 20.0).max(120.0);
        let sep = 22.0;
        let width = |n: &str| (gfx::measure(&a.fonts.semibold, &gfx::fit(&a.fonts.semibold, n, px, 220.0 * a.s), px) / a.s).ceil();
        // не влезает — убираем крошки с начала, оставляя корень
        while names.len() > 2 && names.iter().map(|(_, n)| width(n) + sep).sum::<f32>() > room {
            names.remove(1);
        }
        let mut out = Vec::new();
        let mut cx = x + 54.0;
        for (id, n) in names {
            let wv = width(&n);
            out.push((id, n, [cx, y + 13.0, wv, 30.0]));
            cx += wv + sep;
        }
        out
    }

    fn home_cards(&self) -> Vec<(DHit, [f32; 4])> {
        let [x, y, w, _] = self.area;
        let cw = (w - 64.0).min(900.0);
        let x0 = x + 32.0;
        let cols = if cw > 620.0 { 2 } else { 1 };
        let gap = 14.0;
        let card_w = (cw - gap * (cols as f32 - 1.0)) / cols as f32;
        let mut out = Vec::new();
        let mut cy = y + 118.0;
        for i in 0..self.drives.len() {
            let (c, r) = (i % cols, i / cols);
            out.push((DHit::Drive(i), [x0 + c as f32 * (card_w + gap), cy + r as f32 * (96.0 + gap), card_w, 96.0]));
        }
        cy += self.drives.len().div_ceil(cols) as f32 * (96.0 + gap) + 44.0;
        let mut k = 0;
        if self.here.is_some() {
            out.push((DHit::Here, [x0, cy, card_w, 76.0]));
            k += 1;
        }
        let (c, r) = (k % cols, k / cols);
        out.push((DHit::Pick, [x0 + c as f32 * (card_w + gap), cy + r as f32 * (76.0 + gap), card_w, 76.0]));
        out
    }

    fn modal_rect(&self) -> [f32; 4] {
        let [x, y, w, h] = self.area;
        let Some(m) = &self.modal else { return [0.0; 4] };
        let rows = m.items.len().min(6) as f32 + if m.items.len() > 6 { 1.0 } else { 0.0 };
        let mh = 76.0 + rows * 32.0 + 16.0 + 64.0 + if m.caution() { 34.0 } else { 0.0 } + 64.0;
        let mw = (w - 80.0).min(540.0);
        [x + (w - mw) / 2.0, y + ((h - mh) / 2.0).max(10.0), mw, mh]
    }

    /// Кнопки окна подтверждения
    fn modal_parts(&self) -> Vec<(DHit, [f32; 4])> {
        let Some(m) = &self.modal else { return Vec::new() };
        let r = self.modal_rect();
        let rows = m.items.len().min(6) as f32 + if m.items.len() > 6 { 1.0 } else { 0.0 };
        let mut y = r[1] + 76.0 + rows * 32.0 + 16.0;
        let mut out = vec![
            (DHit::ModalMode(true), [r[0] + 20.0, y, r[2] - 40.0, 30.0]),
            (DHit::ModalMode(false), [r[0] + 20.0, y + 32.0, r[2] - 40.0, 30.0]),
        ];
        y += 64.0;
        if m.caution() {
            out.push((DHit::ModalAck, [r[0] + 20.0, y, r[2] - 40.0, 30.0]));
        }
        let by = r[1] + r[3] - 52.0;
        out.push((DHit::ModalOk, [r[0] + r[2] - 20.0 - 150.0, by, 150.0, 34.0]));
        out.push((DHit::ModalCancel, [r[0] + r[2] - 20.0 - 150.0 - 10.0 - 110.0, by, 110.0, 34.0]));
        out
    }

    fn bin_parts(&self) -> Vec<(DHit, [f32; 4])> {
        let b = self.bin_rect();
        let mut out = Vec::new();
        let Some(s) = &self.sess else { return out };
        if !s.collected.is_empty() && s.deleting.is_none() {
            out.push((DHit::BinDelete, [b[0] + b[2] - 14.0 - 130.0, b[1] + (BIN_H - 34.0) / 2.0, 130.0, 34.0]));
        } else if s.note.as_ref().is_some_and(|n| n.2 > 0) && s.deleting.is_none() {
            out.push((DHit::EmptyBin, [b[0] + b[2] - 14.0 - 160.0, b[1] + (BIN_H - 34.0) / 2.0, 160.0, 34.0]));
        }
        if self.bin_open {
            let p = self.popover_rect();
            out.push((DHit::BinClear, [p[0] + p[2] - 96.0, p[1] + 8.0, 84.0, 26.0]));
            for (k, &n) in s.collected.iter().take(8).enumerate() {
                out.push((DHit::BinRemove(n), [p[0] + p[2] - 36.0, p[1] + 44.0 + k as f32 * 40.0 + 6.0, 24.0, 24.0]));
            }
        }
        out
    }

    fn popover_rect(&self) -> [f32; 4] {
        let b = self.bin_rect();
        let n = self.sess.as_ref().map_or(0, |s| s.collected.len().min(8));
        let h = 48.0 + n as f32 * 40.0 + if self.sess.as_ref().is_some_and(|s| s.collected.len() > 8) { 26.0 } else { 0.0 };
        let w = b[2].min(560.0);
        [b[0], b[1] - h - 8.0, w, h]
    }

    /// Строки списка справа: узел и прямоугольник; последней может быть «ещё N»
    fn rows(&self) -> (Vec<(u32, [f32; 4])>, Option<(usize, u64, ViewAt, [f32; 4])>) {
        let Some(s) = &self.sess else { return (Vec::new(), None) };
        let t = s.scan.tree.read().unwrap();
        if !t.alive(s.panel.node) {
            return (Vec::new(), None);
        }
        let (kids, _) = view_children(&t, s.panel);
        let p = self.panel_rect();
        let top = p[1] + 72.0;
        let foot = if s.scan.volume && s.panel == ViewAt::of(ROOT) { 64.0 } else { 30.0 };
        let max = (((p[1] + p[3] - foot - top) / ROW).floor() as usize).max(1);
        let show = if kids.len() > max { max - 1 } else { kids.len() };
        let rows = kids[..show].iter().enumerate().map(|(k, &c)| (c, [p[0] + 8.0, top + k as f32 * ROW, p[2] - 16.0, ROW - 2.0])).collect();
        let more = (kids.len() > show).then(|| {
            let rest = kids[show..].iter().map(|c| t.get(*c).size).sum();
            (kids.len() - show, rest, ViewAt { node: s.panel.node, skip: s.panel.skip + show }, [p[0] + 8.0, top + show as f32 * ROW, p[2] - 16.0, ROW - 2.0])
        });
        (rows, more)
    }

    pub fn hit(&self, x: f32, y: f32) -> DHit {
        if self.home {
            for (h, r) in self.home_cards() {
                if inside(r, x, y) {
                    return h;
                }
            }
            return DHit::None;
        }
        if self.modal.is_some() {
            for (h, r) in self.modal_parts() {
                if inside(r, x, y) {
                    return h;
                }
            }
            return DHit::Modal;
        }
        for (h, r) in self.bin_parts() {
            if inside(r, x, y) {
                return h;
            }
        }
        if self.bin_open && inside(self.popover_rect(), x, y) {
            return DHit::None;
        }
        if inside(self.bin_rect(), x, y) {
            return DHit::Bin;
        }
        for (h, r, _) in self.top_buttons() {
            if inside(r, x, y) {
                return h;
            }
        }
        // последняя крошка — то, что уже открыто
        for (id, _, r) in self.crumbs.iter().rev().skip(1) {
            if inside(*r, x, y) && *id != NONE {
                return DHit::Crumb(*id);
            }
        }
        let Some(s) = &self.sess else { return DHit::None };
        if inside(self.panel_rect(), x, y) {
            let (rows, more) = self.rows();
            for (n, r) in rows {
                if inside(r, x, y) {
                    return DHit::Row(n);
                }
            }
            if let Some((_, _, v, r)) = more {
                if inside(r, x, y) {
                    return DHit::More(v.node, v.skip);
                }
            }
            return DHit::None;
        }
        match s.anim.hit(&self.geo, x, y) {
            Some(a) => DHit::Seg(a.key),
            None => DHit::None,
        }
    }

    /// Ключ сегмента, который подсветить: под курсором или строка списка под курсором
    fn highlight(&self) -> Option<u64> {
        match &self.hover {
            DHit::Seg(k) => Some(*k),
            DHit::Row(n) => Some(*n as u64),
            DHit::More(n, skip) => Some(group_key(*n, *skip)),
            _ => None,
        }
    }

    /// Список справа следует за курсором на диаграмме, как в SquirrelDisk
    fn update_panel(&mut self) {
        let Some(s) = &mut self.sess else { return };
        let DHit::Seg(key) = self.hover else {
            if !matches!(self.hover, DHit::Row(_) | DHit::More(..)) {
                s.panel = s.view;
            }
            return;
        };
        let Some(a) = s.anim.anims.get(&key) else { return };
        let t = s.scan.tree.read().unwrap();
        s.panel = match a.kind {
            _ if a.d < 0.5 => s.view,
            SegKind::Group { parent, skip, .. } => ViewAt { node: parent, skip },
            SegKind::Node(_) if t.can_enter(a.node) => ViewAt::of(a.node),
            SegKind::Node(_) => ViewAt::of(t.get(a.node).parent),
            SegKind::Free => s.view,
        };
    }

    fn navigate(&mut self, v: ViewAt) {
        let Some(s) = &mut self.sess else { return };
        if s.view != v {
            s.back.push(s.view);
            s.view = v;
            s.panel = v;
        }
    }

    fn go_back(&mut self) -> bool {
        let Some(s) = &mut self.sess else { return false };
        match s.back.pop() {
            Some(v) => {
                s.view = v;
                s.panel = v;
                true
            }
            None => false,
        }
    }

    /// Esc: закрыть окно подтверждения или список сборщика, отдалить, вернуться к дискам; false — выйти из инструмента
    pub fn escape(&mut self) -> bool {
        if self.modal.take().is_some() {
            return true;
        }
        if self.bin_open {
            self.bin_open = false;
            return true;
        }
        if self.home {
            return false;
        }
        if !self.go_back() {
            self.show_home();
        }
        true
    }

    fn can_collect(t: &Tree, n: u32) -> bool {
        n != ROOT && t.alive(n) && matches!(t.get(n).kind, Kind::Dir | Kind::File)
    }

    pub fn collect(&mut self, node: u32) {
        let Some(s) = &mut self.sess else { return };
        let t = s.scan.tree.read().unwrap();
        if !Self::can_collect(&t, node) || s.collected.iter().any(|&c| c == node || t.is_ancestor(c, node)) {
            return;
        }
        // уже собранное внутри этой папки — входит в неё
        s.collected.retain(|&c| !t.is_ancestor(node, c));
        s.collected.push(node);
        s.note = None;
    }

    pub fn uncollect(&mut self, node: u32) {
        if let Some(s) = &mut self.sess {
            s.collected.retain(|&c| c != node);
        }
    }

    pub fn is_collected(&self, node: u32) -> bool {
        self.sess.as_ref().is_some_and(|s| s.collected.contains(&node))
    }

    fn open_confirm(&mut self) {
        let Some(s) = &self.sess else { return };
        let t = s.scan.tree.read().unwrap();
        let items: Vec<ConfirmItem> = s
            .collected
            .iter()
            .filter(|n| t.alive(**n))
            .map(|&n| ConfirmItem { node: n, name: node_label(&t, n), size: t.get(n).size, verdict: self.rules.check(&t.path(n)) })
            .collect();
        drop(t);
        if !items.is_empty() {
            self.modal = Some(Confirm { items, trash: true, ack: false });
            self.bin_open = false;
        }
    }

    fn run_delete(&mut self) {
        let Some(m) = self.modal.take() else { return };
        let Some(s) = &mut self.sess else { return };
        let t = s.scan.tree.read().unwrap();
        let jobs: Vec<(u32, PathBuf, u64)> = m.allowed().map(|i| (i.node, t.path(i.node), i.size)).collect();
        drop(t);
        let del = Arc::new(Deleting {
            trash: m.trash,
            total: jobs.len(),
            done: AtomicUsize::new(0),
            freed: AtomicU64::new(0),
            current: Mutex::new(String::new()),
            results: Mutex::new(Vec::new()),
            finished: AtomicBool::new(false),
        });
        let (d, h) = (del.clone(), self.hwnd);
        std::thread::spawn(move || {
            unsafe {
                let _ = CoInitializeEx(None, COINIT_APARTMENTTHREADED);
            }
            for (node, path, size) in jobs {
                *d.current.lock().unwrap() = fs::display_name(&path);
                let ok = if d.trash { recycle_one(&path) } else { remove_all(&path) };
                if ok {
                    d.freed.fetch_add(size, Ordering::Relaxed);
                }
                d.results.lock().unwrap().push((node, ok, size));
                d.done.fetch_add(1, Ordering::Relaxed);
                unsafe {
                    let _ = PostMessageW(Some(HWND(h as *mut _)), WM_SCAN, WPARAM(0), LPARAM(0));
                }
            }
            d.finished.store(true, Ordering::Relaxed);
            unsafe {
                let _ = PostMessageW(Some(HWND(h as *mut _)), WM_SCAN, WPARAM(0), LPARAM(0));
            }
        });
        s.deleting = Some(del);
        s.note = None;
    }

    // ---------- мышь ----------

    pub fn mouse_move(&mut self, x: f32, y: f32) {
        self.mouse = (x, y);
        if self.drag.is_none() {
            if let Some((px, py, h)) = self.press.clone() {
                if (x - px).hypot(y - py) > 6.0 {
                    self.begin_drag(&h);
                }
            }
        }
        self.hover = if self.drag.is_some() {
            if inside(self.bin_rect(), x, y) {
                DHit::Bin
            } else {
                DHit::None
            }
        } else {
            self.hit(x, y)
        };
        if self.drag.is_none() {
            self.update_panel();
        }
    }

    pub fn leave(&mut self) {
        self.hover = DHit::None;
        self.update_panel();
    }

    pub fn down(&mut self, x: f32, y: f32) {
        self.press = Some((x, y, self.hit(x, y)));
    }

    fn begin_drag(&mut self, h: &DHit) {
        let Some(s) = &self.sess else { return };
        let node = match h {
            DHit::Seg(k) => s.anim.anims.get(k).filter(|a| a.d >= 0.5 && matches!(a.kind, SegKind::Node(_))).map(|a| a.node),
            DHit::Row(n) => Some(*n),
            _ => None,
        };
        let Some(node) = node else { return };
        let t = s.scan.tree.read().unwrap();
        if !Self::can_collect(&t, node) {
            return;
        }
        let c = s.anim.anims.get(&(node as u64)).map_or(rgb8((0x8E, 0x6B, 0xFF)), |a| a.color);
        self.drag = Some(Drag { node, color: c, label: node_label(&t, node), size: t.get(node).size });
        self.bin_open = false;
    }

    pub fn dragging(&self) -> bool {
        self.drag.is_some()
    }

    pub fn up(&mut self, x: f32, y: f32) -> Out {
        let press = self.press.take();
        if let Some(d) = self.drag.take() {
            if inside(self.bin_rect(), x, y) {
                self.collect(d.node);
            }
            self.hover = self.hit(x, y);
            return Out::None;
        }
        let h = self.hit(x, y);
        // отпустили не там, где нажали, — это не клик
        if press.is_none_or(|p| p.2 != h) {
            return Out::None;
        }
        let out = self.click(&h);
        self.hover = self.hit(x, y);
        self.update_panel();
        out
    }

    fn click(&mut self, h: &DHit) -> Out {
        match h {
            DHit::Drive(i) => {
                if let Some(root) = self.drives.get(*i).map(|d| d.root.clone()) {
                    if self.sess.as_ref().is_some_and(|s| s.root == root) {
                        self.home = false;
                    } else {
                        self.start(root);
                    }
                }
            }
            DHit::Here => {
                if let Some(p) = self.here.clone() {
                    if self.sess.as_ref().is_some_and(|s| s.root == p) {
                        self.home = false;
                    } else {
                        self.start(p);
                    }
                }
            }
            DHit::Pick => return Out::Pick,
            DHit::Back => {
                if !self.go_back() {
                    self.show_home();
                }
            }
            DHit::Crumb(n) => {
                if *n != NONE {
                    self.navigate(ViewAt::of(*n));
                }
            }
            DHit::Rescan => {
                if let Some(r) = self.sess.as_ref().map(|s| s.root.clone()) {
                    self.start(r);
                }
            }
            DHit::Reveal => {
                if let Some(p) = self.focus_path() {
                    return Out::Go(p);
                }
            }
            DHit::Seg(key) => {
                let Some(s) = &self.sess else { return Out::None };
                let Some((node, kind, d)) = s.anim.anims.get(key).map(|a| (a.node, a.kind, a.d)) else { return Out::None };
                if d < 0.5 {
                    self.go_back();
                    return Out::None;
                }
                return self.open_node(node, kind);
            }
            DHit::Row(n) => {
                let kind = self.sess.as_ref().map(|s| s.scan.tree.read().unwrap().get(*n).kind);
                if let Some(k) = kind {
                    return self.open_node(*n, SegKind::Node(k));
                }
            }
            DHit::More(n, skip) => self.navigate(ViewAt { node: *n, skip: *skip }),
            DHit::Bin => {
                self.bin_open = !self.bin_open && self.sess.as_ref().is_some_and(|s| !s.collected.is_empty());
            }
            DHit::BinDelete => self.open_confirm(),
            DHit::BinClear => {
                if let Some(s) = &mut self.sess {
                    s.collected.clear();
                }
                self.bin_open = false;
            }
            DHit::BinRemove(n) => {
                self.uncollect(*n);
                if self.sess.as_ref().is_some_and(|s| s.collected.is_empty()) {
                    self.bin_open = false;
                }
            }
            DHit::EmptyBin => {
                if let Some(s) = &self.sess {
                    return Out::EmptyBin(s.root.ancestors().last().unwrap_or(&s.root).to_path_buf());
                }
            }
            DHit::ModalMode(trash) => {
                if let Some(m) = &mut self.modal {
                    m.trash = *trash;
                }
            }
            DHit::ModalAck => {
                if let Some(m) = &mut self.modal {
                    m.ack = !m.ack;
                }
            }
            DHit::ModalCancel => self.modal = None,
            DHit::ModalOk => {
                if self.modal.as_ref().is_some_and(|m| m.ready()) {
                    self.run_delete();
                }
            }
            DHit::Modal | DHit::None => {}
        }
        Out::None
    }

    fn open_node(&mut self, node: u32, kind: SegKind) -> Out {
        let Some(s) = &self.sess else { return Out::None };
        match kind {
            SegKind::Group { parent, skip, .. } => self.navigate(ViewAt { node: parent, skip }),
            SegKind::Node(Kind::Small) => {
                let tree = s.scan.tree.clone();
                let parent = tree.read().unwrap().get(node).parent;
                if scan::expand_small(&tree, node) {
                    self.navigate(ViewAt::of(parent));
                }
            }
            SegKind::Node(_) => {
                let enter = s.scan.tree.read().unwrap().can_enter(node);
                if enter {
                    self.navigate(ViewAt::of(node));
                }
            }
            SegKind::Free => {}
        }
        Out::None
    }

    pub fn double(&mut self, x: f32, y: f32) -> Out {
        let Some(s) = &self.sess else { return Out::None };
        let node = match self.hit(x, y) {
            DHit::Seg(k) => s.anim.anims.get(&k).map(|a| a.node),
            DHit::Row(n) => Some(n),
            _ => None,
        };
        let t = s.scan.tree.read().unwrap();
        match node {
            Some(n) if t.alive(n) && t.get(n).kind == Kind::File => Out::Reveal(t.path(n)),
            _ => Out::None,
        }
    }

    pub fn right(&mut self, x: f32, y: f32) -> Out {
        let Some(s) = &self.sess else { return Out::None };
        let node = match self.hit(x, y) {
            DHit::Seg(k) => s.anim.anims.get(&k).filter(|a| a.d >= 0.5 && matches!(a.kind, SegKind::Node(_))).map(|a| a.node),
            DHit::Row(n) => Some(n),
            _ => None,
        };
        let t = s.scan.tree.read().unwrap();
        match node {
            Some(n) if t.alive(n) && matches!(t.get(n).kind, Kind::Dir | Kind::File) => Out::Menu(n),
            _ => Out::None,
        }
    }

    /// Путь узла и то, папка ли это — для меню по правому клику
    pub fn node_info(&self, node: u32) -> Option<(PathBuf, bool, String)> {
        let s = self.sess.as_ref()?;
        let t = s.scan.tree.read().ok()?;
        t.alive(node).then(|| (t.path(node), t.get(node).kind == Kind::Dir, node_label(&t, node)))
    }

    pub fn confirm_node(&mut self, node: u32) {
        self.collect(node);
        if let Some(s) = &mut self.sess {
            s.collected.retain(|&c| c == node);
        }
        self.open_confirm();
    }

    pub fn emptied_bin(&mut self) {
        if let Some(s) = &mut self.sess {
            if let Some(n) = &mut s.note {
                *n = ("Корзина очищена — место освободилось".into(), true, 0);
            }
        }
    }

    // ---------- рисование ----------

    pub fn compose(&self, pm: &mut PixmapMut, a: &Area) {
        if self.home {
            self.compose_home(pm, a);
            return;
        }
        let Some(s) = &self.sess else { return };
        self.compose_top(pm, a, s);
        self.compose_chart(pm, a, s);
        self.compose_panel(pm, a, s);
        self.compose_bin(pm, a, s);
        if let Some(d) = &self.drag {
            self.compose_drag(pm, a, d);
        }
        if let Some(m) = &self.modal {
            self.compose_modal(pm, a, m);
        }
    }

    fn compose_home(&self, pm: &mut PixmapMut, a: &Area) {
        let s = a.s;
        let p = |v: f32| v * s;
        let f = a.fonts;
        let [x, y, _, _] = self.area;
        let x0 = x + 32.0;
        gfx::text(pm, &f.semibold, "Анализ места", p(x0), p(y + 46.0), 24.0 * s, gfx::white(0.96));
        let sub = "Посмотрите, что занимает место на диске, и освободите его — системное защищено от удаления";
        gfx::text(pm, &f.regular, sub, p(x0), p(y + 70.0), 12.5 * s, gfx::white(0.45));
        gfx::text(pm, &f.semibold, "ДИСКИ", p(x0), p(y + 106.0), 11.0 * s, gfx::white(0.4));
        let cards = self.home_cards();
        if let Some((_, r)) = cards.iter().find(|(h, _)| matches!(h, DHit::Here | DHit::Pick)) {
            gfx::text(pm, &f.semibold, "ДРУГОЕ", p(x0), p(r[1] - 12.0), 11.0 * s, gfx::white(0.4));
        }
        for (h, r) in cards {
            let hov = self.hover == h;
            gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), p(14.0), gfx::white(if hov { 0.075 } else { 0.045 }));
            let bw = 128.0;
            let btn = [r[0] + r[2] - 16.0 - bw, r[1] + (r[3] - 32.0) / 2.0, bw, 32.0];
            let (icon, title, sub, label) = match &h {
                DHit::Drive(i) => {
                    let d = &self.drives[*i];
                    let sp = d.space.as_ref();
                    let (total, free) = sp.map_or((0, 0), |s| (s.total, s.free));
                    let sub = format!("свободно {} из {}", fs::size_text(free), fs::size_text(total));
                    let open = self.sess.as_ref().is_some_and(|s| s.root == d.root);
                    let label = if !open {
                        "Сканировать"
                    } else if self.scanning() {
                        "Смотреть"
                    } else {
                        "Открыть"
                    };
                    // полоска занятости
                    let used = 1.0 - free as f32 / total.max(1) as f32;
                    let (bx, by, bwid) = (r[0] + 56.0, r[1] + 70.0, r[2] - 56.0 - 16.0 - bw - 20.0);
                    gfx::fill_rrect(pm, p(bx), p(by), p(bwid), p(5.0), p(2.5), gfx::usage_track());
                    gfx::fill_rrect(pm, p(bx), p(by), p(bwid * used).max(p(3.0)), p(5.0), p(2.5), gfx::usage_fill(used > 0.9));
                    (Icon::Drive, d.label.clone(), sub, label)
                }
                DHit::Here => {
                    let here = self.here.clone().unwrap_or_default();
                    (Icon::Folder, format!("Эта папка — {}", fs::display_name(&here)), here.display().to_string(), "Сканировать")
                }
                _ => (Icon::Folder, "Другая папка…".to_string(), "Любая папка на выбор".to_string(), "Выбрать…"),
            };
            gfx::icon(pm, icon, p(r[0] + 18.0), p(r[1] + 18.0), p(24.0), gfx::accent(1.0));
            let tw = p(r[2] - 56.0 - 16.0 - bw - 16.0);
            gfx::text(pm, &f.semibold, &gfx::fit(&f.semibold, &title, 14.5 * s, tw), p(r[0] + 56.0), p(r[1] + 32.0), 14.5 * s, gfx::white(0.95));
            gfx::text(pm, &f.regular, &gfx::fit_middle(&f.regular, &sub, 12.0 * s, tw), p(r[0] + 56.0), p(r[1] + 53.0), 12.0 * s, gfx::white(0.5));
            gfx::button(pm, &f.regular, p(btn[0]), p(btn[1]), p(btn[2]), p(btn[3]), label, 12.5 * s, Btn::Primary, hov);
        }
    }

    fn compose_top(&self, pm: &mut PixmapMut, a: &Area, s: &Session) {
        let sc = a.s;
        let p = |v: f32| v * sc;
        let f = a.fonts;
        for (h, r, label) in self.top_buttons() {
            let hov = self.hover == h;
            if h == DHit::Back {
                if hov {
                    gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), p(8.0), gfx::white(0.08));
                }
                gfx::icon(pm, Icon::ChevronLeft, p(r[0] + 5.0), p(r[1] + 5.0), p(20.0), gfx::white(0.85));
            } else {
                gfx::button(pm, &f.regular, p(r[0]), p(r[1]), p(r[2]), p(r[3]), label, 12.5 * sc, Btn::Plain, hov);
            }
        }
        let last = self.crumbs.len().saturating_sub(1);
        for (k, (id, name, r)) in self.crumbs.iter().enumerate() {
            let hov = self.hover == DHit::Crumb(*id) && k < last;
            let px = 13.5 * sc;
            let t = gfx::fit(&f.semibold, name, px, 220.0 * sc);
            let c = if k == last {
                gfx::white(0.95)
            } else if hov {
                gfx::accent(1.0)
            } else {
                gfx::white(0.55)
            };
            gfx::text(pm, &f.semibold, &t, p(r[0]), p(r[1] + 20.0), px, c);
            if k < last {
                gfx::icon(pm, Icon::ChevronRight, p(r[0] + r[2] + 4.0), p(r[1] + 8.0), p(14.0), gfx::white(0.3));
            }
        }
        // справа — ход сканирования, пока оно идёт
        let pr = &s.scan.progress;
        if !pr.done() {
            let [x, y, w, _] = self.area;
            let text = match pr.fraction() {
                Some(fr) => format!("Сканируем… {}%", (fr * 100.0) as u32),
                None => "Сканируем…".into(),
            };
            let sub = files_word(pr.files.load(Ordering::Relaxed));
            let tw = gfx::measure(&f.semibold, &text, 13.0 * sc).max(gfx::measure(&f.regular, &sub, 11.5 * sc));
            let rx = p(x + w - 20.0) - tw;
            gfx::text(pm, &f.semibold, &text, rx, p(y + 25.0), 13.0 * sc, gfx::accent(1.0));
            gfx::text(pm, &f.regular, &sub, rx, p(y + 42.0), 11.5 * sc, gfx::white(0.5));
        }
    }

    fn collected_set(&self, s: &Session, t: &Tree) -> HashSet<u32> {
        // собранное и всё внутри него рисуем приглушённо
        let mut set: HashSet<u32> = s.collected.iter().copied().collect();
        if set.is_empty() {
            return set;
        }
        for a in s.anim.anims.values() {
            if a.node != NONE && (a.node as usize) < t.nodes.len() && s.collected.iter().any(|&c| t.is_ancestor(c, a.node)) {
                set.insert(a.node);
            }
        }
        set
    }

    fn compose_chart(&self, pm: &mut PixmapMut, a: &Area, s: &Session) {
        let sc = a.s;
        let p = |v: f32| v * sc;
        let f = a.fonts;
        let g = &self.geo;
        let t = s.scan.tree.read().unwrap();
        let dimmed = self.collected_set(s, &t);
        let back = bg();
        let edge = color(back, 1.0);
        for an in s.anim.draw_list() {
            if an.d < 0.5 || an.alpha <= 0.01 {
                continue;
            }
            let (r0, r1) = g.radii(an.d);
            let r1 = r0 + (r1 - r0) * ease(an.grow);
            if r1 - r0 < 1.5 || (an.a1 - an.a0) * r1 * sc < 0.6 {
                continue;
            }
            let mut c = an.color;
            if an.hover > 0.0 {
                c = mix(c, (1.0, 1.0, 1.0), 0.28 * an.hover);
            }
            let dim = matches!(an.kind, SegKind::Node(_)) && dimmed.contains(&an.node);
            if dim {
                c = mix(c, back, 0.7);
            }
            gfx::sector(pm, p(g.cx), p(g.cy), p(r0 + 1.0), p(r1 - 1.0), an.a0 - FRAC_PI_2, an.a1 - FRAC_PI_2, color(c, an.alpha), edge);
        }
        // центр: сколько всего и куда нажать
        let center_hover = matches!(&self.hover, DHit::Seg(k) if s.anim.anims.get(k).is_some_and(|an| an.d < 0.5));
        gfx::circle(pm, p(g.cx), p(g.cy), p(g.r0 - 2.0), gfx::white(if center_hover && !s.back.is_empty() { 0.1 } else { 0.05 }));
        let pr = &s.scan.progress;
        if let (false, Some(fr)) = (pr.done(), pr.fraction()) {
            gfx::donut(pm, p(g.cx), p(g.cy), p(g.r0 - 2.0), p(3.0), fr, gfx::accent(1.0), gfx::white(0.08));
        }
        let size = if t.alive(s.view.node) { view_children(&t, s.view).1 } else { 0 };
        let st = fs::size_text(size);
        let sw = gfx::measure(&f.semibold, &st, 20.0 * sc);
        gfx::text(pm, &f.semibold, &st, p(g.cx) - sw / 2.0, p(g.cy + 3.0), 20.0 * sc, gfx::white(0.95));
        let sub = if !s.back.is_empty() {
            "клик — назад".to_string()
        } else {
            // в центре мало места — большие числа коротко: «1,05 млн файлов»
            let n = if pr.done() { t.get(ROOT).files as u64 } else { pr.files.load(Ordering::Relaxed) };
            if n >= 10_000 {
                format!("{} файлов", count_text(n, true))
            } else {
                files_word(n)
            }
        };
        let sub = gfx::fit(&f.regular, &sub, 11.5 * sc, p(g.r0 * 1.7));
        let bw = gfx::measure(&f.regular, &sub, 11.5 * sc);
        gfx::text(pm, &f.regular, &sub, p(g.cx) - bw / 2.0, p(g.cy + 21.0), 11.5 * sc, gfx::white(0.45));
    }

    fn compose_panel(&self, pm: &mut PixmapMut, a: &Area, s: &Session) {
        let sc = a.s;
        let p = |v: f32| v * sc;
        let f = a.fonts;
        let r = self.panel_rect();
        gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), p(12.0), gfx::white(0.045));
        // строки — до блокировки дерева: повторное чтение под той же блокировкой может зависнуть,
        // если сканер как раз ждёт записи
        let (rows, more) = self.rows();
        let t = s.scan.tree.read().unwrap();
        // цвет строки — как у её сегмента; слишком мелким для диаграммы — тот, что был бы на круге
        let (all, total_size) = view_children(&t, s.panel);
        let mut at = 0u64;
        let mut wheel: HashMap<u32, Rgb> = HashMap::new();
        for &c in &all {
            let size = t.get(c).size;
            let mid = (at as f64 + size as f64 / 2.0) / total_size.max(1) as f64;
            wheel.insert(c, seg_color(mid as f32, 1, t.get(c).kind == Kind::File));
            at += size;
        }
        if !t.alive(s.panel.node) {
            return;
        }
        let pv = s.panel;
        let (kids, total) = view_children(&t, pv);
        let title = if pv.skip > 0 {
            format!("ещё {}", fs::plural(kids.len(), ["объект", "объекта", "объектов"]))
        } else if pv.node == ROOT {
            s.title.clone()
        } else {
            node_label(&t, pv.node)
        };
        let (ix, iw) = (r[0] + 16.0, r[2] - 32.0);
        let size = fs::size_text(total);
        let sw = gfx::measure(&f.semibold, &size, 16.0 * sc);
        let name = gfx::fit(&f.semibold, &title, 16.0 * sc, p(iw) - sw - p(12.0));
        gfx::text(pm, &f.semibold, &name, p(ix), p(r[1] + 30.0), 16.0 * sc, gfx::white(0.95));
        gfx::text(pm, &f.semibold, &size, p(ix + iw) - sw, p(r[1] + 30.0), 16.0 * sc, gfx::white(0.95));
        let scanning = !s.scan.progress.done();
        let files = if pv.skip > 0 { kids.iter().map(|k| t.get(*k).files as u64).sum() } else { t.get(pv.node).files as u64 };
        let sub = format!(
            "{} · {}",
            if scanning && files >= 10_000 { format!("{} файлов", count_text(files, true)) } else { files_word(files) },
            fs::plural(kids.len(), ["объект", "объекта", "объектов"])
        );
        gfx::text(pm, &f.regular, &sub, p(ix), p(r[1] + 50.0), 12.0 * sc, gfx::white(0.45));
        if t.get(pv.node).kind == Kind::Hidden {
            let note = "Занято на диске, но не в прочитанных файлах: системные данные, теневые копии, папки без доступа";
            for (k, line) in gfx::wrap2(&f.regular, note, 12.0 * sc, p(iw)).iter().enumerate() {
                gfx::text(pm, &f.regular, line, p(ix), p(r[1] + 84.0 + k as f32 * 18.0), 12.0 * sc, gfx::white(0.6));
            }
        }
        let hl = self.highlight();
        for (n, rr) in &rows {
            let n = *n;
            let node = t.get(n);
            let hov = self.hover == DHit::Row(n) || hl == Some(n as u64);
            if hov {
                gfx::fill_rrect(pm, p(rr[0]), p(rr[1]), p(rr[2]), p(rr[3]), p(8.0), gfx::white(0.07));
            }
            let c = s.anim.anims.get(&(n as u64)).map(|an| an.to.3).or_else(|| wheel.get(&n).copied()).unwrap_or(aggregate());
            let (dx, dy) = (rr[0] + 16.0, rr[1] + rr[3] / 2.0);
            match node.kind {
                Kind::Dir => gfx::circle(pm, p(dx), p(dy), p(5.0), color(c, 1.0)),
                Kind::File => gfx::fill_rrect(pm, p(dx - 4.5), p(dy - 4.5), p(9.0), p(9.0), p(2.5), color(c, 1.0)),
                _ => gfx::stroke_rrect(pm, p(dx - 4.5), p(dy - 4.5), p(9.0), p(9.0), p(4.5), p(1.6), gfx::white(0.4)),
            }
            let collected = s.collected.contains(&n);
            let size = fs::size_text(node.size);
            let szw = gfx::measure(&f.semibold, &size, 12.5 * sc);
            let mut room = p(rr[2] - 44.0) - szw - p(10.0);
            let denied = scan::denied(&t, n);
            // пометка справа: «нет доступа» или «собрано»
            let tag = if collected {
                Some(("собрано", gfx::accent(1.0)))
            } else if denied {
                Some(("нет доступа", amber()))
            } else {
                None
            };
            let tag_w = tag.map_or(0.0, |(t, _)| gfx::measure(&f.regular, t, 11.0 * sc) + p(10.0));
            room -= tag_w;
            let label = gfx::fit(&f.regular, &node_label(&t, n), 13.0 * sc, room);
            let tc = if collected {
                gfx::white(0.35)
            } else if matches!(node.kind, Kind::Small | Kind::Hidden) {
                gfx::white(0.6)
            } else {
                gfx::white(0.9)
            };
            gfx::text(pm, &f.regular, &label, p(rr[0] + 30.0), p(dy + 4.5), 13.0 * sc, tc);
            if let Some((tg, c)) = tag {
                gfx::text(pm, &f.regular, tg, p(rr[0] + rr[2] - 12.0) - szw - tag_w, p(dy + 4.0), 11.0 * sc, c);
            }
            gfx::text(pm, &f.semibold, &size, p(rr[0] + rr[2] - 12.0) - szw, p(dy + 4.5), 12.5 * sc, gfx::white(if hov { 0.95 } else { 0.6 }));
        }
        if let Some((count, rest, v, rr)) = more {
            if self.hover == DHit::More(v.node, v.skip) {
                gfx::fill_rrect(pm, p(rr[0]), p(rr[1]), p(rr[2]), p(rr[3]), p(8.0), gfx::white(0.07));
            }
            let dy = rr[1] + rr[3] / 2.0;
            let label = format!("ещё {}…", fs::plural(count, ["объект", "объекта", "объектов"]));
            gfx::text(pm, &f.regular, &label, p(rr[0] + 30.0), p(dy + 4.5), 13.0 * sc, gfx::white(0.55));
            let size = fs::size_text(rest);
            let szw = gfx::measure(&f.semibold, &size, 12.5 * sc);
            gfx::text(pm, &f.semibold, &size, p(rr[0] + rr[2] - 12.0) - szw, p(dy + 4.5), 12.5 * sc, gfx::white(0.5));
        }
        if rows.is_empty() && t.get(pv.node).kind != Kind::Hidden {
            let e = if scanning { "Сканируем…" } else { "Пусто" };
            gfx::text(pm, &f.regular, e, p(ix), p(r[1] + 100.0), 13.0 * sc, gfx::white(0.4));
        }
        // подвал: у корня диска — свободное место и сколько станет после удаления собранного
        let fy = r[1] + r[3];
        if s.scan.volume && pv == ViewAt::of(ROOT) {
            gfx::fill_rrect(pm, p(ix), p(fy - 62.0), p(iw), 1.0, 0.0, gfx::white(0.08));
            let free = scan::volume_space(&s.root).map_or(0, |(_, av)| av);
            let collected: u64 = s.collected.iter().filter(|n| t.alive(**n)).map(|n| t.get(*n).size).sum();
            let lines = [("Свободно", free, gfx::white(0.6)), ("Свободно, если удалить собранное", free + collected, green())];
            for (k, (label, v, c)) in lines.iter().enumerate() {
                let ly = fy - 38.0 + k as f32 * 22.0;
                gfx::text(pm, &f.regular, label, p(ix), p(ly), 12.5 * sc, gfx::white(0.55));
                let vt = fs::size_text(*v);
                let vw = gfx::measure(&f.semibold, &vt, 12.5 * sc);
                gfx::text(pm, &f.semibold, &vt, p(ix + iw) - vw, p(ly), 12.5 * sc, *c);
            }
        } else {
            let hovered = match &self.hover {
                DHit::Row(n) => Some(*n),
                DHit::Seg(k) => s.anim.anims.get(k).filter(|an| matches!(an.kind, SegKind::Node(_))).map(|an| an.node),
                _ => None,
            };
            let path = hovered.filter(|n| t.alive(*n)).map_or_else(|| t.path(pv.node), |n| t.path(n));
            let pt = gfx::fit_middle(&f.regular, &path.display().to_string(), 11.0 * sc, p(iw));
            gfx::text(pm, &f.regular, &pt, p(ix), p(fy - 12.0), 11.0 * sc, gfx::white(0.38));
        }
    }

    fn compose_bin(&self, pm: &mut PixmapMut, a: &Area, s: &Session) {
        let sc = a.s;
        let p = |v: f32| v * sc;
        let f = a.fonts;
        let b = self.bin_rect();
        let dragging = self.drag.is_some();
        let over = dragging && self.hover == DHit::Bin;
        let fill = if over {
            gfx::accent(0.25)
        } else if self.hover == DHit::Bin && !s.collected.is_empty() {
            gfx::white(0.08)
        } else {
            gfx::white(0.055)
        };
        gfx::fill_rrect(pm, p(b[0]), p(b[1]), p(b[2]), p(b[3]), p(12.0), fill);
        if dragging {
            gfx::stroke_rrect(pm, p(b[0]) + 0.5, p(b[1]) + 0.5, p(b[2]) - 1.0, p(b[3]) - 1.0, p(12.0), p(1.5), gfx::accent(if over { 1.0 } else { 0.6 }));
        }
        let tx = b[0] + 20.0;
        let cy = b[1] + b[3] / 2.0;
        let t = s.scan.tree.read().unwrap();
        if let Some(del) = &s.deleting {
            let (done, total) = (del.done.load(Ordering::Relaxed), del.total.max(1));
            let what = if del.trash { "Перемещаем в корзину" } else { "Удаляем" };
            let line = format!(
                "{what}… {done} из {total} · {} · {}",
                fs::size_text(del.freed.load(Ordering::Relaxed)),
                del.current.lock().unwrap()
            );
            gfx::text(pm, &f.semibold, &gfx::fit(&f.semibold, &line, 13.0 * sc, p(b[2] - 60.0)), p(tx), p(cy - 2.0), 13.0 * sc, gfx::white(0.9));
            let bw = b[2] - 40.0;
            gfx::fill_rrect(pm, p(tx), p(cy + 9.0), p(bw), p(4.0), p(2.0), gfx::white(0.1));
            gfx::fill_rrect(pm, p(tx), p(cy + 9.0), p(bw * done as f32 / total as f32).max(p(4.0)), p(4.0), p(2.0), gfx::accent(1.0));
        } else if s.collected.is_empty() {
            let (msg, c) = match &s.note {
                Some((text, ok, _)) => (text.clone(), if *ok { green() } else { amber() }),
                None if dragging => ("Отпустите здесь, чтобы собрать для удаления".to_string(), gfx::accent(1.0)),
                None => ("Перетащите сюда сегменты или строки, которые хотите удалить".to_string(), gfx::white(0.45)),
            };
            let room = p(b[2] - 40.0 - if s.note.as_ref().is_some_and(|n| n.2 > 0) { 170.0 } else { 0.0 });
            gfx::icon(pm, Icon::Sparkle, p(tx), p(cy - 9.0), p(18.0), c);
            gfx::text(pm, &f.regular, &gfx::fit(&f.regular, &msg, 13.0 * sc, room - p(28.0)), p(tx + 28.0), p(cy + 4.5), 13.0 * sc, c);
        } else {
            let size: u64 = s.collected.iter().filter(|n| t.alive(**n)).map(|n| t.get(*n).size).sum();
            gfx::text(pm, &f.semibold, &fs::size_text(size), p(tx), p(cy - 1.0), 16.0 * sc, gfx::white(0.95));
            let what = format!("собрано · {} · нажмите, чтобы посмотреть", fs::plural(s.collected.len(), ["объект", "объекта", "объектов"]));
            gfx::text(pm, &f.regular, &what, p(tx), p(cy + 16.0), 11.5 * sc, gfx::white(0.5));
        }
        for (h, r) in self.bin_parts() {
            let hov = self.hover == h;
            match h {
                DHit::BinDelete => gfx::button(pm, &f.regular, p(r[0]), p(r[1]), p(r[2]), p(r[3]), "Удалить…", 13.0 * sc, Btn::Danger, hov),
                DHit::EmptyBin => gfx::button(pm, &f.regular, p(r[0]), p(r[1]), p(r[2]), p(r[3]), "Очистить корзину", 12.5 * sc, Btn::Plain, hov),
                _ => {}
            }
        }
        if self.bin_open {
            let r = self.popover_rect();
            gfx::shadow(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), p(16.0), 0.5);
            let surf = if gfx::theme().dark { gfx::rgb(0x2B, 0x2B, 0x2B, 1.0) } else { gfx::rgb(0xFA, 0xFA, 0xFA, 1.0) };
            gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), p(14.0), surf);
            gfx::stroke_rrect(pm, p(r[0]) + 0.5, p(r[1]) + 0.5, p(r[2]) - 1.0, p(r[3]) - 1.0, p(14.0), 1.0, gfx::white(0.1));
            gfx::text(pm, &f.semibold, "Собрано для удаления", p(r[0] + 16.0), p(r[1] + 26.0), 13.0 * sc, gfx::white(0.95));
            for (h, br) in self.bin_parts() {
                let hov = self.hover == h;
                match h {
                    DHit::BinClear => gfx::button(pm, &f.regular, p(br[0]), p(br[1]), p(br[2]), p(br[3]), "Очистить", 12.0 * sc, Btn::Plain, hov),
                    DHit::BinRemove(n) => {
                        let k = s.collected.iter().position(|&c| c == n).unwrap_or(0);
                        let ry = r[1] + 44.0 + k as f32 * 40.0;
                        let name = if t.alive(n) { node_label(&t, n) } else { String::new() };
                        let path = if t.alive(n) { t.path(n).display().to_string() } else { String::new() };
                        let size = if t.alive(n) { fs::size_text(t.get(n).size) } else { String::new() };
                        let szw = gfx::measure(&f.semibold, &size, 12.5 * sc);
                        let room = p(r[2] - 16.0 - 48.0) - szw - p(12.0);
                        gfx::text(pm, &f.semibold, &gfx::fit(&f.semibold, &name, 12.5 * sc, room), p(r[0] + 16.0), p(ry + 17.0), 12.5 * sc, gfx::white(0.92));
                        gfx::text(pm, &f.regular, &gfx::fit_middle(&f.regular, &path, 10.5 * sc, room), p(r[0] + 16.0), p(ry + 32.0), 10.5 * sc, gfx::white(0.4));
                        gfx::text(pm, &f.semibold, &size, p(br[0] - 10.0) - szw, p(ry + 24.0), 12.5 * sc, gfx::white(0.6));
                        if hov {
                            gfx::fill_rrect(pm, p(br[0]), p(br[1]), p(br[2]), p(br[3]), p(6.0), gfx::white(0.12));
                        }
                        gfx::icon(pm, Icon::Close, p(br[0] + 4.0), p(br[1] + 4.0), p(16.0), gfx::white(0.7));
                    }
                    _ => {}
                }
            }
            if s.collected.len() > 8 {
                let more = format!("и ещё {}", fs::plural(s.collected.len() - 8, ["объект", "объекта", "объектов"]));
                gfx::text(pm, &f.regular, &more, p(r[0] + 16.0), p(r[1] + r[3] - 10.0), 11.5 * sc, gfx::white(0.45));
            }
        }
    }

    fn compose_drag(&self, pm: &mut PixmapMut, a: &Area, d: &Drag) {
        let sc = a.s;
        let p = |v: f32| v * sc;
        let f = a.fonts;
        let (x, y) = (self.mouse.0 + 12.0, self.mouse.1 + 10.0);
        let size = fs::size_text(d.size);
        let label = gfx::fit(&f.semibold, &d.label, 12.5 * sc, p(220.0));
        let w = (gfx::measure(&f.semibold, &label, 12.5 * sc) + gfx::measure(&f.regular, &size, 12.0 * sc)) / sc + 52.0;
        gfx::shadow(pm, p(x), p(y), p(w), p(32.0), p(10.0), 0.5);
        let surf = if gfx::theme().dark { gfx::rgb(0x2E, 0x2E, 0x2E, 0.97) } else { gfx::rgb(0xFF, 0xFF, 0xFF, 0.97) };
        gfx::fill_rrect(pm, p(x), p(y), p(w), p(32.0), p(16.0), surf);
        gfx::circle(pm, p(x + 16.0), p(y + 16.0), p(5.5), color(d.color, 1.0));
        gfx::text(pm, &f.semibold, &label, p(x + 30.0), p(y + 20.5), 12.5 * sc, gfx::white(0.95));
        let lw = gfx::measure(&f.semibold, &label, 12.5 * sc);
        gfx::text(pm, &f.regular, &size, p(x + 38.0) + lw, p(y + 20.5), 12.0 * sc, gfx::white(0.5));
    }

    fn compose_modal(&self, pm: &mut PixmapMut, a: &Area, m: &Confirm) {
        let sc = a.s;
        let p = |v: f32| v * sc;
        let f = a.fonts;
        let [ax, ay, aw, ah] = self.area;
        gfx::fill_rrect(pm, p(ax), p(ay), p(aw), p(ah), 0.0, gfx::rgb(0, 0, 0, 0.45));
        let r = self.modal_rect();
        gfx::shadow(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), p(24.0), 0.6);
        let surf = if gfx::theme().dark { gfx::rgb(0x26, 0x26, 0x26, 1.0) } else { gfx::rgb(0xFF, 0xFF, 0xFF, 1.0) };
        gfx::fill_rrect(pm, p(r[0]), p(r[1]), p(r[2]), p(r[3]), p(16.0), surf);
        gfx::stroke_rrect(pm, p(r[0]) + 0.5, p(r[1]) + 0.5, p(r[2]) - 1.0, p(r[3]) - 1.0, p(16.0), 1.0, gfx::white(0.1));
        let allowed: Vec<&ConfirmItem> = m.allowed().collect();
        let total: u64 = allowed.iter().map(|i| i.size).sum();
        let title = if allowed.is_empty() {
            "Это удалить нельзя".to_string()
        } else {
            format!("Удалить {} — {}?", fs::plural(allowed.len(), ["объект", "объекта", "объектов"]), fs::size_text(total))
        };
        let (x0, w0) = (r[0] + 20.0, r[2] - 40.0);
        gfx::text(pm, &f.semibold, &gfx::fit(&f.semibold, &title, 17.0 * sc, p(w0)), p(x0), p(r[1] + 36.0), 17.0 * sc, gfx::white(0.96));
        let blocked = m.items.len() - allowed.len();
        let sub = if blocked > 0 {
            format!("Защищённое не удалится: {}", fs::plural(blocked, ["объект", "объекта", "объектов"]))
        } else {
            "Проверьте список — удалится всё, что внутри этих папок".to_string()
        };
        gfx::text(pm, &f.regular, &sub, p(x0), p(r[1] + 58.0), 12.0 * sc, if blocked > 0 { amber() } else { gfx::white(0.5) });
        let mut y = r[1] + 76.0;
        for it in m.items.iter().take(6) {
            let (tag, tc) = match &it.verdict {
                Verdict::Forbidden(why) => (format!("нельзя: {why}"), gfx::danger(1.0)),
                Verdict::Caution(why) => (format!("осторожно: {why}"), amber()),
                Verdict::Ok => (String::new(), gfx::white(0.5)),
            };
            let size = fs::size_text(it.size);
            let szw = gfx::measure(&f.semibold, &size, 12.5 * sc);
            let tagw = if tag.is_empty() { 0.0 } else { gfx::measure(&f.regular, &gfx::fit(&f.regular, &tag, 11.0 * sc, p(w0 * 0.45)), 11.0 * sc) };
            let room = p(w0 - 12.0) - szw - tagw - p(20.0);
            let off = matches!(it.verdict, Verdict::Forbidden(_));
            gfx::text(pm, &f.regular, &gfx::fit(&f.regular, &it.name, 13.0 * sc, room), p(x0), p(y + 20.0), 13.0 * sc, gfx::white(if off { 0.35 } else { 0.9 }));
            if !tag.is_empty() {
                let tg = gfx::fit(&f.regular, &tag, 11.0 * sc, p(w0 * 0.45));
                gfx::text(pm, &f.regular, &tg, p(x0 + w0) - szw - p(14.0) - tagw, p(y + 19.5), 11.0 * sc, tc);
            }
            gfx::text(pm, &f.semibold, &size, p(x0 + w0) - szw, p(y + 20.0), 12.5 * sc, gfx::white(if off { 0.35 } else { 0.6 }));
            y += 32.0;
        }
        if m.items.len() > 6 {
            let more = format!("и ещё {}", fs::plural(m.items.len() - 6, ["объект", "объекта", "объектов"]));
            gfx::text(pm, &f.regular, &more, p(x0), p(y + 20.0), 12.0 * sc, gfx::white(0.45));
        }
        for (h, br) in self.modal_parts() {
            let hov = self.hover == h;
            match h {
                DHit::ModalMode(trash) => {
                    let on = m.trash == trash;
                    let (cx, cy) = (br[0] + 9.0, br[1] + 15.0);
                    // переключатель: кольцо, внутри точка у выбранного
                    gfx::circle(pm, p(cx), p(cy), p(8.0), if on { gfx::accent(1.0) } else { gfx::white(0.45) });
                    gfx::circle(pm, p(cx), p(cy), p(6.5), surf);
                    if on {
                        gfx::circle(pm, p(cx), p(cy), p(4.0), gfx::accent(1.0));
                    }
                    let (t1, t2) = if trash { ("В корзину", "можно будет вернуть; место освободится после очистки корзины") } else { ("Насовсем", "сразу освобождает место, вернуть нельзя") };
                    gfx::text(pm, &f.semibold, t1, p(br[0] + 26.0), p(cy + 4.5), 13.0 * sc, gfx::white(if hov || on { 0.95 } else { 0.75 }));
                    let t1w = gfx::measure(&f.semibold, t1, 13.0 * sc);
                    let t2f = gfx::fit(&f.regular, t2, 12.0 * sc, p(br[2] - 40.0) - t1w);
                    gfx::text(pm, &f.regular, &format!(" — {t2f}"), p(br[0] + 26.0) + t1w, p(cy + 4.5), 12.0 * sc, gfx::white(0.45));
                }
                DHit::ModalAck => {
                    gfx::checkbox(pm, p(br[0]), p(br[1] + 6.0), p(18.0), m.ack);
                    gfx::text(pm, &f.regular, "Понимаю: программы могут перестать работать", p(br[0] + 28.0), p(br[1] + 20.0), 13.0 * sc, amber());
                }
                DHit::ModalCancel => gfx::button(pm, &f.regular, p(br[0]), p(br[1]), p(br[2]), p(br[3]), "Отмена", 13.0 * sc, Btn::Plain, hov),
                DHit::ModalOk => {
                    let label = if m.trash { "В корзину" } else { "Удалить насовсем" };
                    gfx::button(pm, &f.semibold, p(br[0]), p(br[1]), p(br[2]), p(br[3]), label, 13.0 * sc, Btn::Danger, hov && m.ready());
                    if !m.ready() {
                        let veil = if gfx::theme().dark { gfx::rgb(0x26, 0x26, 0x26, 0.55) } else { gfx::rgb(0xFF, 0xFF, 0xFF, 0.55) };
                        gfx::fill_rrect(pm, p(br[0]), p(br[1]), p(br[2]), p(br[3]), p(br[3] / 2.0), veil);
                    }
                }
                _ => {}
            }
        }
    }
}
