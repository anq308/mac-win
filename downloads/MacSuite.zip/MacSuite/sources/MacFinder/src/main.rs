#![windows_subsystem = "windows"]

mod analyze;
mod clean;
mod finder;
mod fs;
mod gfx;
mod safety;
mod scan;
mod search;
mod settings;
mod shell;
mod thumbs;
mod tree;
mod win;

use std::path::PathBuf;

use windows::Win32::System::Ole::OleInitialize;
use windows::Win32::UI::HiDpi::{SetProcessDpiAwarenessContext, DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2};
use windows::Win32::UI::WindowsAndMessaging::HICON;

use fs::Loc;

fn main() {
    // panic = "abort" не оставляет следов — пишем причину в лог рядом с exe
    std::panic::set_hook(Box::new(|info| {
        if let Ok(exe) = std::env::current_exe() {
            let log = exe.with_file_name("crash.log");
            let line = format!("{:?}: {info}\n", std::time::SystemTime::now());
            let _ =
                std::fs::OpenOptions::new().create(true).append(true).open(log).and_then(|mut f| std::io::Write::write_all(&mut f, line.as_bytes()));
        }
    }));
    unsafe {
        let _ = SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
        let _ = OleInitialize(None);
    }
    gfx::load_themes();
    gfx::use_theme(true);
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.first().map(String::as_str) == Some("--preview") {
        preview(&args[1..]);
        return;
    }
    let (loc, select) = startup(&args);
    // папка уже открыта в другом окне — поднимаем его, а не плодим новое
    if finder::reuse(&loc, select.as_deref()) {
        return;
    }
    finder::run(loc, select);
}

/// Что открыть: папку, «Компьютер» или папку файла с выделенным файлом.
/// Понимает и то, что передаёт проводник: /select,путь, shell:Downloads, ::{CLSID}
fn startup(args: &[String]) -> (Loc, Option<PathBuf>) {
    let mut select = false;
    let mut target = None;
    for a in args {
        let a = a.trim().trim_matches('"');
        let low = a.to_lowercase();
        if low == "--select" || low == "/select" || low == "/select," {
            select = true;
        } else if let Some(rest) = a.get(..8).filter(|h| h.eq_ignore_ascii_case("/select,")).map(|_| &a[8..]) {
            select = true;
            target = Some(rest.trim_matches('"').to_string());
        } else if !a.starts_with("--") && !a.is_empty() {
            target = Some(a.to_string());
        }
    }
    let home = || dirs_home().map_or(Loc::Computer, Loc::Dir);
    let Some(t) = target else { return (home(), None) };
    if t.eq_ignore_ascii_case("computer") || t.to_uppercase().contains("20D04FE0-3AEA-1069-A2D8-08002B30309D") {
        return (Loc::Computer, None);
    }
    let low = t.to_lowercase();
    let p = if low.starts_with("shell:") || low.starts_with("::") || low.starts_with("file:") {
        match win::shell_path(&t) {
            Some(p) => p,
            None => return (home(), None),
        }
    } else {
        PathBuf::from(&t)
    };
    // «C:\» в кавычках доходит как «C:» — а это «текущая папка диска C», не корень
    let p = if p.as_os_str().len() == 2 && t.ends_with(':') { PathBuf::from(format!("{t}\\")) } else { p };
    let p = std::path::absolute(&p).unwrap_or(p);
    if p.is_dir() && !select {
        return (Loc::Dir(p), None);
    }
    // файл (или /select) — открываем его папку и выделяем его
    match p.parent() {
        Some(d) if p.exists() => (Loc::Dir(d.to_path_buf()), Some(p)),
        _ => (home(), None),
    }
}

fn dirs_home() -> Option<PathBuf> {
    win::known_folder(&windows::Win32::UI::Shell::FOLDERID_Profile)
}

/// Значок окна нужного размера — тот же, что вшит в exe (build.rs); без него — папка проводника
pub fn app_icon(small: bool) -> HICON {
    use windows::Win32::System::LibraryLoader::GetModuleHandleW;
    use windows::Win32::UI::Shell::{SHGetStockIconInfo, SHGSI_ICON, SHGSI_LARGEICON, SHSTOCKICONINFO, SIID_FOLDER};
    use windows::Win32::UI::WindowsAndMessaging::{GetSystemMetrics, LoadImageW, IMAGE_ICON, LR_DEFAULTCOLOR, SM_CXICON, SM_CXSMICON};
    unsafe {
        let size = GetSystemMetrics(if small { SM_CXSMICON } else { SM_CXICON });
        let inst = GetModuleHandleW(None).unwrap_or_default();
        // значок с номером 1 из app.rc
        if let Ok(h) = LoadImageW(Some(inst.into()), windows::core::PCWSTR(1 as *const u16), IMAGE_ICON, size, size, LR_DEFAULTCOLOR) {
            return HICON(h.0);
        }
        let mut info = SHSTOCKICONINFO { cbSize: std::mem::size_of::<SHSTOCKICONINFO>() as u32, ..Default::default() };
        let _ = SHGetStockIconInfo(SIID_FOLDER, SHGSI_ICON | SHGSI_LARGEICON, &mut info);
        info.hIcon
    }
}

/// mac-finder.exe --preview grid|list|look папка out.png
fn preview(args: &[String]) {
    let mode = args.first().cloned().unwrap_or_default();
    let loc = match args.get(1).map(String::as_str) {
        Some("computer") | None => Loc::Computer,
        Some(p) => Loc::Dir(PathBuf::from(p)),
    };
    let out = args.get(2).cloned().unwrap_or_else(|| "preview.png".into());
    let s = win::monitor_at(win::cursor()).scale;
    if let Some(png) = finder::preview(loc, &mode, (1120.0 * s) as i32, (720.0 * s) as i32).as_ref().and_then(win::encode_png) {
        let _ = std::fs::write(out, png);
    }
}
