//! Параллельное сканирование для «Анализа места», как в SquirrelDisk: несколько потоков берут папки
//! из общей очереди и вставляют найденное в общее дерево под короткой блокировкой. Очередь — в ширину,
//! поэтому диаграмма растёт от центра прямо во время сканирования. Размер — сколько файл реально
//! занимает на диске: сжатые считаются по сжатому, облачные заглушки (OneDrive) — нулём.

use std::collections::{HashSet, VecDeque};
use std::os::windows::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Condvar, Mutex, RwLock};
use std::time::{Duration, Instant};

use windows::Win32::Foundation::{GetLastError, ERROR_SUCCESS, HWND, LPARAM, WPARAM};
use windows::Win32::Storage::FileSystem::{GetCompressedFileSizeW, GetDiskFreeSpaceExW, GetDiskFreeSpaceW};
use windows::Win32::UI::WindowsAndMessaging::PostMessageW;

use crate::analyze::WM_SCAN;
use crate::tree::{Kind, Tree, F_DENIED, F_DONE, F_EXPANDABLE};
use crate::win::{pcwstr, wide_path};

pub type Shared = Arc<RwLock<Tree>>;

pub const SMALL: &str = "\u{2026}";
pub const HIDDEN: &str = "Скрытое место";

const COMPRESSED: u32 = 0x800;
const SPARSE: u32 = 0x200;
const REPARSE: u32 = 0x400;
const OFFLINE: u32 = 0x1000;
const RECALL_ON_OPEN: u32 = 0x40000;
const RECALL_ON_DATA: u32 = 0x40_0000;

#[derive(Default)]
pub struct Progress {
    pub files: AtomicU64,
    pub dirs: AtomicU64,
    pub bytes: AtomicU64,
    /// сколько занято на диске — для процента; 0, если сканируем просто папку
    pub expected: AtomicU64,
    pub done: AtomicBool,
    pub cancel: AtomicBool,
    pub millis: AtomicU64,
}

impl Progress {
    pub fn fraction(&self) -> Option<f32> {
        let e = self.expected.load(Ordering::Relaxed);
        (e > 0).then(|| (self.bytes.load(Ordering::Relaxed) as f64 / e as f64).clamp(0.0, 0.995) as f32)
    }
    pub fn done(&self) -> bool {
        self.done.load(Ordering::Relaxed)
    }
}

/// Сколько файлов одной папки держим отдельными узлами
#[derive(Clone, Copy)]
struct Limits {
    keep_min: u64,
    max_files: usize,
}

struct Ctx {
    limits: Limits,
    cluster: u64,
    progress: Arc<Progress>,
}

#[derive(Default)]
struct Listing {
    dirs: Vec<String>,
    files: Vec<(String, u64)>,
    small_size: u64,
    small_count: u32,
    denied: bool,
}

pub struct Scan {
    pub tree: Shared,
    pub progress: Arc<Progress>,
    /// сканируем диск целиком — значит, есть свободное и скрытое место
    pub volume: bool,
}

impl Scan {
    pub fn stop(&self) {
        self.progress.cancel.store(true, Ordering::Relaxed);
    }
}

fn compressed_size(path: &Path) -> Option<u64> {
    let w = wide_path(path);
    let mut high = 0u32;
    let low = unsafe { GetCompressedFileSizeW(pcwstr(&w), Some(&mut high)) };
    // u32::MAX бывает и настоящим значением младшей половины — тогда ошибки нет
    (low != u32::MAX || unsafe { GetLastError() } == ERROR_SUCCESS).then(|| (high as u64) << 32 | low as u64)
}

/// Сколько файл занимает на диске
fn alloc(md: &std::fs::Metadata, path: impl FnOnce() -> PathBuf, cluster: u64) -> u64 {
    let attrs = md.file_attributes();
    let len = md.len();
    if attrs & (OFFLINE | RECALL_ON_DATA) != 0 {
        0
    } else if attrs & (COMPRESSED | SPARSE | RECALL_ON_OPEN | REPARSE) != 0 {
        compressed_size(&path()).unwrap_or(len)
    } else if len <= 700 {
        // такая мелочь хранится прямо в записи MFT и места не занимает
        0
    } else {
        len.div_ceil(cluster) * cluster
    }
}

fn list_dir(path: &Path, ctx: &Ctx, all: bool) -> Listing {
    let mut out = Listing::default();
    let Ok(rd) = std::fs::read_dir(path) else {
        out.denied = true;
        return out;
    };
    let mut files: Vec<(String, u64)> = Vec::new();
    let (mut count, mut bytes) = (0u64, 0u64);
    for e in rd.flatten() {
        let Ok(ft) = e.file_type() else { continue };
        // ссылки и точки соединения не обходим: посчитали бы одно и то же дважды или зациклились
        if ft.is_symlink() {
            continue;
        }
        // на Windows это данные из самого перечисления папки, без лишних обращений к диску
        let Ok(md) = e.metadata() else { continue };
        if ft.is_dir() {
            // облачная папка, ещё не скачанная, — заходить в неё значит качать её
            if md.file_attributes() & (OFFLINE | RECALL_ON_DATA) == 0 {
                out.dirs.push(e.file_name().to_string_lossy().into_owned());
            }
            continue;
        }
        let size = alloc(&md, || e.path(), ctx.cluster);
        count += 1;
        bytes += size;
        files.push((e.file_name().to_string_lossy().into_owned(), size));
    }
    ctx.progress.files.fetch_add(count, Ordering::Relaxed);
    ctx.progress.bytes.fetch_add(bytes, Ordering::Relaxed);
    // отдельными узлами — только самые крупные, остальное одним куском
    let (max, keep_min) = if all { (5000, 0) } else { (ctx.limits.max_files, ctx.limits.keep_min) };
    if files.len() > max {
        files.select_nth_unstable_by(max, |a, b| b.1.cmp(&a.1));
    }
    for (i, (name, size)) in files.into_iter().enumerate() {
        if i < max && size >= keep_min && size > 0 {
            out.files.push((name, size));
        } else {
            out.small_size += size;
            out.small_count += 1;
        }
    }
    out
}

fn insert(tree: &mut Tree, node: u32, l: &Listing) -> Vec<(u32, String)> {
    let mut dirs = Vec::with_capacity(l.dirs.len());
    for name in &l.dirs {
        dirs.push((tree.add_child(node, name, Kind::Dir, 0, 0), name.clone()));
    }
    let mut total = 0;
    for (name, size) in &l.files {
        tree.add_child(node, name, Kind::File, *size, 1);
        total += size;
    }
    if l.small_count > 0 {
        let id = tree.add_child(node, SMALL, Kind::Small, l.small_size, l.small_count);
        tree.get_mut(id).flags |= F_EXPANDABLE;
        total += l.small_size;
    }
    tree.add_size(node, total as i64, (l.files.len() as u32 + l.small_count) as i64);
    let n = tree.get_mut(node);
    n.flags |= F_DONE;
    if l.denied {
        n.flags |= F_DENIED;
    }
    dirs
}

struct Queue {
    /// папки в очереди и сколько их сейчас читают
    state: Mutex<(VecDeque<(u32, PathBuf)>, usize)>,
    cv: Condvar,
}

fn worker(tree: &Shared, q: &Queue, ctx: &Ctx) {
    loop {
        let (node, path) = {
            let mut st = q.state.lock().unwrap();
            loop {
                if ctx.progress.cancel.load(Ordering::Relaxed) {
                    q.cv.notify_all();
                    return;
                }
                if let Some(job) = st.0.pop_front() {
                    st.1 += 1;
                    break job;
                }
                if st.1 == 0 {
                    q.cv.notify_all();
                    return;
                }
                st = q.cv.wait(st).unwrap();
            }
        };
        let listing = list_dir(&path, ctx, false);
        ctx.progress.dirs.fetch_add(1, Ordering::Relaxed);
        let dirs = {
            let mut t = tree.write().unwrap();
            if t.alive(node) {
                insert(&mut t, node, &listing)
            } else {
                Vec::new()
            }
        };
        let mut st = q.state.lock().unwrap();
        for (id, name) in dirs {
            st.0.push_back((id, path.join(name)));
        }
        st.1 -= 1;
        drop(st);
        q.cv.notify_all();
    }
}

fn space(root: &Path) -> Option<(u64, u64)> {
    let w = wide_path(root);
    let (mut avail, mut total) = (0u64, 0u64);
    unsafe { GetDiskFreeSpaceExW(pcwstr(&w), Some(&mut avail), Some(&mut total), None).ok()? };
    Some((total, avail))
}

/// Свободное и всё место на диске, где лежит путь
pub fn volume_space(path: &Path) -> Option<(u64, u64)> {
    space(path.ancestors().last().unwrap_or(path))
}

fn cluster(root: &Path) -> u64 {
    let w = wide_path(root.ancestors().last().unwrap_or(root));
    let (mut spc, mut bps, mut free, mut total) = (0u32, 0u32, 0u32, 0u32);
    let ok = unsafe { GetDiskFreeSpaceW(pcwstr(&w), Some(&mut spc), Some(&mut bps), Some(&mut free), Some(&mut total)).is_ok() };
    if ok && spc * bps > 0 {
        (spc * bps) as u64
    } else {
        4096
    }
}

fn post(hwnd: isize) {
    unsafe {
        let _ = PostMessageW(Some(HWND(hwnd as *mut _)), WM_SCAN, WPARAM(0), LPARAM(0));
    }
}

/// Начать сканирование; окно получает WM_SCAN, пока оно идёт, и в конце
pub fn start(hwnd: HWND, root: PathBuf, name: &str) -> Scan {
    let progress = Arc::new(Progress::default());
    let tree = Arc::new(RwLock::new(Tree::new(root.clone(), name)));
    let volume = root.parent().is_none();
    let (t, p, h) = (tree.clone(), progress.clone(), hwnd.0 as isize);
    let _ = std::thread::Builder::new().name("scan".into()).spawn(move || {
        let started = Instant::now();
        let mut limits = Limits { keep_min: 32 << 10, max_files: 48 };
        let sp = if volume { space(&root) } else { None };
        if let Some((total, avail)) = sp {
            let used = total.saturating_sub(avail);
            p.expected.store(used, Ordering::Relaxed);
            // чем больше диск, тем крупнее «мелочь» — иначе узлов будут миллионы
            limits.keep_min = (used / 4_000_000).clamp(16 << 10, 1 << 20);
        }
        let ctx = Ctx { limits, cluster: cluster(&root), progress: p.clone() };
        let q = Queue { state: Mutex::new((VecDeque::from([(0, root.clone())]), 0)), cv: Condvar::new() };
        let threads = std::thread::available_parallelism().map_or(4, |n| n.get()).clamp(4, 8);
        std::thread::scope(|s| {
            for _ in 0..threads {
                s.spawn(|| worker(&t, &q, &ctx));
            }
            // окно перерисовывает растущую диаграмму несколько раз в секунду
            s.spawn(|| loop {
                std::thread::sleep(Duration::from_millis(120));
                post(h);
                let st = q.state.lock().unwrap();
                if p.cancel.load(Ordering::Relaxed) || st.0.is_empty() && st.1 == 0 {
                    break;
                }
            });
        });
        if !p.cancel.load(Ordering::Relaxed) {
            if let Some((total, avail)) = sp {
                // занятое, которого нет ни в одном прочитанном файле: системные данные, папки без доступа
                let used = total.saturating_sub(avail);
                let mut tr = t.write().unwrap();
                let seen = tr.get(0).size;
                if used > seen {
                    tr.add_child_sized(0, HIDDEN, Kind::Hidden, used - seen, 0);
                }
            }
        }
        p.millis.store(started.elapsed().as_millis() as u64, Ordering::Relaxed);
        p.done.store(true, Ordering::Relaxed);
        post(h);
    });
    Scan { tree, progress, volume }
}

/// Раскрыть «помельче»: перечитать папку и показать каждый её файл
pub fn expand_small(tree: &Shared, small: u32) -> bool {
    let (dir, path) = {
        let t = tree.read().unwrap();
        if !t.alive(small) || t.get(small).kind != Kind::Small || t.get(small).flags & F_EXPANDABLE == 0 {
            return false;
        }
        let dir = t.get(small).parent;
        (dir, t.path(dir))
    };
    let ctx = Ctx { limits: Limits { keep_min: 0, max_files: 5000 }, cluster: cluster(&path), progress: Arc::new(Progress::default()) };
    let listing = list_dir(&path, &ctx, true);
    let mut t = tree.write().unwrap();
    if !t.alive(dir) {
        return false;
    }
    let known: HashSet<String> = t.children(dir).filter(|c| t.get(*c).kind == Kind::File).map(|c| t.get(c).name.to_string()).collect();
    t.remove(small);
    for (name, size) in &listing.files {
        if !known.contains(name) {
            t.add_child_sized(dir, name, Kind::File, *size, 1);
        }
    }
    // пустые файлы и то, что не влезло, — всё равно одним куском, но уже без раскрытия
    if listing.small_count > 0 {
        t.add_child_sized(dir, SMALL, Kind::Small, listing.small_size, listing.small_count);
    }
    true
}

pub fn denied(tree: &Tree, id: u32) -> bool {
    tree.get(id).flags & F_DENIED != 0
}
