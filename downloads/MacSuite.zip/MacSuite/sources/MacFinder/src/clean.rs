//! Очистка: мусор (корзина, временные файлы, кэш) удаляется насовсем,
//! лишние файлы на диске (дубликаты, большие, старые загрузки) — только в корзину

use std::collections::HashMap;
use std::io::{Read, Seek, SeekFrom};
use std::os::windows::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Mutex};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

use tiny_skia::PixmapMut;
use windows::core::PCWSTR;
use windows::Win32::Foundation::{HWND, LPARAM, WPARAM};
use windows::Win32::Storage::FileSystem::FILE_ATTRIBUTE_REPARSE_POINT;
use windows::Win32::System::Com::{CoInitializeEx, COINIT_APARTMENTTHREADED};
use windows::Win32::UI::Shell::*;
use windows::Win32::UI::WindowsAndMessaging::PostMessageW;
use xxhash_rust::xxh3::Xxh3;

use crate::analyze::WM_SCAN;
use crate::fs;
use crate::gfx::{self, Area, Btn, Icon};
use crate::win;

// ---------- проверка диска: большие файлы и дубликаты ----------

/// с этого размера файл попадает в «Большие файлы»
const BIG: u64 = 200 << 20;
/// дубликаты ищем среди файлов не меньше этого — мелочь места не освободит
const DUP_MIN: u64 = 1 << 20;
/// кусок для отпечатков
const PART: usize = 64 << 10;

#[derive(Clone)]
pub struct Found {
    pub path: PathBuf,
    pub size: u64,
    pub modified: u64,
}

pub struct Check {
    pub big: Vec<Found>,
    pub dups: Vec<Vec<Found>>,
}

pub enum Msg {
    Progress(u64, u64, String),
    Done(Box<Check>),
}

/// Папки, где одинаковые файлы — норма: система, программы, служебные данные,
/// скрытые папки настроек (.cargo, .local, .vscode…)
fn skip_dups(p: &Path) -> bool {
    let s = p.to_string_lossy().to_lowercase();
    ["\\windows\\", "\\program files", "\\programdata\\", "\\appdata\\", "\\$recycle.bin", "\\node_modules\\", "\\steamapps\\", "\\target\\"]
        .iter()
        .any(|k| s.contains(k))
        || s.contains("\\.")
}

/// Программы сами в корзину не отмечаем: две одинаковые .exe часто нужны обеим своим программам
fn is_program(p: &Path) -> bool {
    let ext = p.extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default();
    matches!(ext.as_str(), "exe" | "dll" | "sys" | "msi" | "node" | "pyd")
}

/// Номер файла на томе: у жёстких ссылок он общий — это один файл, а не копии
fn file_id(p: &Path) -> Option<(u32, u64)> {
    use std::os::windows::io::AsRawHandle;
    use windows::Win32::Storage::FileSystem::{GetFileInformationByHandle, BY_HANDLE_FILE_INFORMATION};
    let f = std::fs::File::open(p).ok()?;
    let mut info = BY_HANDLE_FILE_INFORMATION::default();
    unsafe { GetFileInformationByHandle(windows::Win32::Foundation::HANDLE(f.as_raw_handle()), &mut info).ok()? };
    Some((info.dwVolumeSerialNumber, (info.nFileIndexHigh as u64) << 32 | info.nFileIndexLow as u64))
}

struct Walk {
    gen: Arc<AtomicU64>,
    my: u64,
    files: u64,
    bytes: u64,
    last: Instant,
    tx: Sender<Msg>,
    hwnd: isize,
}

impl Walk {
    fn stopped(&self) -> bool {
        self.gen.load(Ordering::Relaxed) != self.my
    }
    fn progress(&mut self, what: &str) {
        if self.last.elapsed().as_millis() > 120 {
            self.send(what);
        }
    }
    fn send(&mut self, what: &str) {
        self.last = Instant::now();
        let _ = self.tx.send(Msg::Progress(self.files, self.bytes, what.to_string()));
        post(self.hwnd);
    }
}

/// Отпечаток начала и конца файла — отсеивает почти все разные файлы одного размера
fn quick(p: &Path, size: u64) -> Option<u64> {
    let mut f = std::fs::File::open(p).ok()?;
    let mut h = Xxh3::new();
    let mut buf = vec![0u8; PART];
    let n = f.read(&mut buf).ok()?;
    h.update(&buf[..n]);
    if size > 2 * PART as u64 {
        f.seek(SeekFrom::End(-(PART as i64))).ok()?;
        let n = f.read(&mut buf).ok()?;
        h.update(&buf[..n]);
    }
    Some(h.digest())
}

/// Отпечаток по всему файлу, как в SquirrelDisk: небольшие читаем целиком,
/// большие — 32 куска, разбросанных от начала до конца (около 2 МБ на файл)
fn sampled(p: &Path, size: u64) -> Option<u64> {
    let mut f = std::fs::File::open(p).ok()?;
    let mut h = Xxh3::new();
    let mut buf = vec![0u8; PART];
    if size <= 8 << 20 {
        loop {
            let n = f.read(&mut buf).ok()?;
            if n == 0 {
                break;
            }
            h.update(&buf[..n]);
        }
    } else {
        let spots = 32u64;
        for i in 0..spots {
            f.seek(SeekFrom::Start((size - PART as u64) * i / (spots - 1))).ok()?;
            f.read_exact(&mut buf).ok()?;
            h.update(&buf);
        }
    }
    Some(h.digest())
}

fn group_by(list: Vec<Found>, key: impl Fn(&Found) -> Option<u64>) -> Vec<Vec<Found>> {
    let mut m: HashMap<u64, Vec<Found>> = HashMap::new();
    for f in list {
        if let Some(k) = key(&f) {
            m.entry(k).or_default().push(f);
        }
    }
    m.into_values().filter(|g| g.len() > 1).collect()
}

/// Дубликаты: одинаковый размер → одинаковые начало и конец → одинаковые куски по всему файлу.
/// Имена не важны: копии часто переименованы. Самые крупные сравниваем первыми, в несколько потоков
fn find_dups(sizes: HashMap<u64, Vec<Found>>, w: &mut Walk) -> Vec<Vec<Found>> {
    let mut cands: Vec<(u64, Vec<Found>)> = sizes.into_iter().filter(|(_, v)| v.len() > 1).collect();
    cands.sort_by(|a, b| b.0.cmp(&a.0));
    let total = cands.len();
    let next = AtomicUsize::new(0);
    let out = Mutex::new(Vec::new());
    let jobs = Mutex::new(cands.into_iter().map(Some).collect::<Vec<_>>());
    let (gen, my) = (w.gen.clone(), w.my);
    std::thread::scope(|s| {
        for _ in 0..4 {
            s.spawn(|| loop {
                let i = next.fetch_add(1, Ordering::Relaxed);
                if i >= total || gen.load(Ordering::Relaxed) != my {
                    break;
                }
                let Some((size, list)) = jobs.lock().unwrap()[i].take() else { continue };
                for g in group_by(list, |f| quick(&f.path, size)) {
                    let mut same = group_by(g, |f| sampled(&f.path, size));
                    // жёсткие ссылки на один файл — не дубликаты: удаление одной ничего не освободит
                    for grp in &mut same {
                        let mut seen = std::collections::HashSet::new();
                        grp.retain(|f| file_id(&f.path).is_none_or(|id| seen.insert(id)));
                    }
                    same.retain(|grp| grp.len() > 1);
                    out.lock().unwrap().extend(same);
                }
            });
        }
        while next.load(Ordering::Relaxed) < total && !w.stopped() {
            std::thread::sleep(std::time::Duration::from_millis(120));
            let done = next.load(Ordering::Relaxed).min(total);
            w.send(&format!("Сравниваем файлы одного размера… {done} из {total}"));
        }
    });
    let mut out = out.into_inner().unwrap();
    for g in &mut out {
        // первым — самый старый: его и оставляем
        g.sort_by_key(|f| f.modified);
    }
    let waste = |g: &Vec<Found>| g[0].size * (g.len() as u64 - 1);
    out.sort_by_key(|g| std::cmp::Reverse(waste(g)));
    out.truncate(500);
    out
}

/// Проверить папку или диск: большие файлы и дубликаты; поток бросит работу, как только gen сменится
pub fn check(hwnd: HWND, root: PathBuf, gen: Arc<AtomicU64>) -> Receiver<Msg> {
    let (tx, rx) = channel();
    let my = gen.load(Ordering::Relaxed);
    let h = hwnd.0 as isize;
    std::thread::spawn(move || {
        let mut w = Walk { gen, my, files: 0, bytes: 0, last: Instant::now(), tx, hwnd: h };
        let mut big = Vec::new();
        let mut sizes: HashMap<u64, Vec<Found>> = HashMap::new();
        let mut stack = vec![root];
        while let Some(dir) = stack.pop() {
            if w.stopped() {
                return;
            }
            let Ok(rd) = std::fs::read_dir(&dir) else { continue };
            for e in rd.flatten() {
                let Ok(ft) = e.file_type() else { continue };
                if ft.is_symlink() {
                    continue;
                }
                let Ok(md) = e.metadata() else { continue };
                if ft.is_dir() {
                    stack.push(e.path());
                    continue;
                }
                let size = md.file_size();
                w.files += 1;
                w.bytes += size;
                if size >= DUP_MIN {
                    let f = Found { path: e.path(), size, modified: md.last_write_time() };
                    if size >= BIG {
                        big.push(f.clone());
                    }
                    if !skip_dups(&f.path) {
                        sizes.entry(size).or_default().push(f);
                    }
                }
            }
            w.progress(&dir.to_string_lossy());
        }
        let dups = find_dups(sizes, &mut w);
        if w.stopped() {
            return;
        }
        big.sort_by_key(|f| std::cmp::Reverse(f.size));
        big.truncate(100);
        let _ = w.tx.send(Msg::Done(Box::new(Check { big, dups })));
        post(h);
    });
    rx
}

pub struct Junk {
    pub name: &'static str,
    pub hint: &'static str,
    pub paths: Vec<PathBuf>,
    pub size: Option<u64>,
    pub on: bool,
    /// корзина чистится своей функцией Windows, а не удалением файлов
    pub bin: bool,
}

#[derive(Clone, Copy, PartialEq)]
pub enum Kind {
    Dup,
    Big,
    Old,
}

pub struct Item {
    pub kind: Kind,
    pub path: PathBuf,
    pub size: u64,
    pub modified: u64,
    pub on: bool,
    /// первый файл в группе дубликатов — с отступом сверху
    pub first: bool,
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum CHit {
    None,
    Junk(usize),
    CleanJunk,
    Drive,
    Scan,
    Item(usize),
    Trash,
}

pub struct Clean {
    pub junk: Vec<Junk>,
    junk_rx: Option<Receiver<(usize, u64)>>,
    clean_rx: Option<Receiver<u64>>,
    pub cleaning: bool,
    pub freed: Option<u64>,
    pub drive: PathBuf,
    gen: Arc<AtomicU64>,
    scan_rx: Option<Receiver<Msg>>,
    pub progress: Option<(u64, u64, String)>,
    pub items: Vec<Item>,
    pub scanned: bool,
    pub scroll: f32,
    pub hover: CHit,
}

fn post(h: isize) {
    unsafe {
        let _ = PostMessageW(Some(HWND(h as *mut _)), WM_SCAN, WPARAM(0), LPARAM(0));
    }
}

/// Кэш браузеров на движке Chromium: в каждом профиле одни и те же папки
fn chromium(base: &Path, out: &mut Vec<PathBuf>) {
    let Ok(rd) = std::fs::read_dir(base) else { return };
    for e in rd.flatten() {
        let n = e.file_name().to_string_lossy().to_string();
        if n == "Default" || n.starts_with("Profile ") || n == "Guest Profile" {
            for sub in ["Cache", "Code Cache", "GPUCache", "Service Worker\\CacheStorage"] {
                out.push(e.path().join(sub));
            }
        }
    }
}

fn junk_list() -> Vec<Junk> {
    let la = std::env::var_os("LOCALAPPDATA").map(PathBuf::from).unwrap_or_default();
    let mut browsers = Vec::new();
    for b in
        ["Google\\Chrome\\User Data", "Microsoft\\Edge\\User Data", "Yandex\\YandexBrowser\\User Data", "BraveSoftware\\Brave-Browser\\User Data"]
    {
        chromium(&la.join(b), &mut browsers);
    }
    for o in ["Opera Software\\Opera Stable", "Opera Software\\Opera GX Stable"] {
        browsers.push(la.join(o).join("Cache"));
    }
    if let Ok(rd) = std::fs::read_dir(la.join("Mozilla\\Firefox\\Profiles")) {
        for e in rd.flatten() {
            browsers.push(e.path().join("cache2"));
        }
    }
    let gpu = ["D3DSCache", "NVIDIA\\DXCache", "NVIDIA\\GLCache", "AMD\\DxCache", "AMD\\DxcCache", "AMD\\GLCache"].map(|p| la.join(p)).to_vec();
    let reports = vec![la.join("CrashDumps"), la.join("Microsoft\\Windows\\WER")];
    let keep = |v: Vec<PathBuf>| v.into_iter().filter(|p| p.is_dir()).collect::<Vec<_>>();
    vec![
        Junk {
            name: "Корзина", hint: "Удалённые файлы со всех дисков", paths: Vec::new(), size: None, on: true, bin: true
        },
        Junk {
            name: "Временные файлы",
            hint: "Папка Temp: остатки установок и программ",
            paths: keep(vec![std::env::temp_dir()]),
            size: None,
            on: true,
            bin: false,
        },
        Junk {
            name: "Кэш браузеров",
            hint: "Chrome, Edge, Яндекс, Opera, Firefox — сайты скачают его заново",
            paths: keep(browsers),
            size: None,
            on: true,
            bin: false,
        },
        Junk {
            name: "Кэш видеодрайвера",
            hint: "Шейдеры DirectX, NVIDIA и AMD — игры соберут их снова",
            paths: keep(gpu),
            size: None,
            on: true,
            bin: false,
        },
        Junk {
            name: "Отчёты об ошибках", hint: "Дампы падений программ и отчёты Windows", paths: keep(reports), size: None, on: true, bin: false
        },
    ]
}

pub fn dir_size(p: &Path) -> u64 {
    let mut total = 0;
    let mut stack = vec![p.to_path_buf()];
    while let Some(d) = stack.pop() {
        let Ok(rd) = std::fs::read_dir(&d) else { continue };
        for e in rd.flatten() {
            let Ok(md) = e.metadata() else { continue };
            if md.is_dir() {
                if md.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT.0 == 0 {
                    stack.push(e.path());
                }
            } else {
                total += md.file_size();
            }
        }
    }
    total
}

fn bin_size() -> u64 {
    let mut info = SHQUERYRBINFO { cbSize: std::mem::size_of::<SHQUERYRBINFO>() as u32, ..Default::default() };
    unsafe {
        let _ = SHQueryRecycleBinW(PCWSTR::null(), &mut info);
    }
    info.i64Size.max(0) as u64
}

/// Удалить содержимое папки (саму папку оставить); занятые файлы просто пропускаются
fn wipe(dir: &Path) -> u64 {
    let mut freed = 0;
    let Ok(rd) = std::fs::read_dir(dir) else { return 0 };
    for e in rd.flatten() {
        let p = e.path();
        let Ok(md) = e.metadata() else { continue };
        if md.is_dir() {
            // у ссылки на папку удаляем только саму ссылку, не то, куда она ведёт
            if md.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT.0 == 0 {
                freed += wipe(&p);
            }
            let _ = std::fs::remove_dir(&p);
        } else if std::fs::remove_file(&p).is_ok() {
            freed += md.file_size();
        }
    }
    freed
}

fn now_ft() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| (d.as_nanos() / 100) as u64 + 116_444_736_000_000_000).unwrap_or(0)
}

impl Clean {
    pub fn new(hwnd: HWND, drive: PathBuf) -> Clean {
        let mut c = Clean {
            junk: junk_list(),
            junk_rx: None,
            clean_rx: None,
            cleaning: false,
            freed: None,
            drive,
            gen: Arc::new(AtomicU64::new(0)),
            scan_rx: None,
            progress: None,
            items: Vec::new(),
            scanned: false,
            scroll: 0.0,
            hover: CHit::None,
        };
        c.measure(hwnd);
        c
    }

    /// Посчитать размер мусора в фоне
    fn measure(&mut self, hwnd: HWND) {
        let (tx, rx) = channel();
        let jobs: Vec<(usize, bool, Vec<PathBuf>)> = self.junk.iter().enumerate().map(|(i, j)| (i, j.bin, j.paths.clone())).collect();
        let h = hwnd.0 as isize;
        std::thread::spawn(move || {
            for (i, bin, paths) in jobs {
                let size = if bin { bin_size() } else { paths.iter().map(|p| dir_size(p)).sum() };
                if tx.send((i, size)).is_err() {
                    return;
                }
                post(h);
            }
        });
        for j in &mut self.junk {
            j.size = None;
        }
        self.junk_rx = Some(rx);
    }

    pub fn junk_total(&self) -> u64 {
        self.junk.iter().filter(|j| j.on).filter_map(|j| j.size).sum()
    }

    /// Удалить отмеченный мусор (подтверждение спрашивает окно)
    pub fn clean_junk(&mut self, hwnd: HWND) {
        let jobs: Vec<(bool, u64, Vec<PathBuf>)> = self.junk.iter().filter(|j| j.on).map(|j| (j.bin, j.size.unwrap_or(0), j.paths.clone())).collect();
        let (tx, rx) = channel();
        let h = hwnd.0 as isize;
        std::thread::spawn(move || {
            unsafe {
                let _ = CoInitializeEx(None, COINIT_APARTMENTTHREADED);
            }
            let mut freed = 0;
            for (bin, size, paths) in jobs {
                if bin {
                    let flags = SHERB_NOCONFIRMATION | SHERB_NOPROGRESSUI | SHERB_NOSOUND;
                    if unsafe { SHEmptyRecycleBinW(None, PCWSTR::null(), flags) }.is_ok() {
                        freed += size;
                    }
                } else {
                    for p in paths {
                        freed += wipe(&p);
                    }
                }
            }
            let _ = tx.send(freed);
            post(h);
        });
        self.cleaning = true;
        self.freed = None;
        self.clean_rx = Some(rx);
    }

    pub fn scan(&mut self, hwnd: HWND) {
        self.gen.fetch_add(1, Ordering::Relaxed);
        self.items.clear();
        self.scanned = false;
        self.progress = Some((0, 0, String::new()));
        self.scan_rx = Some(check(hwnd, self.drive.clone(), self.gen.clone()));
    }

    pub fn stop(&self) {
        self.gen.fetch_add(1, Ordering::Relaxed);
    }

    /// Забрать результаты фоновых задач; true — есть что перерисовать
    pub fn pump(&mut self, hwnd: HWND) -> bool {
        let mut changed = false;
        if let Some(rx) = &self.junk_rx {
            for (i, size) in rx.try_iter().collect::<Vec<_>>() {
                self.junk[i].size = Some(size);
                changed = true;
            }
        }
        if let Some(rx) = &self.clean_rx {
            if let Ok(freed) = rx.try_recv() {
                self.cleaning = false;
                self.freed = Some(freed);
                self.clean_rx = None;
                self.measure(hwnd);
                changed = true;
            }
        }
        if let Some(rx) = &self.scan_rx {
            let msgs: Vec<Msg> = rx.try_iter().collect();
            for m in msgs {
                changed = true;
                match m {
                    Msg::Progress(f, b, d) => self.progress = Some((f, b, d)),
                    Msg::Done(s) => {
                        self.fill(*s);
                        self.scan_rx = None;
                        self.progress = None;
                        self.scanned = true;
                    }
                }
            }
        }
        changed
    }

    fn fill(&mut self, s: Check) {
        let mut items = Vec::new();
        let mut in_dups = std::collections::HashSet::new();
        for g in &s.dups {
            for (k, f) in g.iter().enumerate() {
                in_dups.insert(f.path.clone());
                // самый старый оставляем, копии отмечаем
                let on = k > 0 && !is_program(&f.path);
                items.push(Item { kind: Kind::Dup, path: f.path.clone(), size: f.size, modified: f.modified, on, first: k == 0 });
            }
        }
        for f in &s.big {
            if !in_dups.contains(&f.path) {
                items.push(Item { kind: Kind::Big, path: f.path.clone(), size: f.size, modified: f.modified, on: false, first: false });
            }
        }
        // старые загрузки: лежат в «Загрузках» больше трёх месяцев
        if let Some(dl) = win::known_folder(&FOLDERID_Downloads) {
            let limit = now_ft().saturating_sub(90 * 24 * 3600 * 10_000_000);
            if let Ok(rd) = std::fs::read_dir(&dl) {
                let mut old: Vec<Item> = rd
                    .flatten()
                    .filter_map(|e| {
                        let md = e.metadata().ok()?;
                        (md.is_file() && md.last_write_time() < limit).then(|| Item {
                            kind: Kind::Old,
                            path: e.path(),
                            size: md.file_size(),
                            modified: md.last_write_time(),
                            on: false,
                            first: false,
                        })
                    })
                    .collect();
                old.sort_by_key(|i| std::cmp::Reverse(i.size));
                old.truncate(200);
                items.extend(old);
            }
        }
        self.items = items;
    }

    pub fn selected(&self) -> Vec<PathBuf> {
        self.items.iter().filter(|i| i.on).map(|i| i.path.clone()).collect()
    }

    pub fn selected_size(&self) -> u64 {
        self.items.iter().filter(|i| i.on).map(|i| i.size).sum()
    }

    /// После удаления в корзину убираем из списка то, чего больше нет
    pub fn forget_missing(&mut self) {
        self.items.retain(|i| i.path.exists());
    }

    // ---------- вёрстка ----------

    fn rows(&self, a: &Area) -> (Vec<(Row, f32, f32)>, f32) {
        let mut out = Vec::new();
        let mut y = 0.0;
        out.push((Row::Title, y, 76.0));
        y += 76.0;
        out.push((Row::JunkHead, y, 46.0));
        y += 46.0;
        for i in 0..self.junk.len() {
            out.push((Row::Junk(i), y, 52.0));
            y += 52.0;
        }
        out.push((Row::JunkFoot, y, 60.0));
        y += 60.0 + 28.0;
        out.push((Row::ExtraHead, y, 60.0));
        y += 60.0;
        if self.progress.is_some() {
            out.push((Row::Progress, y, 50.0));
            y += 50.0;
        } else if self.scanned && self.items.is_empty() {
            out.push((Row::Note("Ничего лишнего не нашлось"), y, 44.0));
            y += 44.0;
        } else if !self.scanned {
            out.push((Row::Note("Нажмите «Проверить» — найдём дубликаты, большие файлы и старые загрузки"), y, 44.0));
            y += 44.0;
        }
        let mut last = None;
        for (i, it) in self.items.iter().enumerate() {
            if last != Some(it.kind) {
                y += 8.0;
                out.push((Row::Section(it.kind), y, 40.0));
                y += 40.0;
                last = Some(it.kind);
            } else if it.first {
                y += 10.0;
            }
            out.push((Row::Item(i), y, 34.0));
            y += 34.0;
        }
        let _ = a;
        (out, y + 30.0)
    }

    fn width(a: &Area) -> (f32, f32) {
        let w = (a.w - 48.0).min(900.0);
        (a.x + 24.0, w)
    }

    fn buttons(&self, a: &Area, rows: &[(Row, f32, f32)]) -> Vec<(CHit, [f32; 4])> {
        let (x, w) = Self::width(a);
        let top = a.y - self.scroll;
        let mut out = Vec::new();
        for (r, y, h) in rows {
            let y = top + y;
            match r {
                Row::JunkFoot => out.push((CHit::CleanJunk, [x + w - 16.0 - 190.0, y + (h - 34.0) / 2.0, 190.0, 34.0])),
                Row::ExtraHead => {
                    // ширина под подпись: «Диск C:» короткая, а папка может называться длинно
                    let label = format!("Диск {}", fs::display_name(&self.drive));
                    let dw = (gfx::measure(&a.fonts.regular, &label, 12.5 * a.s) / a.s + 52.0).clamp(110.0, 260.0);
                    out.push((CHit::Drive, [x + 170.0, y + 14.0, dw, 32.0]));
                    out.push((CHit::Scan, [x + 180.0 + dw, y + 14.0, 120.0, 32.0]));
                    if self.items.iter().any(|i| i.on) {
                        out.push((CHit::Trash, [x + w - 230.0, y + 14.0, 230.0, 32.0]));
                    }
                }
                _ => {}
            }
        }
        out
    }

    pub fn hit(&self, a: &Area, x: f32, y: f32) -> CHit {
        let (rows, _) = self.rows(a);
        for (h, r) in self.buttons(a, &rows) {
            if x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3] {
                return h;
            }
        }
        let (cx, w) = Self::width(a);
        let top = a.y - self.scroll;
        for (r, ry, rh) in &rows {
            let ry = top + ry;
            if y < ry || y >= ry + rh || x < cx || x > cx + w {
                continue;
            }
            return match r {
                Row::Junk(i) => CHit::Junk(*i),
                Row::Item(i) => CHit::Item(*i),
                _ => CHit::None,
            };
        }
        CHit::None
    }

    pub fn wheel(&mut self, a: &Area, delta: f32) {
        let (_, total) = self.rows(a);
        self.scroll = (self.scroll - delta * 90.0).clamp(0.0, (total - a.h).max(0.0));
    }

    pub fn click(&mut self, h: CHit) {
        match h {
            CHit::Junk(i) => {
                if let Some(j) = self.junk.get_mut(i) {
                    j.on = !j.on;
                }
            }
            CHit::Item(i) => {
                if let Some(it) = self.items.get_mut(i) {
                    it.on = !it.on;
                }
            }
            _ => {}
        }
    }

    pub fn compose(&self, pm: &mut PixmapMut, a: &Area) {
        let s = a.s;
        let p = |v: f32| v * s;
        let f = a.fonts;
        let (rows, _) = self.rows(a);
        let (x, w) = Self::width(a);
        let top = a.y - self.scroll;
        // карточка мусора — подложка от шапки до подвала
        let card_top = rows.iter().find(|r| matches!(r.0, Row::JunkHead)).map(|r| r.1);
        let card_bot = rows.iter().find(|r| matches!(r.0, Row::JunkFoot)).map(|r| r.1 + r.2);
        if let (Some(t), Some(b)) = (card_top, card_bot) {
            gfx::fill_rrect(pm, p(x), p(top + t), p(w), p(b - t), p(14.0), gfx::white(0.045));
        }
        for &(ref r, ry, rh) in &rows {
            let y = top + ry;
            if y > a.y + a.h || y + rh < a.y {
                continue;
            }
            match r {
                Row::Title => {
                    gfx::text(pm, &f.semibold, "Очистка", p(x), p(y + 40.0), 24.0 * s, gfx::white(0.96));
                    let sub = "Мусор удаляется насовсем, лишние файлы — только в корзину, их можно вернуть";
                    gfx::text(pm, &f.regular, sub, p(x), p(y + 62.0), 12.5 * s, gfx::white(0.45));
                }
                Row::JunkHead => {
                    gfx::icon(pm, Icon::Sparkle, p(x + 16.0), p(y + 14.0), p(20.0), gfx::accent(1.0));
                    gfx::text(pm, &f.semibold, "Мусор", p(x + 46.0), p(y + 30.0), 15.0 * s, gfx::white(0.95));
                }
                Row::Junk(i) => {
                    let j = &self.junk[*i];
                    if self.hover == CHit::Junk(*i) {
                        gfx::fill_rrect(pm, p(x + 6.0), p(y + 2.0), p(w - 12.0), p(rh - 4.0), p(10.0), gfx::white(0.05));
                    }
                    gfx::checkbox(pm, p(x + 18.0), p(y + 16.0), p(18.0), j.on);
                    gfx::text(pm, &f.semibold, j.name, p(x + 48.0), p(y + 22.0), 13.5 * s, gfx::white(if j.on { 0.95 } else { 0.6 }));
                    let hint = gfx::fit(&f.regular, j.hint, 12.0 * s, p(w - 200.0));
                    gfx::text(pm, &f.regular, &hint, p(x + 48.0), p(y + 40.0), 12.0 * s, gfx::white(0.42));
                    let size = match j.size {
                        Some(n) => fs::size_text(n),
                        None => "считаем…".into(),
                    };
                    let sw = gfx::measure(&f.semibold, &size, 13.5 * s);
                    gfx::text(pm, &f.semibold, &size, p(x + w - 20.0) - sw, p(y + 31.0), 13.5 * s, gfx::white(if j.on { 0.9 } else { 0.45 }));
                }
                Row::JunkFoot => {
                    gfx::fill_rrect(pm, p(x + 16.0), p(y), p(w - 32.0), 1.0, 0.0, gfx::white(0.07));
                    let msg = if self.cleaning {
                        "Очищаем…".to_string()
                    } else if let Some(fr) = self.freed {
                        format!("Готово — освобождено {}", fs::size_text(fr))
                    } else {
                        "Занятые программами файлы пропускаются".to_string()
                    };
                    let green = if gfx::theme().dark { gfx::rgb(0x6C, 0xCB, 0x5F, 1.0) } else { gfx::rgb(0x10, 0x7C, 0x10, 1.0) };
                    let c = if self.freed.is_some() { green } else { gfx::white(0.45) };
                    gfx::text(pm, &f.regular, &msg, p(x + 20.0), p(y + rh / 2.0 + 4.6), 12.5 * s, c);
                }
                Row::ExtraHead => {
                    gfx::icon(pm, Icon::Pie, p(x + 4.0), p(y + 20.0), p(20.0), gfx::accent(1.0));
                    gfx::text(pm, &f.semibold, "Лишние файлы", p(x + 34.0), p(y + 36.0), 15.0 * s, gfx::white(0.95));
                }
                Row::Progress => {
                    let Some((files, bytes, dir)) = &self.progress else { continue };
                    let t = format!("Проверяем… {} · {}", fs::plural(*files as usize, ["файл", "файла", "файлов"]), fs::size_text(*bytes));
                    gfx::text(pm, &f.regular, &t, p(x + 4.0), p(y + 20.0), 13.0 * s, gfx::white(0.8));
                    let d = gfx::fit_middle(&f.regular, dir, 11.5 * s, p(w - 8.0));
                    gfx::text(pm, &f.regular, &d, p(x + 4.0), p(y + 40.0), 11.5 * s, gfx::white(0.38));
                }
                Row::Note(t) => {
                    gfx::text(pm, &f.regular, t, p(x + 4.0), p(y + 26.0), 13.0 * s, gfx::white(0.5));
                }
                Row::Section(k) => {
                    let list: Vec<&Item> = self.items.iter().filter(|i| i.kind == *k).collect();
                    let (title, extra) = match k {
                        Kind::Dup => {
                            let waste: u64 = list.iter().filter(|i| !i.first).map(|i| i.size).sum();
                            ("Дубликаты", format!("копии занимают {}", fs::size_text(waste)))
                        }
                        Kind::Big => ("Большие файлы", format!("больше 200 МБ · {}", fs::plural(list.len(), ["файл", "файла", "файлов"]))),
                        Kind::Old => {
                            ("Старые загрузки", format!("в «Загрузках» дольше 3 месяцев · {}", fs::size_text(list.iter().map(|i| i.size).sum())))
                        }
                    };
                    gfx::text(pm, &f.semibold, title, p(x + 4.0), p(y + 26.0), 14.0 * s, gfx::white(0.9));
                    let tw = gfx::measure(&f.semibold, title, 14.0 * s);
                    gfx::text(pm, &f.regular, &extra, p(x + 4.0) + tw + p(10.0), p(y + 26.0), 12.5 * s, gfx::white(0.45));
                }
                Row::Item(i) => {
                    let it = &self.items[*i];
                    if self.hover == CHit::Item(*i) {
                        gfx::fill_rrect(pm, p(x), p(y), p(w), p(rh), p(8.0), gfx::white(0.05));
                    }
                    gfx::checkbox(pm, p(x + 10.0), p(y + 9.0), p(16.0), it.on);
                    let name = it.path.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default();
                    let dir = it.path.parent().map(|d| d.display().to_string()).unwrap_or_default();
                    let size = fs::size_text(it.size);
                    let date = fs::date_text(it.modified);
                    let sw = gfx::measure(&f.regular, &size, 12.5 * s);
                    let dw = gfx::measure(&f.regular, &date, 12.0 * s);
                    let right = p(x + w - 12.0);
                    gfx::text(pm, &f.regular, &size, right - sw, p(y + 22.0), 12.5 * s, gfx::white(0.85));
                    gfx::text(pm, &f.regular, &date, right - sw - p(20.0) - dw, p(y + 22.0), 12.0 * s, gfx::white(0.4));
                    let room = right - sw - dw - p(40.0) - p(x + 36.0);
                    let nm = gfx::fit_middle(&f.regular, &name, 13.0 * s, room * 0.5);
                    let nw = gfx::measure(&f.regular, &nm, 13.0 * s);
                    let col = gfx::white(if it.on { 0.95 } else { 0.75 });
                    gfx::text(pm, &f.regular, &nm, p(x + 36.0), p(y + 22.0), 13.0 * s, col);
                    let dr = gfx::fit_middle(&f.regular, &dir, 11.5 * s, room - nw - p(12.0));
                    gfx::text(pm, &f.regular, &dr, p(x + 36.0) + nw + p(10.0), p(y + 22.0), 11.5 * s, gfx::white(0.35));
                }
            }
        }
        for (h, r) in self.buttons(a, &rows) {
            let hov = self.hover == h;
            let (label, kind) = match h {
                CHit::CleanJunk => {
                    let t = self.junk_total();
                    if self.cleaning {
                        ("Очищаем…".to_string(), Btn::Plain)
                    } else {
                        (format!("Очистить · {}", fs::size_text(t)), Btn::Primary)
                    }
                }
                CHit::Drive => (format!("Диск {}", fs::display_name(&self.drive)), Btn::Plain),
                CHit::Scan => ((if self.progress.is_some() { "Заново" } else { "Проверить" }).to_string(), Btn::Primary),
                CHit::Trash => {
                    let n = self.items.iter().filter(|i| i.on).count();
                    (format!("В корзину · {} · {}", n, fs::size_text(self.selected_size())), Btn::Danger)
                }
                _ => continue,
            };
            gfx::button(pm, &f.regular, p(r[0]), p(r[1]), p(r[2]), p(r[3]), &label, 12.5 * s, kind, hov);
            if h == CHit::Drive {
                gfx::icon(pm, Icon::ChevronDown, p(r[0] + r[2] - 26.0), p(r[1] + 9.0), p(14.0), gfx::white(0.7));
            }
        }
    }
}

enum Row {
    Title,
    JunkHead,
    Junk(usize),
    JunkFoot,
    ExtraHead,
    Progress,
    Note(&'static str),
    Section(Kind),
    Item(usize),
}
