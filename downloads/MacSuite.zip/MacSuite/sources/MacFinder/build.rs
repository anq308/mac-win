//! Вшивает значок в exe: без него ярлыки на рабочем столе и в «Пуске» пустые

fn main() {
    println!("cargo:rerun-if-changed=app.rc");
    println!("cargo:rerun-if-changed=app.ico");
    let out = std::env::var("OUT_DIR").unwrap_or_default();
    let res = format!("{out}/app.res.o");
    // windres из MinGW (build.ps1 добавляет его в PATH)
    let ok = std::process::Command::new("windres")
        .args(["app.rc", "-O", "coff", "-o", &res])
        .status()
        .is_ok_and(|s| s.success());
    if ok {
        println!("cargo:rustc-link-arg-bins={res}");
    } else {
        println!("cargo:warning=windres не найден — exe соберётся без значка");
    }
}
