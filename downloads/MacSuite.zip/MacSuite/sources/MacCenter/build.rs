//! Вшивает в exe значок и все пять программ комплекта (папки «Приложение» рядом с их исходниками):
//! один файл и ставит, и настраивает всё

use std::path::{Path, PathBuf};

const APPS: [(&str, &str); 5] = [
    ("MacShot", "MacShot-extracted/MacShot"),
    ("MacMixer", "MacMixer"),
    ("MacFinder", "MacFinfer2/MacFinder"),
    ("MacSpotlight", "MacSpotlight"),
    ("MacMirror", "MacMirror"),
];

fn walk(dir: &Path, base: &Path, out: &mut Vec<(String, PathBuf)>) {
    let Ok(rd) = std::fs::read_dir(dir) else { return };
    let mut items: Vec<_> = rd.flatten().map(|e| e.path()).collect();
    items.sort();
    for p in items {
        if p.is_dir() {
            walk(&p, base, out);
            continue;
        }
        let name = p.file_name().map(|n| n.to_string_lossy().to_lowercase()).unwrap_or_default();
        if name.ends_with(".log") {
            continue;
        }
        let rel = p.strip_prefix(base).unwrap().to_string_lossy().replace('\\', "/");
        out.push((rel, p));
    }
}

/// Метка сборки «ГГГГММДДччмм» (UTC): по ней центры сравнивают, кто новее
fn stamp() -> String {
    let secs = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0) as i64;
    let (days, rem) = (secs.div_euclid(86400), secs.rem_euclid(86400));
    // дата из числа дней (алгоритм Хиннанта)
    let z = days + 719468;
    let era = z.div_euclid(146097);
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    let y = yoe + era * 400 + if m <= 2 { 1 } else { 0 };
    format!("{y:04}{m:02}{d:02}{:02}{:02}", rem / 3600, rem % 3600 / 60)
}

fn main() {
    println!("cargo:rustc-env=BUILD_STAMP={}", stamp());
    println!("cargo:rerun-if-changed=src");
    println!("cargo:rerun-if-changed=app.rc");
    println!("cargo:rerun-if-changed=app.ico");
    let out = std::env::var("OUT_DIR").unwrap_or_default();
    let res = format!("{out}/app.res.o");
    let ok = std::process::Command::new("windres").args(["app.rc", "-O", "coff", "-o", &res]).status().is_ok_and(|s| s.success());
    if ok {
        println!("cargo:rustc-link-arg-bins={res}");
    } else {
        println!("cargo:warning=windres не найден — exe соберётся без значка");
    }
    // корень с программами: по умолчанию D:\mac-wind (две папки выше исходников)
    let root = std::env::var("MAC_WIND").map(PathBuf::from).unwrap_or_else(|_| {
        PathBuf::from(std::env::var("CARGO_MANIFEST_DIR").unwrap()).join("..").join("..")
    });
    println!("cargo:rerun-if-env-changed=MAC_WIND");
    let mut code = String::from("pub static FILES: &[(&str, &str, &[u8])] = &[\n");
    for (id, dir) in APPS {
        let base = root.join(dir).join("Приложение");
        println!("cargo:rerun-if-changed={}", base.display());
        let mut files = Vec::new();
        walk(&base, &base, &mut files);
        if files.is_empty() {
            println!("cargo:warning=нет файлов программы {id} в {}", base.display());
        }
        for (rel, p) in files {
            println!("cargo:rerun-if-changed={}", p.display());
            let abs = std::fs::canonicalize(&p).unwrap_or(p);
            let s = abs.to_string_lossy().trim_start_matches(r"\\?\").to_string();
            code += &format!("    ({id:?}, {rel:?}, include_bytes!({s:?})),\n");
        }
    }
    code += "];\n";
    std::fs::write(Path::new(&out).join("payload.rs"), code).unwrap();
}
