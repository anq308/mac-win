//! Пять программ комплекта: что это, где стоят, работают ли, их настройки, установка и удаление.
//! Сами программы вшиты в exe (build.rs) — установка запускает их же проверенные install.ps1.

use std::path::PathBuf;
use std::sync::atomic::{AtomicIsize, Ordering};
use std::sync::Mutex;

use crate::sys;

mod payload {
    include!(concat!(env!("OUT_DIR"), "/payload.rs"));
}

pub struct App {
    pub id: &'static str,
    pub exe: &'static str,
    pub title: &'static str,
    pub about: &'static str,
    pub glyph: char,
    /// имя в автозапуске и аргументы для него (None — программа без автозапуска)
    pub run: Option<(&'static str, &'static str)>,
    pub keys: &'static [(&'static str, &'static str)],
}

pub const APPS: [App; 5] = [
    App {
        id: "MacShot",
        exe: "mac-shot.exe",
        title: "Снимки экрана",
        about: "Снимок области, окна или всего экрана, редактор со стрелками и подписями, хранилище снимков и текст с картинки.",
        glyph: '\u{E722}',
        run: Some(("MacShot", "")),
        keys: &[
            ("Win+Shift+S", "панель: окно, область или весь экран"),
            ("Win+Shift+4", "сразу область (Пробел — окно)"),
            ("Win+Shift+3", "весь экран"),
            ("Win+Shift+2", "хранилище всех снимков"),
            ("Win+Shift+1", "скопировать текст с экрана"),
        ],
    },
    App {
        id: "MacMixer",
        exe: "mac-mixer.exe",
        title: "Звук и музыка",
        about: "Громкость каждой программы в трее, панель музыки сверху по центру с текстом песни и «островок» с уведомлениями.",
        glyph: '\u{E767}',
        run: Some(("MacMixer", "")),
        keys: &[("Клавиши музыки", "панель музыки сверху"), ("Ctrl+Win+M", "показать или спрятать панель музыки"), ("Щелчок по динамику", "микшер громкости")],
    },
    App {
        id: "MacFinder",
        exe: "mac-finder.exe",
        title: "Finder",
        about: "Файловый менеджер как в Mac: боковая панель, плитки и список, быстрый просмотр по Пробелу, анализ места и очистка.",
        glyph: '\u{E8B7}',
        run: None,
        keys: &[("Win+E", "открыть Finder"), ("Пробел", "быстрый просмотр файла"), ("Shift + открыть папку", "обычный Проводник")],
    },
    App {
        id: "MacSpotlight",
        exe: "mac-spotlight.exe",
        title: "Поиск",
        about: "Поиск приложений, файлов и действий по Win+Пробел, история буфера обмена, исправление раскладки и быстрый просмотр.",
        glyph: '\u{E721}',
        run: Some(("MacSpotlight", "")),
        keys: &[
            ("Win+Пробел", "открыть поиск"),
            ("Pause или Shift дважды", "исправить раскладку: «ghbdtn» → «привет»"),
            ("Shift+Pause", "исправить раскладку выделенного текста"),
            ("Пробел в Проводнике", "быстрый просмотр файла"),
            ("Alt+Shift", "сменить раскладку (Win+Пробел теперь занят поиском)"),
        ],
    },
    App {
        id: "MacMirror",
        exe: "mac-mirror.exe",
        title: "Экран iPhone",
        about: "Экран iPhone на компьютере по Wi-Fi через «Повтор экрана»: со звуком, снимками, записью и передачей файлов по QR-коду.",
        glyph: '\u{E8EA}',
        run: Some(("MacMirror", "--tray")),
        keys: &[("Ctrl+S", "снимок экрана телефона"), ("Ctrl+R", "запись видео"), ("Ctrl+F", "файлы с iPhone и на iPhone"), ("Ctrl+T", "поверх всех окон"), ("F11", "во весь экран")],
    },
];

pub fn dir(app: &App) -> PathBuf {
    sys::local("Programs").join(app.id)
}

pub fn exe_path(app: &App) -> PathBuf {
    dir(app).join(app.exe)
}

pub fn installed(app: &App) -> bool {
    exe_path(app).exists()
}

fn bundled(app: &App) -> Option<&'static [u8]> {
    payload::FILES.iter().find(|(id, rel, _)| *id == app.id && *rel == app.exe).map(|f| f.2)
}

pub fn has_payload(app: &App) -> bool {
    bundled(app).is_some()
}

/// Установленная версия совпадает с той, что внутри этого exe
pub fn up_to_date(app: &App) -> bool {
    let Some(b) = bundled(app) else { return true };
    let Ok(meta) = std::fs::metadata(exe_path(app)) else { return false };
    if meta.len() != b.len() as u64 {
        return false;
    }
    // сравнение целиком — раз на каждую версию файла, дальше из памяти
    static CACHE: Mutex<Vec<(PathBuf, Option<std::time::SystemTime>, bool)>> = Mutex::new(Vec::new());
    let (path, when) = (exe_path(app), meta.modified().ok());
    if let Some(hit) = CACHE.lock().ok().and_then(|c| c.iter().find(|e| e.0 == path && e.1 == when).map(|e| e.2)) {
        return hit;
    }
    let same = std::fs::read(&path).is_ok_and(|f| f == b);
    if let Ok(mut c) = CACHE.lock() {
        c.retain(|e| e.0 != path);
        c.push((path, when, same));
    }
    same
}

// ---------- состояние для окна (обновляется таймером) ----------

#[derive(Clone, Copy, PartialEq, Default)]
pub struct Status {
    pub installed: bool,
    pub running: bool,
    pub current: bool,
    pub autostart: bool,
}

pub fn status(app: &App, procs: &[String]) -> Status {
    let installed = installed(app);
    Status {
        installed,
        running: procs.iter().any(|p| p == app.exe),
        current: !installed || up_to_date(app),
        autostart: app.run.is_some_and(|(v, _)| sys::run_get(v)),
    }
}

// ---------- настройки ----------

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Opt {
    Autostart(usize),
    Lyrics,
    Island(&'static str),
    Layout,
    QuickLook,
    MirrorTray,
    MirrorTop,
    MirrorMuted,
    FinderExplorer,
    Snap,
    Mission,
}

pub struct OptInfo {
    pub opt: Opt,
    pub title: &'static str,
    pub sub: &'static str,
}

/// Настройки программы — то, что она сама хранит в своих файлах
pub fn options(i: usize) -> Vec<OptInfo> {
    let o = |opt, title, sub| OptInfo { opt, title, sub };
    let mut v = Vec::new();
    if APPS[i].run.is_some() {
        v.push(o(Opt::Autostart(i), "Запускать вместе с Windows", "Программа стартует при входе и ждёт в трее"));
    }
    match APPS[i].id {
        "MacMixer" => {
            v.push(o(Opt::Lyrics, "Текст песни в панели музыки", "Слова приходят из открытой базы lrclib.net для играющей песни"));
            v.push(o(Opt::Island("messages"), "Островок: сообщения и уведомления", "Уведомления программ сверху по центру, а не в углу"));
            v.push(o(Opt::Island("tracks"), "Островок: смена трека", "Название новой песни, когда панель музыки закрыта"));
            v.push(o(Opt::Island("downloads"), "Островок: завершённые загрузки", "Щелчок по карточке покажет файл в папке"));
            v.push(o(Opt::Island("devices"), "Островок: смена устройства звука", "Наушники, колонки, Bluetooth"));
            v.push(o(Opt::Island("battery"), "Островок: заряд наушников", "Bluetooth-наушники подключились или садятся (меньше 20%)"));
            v.push(o(Opt::Island("hide_banners"), "Скрывать стандартные уведомления", "Чтобы одно и то же не показывалось дважды"));
        }
        "MacSpotlight" => {
            v.push(o(Opt::Layout, "Исправление раскладки", "Pause или Shift дважды: «ghbdtn» → «привет»"));
            v.push(o(Opt::QuickLook, "Быстрый просмотр", "Пробел в Проводнике и на рабочем столе показывает файл"));
        }
        "MacMirror" => {
            v.push(o(Opt::MirrorTray, "Крестик прячет окно в трей", "Телефон может подключиться в любой момент"));
            v.push(o(Opt::MirrorTop, "Окно поверх всех окон", "Экран телефона не перекрывается другими окнами"));
            v.push(o(Opt::MirrorMuted, "Без звука телефона", "Звук остаётся на iPhone"));
        }
        "MacFinder" => {
            v.push(o(Opt::FinderExplorer, "Открывать папки в Finder вместо Проводника", "Через Windhawk; Проводник — с зажатым Shift"));
        }
        _ => {}
    }
    v
}

fn mixer(name: &str) -> PathBuf {
    sys::local("MacMixer").join(name)
}

fn on(v: Option<String>, default: bool) -> bool {
    v.map_or(default, |v| v.trim() == "1")
}

pub fn get(opt: Opt) -> bool {
    match opt {
        Opt::Autostart(i) => APPS[i].run.is_some_and(|(v, _)| sys::run_get(v)),
        Opt::Lyrics => mixer("lyrics.on").exists(),
        Opt::Island(k) => on(sys::kv_get(&mixer("island.txt"), k), k != "hide_banners"),
        Opt::Layout => on(sys::kv_get(&sys::local("MacSpotlight").join("settings.txt"), "layout"), true),
        Opt::QuickLook => on(sys::kv_get(&sys::local("MacSpotlight").join("settings.txt"), "look"), true),
        Opt::MirrorTray => on(sys::kv_get(&sys::local("MacMirror").join("settings.txt"), "tray"), true),
        Opt::MirrorTop => on(sys::kv_get(&sys::local("MacMirror").join("settings.txt"), "topmost"), false),
        Opt::MirrorMuted => on(sys::kv_get(&sys::local("MacMirror").join("settings.txt"), "muted"), false),
        Opt::FinderExplorer => sys::finder_mod(),
        Opt::Snap => on(sys::kv_get(&sys::local("MacSpotlight").join("settings.txt"), "snap"), true),
        Opt::Mission => on(sys::kv_get(&sys::local("MacSpotlight").join("settings.txt"), "mission"), true),
    }
}

/// Какой программе принадлежит настройка: её перезапускаем, чтобы она перечитала файл
pub fn owner(opt: Opt) -> usize {
    let id = match opt {
        Opt::Autostart(i) => return i,
        Opt::Lyrics | Opt::Island(_) => "MacMixer",
        Opt::Layout | Opt::QuickLook | Opt::Snap | Opt::Mission => "MacSpotlight",
        Opt::MirrorTray | Opt::MirrorTop | Opt::MirrorMuted => "MacMirror",
        Opt::FinderExplorer => "MacFinder",
    };
    APPS.iter().position(|a| a.id == id).unwrap_or(0)
}

/// Записать настройку. Программа читает свои файлы при запуске — если работает, перезапускаем
pub fn set(opt: Opt, value: bool) {
    let b = if value { "1" } else { "0" };
    let i = owner(opt);
    let restart = !matches!(opt, Opt::Autostart(_) | Opt::FinderExplorer) && sys::processes().iter().any(|p| p == APPS[i].exe);
    if restart {
        stop(i);
    }
    match opt {
        Opt::Autostart(i) => {
            let app = &APPS[i];
            if let Some((v, args)) = app.run {
                let cmd = format!("\"{}\"{}{}", exe_path(app).display(), if args.is_empty() { "" } else { " " }, args);
                sys::run_set(v, value.then_some(cmd.as_str()));
            }
        }
        Opt::Lyrics => {
            if value {
                let _ = std::fs::create_dir_all(sys::local("MacMixer"));
                let _ = std::fs::write(mixer("lyrics.on"), b"1");
            } else {
                let _ = std::fs::remove_file(mixer("lyrics.on"));
            }
        }
        Opt::Island(k) => sys::kv_set(&mixer("island.txt"), k, b),
        Opt::Layout => sys::kv_set(&sys::local("MacSpotlight").join("settings.txt"), "layout", b),
        Opt::QuickLook => sys::kv_set(&sys::local("MacSpotlight").join("settings.txt"), "look", b),
        Opt::MirrorTray => sys::kv_set(&sys::local("MacMirror").join("settings.txt"), "tray", b),
        Opt::MirrorTop => sys::kv_set(&sys::local("MacMirror").join("settings.txt"), "topmost", b),
        Opt::MirrorMuted => sys::kv_set(&sys::local("MacMirror").join("settings.txt"), "muted", b),
        Opt::Snap => sys::kv_set(&sys::local("MacSpotlight").join("settings.txt"), "snap", b),
        Opt::Mission => sys::kv_set(&sys::local("MacSpotlight").join("settings.txt"), "mission", b),
        Opt::FinderExplorer => {
            // Windhawk и мод ставит установщик Finder (спросит права администратора)
            if value && !sys::windhawk_installed() {
                install_windhawk();
            }
            let _ = run_script(i, if value { "" } else { "-KeepExplorer" });
        }
    }
    if restart {
        start(i, true);
    }
}

// ---------- запуск и остановка ----------

pub fn start(i: usize, quiet: bool) {
    let app = &APPS[i];
    // экран iPhone «тихо» — сразу в трей, без окна
    let args = if quiet && app.id == "MacMirror" { "--tray" } else { "" };
    sys::launch(&exe_path(app), args);
}

pub fn stop(i: usize) {
    let app = &APPS[i];
    sys::kill(app.exe);
    // микшер при обычном выходе возвращает баннеры Windows — после остановки делаем это за него
    if app.id == "MacMixer" && installed(app) {
        let _ = std::process::Command::new(exe_path(app)).arg("--restore-banners").status();
    }
}

/// Открыть программу так, как её открыл бы человек: окно, панель или поиск
pub fn open(i: usize) {
    let app = &APPS[i];
    sys::launch(&exe_path(app), "");
}

// ---------- установка ----------

/// Распаковать папку программы во временную и запустить её install.ps1
pub fn run_script(i: usize, args: &str) -> bool {
    let app = &APPS[i];
    let tmp = std::env::temp_dir().join("MacCenter").join(app.id);
    let _ = std::fs::remove_dir_all(&tmp);
    for (id, rel, data) in payload::FILES {
        if *id != app.id {
            continue;
        }
        let p = tmp.join(rel.replace('/', "\\"));
        if let Some(d) = p.parent() {
            let _ = std::fs::create_dir_all(d);
        }
        // PowerShell 5 читает русский только с BOM, и он должен быть ровно один
        let bytes: Vec<u8> = if rel.ends_with(".ps1") {
            let mut b: &[u8] = data;
            while let Some(rest) = b.strip_prefix(&[0xEF, 0xBB, 0xBF]) {
                b = rest;
            }
            [&[0xEF, 0xBB, 0xBF][..], b].concat()
        } else {
            data.to_vec()
        };
        if std::fs::write(&p, bytes).is_err() {
            sys::log(&format!("{}: не записался {rel}", app.id));
            return false;
        }
    }
    let script = tmp.join("install.ps1");
    let cmd = format!(
        "[Console]::OutputEncoding = [Text.Encoding]::UTF8; & '{}' {args}",
        script.display().to_string().replace('\'', "''")
    );
    sys::log(&format!("{}: install.ps1 {args}", app.id));
    use std::os::windows::process::CommandExt;
    let out = std::process::Command::new("powershell.exe")
        .args(["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", &cmd])
        .creation_flags(0x0800_0000)
        .output();
    match out {
        Ok(o) => {
            let text = String::from_utf8_lossy(&o.stdout).to_string() + &String::from_utf8_lossy(&o.stderr);
            for line in text.lines().filter(|l| !l.trim().is_empty()) {
                sys::log(&format!("  {line}"));
            }
            o.status.success()
        }
        Err(e) => {
            sys::log(&format!("  PowerShell не запустился: {e}"));
            false
        }
    }
}

pub fn install(i: usize, keep_explorer: bool) -> bool {
    let args = if APPS[i].id == "MacFinder" && keep_explorer { "-KeepExplorer" } else { "" };
    run_script(i, args) && installed(&APPS[i])
}

pub fn uninstall(i: usize) -> bool {
    run_script(i, "-Uninstall") && !installed(&APPS[i])
}

/// Windhawk нужен, чтобы папки открывались в Finder; ставится через winget, как и в «Установить всё»
pub fn install_windhawk() -> bool {
    use std::os::windows::process::CommandExt;
    sys::log("Windhawk: ставлю через winget");
    let ok = std::process::Command::new("winget")
        .args(["install", "--id", "RamenSoftware.Windhawk", "-e", "--silent", "--accept-package-agreements", "--accept-source-agreements"])
        .creation_flags(0x0800_0000)
        .status()
        .is_ok_and(|s| s.success());
    sys::log(&format!("Windhawk: {}", if ok { "готово" } else { "не получилось" }));
    ok && sys::windhawk_installed()
}

/// Сам центр — в «Программы» и в «Пуск», чтобы открывать его потом без архива
pub fn install_self() {
    let Ok(me) = std::env::current_exe() else { return };
    let dir = sys::local("Programs").join("MacCenter");
    let target = dir.join("mac-center.exe");
    if me != target {
        let _ = std::fs::create_dir_all(&dir);
        if std::fs::copy(&me, &target).is_err() {
            return;
        }
    }
    let cmd = format!(
        "$s = (New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath('Programs')) 'Центр Mac.lnk')); \
         $s.TargetPath = '{0}'; $s.IconLocation = '{0},0'; $s.Description = 'Настройки программ в стиле Mac'; $s.Save()",
        target.display().to_string().replace('\'', "''")
    );
    use std::os::windows::process::CommandExt;
    let _ = std::process::Command::new("powershell.exe")
        .args(["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", &cmd])
        .creation_flags(0x0800_0000)
        .status();
}

// ---------- фоновые задачи ----------

#[derive(Clone, Copy, PartialEq)]
pub enum Job {
    Waiting,
    Working,
    Done,
    Failed,
}

/// Что сейчас делается с каждой программой (для кнопок и экрана установки)
pub static JOBS: Mutex<[Option<Job>; 5]> = Mutex::new([None; 5]);
/// Сообщение главному окну «состояние поменялось»
pub static NOTIFY: AtomicIsize = AtomicIsize::new(0);
pub const WM_JOBS: u32 = windows::Win32::UI::WindowsAndMessaging::WM_APP + 1;

pub fn job(i: usize) -> Option<Job> {
    JOBS.lock().ok().and_then(|j| j[i])
}

pub fn set_job(i: usize, j: Option<Job>) {
    if let Ok(mut g) = JOBS.lock() {
        g[i] = j;
    }
    ping();
}

pub fn ping() {
    let h = NOTIFY.load(Ordering::Relaxed);
    if h != 0 {
        unsafe {
            let _ = windows::Win32::UI::WindowsAndMessaging::PostMessageW(
                Some(windows::Win32::Foundation::HWND(h as *mut _)),
                WM_JOBS,
                windows::Win32::Foundation::WPARAM(0),
                windows::Win32::Foundation::LPARAM(0),
            );
        }
    }
}

pub fn busy(i: usize) -> bool {
    matches!(job(i), Some(Job::Working | Job::Waiting))
}

/// Сделать что-то с программой в фоне: окно не замирает, кнопка показывает «…»
pub fn spawn(i: usize, f: impl FnOnce() -> bool + Send + 'static) {
    if busy(i) {
        return;
    }
    set_job(i, Some(Job::Working));
    std::thread::spawn(move || {
        let ok = f();
        set_job(i, if ok { None } else { Some(Job::Failed) });
    });
}

/// Установить выбранные по очереди (экран первого запуска и «Обновить всё»)
pub fn install_many(list: Vec<usize>, keep_explorer: bool) {
    if let Ok(mut g) = JOBS.lock() {
        for &i in &list {
            g[i] = Some(Job::Waiting);
        }
    }
    ping();
    std::thread::spawn(move || {
        if !keep_explorer && list.iter().any(|&i| APPS[i].id == "MacFinder") && !sys::windhawk_installed() {
            install_windhawk();
        }
        for i in list {
            if let Ok(mut g) = JOBS.lock() {
                g[i] = Some(Job::Working);
            }
            ping();
            let ok = install(i, keep_explorer);
            if let Ok(mut g) = JOBS.lock() {
                g[i] = Some(if ok { Job::Done } else { Job::Failed });
            }
            ping();
        }
        install_self();
        ping();
    });
}

/// Строка настроек MacSpotlight (тема, обои, окна); работающий MacSpotlight перезапускаем — он читает их при старте
pub fn spot(key: &'static str, value: String) {
    let i = APPS.iter().position(|a| a.id == "MacSpotlight").unwrap_or(3);
    spawn(i, move || {
        sys::kv_set(&sys::local("MacSpotlight").join("settings.txt"), key, &value);
        if sys::processes().iter().any(|p| p == APPS[i].exe) {
            stop(i);
            start(i, true);
            std::thread::sleep(std::time::Duration::from_millis(500));
        }
        true
    });
}
