//! Окно центра: приветствие с версией Windows, выбор программ и установка, затем панель как
//! «Параметры» Windows — слева разделы, справа карточки с переключателями. Всё рисует tiny-skia.

use ab_glyph::FontVec;
use tiny_skia::{Color, PixmapMut};

use crate::apps::{self, Job, Opt, Status, APPS};
use crate::gfx::{self, Img};
use crate::sys::{self, Os};

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Page {
    Welcome,
    Setup,
    Progress,
    Home,
    App(usize),
    Look,
    Windows,
    Tweaks,
    System,
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Menu {
    City,
    Light,
    Dark,
}

/// Что нашла проверка обновлений
#[derive(Clone, PartialEq)]
pub enum Found {
    Nothing,
    Newer(std::path::PathBuf, String),
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Act {
    Nav(Page),
    Toggle(Opt),
    Power(usize),
    Open(usize),
    Restart(usize),
    Stop(usize),
    Install(usize),
    Remove(usize),
    Next,
    Pick(usize),
    Explorer,
    Go,
    Later,
    Finish,
    UpdateAll,
    RemoveAll,
    Url(&'static str),
    Log,
    Programs,
    Spot(&'static str, &'static str),
    Menu(Menu),
    PickFolder,
    Tweak(crate::tweaks::Tw),
    RestartExplorer,
    Export,
    Import,
    CheckUpdate,
    RunUpdate,
    InstallCenter,
}

pub struct Fonts {
    pub regular: FontVec,
    pub semibold: FontVec,
}

impl Fonts {
    pub fn load() -> Option<Fonts> {
        let dir = std::env::var("MAC_FONT_DIR").unwrap_or_else(|_| std::env::var("WINDIR").unwrap_or_else(|_| "C:\\Windows".into()) + "\\Fonts");
        let file = |n: &str| std::fs::read(format!("{dir}\\{n}")).ok().and_then(|v| FontVec::try_from_vec(v).ok());
        Some(Fonts {
            regular: gfx::variable_font(400.0).or_else(|| file("segoeui.ttf"))?,
            semibold: gfx::variable_font(600.0).or_else(|| file("seguisb.ttf")).or_else(|| file("segoeui.ttf"))?,
        })
    }
}

pub struct Ui {
    pub fonts: Fonts,
    pub os: Os,
    pub user: String,
    pub page: Page,
    pub st: [Status; 5],
    pub hover: Option<Act>,
    pub zones: Vec<([f32; 4], Act)>,
    pub scroll: f32,
    pub content_h: f32,
    pub pick: [bool; 5],
    pub keep_explorer: bool,
    pub tick: u32,
    pub icon: Option<Img>,
    /// переключатель уже нажат, а программа ещё перезапускается — показываем новое положение
    pub pending: Vec<(Opt, bool)>,
    /// миниатюры «Пейзажа дня»: утро, день, вечер, ночь
    pub scenes: Option<Vec<Img>>,
    /// поменяли твик, которому нужен перезапуск Проводника
    pub explorer_dirty: bool,
    pub found: Option<Found>,
    /// короткий итог последнего действия (перенос настроек, обновление)
    pub note: Option<String>,
}

pub const SIDEBAR: f32 = 288.0;

// ---------- цвета ----------

fn dark() -> bool {
    gfx::theme().dark
}

pub fn window_bg() -> Color {
    match (dark(), gfx::win11()) {
        (true, true) => gfx::rgb(0x20, 0x20, 0x20, 1.0),
        (true, false) => gfx::rgb(0x17, 0x17, 0x17, 1.0),
        (false, true) => gfx::rgb(0xF3, 0xF3, 0xF3, 1.0),
        (false, false) => gfx::rgb(0xF2, 0xF2, 0xF2, 1.0),
    }
}

fn card_bg() -> Color {
    match (dark(), gfx::win11()) {
        (true, true) => gfx::rgb(0x2B, 0x2B, 0x2B, 1.0),
        (true, false) => gfx::rgb(0x23, 0x23, 0x23, 1.0),
        (false, _) => gfx::rgb(0xFF, 0xFF, 0xFF, 1.0),
    }
}

fn card_hover() -> Color {
    if dark() {
        gfx::rgb(0x32, 0x32, 0x32, 1.0)
    } else {
        gfx::rgb(0xF6, 0xF6, 0xF6, 1.0)
    }
}

fn green() -> Color {
    if dark() {
        gfx::rgb(0x6C, 0xCB, 0x5F, 1.0)
    } else {
        gfx::rgb(0x0F, 0x7B, 0x0F, 1.0)
    }
}

fn red() -> Color {
    if dark() {
        gfx::rgb(0xFF, 0x99, 0xA4, 1.0)
    } else {
        gfx::rgb(0xC4, 0x2B, 0x1C, 1.0)
    }
}

// ---------- рисование ----------

/// Заливка со скруглением. Круги и «пилюли» (радиус — половина высоты) круглые и в Windows 10,
/// остальное — с углами по стилю системы
fn fill(pm: &mut PixmapMut, x: f32, y: f32, w: f32, h: f32, r: f32, c: Color) {
    let path = if r * 2.0 >= w.min(h) - 0.01 { gfx::round_rect(x, y, w, h, r) } else { gfx::rrect(x, y, w, h, r) };
    if let Some(p) = path {
        pm.fill_path(&p, &gfx::solid(c), tiny_skia::FillRule::Winding, tiny_skia::Transform::identity(), None);
    }
}

struct Ctx<'a, 'b> {
    pm: &'a mut PixmapMut<'b>,
    s: f32,
    f: &'a Fonts,
    zones: &'a mut Vec<([f32; 4], Act)>,
    hover: Option<Act>,
    /// сдвиг прокрутки: всё, что справа от боковой панели, рисуется выше на него
    dy: f32,
}

impl Ctx<'_, '_> {
    fn p(&self, v: f32) -> f32 {
        v * self.s
    }

    fn zone(&mut self, x: f32, y: f32, w: f32, h: f32, a: Act) {
        self.zones.push(([x, y - self.dy, w, h], a));
    }

    fn hot(&self, a: Act) -> bool {
        self.hover == Some(a)
    }

    fn text(&mut self, t: &str, x: f32, y: f32, px: f32, bold: bool, c: Color) {
        let font = if bold { &self.f.semibold } else { &self.f.regular };
        gfx::text(self.pm, font, t, self.p(x), self.p(y - self.dy), self.p(px), c);
    }

    fn width(&self, t: &str, px: f32, bold: bool) -> f32 {
        let font = if bold { &self.f.semibold } else { &self.f.regular };
        gfx::measure(font, t, self.p(px)) / self.s
    }

    fn fit(&self, t: &str, px: f32, bold: bool, max: f32) -> String {
        let font = if bold { &self.f.semibold } else { &self.f.regular };
        gfx::fit(font, t, self.p(px), self.p(max))
    }

    /// Перенос по словам; возвращает строки
    fn wrap(&self, t: &str, px: f32, max: f32) -> Vec<String> {
        let mut lines = Vec::new();
        let mut cur = String::new();
        for w in t.split(' ') {
            let next = if cur.is_empty() { w.to_string() } else { format!("{cur} {w}") };
            if self.width(&next, px, false) <= max || cur.is_empty() {
                cur = next;
            } else {
                lines.push(std::mem::take(&mut cur));
                cur = w.to_string();
            }
        }
        if !cur.is_empty() {
            lines.push(cur);
        }
        lines
    }

    fn rect(&mut self, x: f32, y: f32, w: f32, h: f32, r: f32, c: Color) {
        let (px, py, pw, ph) = (self.p(x), self.p(y - self.dy), self.p(w), self.p(h));
        fill(self.pm, px, py, pw, ph, self.p(r), c);
    }

    /// Квадрат без скругления (окна логотипа Windows)
    fn square(&mut self, x: f32, y: f32, size: f32, c: Color) {
        if let Some(r) = tiny_skia::Rect::from_xywh(self.p(x), self.p(y - self.dy), self.p(size), self.p(size)) {
            self.pm.fill_rect(r, &gfx::solid(c), tiny_skia::Transform::identity(), None);
        }
    }

    fn outline(&mut self, x: f32, y: f32, w: f32, h: f32, r: f32, c: Color) {
        gfx::stroke_rrect(self.pm, self.p(x) + 0.5, self.p(y - self.dy) + 0.5, self.p(w) - 1.0, self.p(h) - 1.0, self.p(r), 1.0, c);
    }

    fn glyph(&mut self, ch: char, cx: f32, cy: f32, px: f32, c: Color) {
        gfx::glyph(self.pm, ch, self.p(cx), self.p(cy - self.dy), self.p(px), c);
    }

    fn card(&mut self, x: f32, y: f32, w: f32, h: f32, hot: bool) {
        let bg = if hot { card_hover() } else { card_bg() };
        self.rect(x, y, w, h, 6.0, bg);
        if gfx::win11() || !dark() {
            self.outline(x, y, w, h, 6.0, gfx::white(if dark() { 0.05 } else { 0.07 }));
        }
    }

    /// Плитка с значком программы: квадрат цвета акцента и белый знак
    fn tile(&mut self, ch: char, x: f32, y: f32, size: f32) {
        self.rect(x, y, size, size, size * 0.22, gfx::accent(1.0));
        self.glyph(ch, x + size / 2.0, y + size / 2.0, size * 0.5, gfx::on_accent(1.0));
    }

    /// Переключатель как в «Параметрах» Windows
    fn toggle(&mut self, x: f32, y: f32, on: bool, a: Act, enabled: bool) {
        let (w, h) = if gfx::win11() { (40.0, 20.0) } else { (44.0, 20.0) };
        let hot = enabled && self.hot(a);
        let alpha = if enabled { 1.0 } else { 0.4 };
        if on {
            let c = if hot { gfx::accent(0.85 * alpha) } else { gfx::accent(alpha) };
            self.rect(x, y, w, h, h / 2.0, c);
            self.knob(x + w - h / 2.0, y + h / 2.0, if hot { 6.0 } else { 5.0 }, gfx::on_accent(alpha));
        } else {
            if hot {
                self.rect(x, y, w, h, h / 2.0, gfx::white(0.05));
            }
            let width = if gfx::win11() { 1.0 } else { 2.0 };
            let r = gfx::round_rect(self.p(x) + width / 2.0, self.p(y - self.dy) + width / 2.0, self.p(w) - width, self.p(h) - width, self.p(h / 2.0));
            if let Some(path) = r {
                let st = tiny_skia::Stroke { width: width * self.s.max(1.0), ..Default::default() };
                self.pm.stroke_path(&path, &gfx::solid(gfx::white(0.6 * alpha)), &st, tiny_skia::Transform::identity(), None);
            }
            self.knob(x + h / 2.0, y + h / 2.0, if hot { 6.0 } else { 5.0 }, gfx::white(0.7 * alpha));
        }
        if enabled {
            self.zone(x - 4.0, y - 6.0, w + 8.0, h + 12.0, a);
        }
    }

    fn knob(&mut self, cx: f32, cy: f32, r: f32, c: Color) {
        let r = self.p(r);
        fill(self.pm, self.p(cx) - r, self.p(cy - self.dy) - r, 2.0 * r, 2.0 * r, r, c);
    }

    /// Кнопка: возвращает её ширину. primary — залита акцентом
    fn button(&mut self, label: &str, x: f32, y: f32, primary: bool, a: Act, enabled: bool) -> f32 {
        let w = self.width(label, 14.0, false) + 32.0;
        let h = 32.0;
        let hot = enabled && self.hot(a);
        let alpha = if enabled { 1.0 } else { 0.45 };
        if primary {
            self.rect(x, y, w, h, 4.0, gfx::accent(if hot { 0.88 * alpha } else { alpha }));
            self.text(label, x + 16.0, y + 21.0, 14.0, false, gfx::on_accent(alpha));
        } else {
            let bg = if hot { card_hover() } else { card_bg() };
            self.rect(x, y, w, h, 4.0, bg);
            self.outline(x, y, w, h, 4.0, gfx::white(if dark() { 0.09 } else { 0.14 }));
            self.text(label, x + 16.0, y + 21.0, 14.0, false, gfx::white(0.9 * alpha));
        }
        if enabled {
            self.zone(x, y, w, h, a);
        }
        w
    }

    fn checkbox(&mut self, x: f32, y: f32, on: bool, hot: bool) {
        let r = if gfx::win11() { 4.0 } else { 0.0 };
        if on {
            self.rect(x, y, 20.0, 20.0, r, gfx::accent(if hot { 0.88 } else { 1.0 }));
            self.glyph('\u{E73E}', x + 10.0, y + 10.0, 13.0, gfx::on_accent(1.0));
        } else {
            if hot {
                self.rect(x, y, 20.0, 20.0, r, gfx::white(0.05));
            }
            self.outline(x, y, 20.0, 20.0, r, gfx::white(0.6));
        }
    }

    /// Логотип Windows: в 11 — четыре квадрата цвета акцента, в 10 — белые окна на плитке
    fn logo(&mut self, x: f32, y: f32, size: f32, win11: bool) {
        let gap = size * 0.06;
        let q = (size - gap) / 2.0;
        if win11 {
            for (i, j) in [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0)] {
                self.square(x + i * (q + gap), y + j * (q + gap), q, gfx::accent(1.0));
            }
        } else {
            self.rect(x, y, size, size, size * 0.12, gfx::accent(1.0));
            let pad = size * 0.2;
            let inner = size - 2.0 * pad;
            let g = inner * 0.06;
            let q = (inner - g) / 2.0;
            for (i, j) in [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0)] {
                self.square(x + pad + i * (q + g), y + pad + j * (q + g), q, gfx::rgb(0xFF, 0xFF, 0xFF, 1.0));
            }
        }
    }

    /// Вращающиеся точки — «идёт работа»
    fn spinner(&mut self, cx: f32, cy: f32, r: f32, tick: u32) {
        for k in 0..8 {
            let a = (k as f32) * std::f32::consts::TAU / 8.0;
            let age = ((k + 8 - (tick % 8)) % 8) as f32;
            let alpha = 1.0 - age / 9.0;
            let (x, y) = (cx + a.cos() * r, cy + a.sin() * r);
            let d = r * 0.32;
            self.rect(x - d / 2.0, y - d / 2.0, d, d, d / 2.0, gfx::accent(alpha));
        }
    }

    fn section(&mut self, t: &str, x: f32, y: f32) {
        self.text(t, x, y, 14.0, true, gfx::white(0.9));
    }
}

fn os_line(os: &Os) -> String {
    let mut parts = vec![os.name.clone()];
    if !os.version.is_empty() {
        parts.push(format!("версия {}", os.version));
    }
    parts.push(format!("сборка {}.{}", os.build, os.ubr));
    parts.join(" · ")
}

fn style_line(win11: bool) -> &'static str {
    if win11 {
        "Программы будут выглядеть как Windows 11: скругления, шрифт Segoe UI Variable и значки Fluent."
    } else {
        "Программы будут выглядеть как Windows 10: строгие углы, шрифт Segoe UI и значки MDL2."
    }
}

impl Ui {
    fn opt(&self, o: Opt) -> bool {
        self.pending.iter().find(|p| p.0 == o).map_or_else(|| apps::get(o), |p| p.1)
    }

    pub fn compose(&mut self, pm: &mut PixmapMut, w: f32, h: f32, s: f32) {
        gfx::use_theme(true);
        pm.fill(window_bg());
        let mut zones = Vec::new();
        let full = matches!(self.page, Page::Welcome | Page::Setup | Page::Progress);
        {
            let mut c = Ctx { pm, s, f: &self.fonts, zones: &mut zones, hover: self.hover, dy: self.scroll };
            let wl = w / s;
            let hl = h / s;
            let end = match self.page {
                Page::Welcome => welcome(&mut c, self, wl, hl),
                Page::Setup => setup(&mut c, self, wl),
                Page::Progress => progress(&mut c, self, wl),
                Page::Home => home(&mut c, self, wl),
                Page::App(i) => app_page(&mut c, self, i, wl),
                Page::Look => look_page(&mut c, self, wl),
                Page::Windows => windows_page(&mut c, self, wl),
                Page::Tweaks => tweaks_page(&mut c, self, wl),
                Page::System => system(&mut c, self, wl),
            };
            self.content_h = end;
            if !full {
                c.dy = 0.0;
                sidebar(&mut c, self, hl);
            }
        }
        self.zones = zones;
    }

    /// Последняя подходящая зона — та, что нарисована сверху
    pub fn hit(&self, x: f32, y: f32) -> Option<Act> {
        self.zones.iter().rev().find(|(r, _)| x >= r[0] && x < r[0] + r[2] && y >= r[1] && y < r[1] + r[3]).map(|z| z.1)
    }
}

// ---------- боковая панель ----------

fn sidebar(c: &mut Ctx, ui: &Ui, hl: f32) {
    c.rect(0.0, 0.0, SIDEBAR, hl, 0.0, window_bg());
    // кто за компьютером и какая система
    let (x, y) = (20.0, 22.0);
    let initial: String = ui.user.chars().next().map(|ch| ch.to_uppercase().collect()).unwrap_or_else(|| "?".into());
    c.rect(x, y, 56.0, 56.0, 28.0, gfx::accent(1.0));
    let iw = c.width(&initial, 24.0, true);
    c.text(&initial, x + 28.0 - iw / 2.0, y + 37.0, 24.0, true, gfx::on_accent(1.0));
    let name = if ui.user.is_empty() { "Пользователь".to_string() } else { ui.user.clone() };
    let n = c.fit(&name, 15.0, true, SIDEBAR - 100.0);
    c.text(&n, x + 70.0, y + 25.0, 15.0, true, gfx::white(0.95));
    let os = c.fit(&ui.os.name, 12.5, false, SIDEBAR - 100.0);
    c.text(&os, x + 70.0, y + 44.0, 12.5, false, gfx::white(0.6));

    let mut items: Vec<(Page, char, String)> = vec![(Page::Home, '\u{E80F}', "Главная".into())];
    for (i, a) in APPS.iter().enumerate() {
        items.push((Page::App(i), a.glyph, a.title.into()));
    }
    items.push((Page::Look, '\u{E790}', "Оформление".into()));
    items.push((Page::Windows, '\u{E737}', "Окна".into()));
    items.push((Page::Tweaks, '\u{E9E9}', "Твики".into()));
    items.push((Page::System, '\u{E770}', "Система".into()));
    let mut y = 108.0;
    for (k, (page, glyph, label)) in items.iter().enumerate() {
        if k == 6 || k == items.len() - 1 {
            y += 10.0;
            c.rect(20.0, y - 6.0, SIDEBAR - 40.0, 1.0, 0.0, gfx::white(0.08));
        }
        let sel = ui.page == *page;
        let hot = c.hot(Act::Nav(*page));
        let (ix, iw, ih) = (8.0, SIDEBAR - 16.0, 38.0);
        if gfx::win11() {
            if sel || hot {
                c.rect(ix, y, iw, ih, 4.0, gfx::white(if sel { 0.06 } else { 0.04 }));
            }
            if sel {
                c.rect(ix, y + 11.0, 3.0, 16.0, 1.5, gfx::accent(1.0));
            }
        } else {
            if hot {
                c.rect(0.0, y, SIDEBAR, ih, 0.0, gfx::white(0.06));
            }
            if sel {
                c.rect(0.0, y, 5.0, ih, 0.0, gfx::accent(1.0));
            }
        }
        c.glyph(*glyph, 36.0, y + ih / 2.0, 16.0, gfx::white(0.85));
        c.text(label, 60.0, y + 24.0, 14.0, false, gfx::white(0.92));
        // точка: программа не стоит или есть обновление
        if let Page::App(i) = page {
            let st = ui.st[*i];
            if !st.installed || !st.current {
                c.rect(SIDEBAR - 34.0, y + 15.0, 8.0, 8.0, 4.0, gfx::accent(1.0));
            } else if st.running {
                c.rect(SIDEBAR - 34.0, y + 16.0, 6.0, 6.0, 3.0, green());
            }
        }
        c.zone(ix, y, iw, ih, Act::Nav(*page));
        y += ih + 4.0;
    }
}

fn content_x(wl: f32) -> (f32, f32) {
    let x = SIDEBAR + 28.0;
    let w = (wl - x - 36.0).min(940.0);
    (x, w)
}

fn status_text(ui: &Ui, i: usize) -> (String, Color) {
    let st = ui.st[i];
    match apps::job(i) {
        Some(Job::Working) => return ("Подождите…".into(), gfx::accent(1.0)),
        Some(Job::Waiting) => return ("В очереди".into(), gfx::white(0.6)),
        Some(Job::Failed) => return ("Не получилось — см. журнал".into(), red()),
        _ => {}
    }
    if !st.installed {
        return ("Не установлено".into(), gfx::white(0.55));
    }
    if !st.current {
        return ("Есть новая версия".into(), gfx::accent(1.0));
    }
    if st.running {
        ("Работает".into(), green())
    } else if APPS[i].run.is_none() {
        ("Установлено".into(), gfx::white(0.6))
    } else {
        ("Выключено".into(), gfx::white(0.55))
    }
}

// ---------- главная ----------

fn home(c: &mut Ctx, ui: &Ui, wl: f32) -> f32 {
    let (x, w) = content_x(wl);
    let mut y = 34.0;
    let hello = if ui.user.is_empty() { sys::greeting().to_string() } else { format!("{}, {}", sys::greeting(), ui.user) };
    c.text(&hello, x, y + 30.0, 28.0, true, gfx::white(0.95));
    y += 48.0;
    c.logo(x, y, 16.0, ui.os.win11);
    c.text(&os_line(&ui.os), x + 26.0, y + 13.0, 14.0, false, gfx::white(0.65));
    y += 40.0;

    let missing: Vec<usize> = (0..5).filter(|&i| !ui.st[i].installed && apps::has_payload(&APPS[i])).collect();
    let old: Vec<usize> = (0..5).filter(|&i| ui.st[i].installed && !ui.st[i].current).collect();
    if !missing.is_empty() || !old.is_empty() {
        c.card(x, y, w, 72.0, false);
        c.glyph(if missing.is_empty() { '\u{E895}' } else { '\u{E896}' }, x + 32.0, y + 36.0, 20.0, gfx::accent(1.0));
        let (title, sub) = if !missing.is_empty() {
            let names: Vec<&str> = missing.iter().map(|&i| APPS[i].title).collect();
            ("Не все программы установлены".to_string(), names.join(", "))
        } else {
            let names: Vec<&str> = old.iter().map(|&i| APPS[i].title).collect();
            ("Есть новые версии".to_string(), names.join(", "))
        };
        c.text(&title, x + 60.0, y + 31.0, 14.0, true, gfx::white(0.92));
        let sub = c.fit(&sub, 13.0, false, w - 260.0);
        c.text(&sub, x + 60.0, y + 51.0, 13.0, false, gfx::white(0.6));
        let label = if missing.is_empty() { "Обновить" } else { "Установить" };
        let bw = c.width(label, 14.0, false) + 32.0;
        let busy = (0..5).any(apps::busy);
        c.button(label, x + w - bw - 20.0, y + 20.0, true, Act::UpdateAll, !busy);
        y += 88.0;
    }

    c.section("Программы", x, y + 16.0);
    y += 30.0;
    let gap = 12.0;
    let cw = (w - gap) / 2.0;
    let ch = 132.0;
    for i in 0..5 {
        let (cx, cy) = (x + (i % 2) as f32 * (cw + gap), y + (i / 2) as f32 * (ch + gap));
        let app = &APPS[i];
        let hot = c.hot(Act::Nav(Page::App(i)));
        c.card(cx, cy, cw, ch, hot);
        c.zone(cx, cy, cw, ch, Act::Nav(Page::App(i)));
        c.tile(app.glyph, cx + 20.0, cy + 20.0, 44.0);
        let t = c.fit(app.title, 16.0, true, cw - 160.0);
        c.text(&t, cx + 78.0, cy + 38.0, 16.0, true, gfx::white(0.95));
        c.text(app.id, cx + 78.0, cy + 58.0, 12.5, false, gfx::white(0.55));
        let st = ui.st[i];
        let (label, col) = status_text(ui, i);
        if apps::busy(i) {
            c.spinner(cx + 26.0, cy + ch - 28.0, 6.0, ui.tick);
        } else {
            c.rect(cx + 22.0, cy + ch - 32.0, 8.0, 8.0, 4.0, col);
        }
        c.text(&label, cx + 40.0, cy + ch - 23.0, 13.0, false, col);
        if !st.installed {
            let bw = c.width("Установить", 14.0, false) + 32.0;
            c.button("Установить", cx + cw - bw - 16.0, cy + ch - 46.0, false, Act::Install(i), !apps::busy(i));
        } else if app.run.is_some() {
            c.toggle(cx + cw - 64.0, cy + 22.0, st.running, Act::Power(i), !apps::busy(i));
        } else {
            let bw = c.width("Открыть", 14.0, false) + 32.0;
            c.button("Открыть", cx + cw - bw - 16.0, cy + ch - 46.0, false, Act::Open(i), true);
        }
    }
    y += 3.0 * (ch + gap);
    // подсказки по главным клавишам
    c.section("Главное за одну минуту", x, y + 16.0);
    y += 30.0;
    let tips = [
        ("Win+Пробел", "поиск приложений и файлов"),
        ("Win+Shift+S", "снимок экрана"),
        ("Pause", "исправить раскладку: «ghbdtn» → «привет»"),
        ("Пробел", "быстрый просмотр файла в Проводнике"),
        ("Клавиши музыки", "панель музыки сверху по центру"),
        ("Ctrl+Win+↑", "все окна плитками"),
        ("Ctrl+Alt+← →", "окно на половину экрана"),
    ];
    let rows = tips.len() as f32;
    c.card(x, y, w, rows * 44.0, false);
    for (k, (key, what)) in tips.iter().enumerate() {
        let ry = y + k as f32 * 44.0;
        if k > 0 {
            c.rect(x + 16.0, ry, w - 32.0, 1.0, 0.0, gfx::white(0.06));
        }
        keycap(c, key, x + 16.0, ry + 9.0);
        c.text(what, x + 200.0, ry + 28.0, 14.0, false, gfx::white(0.8));
    }
    y + rows * 44.0 + 40.0
}

fn keycap(c: &mut Ctx, key: &str, x: f32, y: f32) {
    let w = c.width(key, 12.5, true) + 20.0;
    c.rect(x, y, w, 26.0, 4.0, gfx::white(if dark() { 0.08 } else { 0.05 }));
    c.outline(x, y, w, 26.0, 4.0, gfx::white(0.12));
    c.text(key, x + 10.0, y + 18.0, 12.5, true, gfx::white(0.85));
}

// ---------- страница программы ----------

fn app_page(c: &mut Ctx, ui: &Ui, i: usize, wl: f32) -> f32 {
    let (x, w) = content_x(wl);
    let app = &APPS[i];
    let st = ui.st[i];
    let busy = apps::busy(i);
    let mut y = 34.0;
    c.text(app.title, x, y + 30.0, 28.0, true, gfx::white(0.95));
    y += 52.0;
    // шапка: значок, имя, состояние и кнопки
    c.card(x, y, w, 96.0, false);
    c.tile(app.glyph, x + 20.0, y + 20.0, 56.0);
    c.text(app.id, x + 92.0, y + 42.0, 18.0, true, gfx::white(0.95));
    let (label, col) = status_text(ui, i);
    if busy {
        c.spinner(x + 98.0, y + 64.0, 5.0, ui.tick);
    } else {
        c.rect(x + 94.0, y + 60.0, 8.0, 8.0, 4.0, col);
    }
    c.text(&label, x + 110.0, y + 68.0, 13.0, false, col);
    let mut bx = x + w - 20.0;
    let mut place = |c: &mut Ctx, label: &str, primary: bool, a: Act, enabled: bool| {
        let bw = c.width(label, 14.0, false) + 32.0;
        bx -= bw;
        c.button(label, bx, y + 32.0, primary, a, enabled);
        bx -= 8.0;
    };
    if !st.installed {
        place(c, "Установить", true, Act::Install(i), !busy);
    } else {
        if st.running && app.run.is_some() {
            place(c, "Остановить", false, Act::Stop(i), !busy);
            place(c, "Перезапустить", false, Act::Restart(i), !busy);
        }
        place(c, "Открыть", true, Act::Open(i), !busy);
    }
    y += 112.0;
    for line in c.wrap(app.about, 14.0, w - 8.0) {
        c.text(&line, x + 4.0, y + 14.0, 14.0, false, gfx::white(0.75));
        y += 21.0;
    }
    y += 18.0;

    let opts = apps::options(i);
    if !opts.is_empty() {
        c.section("Параметры", x, y + 14.0);
        y += 28.0;
        let rh = 66.0;
        c.card(x, y, w, rh * opts.len() as f32, false);
        for (k, o) in opts.iter().enumerate() {
            let ry = y + k as f32 * rh;
            if k > 0 {
                c.rect(x + 16.0, ry, w - 32.0, 1.0, 0.0, gfx::white(0.06));
            }
            let enabled = st.installed && !busy;
            let a = if enabled { 0.95 } else { 0.45 };
            c.text(o.title, x + 20.0, ry + 28.0, 14.0, false, gfx::white(a));
            let sub = c.fit(o.sub, 12.5, false, w - 120.0);
            c.text(&sub, x + 20.0, ry + 48.0, 12.5, false, gfx::white(a * 0.62));
            let on = ui.opt(o.opt);
            let tw = if gfx::win11() { 40.0 } else { 44.0 };
            c.toggle(x + w - tw - 22.0, ry + 23.0, on, Act::Toggle(o.opt), enabled);
        }
        y += rh * opts.len() as f32 + 22.0;
    }

    c.section("Сочетания клавиш", x, y + 14.0);
    y += 28.0;
    let rh = 46.0;
    c.card(x, y, w, rh * app.keys.len() as f32, false);
    for (k, (key, what)) in app.keys.iter().enumerate() {
        let ry = y + k as f32 * rh;
        if k > 0 {
            c.rect(x + 16.0, ry, w - 32.0, 1.0, 0.0, gfx::white(0.06));
        }
        keycap(c, key, x + 16.0, ry + 10.0);
        c.text(what, x + 230.0, ry + 29.0, 14.0, false, gfx::white(0.8));
    }
    y += rh * app.keys.len() as f32 + 22.0;

    if st.installed {
        c.section("Обслуживание", x, y + 14.0);
        y += 28.0;
        c.card(x, y, w, 132.0, false);
        let (t, sub) = if st.current {
            ("Установлена последняя версия", "Та же, что внутри «Центра Mac»")
        } else {
            ("Есть новая версия", "Обновление сохранит настройки программы")
        };
        c.text(t, x + 20.0, y + 28.0, 14.0, false, gfx::white(0.95));
        c.text(sub, x + 20.0, y + 48.0, 12.5, false, gfx::white(0.6));
        let label = if st.current { "Переустановить" } else { "Обновить" };
        let bw = c.width(label, 14.0, false) + 32.0;
        c.button(label, x + w - bw - 20.0, y + 17.0, !st.current, Act::Install(i), !busy);
        c.rect(x + 16.0, y + 66.0, w - 32.0, 1.0, 0.0, gfx::white(0.06));
        c.text("Удалить программу", x + 20.0, y + 94.0, 14.0, false, gfx::white(0.95));
        c.text("Настройки и снимки останутся на диске", x + 20.0, y + 114.0, 12.5, false, gfx::white(0.6));
        let bw = c.width("Удалить", 14.0, false) + 32.0;
        c.button("Удалить", x + w - bw - 20.0, y + 83.0, false, Act::Remove(i), !busy);
        y += 132.0 + 22.0;
    }
    y + 20.0
}

// ---------- система ----------

fn system(c: &mut Ctx, ui: &Ui, wl: f32) -> f32 {
    let (x, w) = content_x(wl);
    let mut y = 34.0;
    c.text("Система", x, y + 30.0, 28.0, true, gfx::white(0.95));
    y += 52.0;
    c.card(x, y, w, 120.0, false);
    c.logo(x + 24.0, y + 28.0, 64.0, ui.os.win11);
    c.text(&ui.os.name, x + 112.0, y + 48.0, 20.0, true, gfx::white(0.95));
    let ver = if ui.os.version.is_empty() {
        format!("Сборка {}.{}", ui.os.build, ui.os.ubr)
    } else {
        format!("Версия {} · сборка {}.{}", ui.os.version, ui.os.build, ui.os.ubr)
    };
    c.text(&ver, x + 112.0, y + 72.0, 14.0, false, gfx::white(0.7));
    let style = c.fit(style_line(ui.os.win11), 13.0, false, w - 130.0);
    c.text(&style, x + 112.0, y + 94.0, 13.0, false, gfx::white(0.55));
    y += 136.0;

    let look = sys::look();
    let theme = |d: bool| if d { "Тёмная" } else { "Светлая" };
    let scale = (c.s * 100.0).round() as u32;
    let rows: Vec<(&str, String)> = vec![
        ("Тема приложений", theme(look.apps_dark).into()),
        ("Тема панели задач и меню", theme(look.system_dark).into()),
        ("Цвет акцента", format!("#{:02X}{:02X}{:02X}", look.accent.0, look.accent.1, look.accent.2)),
        ("Масштаб экрана", format!("{scale}%")),
        ("Windhawk (замена Проводника)", if sys::windhawk_installed() { "Установлен".into() } else { "Не установлен".into() }),
        ("Папки открываются в", if sys::finder_mod() { "Finder".into() } else { "Проводнике".into() }),
    ];
    let rh = 50.0;
    c.card(x, y, w, rh * rows.len() as f32, false);
    for (k, (t, v)) in rows.iter().enumerate() {
        let ry = y + k as f32 * rh;
        if k > 0 {
            c.rect(x + 16.0, ry, w - 32.0, 1.0, 0.0, gfx::white(0.06));
        }
        c.text(t, x + 20.0, ry + 31.0, 14.0, false, gfx::white(0.9));
        let vw = c.width(v, 14.0, false);
        c.text(v, x + w - 20.0 - vw, ry + 31.0, 14.0, false, gfx::white(0.65));
        if *t == "Цвет акцента" {
            let (r, g, b) = look.accent;
            c.rect(x + w - 32.0 - vw - 16.0, ry + 17.0, 16.0, 16.0, 8.0, gfx::rgb(r, g, b, 1.0));
        }
    }
    y += rh * rows.len() as f32 + 16.0;
    let mut bx = x;
    bx += c.button("Цвета и тема Windows", bx, y, false, Act::Url("ms-settings:colors"), true) + 8.0;
    bx += c.button("Папка программ", bx, y, false, Act::Programs, true) + 8.0;
    c.button("Журнал установки", bx, y, false, Act::Log, true);
    y += 56.0;

    y = backup_and_updates(c, ui, x, y, w) + 8.0;
    c.section("Комплект", x, y + 14.0);
    y += 28.0;
    c.card(x, y, w, 132.0, false);
    let have = (0..5).filter(|&i| ui.st[i].installed).count();
    c.text(&format!("Установлено программ: {have} из 5"), x + 20.0, y + 28.0, 14.0, false, gfx::white(0.95));
    c.text(&format!("«Центр Mac» {}", env!("CARGO_PKG_VERSION")), x + 20.0, y + 48.0, 12.5, false, gfx::white(0.6));
    let busy = (0..5).any(apps::busy);
    let bw = c.width("Установить или обновить всё", 14.0, false) + 32.0;
    c.button("Установить или обновить всё", x + w - bw - 20.0, y + 17.0, true, Act::UpdateAll, !busy);
    c.rect(x + 16.0, y + 66.0, w - 32.0, 1.0, 0.0, gfx::white(0.06));
    c.text("Удалить всё", x + 20.0, y + 94.0, 14.0, false, gfx::white(0.95));
    c.text("Вернёт Проводник и обычную смену раскладки по Win+Пробел", x + 20.0, y + 114.0, 12.5, false, gfx::white(0.6));
    let bw = c.width("Удалить всё", 14.0, false) + 32.0;
    c.button("Удалить всё", x + w - bw - 20.0, y + 83.0, false, Act::RemoveAll, !busy && have > 0);
    y + 132.0 + 40.0
}

// ---------- приветствие и установка ----------

fn welcome(c: &mut Ctx, ui: &Ui, wl: f32, hl: f32) -> f32 {
    let cw = 600.0;
    let x = (wl - cw) / 2.0;
    let total = 540.0;
    let mut y = ((hl - total) / 2.0).max(24.0);
    if let Some(icon) = &ui.icon {
        let size = 88.0;
        gfx::image(c.pm, icon, c.p((wl - size) / 2.0), c.p(y), c.p(size), c.p(size), 0.0, 1.0);
    }
    y += 112.0;
    let center = |c: &mut Ctx, t: &str, y: f32, px: f32, bold: bool, col: Color| {
        let tw = c.width(t, px, bold);
        c.text(t, (wl - tw) / 2.0, y, px, bold, col);
    };
    let hello = if ui.user.is_empty() { "Добро пожаловать".to_string() } else { format!("Добро пожаловать, {}", ui.user) };
    center(c, &hello, y + 10.0, 32.0, true, gfx::white(0.95));
    center(c, "Центр Mac настроит программы в стиле Mac под вашу Windows", y + 44.0, 15.0, false, gfx::white(0.6));
    y += 78.0;
    // карточка системы
    c.card(x, y, cw, 156.0, false);
    c.logo(x + 30.0, y + 36.0, 72.0, ui.os.win11);
    c.text("Ваша система", x + 130.0, y + 38.0, 13.0, false, gfx::white(0.55));
    c.text(&ui.os.name, x + 130.0, y + 66.0, 22.0, true, gfx::white(0.95));
    let ver = if ui.os.version.is_empty() {
        format!("Сборка {}.{}", ui.os.build, ui.os.ubr)
    } else {
        format!("Версия {} · сборка {}.{}", ui.os.version, ui.os.build, ui.os.ubr)
    };
    c.text(&ver, x + 130.0, y + 90.0, 14.0, false, gfx::white(0.7));
    let mut ly = y + 116.0;
    for line in c.wrap(style_line(ui.os.win11), 13.0, cw - 150.0) {
        c.text(&line, x + 130.0, ly, 13.0, false, gfx::white(0.55));
        ly += 18.0;
    }
    y += 172.0;
    // тема и акцент — то, что программы возьмут из системы
    let look = sys::look();
    let chips = [
        (if look.apps_dark { '\u{E708}' } else { '\u{E706}' }, if look.apps_dark { "Тёмная тема" } else { "Светлая тема" }.to_string()),
        ('\u{E790}', "Цвет акцента из Windows".to_string()),
        ('\u{E7F4}', format!("Масштаб {}%", (c.s * 100.0).round())),
    ];
    let widths: Vec<f32> = chips.iter().map(|(_, t)| c.width(t, 13.0, false) + 48.0).collect();
    let total_w: f32 = widths.iter().sum::<f32>() + 8.0 * (chips.len() - 1) as f32;
    let mut cx = (wl - total_w) / 2.0;
    for (k, (g, t)) in chips.iter().enumerate() {
        c.rect(cx, y, widths[k], 32.0, 16.0, card_bg());
        c.outline(cx, y, widths[k], 32.0, 16.0, gfx::white(0.08));
        let col = if k == 1 {
            let (r, gg, b) = look.accent;
            gfx::rgb(r, gg, b, 1.0)
        } else {
            gfx::white(0.8)
        };
        c.glyph(*g, cx + 20.0, y + 16.0, 14.0, col);
        c.text(t, cx + 36.0, y + 21.0, 13.0, false, gfx::white(0.8));
        cx += widths[k] + 8.0;
    }
    y += 60.0;
    if ui.os.supported {
        let bw = c.width("Продолжить", 14.0, false) + 32.0;
        c.button("Продолжить", (wl - bw) / 2.0, y, true, Act::Next, true);
    } else {
        center(c, "Нужна 64-битная Windows 10 версии 1809 или новее, либо Windows 11", y + 20.0, 14.0, false, red());
    }
    y + 60.0
}

fn setup(c: &mut Ctx, ui: &Ui, wl: f32) -> f32 {
    let cw = 640.0;
    let x = (wl - cw) / 2.0;
    let mut y = 40.0;
    c.text("Что установить", x, y + 30.0, 28.0, true, gfx::white(0.95));
    c.text("Отметьте программы. Включать и выключать их можно потом здесь же.", x, y + 58.0, 14.0, false, gfx::white(0.6));
    y += 84.0;
    let rh = 64.0;
    c.card(x, y, cw, rh * 5.0, false);
    for i in 0..5 {
        let app = &APPS[i];
        let ry = y + i as f32 * rh;
        if i > 0 {
            c.rect(x + 16.0, ry, cw - 32.0, 1.0, 0.0, gfx::white(0.06));
        }
        let hot = c.hot(Act::Pick(i));
        c.zone(x, ry, cw, rh, Act::Pick(i));
        c.checkbox(x + 20.0, ry + 22.0, ui.pick[i], hot);
        c.tile(app.glyph, x + 56.0, ry + 14.0, 36.0);
        c.text(app.title, x + 106.0, ry + 30.0, 14.0, true, gfx::white(0.95));
        let about = c.fit(app.about, 12.5, false, cw - 260.0);
        c.text(&about, x + 106.0, ry + 49.0, 12.5, false, gfx::white(0.55));
        let st = ui.st[i];
        let note = if !st.installed {
            ""
        } else if st.current {
            "Уже установлено"
        } else {
            "Будет обновлено"
        };
        let nw = c.width(note, 12.5, false);
        c.text(note, x + cw - 20.0 - nw, ry + 38.0, 12.5, false, gfx::white(0.55));
    }
    y += rh * 5.0 + 16.0;
    let finder = APPS.iter().position(|a| a.id == "MacFinder").unwrap_or(2);
    if ui.pick[finder] {
        c.card(x, y, cw, 70.0, false);
        c.text("Открывать папки в Finder вместо Проводника", x + 20.0, y + 30.0, 14.0, false, gfx::white(0.95));
        let sub = if ui.os.win11 {
            "Ставит Windhawk. На Windows 11 замена ещё не проверялась — лучше оставить выключенной"
        } else {
            "Ставит Windhawk. Вернуть Проводник можно в любой момент — здесь же"
        };
        let sub = c.fit(sub, 12.5, false, cw - 110.0);
        c.text(&sub, x + 20.0, y + 50.0, 12.5, false, gfx::white(0.6));
        let tw = if gfx::win11() { 40.0 } else { 44.0 };
        c.toggle(x + cw - tw - 22.0, y + 25.0, !ui.keep_explorer, Act::Explorer, true);
        y += 86.0;
    }
    c.glyph('\u{EA18}', x + 10.0, y + 10.0, 16.0, gfx::white(0.6));
    for (k, line) in c.wrap("Windows спросит разрешение администратора: для брандмауэра экрана iPhone и, если включено, для замены Проводника.", 13.0, cw - 30.0).iter().enumerate() {
        c.text(line, x + 28.0, y + 15.0 + k as f32 * 18.0, 13.0, false, gfx::white(0.6));
    }
    y += 52.0;
    let any = ui.pick.iter().any(|p| *p);
    let bw = c.button("Установить", x, y, true, Act::Go, any);
    c.button("Позже", x + bw + 8.0, y, false, Act::Later, true);
    y + 70.0
}

fn progress(c: &mut Ctx, ui: &Ui, wl: f32) -> f32 {
    let cw = 640.0;
    let x = (wl - cw) / 2.0;
    let mut y = 40.0;
    let list: Vec<usize> = (0..5).filter(|&i| apps::job(i).is_some()).collect();
    let working = list.iter().any(|&i| matches!(apps::job(i), Some(Job::Working | Job::Waiting)));
    let failed = list.iter().any(|&i| apps::job(i) == Some(Job::Failed));
    let title = if working {
        "Устанавливаю…"
    } else if failed {
        "Почти готово"
    } else {
        "Готово"
    };
    c.text(title, x, y + 30.0, 28.0, true, gfx::white(0.95));
    let sub = if working {
        "Если Windows спросит разрешение — нажмите «Да». Окно можно не трогать."
    } else if failed {
        "Часть программ не установилась. Подробности — в журнале."
    } else {
        "Всё установлено и уже работает. Настройки — в разделах слева."
    };
    c.text(sub, x, y + 58.0, 14.0, false, gfx::white(0.6));
    y += 84.0;
    let rh = 58.0;
    c.card(x, y, cw, rh * list.len().max(1) as f32, false);
    for (k, &i) in list.iter().enumerate() {
        let ry = y + k as f32 * rh;
        if k > 0 {
            c.rect(x + 16.0, ry, cw - 32.0, 1.0, 0.0, gfx::white(0.06));
        }
        let (text, col) = match apps::job(i) {
            Some(Job::Working) => {
                c.spinner(x + 32.0, ry + rh / 2.0, 7.0, ui.tick);
                ("Устанавливается…", gfx::accent(1.0))
            }
            Some(Job::Waiting) => {
                c.glyph('\u{E823}', x + 32.0, ry + rh / 2.0, 16.0, gfx::white(0.45));
                ("Ждёт очереди", gfx::white(0.55))
            }
            Some(Job::Done) => {
                c.glyph('\u{E73E}', x + 32.0, ry + rh / 2.0, 16.0, green());
                ("Установлено", green())
            }
            _ => {
                c.glyph('\u{E711}', x + 32.0, ry + rh / 2.0, 14.0, red());
                ("Не получилось", red())
            }
        };
        c.text(APPS[i].title, x + 60.0, ry + 26.0, 14.0, true, gfx::white(0.95));
        c.text(APPS[i].id, x + 60.0, ry + 45.0, 12.5, false, gfx::white(0.55));
        let tw = c.width(text, 13.0, false);
        c.text(text, x + cw - 20.0 - tw, ry + 35.0, 13.0, false, col);
    }
    y += rh * list.len().max(1) as f32 + 24.0;
    let bw = c.button("Готово", x, y, true, Act::Finish, !working);
    if failed && !working {
        c.button("Журнал установки", x + bw + 8.0, y, false, Act::Log, true);
    }
    y + 70.0
}

// ---------- оформление: тема и обои ----------

impl Ctx<'_, '_> {
    /// Переключатель из нескольких вариантов; рисуется вправо от x (правый край — x)
    fn segmented(&mut self, right: f32, y: f32, items: &[(&str, Act, bool)], enabled: bool) {
        let widths: Vec<f32> = items.iter().map(|(t, _, _)| self.width(t, 13.0, false) + 24.0).collect();
        let total: f32 = widths.iter().sum();
        let mut x = right - total;
        let h = 30.0;
        self.rect(x, y, total, h, 4.0, gfx::white(if dark() { 0.06 } else { 0.05 }));
        for (k, (t, a, sel)) in items.iter().enumerate() {
            let w = widths[k];
            let hot = enabled && self.hot(*a);
            if *sel {
                self.rect(x + 2.0, y + 2.0, w - 4.0, h - 4.0, 4.0, card_bg());
                self.outline(x + 2.0, y + 2.0, w - 4.0, h - 4.0, 4.0, gfx::white(0.1));
            } else if hot {
                self.rect(x + 2.0, y + 2.0, w - 4.0, h - 4.0, 4.0, gfx::white(0.05));
            }
            let col = if !enabled {
                gfx::white(0.4)
            } else if *sel {
                gfx::white(0.95)
            } else {
                gfx::white(0.7)
            };
            self.text(t, x + 12.0, y + 20.0, 13.0, *sel, col);
            if enabled && !*sel {
                self.zone(x, y, w, h, *a);
            }
            x += w;
        }
    }

    /// Кнопка-выпадашка «Москва ⌄»
    fn chooser(&mut self, right: f32, y: f32, label: &str, a: Act, enabled: bool) {
        let w = self.width(label, 14.0, false) + 46.0;
        let x = right - w;
        let hot = enabled && self.hot(a);
        self.rect(x, y, w, 32.0, 4.0, if hot { card_hover() } else { card_bg() });
        self.outline(x, y, w, 32.0, 4.0, gfx::white(if dark() { 0.09 } else { 0.14 }));
        self.text(label, x + 14.0, y + 21.0, 14.0, false, gfx::white(if enabled { 0.9 } else { 0.4 }));
        self.glyph('\u{E70D}', x + w - 18.0, y + 16.0, 10.0, gfx::white(0.6));
        if enabled {
            self.zone(x, y, w, 32.0, a);
        }
    }

    fn row_text(&mut self, x: f32, y: f32, title: &str, sub: &str, w: f32, enabled: bool) {
        let a = if enabled { 0.95 } else { 0.45 };
        self.text(title, x + 20.0, y + 28.0, 14.0, false, gfx::white(a));
        if !sub.is_empty() {
            let s = self.fit(sub, 12.5, false, w);
            self.text(&s, x + 20.0, y + 48.0, 12.5, false, gfx::white(a * 0.62));
        }
    }
}

fn spot(key: &str) -> Option<String> {
    sys::kv_get(&sys::local("MacSpotlight").join("settings.txt"), key)
}

pub const LIGHT_TIMES: [&str; 12] = ["05:00", "05:30", "06:00", "06:30", "07:00", "07:30", "08:00", "08:30", "09:00", "09:30", "10:00", "11:00"];
pub const DARK_TIMES: [&str; 14] =
    ["16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "23:00"];

fn spotlight_ready(ui: &Ui) -> bool {
    let i = APPS.iter().position(|a| a.id == "MacSpotlight").unwrap_or(3);
    ui.st[i].installed && !apps::busy(i)
}

fn needs_spotlight(c: &mut Ctx, ui: &Ui, x: f32, y: &mut f32, w: f32) {
    let i = APPS.iter().position(|a| a.id == "MacSpotlight").unwrap_or(3);
    if ui.st[i].installed {
        return;
    }
    c.card(x, *y, w, 64.0, false);
    c.glyph('\u{E946}', x + 30.0, *y + 32.0, 18.0, gfx::accent(1.0));
    c.text("Это делает «Поиск» (MacSpotlight) — он работает в фоне", x + 56.0, *y + 37.0, 14.0, false, gfx::white(0.9));
    let bw = c.width("Установить", 14.0, false) + 32.0;
    c.button("Установить", x + w - bw - 16.0, *y + 16.0, true, Act::Install(i), !apps::busy(i));
    *y += 80.0;
}

fn look_page(c: &mut Ctx, ui: &Ui, wl: f32) -> f32 {
    let (x, w) = content_x(wl);
    let mut y = 34.0;
    c.text("Оформление", x, y + 30.0, 28.0, true, gfx::white(0.95));
    y += 52.0;
    needs_spotlight(c, ui, x, &mut y, w);
    let ready = spotlight_ready(ui);
    let theme = spot("theme").unwrap_or_else(|| "off".into());
    let city = crate::sun::city(&spot("city").unwrap_or_default());

    c.section("Светлая и тёмная тема", x, y + 14.0);
    y += 28.0;
    let rows = if theme == "time" { 4.0 } else if theme == "sun" { 3.0 } else { 1.0 };
    let rh = 66.0;
    c.card(x, y, w, rh * rows, false);
    c.row_text(x, y, "Менять тему по времени суток", "Днём светлая, вечером тёмная, как в Mac", w - 420.0, ready);
    c.segmented(
        x + w - 20.0,
        y + 18.0,
        &[
            ("Выключено", Act::Spot("theme", "off"), theme == "off"),
            ("По солнцу", Act::Spot("theme", "sun"), theme == "sun"),
            ("По расписанию", Act::Spot("theme", "time"), theme == "time"),
        ],
        ready,
    );
    let mut ry = y + rh;
    let line = |c: &mut Ctx, ry: f32| c.rect(x + 16.0, ry, w - 32.0, 1.0, 0.0, gfx::white(0.06));
    if theme == "sun" {
        line(c, ry);
        let t = crate::sun::now_unix();
        let (rise, set) = crate::sun::sunrise_sunset(t, city.lat, city.lon);
        let today = match (rise, set) {
            (Some(r), Some(s)) => format!("Сегодня светлая с {} до {}", crate::sun::clock(r), crate::sun::clock(s)),
            _ => "Сегодня полярный день или ночь".into(),
        };
        c.row_text(x, ry, "Город", &today, w - 260.0, ready);
        c.chooser(x + w - 20.0, ry + 17.0, city.name, Act::Menu(Menu::City), ready);
        ry += rh;
    }
    if theme == "time" {
        line(c, ry);
        c.row_text(x, ry, "Светлая тема с", "Утром, когда включается светлая", w - 260.0, ready);
        c.chooser(x + w - 20.0, ry + 17.0, &spot("light").unwrap_or_else(|| "07:00".into()), Act::Menu(Menu::Light), ready);
        ry += rh;
        line(c, ry);
        c.row_text(x, ry, "Тёмная тема с", "Вечером, когда включается тёмная", w - 260.0, ready);
        c.chooser(x + w - 20.0, ry + 17.0, &spot("dark").unwrap_or_else(|| "20:00".into()), Act::Menu(Menu::Dark), ready);
        ry += rh;
    }
    if theme != "off" {
        line(c, ry);
        c.row_text(x, ry, "Панель задач днём тоже светлая", "Иначе она остаётся тёмной, а светлеют окна программ", w - 120.0, ready);
        let tw = if gfx::win11() { 40.0 } else { 44.0 };
        let on = spot("taskbar").as_deref() == Some("1");
        c.toggle(x + w - tw - 22.0, ry + 23.0, on, Act::Spot("taskbar", if on { "0" } else { "1" }), ready);
    }
    y += rh * rows + 24.0;

    c.section("Обои", x, y + 14.0);
    y += 28.0;
    let wall = spot("wall").unwrap_or_else(|| "off".into());
    let extra = match wall.as_str() {
        "scene" => 172.0,
        "folder" => 66.0 + 46.0,
        _ => 0.0,
    };
    c.card(x, y, w, rh + extra, false);
    c.row_text(x, y, "Обои по времени суток", "Утро, день, вечер и ночь плавно сменяют друг друга", w - 420.0, ready);
    c.segmented(
        x + w - 20.0,
        y + 18.0,
        &[
            ("Выключено", Act::Spot("wall", "off"), wall == "off"),
            ("Пейзаж дня", Act::Spot("wall", "scene"), wall == "scene"),
            ("Свои картинки", Act::Spot("wall", "folder"), wall == "folder"),
        ],
        ready,
    );
    let ry = y + rh;
    if wall == "scene" {
        line(c, ry);
        if let Some(scenes) = &ui.scenes {
            let gap = 12.0;
            let tw = ((w - 40.0 - 3.0 * gap) / 4.0).min(220.0);
            let th = tw * 9.0 / 16.0;
            for (k, (img, label)) in scenes.iter().zip(["Утро", "День", "Вечер", "Ночь"]).enumerate() {
                let tx = x + 20.0 + k as f32 * (tw + gap);
                gfx::image(c.pm, img, c.p(tx), c.p(ry + 16.0 - c.dy), c.p(tw), c.p(th), c.p(6.0), 1.0);
                c.text(label, tx, ry + 16.0 + th + 20.0, 12.5, false, gfx::white(0.65));
            }
        }
        c.text(
            "Рисуются сами под солнце в вашем городе. Выключите — вернутся прежние обои.",
            x + 20.0,
            ry + 160.0,
            12.5,
            false,
            gfx::white(0.55),
        );
    }
    if wall == "folder" {
        line(c, ry);
        let dir = spot("wall_dir").unwrap_or_default();
        let sub = if dir.is_empty() { "Папка не выбрана".to_string() } else { dir };
        c.row_text(x, ry, "Папка с картинками", &sub, w - 260.0, ready);
        let bw = c.width("Выбрать папку…", 14.0, false) + 32.0;
        c.button("Выбрать папку…", x + w - bw - 20.0, ry + 17.0, false, Act::PickFolder, ready);
        c.text(
            "Назовите картинки «утро», «день», «вечер», «ночь» — или просто положите несколько: сменятся за день.",
            x + 20.0,
            ry + 88.0,
            12.5,
            false,
            gfx::white(0.55),
        );
    }
    y + rh + extra + 40.0
}

// ---------- окна ----------

fn windows_page(c: &mut Ctx, ui: &Ui, wl: f32) -> f32 {
    let (x, w) = content_x(wl);
    let mut y = 34.0;
    c.text("Окна", x, y + 30.0, 28.0, true, gfx::white(0.95));
    y += 52.0;
    needs_spotlight(c, ui, x, &mut y, w);
    let ready = spotlight_ready(ui);
    let rh = 66.0;
    let opts = [
        (Opt::Mission, "Все окна плитками", "Ctrl+Win+↑ — как Mission Control: щелчок по плитке открывает окно, Esc — назад"),
        (Opt::Snap, "Раскладка окон клавишами", "Ctrl+Alt+стрелки и буквы — как Rectangle в Mac, для двух мониторов тоже"),
    ];
    c.card(x, y, w, rh * opts.len() as f32, false);
    for (k, (o, t, s)) in opts.iter().enumerate() {
        let ry = y + k as f32 * rh;
        if k > 0 {
            c.rect(x + 16.0, ry, w - 32.0, 1.0, 0.0, gfx::white(0.06));
        }
        c.row_text(x, ry, t, s, w - 120.0, ready);
        let tw = if gfx::win11() { 40.0 } else { 44.0 };
        c.toggle(x + w - tw - 22.0, ry + 23.0, ui.opt(*o), Act::Toggle(*o), ready);
    }
    y += rh * opts.len() as f32 + 24.0;
    c.section("Сочетания клавиш", x, y + 14.0);
    y += 28.0;
    let keys = [
        ("Ctrl+Win+↑", "все окна плитками"),
        ("Ctrl+Alt+← / →", "левая или правая половина (ещё раз — ⅔, потом ⅓)"),
        ("Ctrl+Alt+↑ / ↓", "верхняя или нижняя половина"),
        ("Ctrl+Alt+Enter", "развернуть"),
        ("Ctrl+Alt+C", "по центру, не меняя размер"),
        ("Ctrl+Alt+D / F / G", "левая, средняя, правая треть"),
        ("Ctrl+Alt+E / T", "левые или правые две трети"),
        ("Ctrl+Alt+U / I / J / K", "четверти экрана"),
        ("Ctrl+Alt+Backspace", "вернуть, как было до раскладки"),
        ("Ctrl+Alt+Win+← / →", "перенести на другой монитор"),
    ];
    let kh = 46.0;
    c.card(x, y, w, kh * keys.len() as f32, false);
    for (k, (key, what)) in keys.iter().enumerate() {
        let ry = y + k as f32 * kh;
        if k > 0 {
            c.rect(x + 16.0, ry, w - 32.0, 1.0, 0.0, gfx::white(0.06));
        }
        keycap(c, key, x + 16.0, ry + 10.0);
        c.text(what, x + 240.0, ry + 29.0, 14.0, false, gfx::white(0.8));
    }
    y + kh * keys.len() as f32 + 40.0
}

// ---------- твики ----------

fn tweaks_page(c: &mut Ctx, ui: &Ui, wl: f32) -> f32 {
    let (x, w) = content_x(wl);
    let mut y = 34.0;
    c.text("Твики", x, y + 30.0, 28.0, true, gfx::white(0.95));
    c.text("Каждый можно вернуть тем же переключателем — Windows станет как была.", x, y + 58.0, 14.0, false, gfx::white(0.6));
    y += 80.0;
    if ui.explorer_dirty {
        c.card(x, y, w, 64.0, false);
        c.glyph('\u{E72C}', x + 30.0, y + 32.0, 18.0, gfx::accent(1.0));
        c.text("Часть изменений применится после перезапуска Проводника", x + 56.0, y + 37.0, 14.0, false, gfx::white(0.9));
        let bw = c.width("Перезапустить Проводник", 14.0, false) + 32.0;
        c.button("Перезапустить Проводник", x + w - bw - 16.0, y + 16.0, true, Act::RestartExplorer, true);
        y += 80.0;
    }
    let list = crate::tweaks::list(ui.os.win11);
    let rh = 66.0;
    c.card(x, y, w, rh * list.len() as f32, false);
    for (k, t) in list.iter().enumerate() {
        let ry = y + k as f32 * rh;
        if k > 0 {
            c.rect(x + 16.0, ry, w - 32.0, 1.0, 0.0, gfx::white(0.06));
        }
        c.row_text(x, ry, t.title, t.sub, w - 120.0, true);
        let tw = if gfx::win11() { 40.0 } else { 44.0 };
        c.toggle(x + w - tw - 22.0, ry + 23.0, crate::tweaks::get(t.tw), Act::Tweak(t.tw), true);
    }
    y + rh * list.len() as f32 + 40.0
}

// ---------- перенос настроек и обновления (часть страницы «Система») ----------

fn backup_and_updates(c: &mut Ctx, ui: &Ui, x: f32, mut y: f32, w: f32) -> f32 {
    c.section("Перенос настроек", x, y + 14.0);
    y += 28.0;
    c.card(x, y, w, 66.0, false);
    c.row_text(x, y, "Все настройки и твики в одном файле", "Перенесите на другой компьютер или отправьте другу", w - 420.0, true);
    let b2 = c.width("Загрузить…", 14.0, false) + 32.0;
    let b1 = c.width("Сохранить в файл…", 14.0, false) + 32.0;
    c.button("Загрузить…", x + w - 20.0 - b2, y + 17.0, false, Act::Import, true);
    c.button("Сохранить в файл…", x + w - 28.0 - b2 - b1, y + 17.0, false, Act::Export, true);
    y += 82.0;

    c.section("Обновления", x, y + 14.0);
    y += 28.0;
    let me = crate::update::stamp();
    let installed = crate::update::installed();
    let older_installed = installed.as_ref().is_some_and(|(p, s)| s.as_str() < me && std::env::current_exe().ok().as_ref() != Some(p));
    let rows = if older_installed { 2.0 } else { 1.0 };
    c.card(x, y, w, 66.0 * rows, false);
    let status = match &ui.found {
        None => "Новая версия — это новый «Центр Mac.exe»: положите его в «Загрузки» и нажмите «Проверить»".to_string(),
        Some(Found::Nothing) => "Новее нет: проверены «Загрузки», рабочий стол и папка этого файла".to_string(),
        Some(Found::Newer(p, s)) => format!("Найдена версия от {}: {}", crate::update::pretty(s), p.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_default()),
    };
    c.row_text(x, y, &format!("Версия от {}", crate::update::pretty(me)), &status, w - 200.0, true);
    match &ui.found {
        Some(Found::Newer(..)) => {
            let bw = c.width("Обновить", 14.0, false) + 32.0;
            c.button("Обновить", x + w - bw - 20.0, y + 17.0, true, Act::RunUpdate, true);
        }
        _ => {
            let bw = c.width("Проверить", 14.0, false) + 32.0;
            c.button("Проверить", x + w - bw - 20.0, y + 17.0, false, Act::CheckUpdate, true);
        }
    }
    if older_installed {
        let ry = y + 66.0;
        c.rect(x + 16.0, ry, w - 32.0, 1.0, 0.0, gfx::white(0.06));
        c.row_text(x, ry, "Эта копия центра новее установленной", "Заменить ярлык «Центр Mac» в «Пуске» на эту версию", w - 220.0, true);
        let bw = c.width("Установить", 14.0, false) + 32.0;
        c.button("Установить", x + w - bw - 20.0, ry + 17.0, true, Act::InstallCenter, true);
    }
    y += 66.0 * rows + 16.0;
    if let Some(n) = &ui.note {
        c.text(n, x + 4.0, y + 8.0, 13.0, false, gfx::accent(1.0));
        y += 24.0;
    }
    y
}

/// Миниатюры «Пейзажа дня» для страницы «Оформление»
pub fn scene_thumbs() -> Vec<Img> {
    [(4.0f32, false, 0.08f32), (30.0, false, 0.5), (3.0, true, 0.92), (-22.0, false, 0.5)]
        .iter()
        .map(|(e, ev, sx)| crate::scenery::render(352, 198, *e, *ev, *sx))
        .collect()
}
