#![allow(dead_code)]
//! Обои «Пейзаж дня»: горы, небо, солнце, луна и звёзды рисуются под настоящее положение солнца,
//! поэтому утро, день, вечер и ночь плавно сменяют друг друга. Рисунок свой, без чужих картинок.
//! Общий файл: обои ставит MacSpotlight, а «Центр Mac» показывает их миниатюры

use tiny_skia::*;

use crate::gfx::Img;

#[derive(Clone, Copy)]
struct Rgb(f32, f32, f32);

fn hex(v: u32) -> Rgb {
    Rgb((v >> 16 & 0xFF) as f32, (v >> 8 & 0xFF) as f32, (v & 0xFF) as f32)
}

fn mix(a: Rgb, b: Rgb, k: f32) -> Rgb {
    let k = k.clamp(0.0, 1.0);
    Rgb(a.0 + (b.0 - a.0) * k, a.1 + (b.1 - a.1) * k, a.2 + (b.2 - a.2) * k)
}

/// Буферы у нас BGRA — R и B меняем местами (как gfx::rgb)
fn color(c: Rgb, a: f32) -> Color {
    Color::from_rgba8(c.2.round() as u8, c.1.round() as u8, c.0.round() as u8, (a.clamp(0.0, 1.0) * 255.0) as u8)
}

/// Цвет по высоте солнца: опорные точки и плавный переход между ними
fn by_elevation(e: f32, keys: &[(f32, u32)]) -> Rgb {
    if e <= keys[0].0 {
        return hex(keys[0].1);
    }
    for w in keys.windows(2) {
        if e <= w[1].0 {
            let k = (e - w[0].0) / (w[1].0 - w[0].0);
            // плавнее, чем линейно
            let k = k * k * (3.0 - 2.0 * k);
            return mix(hex(w[0].1), hex(w[1].1), k);
        }
    }
    hex(keys[keys.len() - 1].1)
}

const TOP: [(f32, u32); 8] =
    [(-18.0, 0x0A0F24), (-10.0, 0x111A3E), (-4.0, 0x26336E), (0.0, 0x3A55A0), (6.0, 0x4A80CF), (15.0, 0x3D88DD), (30.0, 0x307DD8), (60.0, 0x2A74D2)];
const HORIZON: [(f32, u32); 8] =
    [(-18.0, 0x151C3C), (-10.0, 0x2A2A5C), (-4.0, 0xC9707A), (0.0, 0xF4A36E), (6.0, 0xF8CF9C), (15.0, 0xC5E2FA), (30.0, 0xCDE8FF), (60.0, 0xD6ECFF)];
const NEAR: [(f32, u32); 6] = [(-14.0, 0x05070F), (-6.0, 0x13122A), (0.0, 0x2E2440), (6.0, 0x34304F), (15.0, 0x1E3A5A), (40.0, 0x1A3756)];

/// Детерминированный «шум» хребта: сумма синусоид — одни и те же горы при каждой перерисовке
fn ridge(x: f32, seed: f32) -> f32 {
    let mut y = 0.0;
    let mut amp = 1.0;
    let mut freq = 1.0;
    for k in 0..5 {
        let kf = k as f32;
        y += amp * (x * freq * 6.2 + seed * (1.7 + kf) + kf * 1.3).sin();
        amp *= 0.5;
        freq *= 2.1;
    }
    y
}

fn rng(seed: &mut u32) -> f32 {
    *seed ^= *seed << 13;
    *seed ^= *seed >> 17;
    *seed ^= *seed << 5;
    (*seed % 100_000) as f32 / 100_000.0
}

/// Сцена: e — высота солнца в градусах, evening — солнце садится, sun_x — где оно по горизонтали (0…1)
pub fn render(w: u32, h: u32, e: f32, evening: bool, sun_x: f32) -> Img {
    let mut img = Img::new(w, h);
    let Some(mut pm) = img.pixmap_mut() else { return img };
    let (wf, hf) = (w as f32, h as f32);
    let top = by_elevation(e, &TOP);
    let mut horizon = by_elevation(e, &HORIZON);
    // вечером горизонт розовее, утром — золотистее
    let golden = 1.0 - ((e - 2.0).abs() / 10.0).min(1.0);
    horizon = if evening { mix(horizon, hex(0xE9728E), 0.35 * golden) } else { mix(horizon, hex(0xFFC27A), 0.2 * golden) };
    let mid = mix(top, horizon, 0.45);
    // небо
    if let Some(sh) = LinearGradient::new(
        Point::from_xy(0.0, 0.0),
        Point::from_xy(0.0, hf * 0.78),
        vec![GradientStop::new(0.0, color(top, 1.0)), GradientStop::new(0.55, color(mid, 1.0)), GradientStop::new(1.0, color(horizon, 1.0))],
        SpreadMode::Pad,
        Transform::identity(),
    ) {
        let paint = Paint { shader: sh, ..Default::default() };
        if let Some(r) = Rect::from_xywh(0.0, 0.0, wf, hf) {
            pm.fill_rect(r, &paint, Transform::identity(), None);
        }
    }
    // звёзды
    let night = ((-e - 5.0) / 10.0).clamp(0.0, 1.0);
    if night > 0.0 {
        let mut seed = 0x9E37_79B9u32;
        for _ in 0..(wf * hf / 9000.0) as usize {
            let (x, y) = (rng(&mut seed) * wf, rng(&mut seed).powf(1.4) * hf * 0.62);
            let r = (0.6 + rng(&mut seed) * 1.4) * (hf / 1440.0).max(0.6);
            let a = night * (0.35 + rng(&mut seed) * 0.65);
            disk(&mut pm, x, y, r, color(hex(0xF4F6FF), a));
        }
    }
    let horizon_y = hf * 0.66;
    // солнце над горизонтом (или чуть за ним — тогда его закроют горы)
    if e > -3.0 {
        let sy = horizon_y - (e.max(-3.0) / 50.0).min(1.0) * hf * 0.55;
        let sx = wf * (0.12 + 0.76 * sun_x.clamp(0.0, 1.0));
        let low = (1.0 - e / 25.0).clamp(0.0, 1.0);
        let core = mix(hex(0xFFF7E0), hex(0xFF9C5C), low);
        glow(&mut pm, sx, sy, hf * 0.32, color(core, 0.42 * (1.0 - 0.4 * (1.0 - low))));
        disk(&mut pm, sx, sy, hf * 0.035, color(core, 1.0));
    } else if e < -6.0 {
        // луна
        let (mx, my) = (wf * 0.74, hf * 0.2);
        let a = ((-e - 6.0) / 6.0).clamp(0.0, 1.0);
        glow(&mut pm, mx, my, hf * 0.16, color(hex(0xC9D4FF), 0.18 * a));
        disk(&mut pm, mx, my, hf * 0.028, color(hex(0xF1EEE2), a));
        // серп: тень сбоку цветом неба
        disk(&mut pm, mx + hf * 0.014, my - hf * 0.006, hf * 0.026, color(mix(top, mid, 0.3), a * 0.92));
    }
    // горы: дальние светлее и растворяются в дымке
    let near = by_elevation(e, &NEAR);
    let layers = [(0.60, 0.055, 1.3, 0.18), (0.66, 0.075, 2.9, 0.42), (0.74, 0.09, 4.6, 0.68), (0.84, 0.10, 7.1, 0.92)];
    for (base, amp, seed, depth) in layers {
        let c = mix(horizon, near, depth);
        let mut pb = PathBuilder::new();
        pb.move_to(0.0, hf);
        let step = (wf / 240.0).max(4.0);
        let mut x = 0.0;
        while x <= wf + step {
            let y = hf * base - hf * amp * (0.5 + 0.35 * ridge(x / wf, seed));
            pb.line_to(x, y);
            x += step;
        }
        pb.line_to(wf, hf);
        pb.close();
        if let Some(path) = pb.finish() {
            pm.fill_path(&path, &solid(color(c, 1.0)), FillRule::Winding, Transform::identity(), None);
        }
        // лёгкая дымка у подножия каждого слоя
        if let Some(sh) = LinearGradient::new(
            Point::from_xy(0.0, hf * (base - 0.02)),
            Point::from_xy(0.0, hf * (base + 0.12)),
            vec![GradientStop::new(0.0, color(horizon, 0.0)), GradientStop::new(1.0, color(horizon, 0.18 * (1.0 - depth)))],
            SpreadMode::Pad,
            Transform::identity(),
        ) {
            let paint = Paint { shader: sh, ..Default::default() };
            if let Some(r) = Rect::from_xywh(0.0, hf * (base - 0.02), wf, hf * 0.14) {
                pm.fill_rect(r, &paint, Transform::identity(), None);
            }
        }
    }
    img
}

fn solid(c: Color) -> Paint<'static> {
    let mut p = Paint::default();
    p.set_color(c);
    p.anti_alias = true;
    p
}

fn disk(pm: &mut PixmapMut, x: f32, y: f32, r: f32, c: Color) {
    if let Some(p) = PathBuilder::from_circle(x, y, r) {
        pm.fill_path(&p, &solid(c), FillRule::Winding, Transform::identity(), None);
    }
}

fn glow(pm: &mut PixmapMut, x: f32, y: f32, r: f32, c: Color) {
    let mut clear = c;
    clear.set_alpha(0.0);
    if let Some(sh) = RadialGradient::new(Point::from_xy(x, y), Point::from_xy(x, y), r, vec![GradientStop::new(0.0, c), GradientStop::new(1.0, clear)], SpreadMode::Pad, Transform::identity()) {
        let paint = Paint { shader: sh, anti_alias: true, ..Default::default() };
        if let Some(p) = PathBuilder::from_circle(x, y, r) {
            pm.fill_path(&p, &paint, FillRule::Winding, Transform::identity(), None);
        }
    }
}

/// Сцена для момента t (секунды UTC) в городе: считает солнце сама
pub fn at(w: u32, h: u32, t: f64, lat: f64, lon: f64) -> Img {
    let e = crate::sun::elevation(t, lat, lon) as f32;
    let evening = crate::sun::elevation(t + 600.0, lat, lon) < e as f64;
    let (rise, set) = crate::sun::sunrise_sunset(t, lat, lon);
    let sun_x = match (rise, set) {
        (Some(r), Some(s)) if s > r => ((t - r) / (s - r)) as f32,
        _ => 0.5,
    };
    render(w, h, e, evening, sun_x)
}
