//! Сведения о системе: версия Windows, имя пользователя, тема, процессы, реестр и файлы настроек программ

use std::path::{Path, PathBuf};

use windows::core::{PCWSTR, PWSTR};
use windows::Win32::Foundation::*;
use windows::Win32::System::Diagnostics::ToolHelp::*;
use windows::Win32::System::Registry::*;
use windows::Win32::System::Threading::*;

use crate::win::{pcwstr, wide};

pub struct Os {
    /// «Windows 11 Pro»
    pub name: String,
    /// «23H2»
    pub version: String,
    pub build: u32,
    pub ubr: u32,
    pub win11: bool,
    /// Windows 10 1809 и новее, 64 бита — на остальных программы не работают
    pub supported: bool,
}

fn reg_string(root: HKEY, path: &str, name: &str) -> Option<String> {
    let (p, n) = (wide(path), wide(name));
    let mut buf = vec![0u16; 512];
    let mut size = (buf.len() * 2) as u32;
    unsafe {
        RegGetValueW(root, pcwstr(&p), pcwstr(&n), RRF_RT_REG_SZ, None, Some(buf.as_mut_ptr() as *mut _), Some(&mut size)).ok().ok()?;
    }
    let len = buf.iter().position(|c| *c == 0).unwrap_or(0);
    Some(String::from_utf16_lossy(&buf[..len]))
}

fn reg_dword(root: HKEY, path: &str, name: &str) -> Option<u32> {
    let (p, n) = (wide(path), wide(name));
    let mut v = 0u32;
    let mut size = 4u32;
    unsafe {
        RegGetValueW(root, pcwstr(&p), pcwstr(&n), RRF_RT_REG_DWORD, None, Some(&mut v as *mut u32 as *mut _), Some(&mut size)).ok().ok()?;
    }
    Some(v)
}

pub fn os() -> Os {
    // для снимков на сайт: MAC_FAKE_WIN11=1 — как будто это Windows 11
    if std::env::var("MAC_FAKE_WIN11").is_ok() {
        return Os { name: "Windows 11 Pro".into(), version: "24H2".into(), build: 26100, ubr: 2314, win11: true, supported: true };
    }
    const KEY: &str = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion";
    let build: u32 = reg_string(HKEY_LOCAL_MACHINE, KEY, "CurrentBuildNumber").and_then(|s| s.parse().ok()).unwrap_or(0);
    let ubr = reg_dword(HKEY_LOCAL_MACHINE, KEY, "UBR").unwrap_or(0);
    let win11 = build >= 22000;
    // в Windows 11 реестр по старой памяти называет систему «Windows 10»
    let mut name = reg_string(HKEY_LOCAL_MACHINE, KEY, "ProductName").unwrap_or_else(|| "Windows".into());
    if win11 {
        name = name.replace("Windows 10", "Windows 11");
    }
    let version = reg_string(HKEY_LOCAL_MACHINE, KEY, "DisplayVersion")
        .or_else(|| reg_string(HKEY_LOCAL_MACHINE, KEY, "ReleaseId"))
        .unwrap_or_default();
    let supported = cfg!(target_pointer_width = "64") && build >= 17763;
    Os { name, version, build, ubr, win11, supported }
}

/// Как обращаться к человеку: полное имя учётной записи, а если его нет — имя входа
pub fn user_name() -> String {
    use windows::Win32::Security::Authentication::Identity::{GetUserNameExW, NameDisplay};
    let full = unsafe {
        let mut buf = [0u16; 256];
        let mut n = buf.len() as u32;
        GetUserNameExW(NameDisplay, Some(PWSTR(buf.as_mut_ptr())), &mut n).then(|| String::from_utf16_lossy(&buf[..n as usize]))
    }
    .filter(|s| !s.trim().is_empty());
    let login = std::env::var("USERNAME").unwrap_or_default();
    let name = full.unwrap_or(login);
    // для приветствия хватит имени
    name.split_whitespace().next().unwrap_or("").to_string()
}

pub fn greeting() -> &'static str {
    let h = unsafe { windows::Win32::System::SystemInformation::GetLocalTime() }.wHour;
    match h {
        5..=11 => "Доброе утро",
        12..=17 => "Добрый день",
        18..=22 => "Добрый вечер",
        _ => "Доброй ночи",
    }
}

pub struct Look {
    pub apps_dark: bool,
    pub system_dark: bool,
    pub accent: (u8, u8, u8),
}

pub fn look() -> Look {
    const KEY: &str = "Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize";
    let accent = reg_dword(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Accent", "AccentColorMenu")
        .map_or((0x00, 0x78, 0xD7), |v| ((v & 0xFF) as u8, (v >> 8 & 0xFF) as u8, (v >> 16 & 0xFF) as u8));
    Look {
        apps_dark: reg_dword(HKEY_CURRENT_USER, KEY, "AppsUseLightTheme") == Some(0),
        system_dark: reg_dword(HKEY_CURRENT_USER, KEY, "SystemUsesLightTheme") != Some(1),
        accent,
    }
}

pub fn windhawk_installed() -> bool {
    std::env::var("ProgramFiles").is_ok_and(|p| Path::new(&p).join("Windhawk").join("windhawk.ini").exists())
}

/// Стоит ли мод Windhawk «MacFinder вместо Проводника»
pub fn finder_mod() -> bool {
    let p = wide("SOFTWARE\\Windhawk\\Engine\\Mods\\local@macfinder-instead-of-explorer");
    let mut h = HKEY::default();
    unsafe {
        let ok = RegOpenKeyExW(HKEY_LOCAL_MACHINE, pcwstr(&p), Some(0), KEY_READ, &mut h).is_ok();
        if ok {
            let _ = RegCloseKey(h);
        }
        ok
    }
}

// ---------- автозапуск ----------

const RUN: &str = "Software\\Microsoft\\Windows\\CurrentVersion\\Run";

pub fn run_get(value: &str) -> bool {
    reg_string(HKEY_CURRENT_USER, RUN, value).is_some()
}

pub fn run_set(value: &str, cmd: Option<&str>) {
    let (k, v) = (wide(RUN), wide(value));
    unsafe {
        match cmd {
            Some(c) => {
                let data = wide(c);
                let _ = RegSetKeyValueW(HKEY_CURRENT_USER, pcwstr(&k), pcwstr(&v), REG_SZ.0, Some(data.as_ptr() as *const _), (data.len() * 2) as u32);
            }
            None => {
                let _ = RegDeleteKeyValueW(HKEY_CURRENT_USER, pcwstr(&k), pcwstr(&v));
            }
        }
    }
}

// ---------- процессы ----------

/// Имена запущенных exe (в нижнем регистре)
pub fn processes() -> Vec<String> {
    let mut out = Vec::new();
    unsafe {
        let Ok(snap) = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0) else { return out };
        let mut e = PROCESSENTRY32W { dwSize: std::mem::size_of::<PROCESSENTRY32W>() as u32, ..Default::default() };
        if Process32FirstW(snap, &mut e).is_ok() {
            loop {
                let n = e.szExeFile.iter().position(|c| *c == 0).unwrap_or(0);
                out.push(String::from_utf16_lossy(&e.szExeFile[..n]).to_lowercase());
                if Process32NextW(snap, &mut e).is_err() {
                    break;
                }
            }
        }
        let _ = CloseHandle(snap);
    }
    out
}

/// Закрыть все копии программы и дождаться, пока они действительно выйдут
pub fn kill(exe: &str) {
    let exe = exe.to_lowercase();
    unsafe {
        let Ok(snap) = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0) else { return };
        let mut e = PROCESSENTRY32W { dwSize: std::mem::size_of::<PROCESSENTRY32W>() as u32, ..Default::default() };
        let mut pids = Vec::new();
        if Process32FirstW(snap, &mut e).is_ok() {
            loop {
                let n = e.szExeFile.iter().position(|c| *c == 0).unwrap_or(0);
                if String::from_utf16_lossy(&e.szExeFile[..n]).to_lowercase() == exe {
                    pids.push(e.th32ProcessID);
                }
                if Process32NextW(snap, &mut e).is_err() {
                    break;
                }
            }
        }
        let _ = CloseHandle(snap);
        for pid in pids {
            if let Ok(h) = OpenProcess(PROCESS_TERMINATE | PROCESS_SYNCHRONIZE, false, pid) {
                let _ = TerminateProcess(h, 0);
                let _ = WaitForSingleObject(h, 3000);
                let _ = CloseHandle(h);
            }
        }
    }
}

pub fn launch(exe: &Path, args: &str) {
    let (e, a) = (wide(&exe.to_string_lossy()), wide(args));
    unsafe {
        windows::Win32::UI::Shell::ShellExecuteW(
            None,
            windows::core::w!("open"),
            pcwstr(&e),
            if args.is_empty() { PCWSTR::null() } else { pcwstr(&a) },
            None,
            windows::Win32::UI::WindowsAndMessaging::SW_SHOWNORMAL,
        );
    }
}

/// Открыть ссылку, папку или страницу параметров Windows
pub fn open(target: &str) {
    let t = wide(target);
    unsafe {
        windows::Win32::UI::Shell::ShellExecuteW(None, windows::core::w!("open"), pcwstr(&t), None, None, windows::Win32::UI::WindowsAndMessaging::SW_SHOWNORMAL);
    }
}

// ---------- файлы «ключ=значение» ----------

pub fn local(sub: &str) -> PathBuf {
    PathBuf::from(std::env::var("LOCALAPPDATA").unwrap_or_default()).join(sub)
}

pub fn kv_get(file: &Path, key: &str) -> Option<String> {
    let text = std::fs::read_to_string(file).ok()?;
    text.lines().find_map(|l| {
        let (k, v) = l.split_once('=')?;
        (k.trim() == key).then(|| v.trim().to_string())
    })
}

/// Поменять одну строку, остальные оставить как были
pub fn kv_set(file: &Path, key: &str, value: &str) {
    let text = std::fs::read_to_string(file).unwrap_or_default();
    let mut found = false;
    let mut lines: Vec<String> = text
        .lines()
        .map(|l| match l.split_once('=') {
            Some((k, _)) if k.trim() == key => {
                found = true;
                format!("{key}={value}")
            }
            _ => l.to_string(),
        })
        .collect();
    if !found {
        lines.push(format!("{key}={value}"));
    }
    if let Some(d) = file.parent() {
        let _ = std::fs::create_dir_all(d);
    }
    let _ = std::fs::write(file, lines.join("\n") + "\n");
}

/// Журнал установки: %LOCALAPPDATA%\MacCenter\center.log
pub fn log(s: &str) {
    let dir = local("MacCenter");
    let _ = std::fs::create_dir_all(&dir);
    let f = dir.join("center.log");
    if std::fs::metadata(&f).is_ok_and(|m| m.len() > 1_000_000) {
        let _ = std::fs::remove_file(&f);
    }
    let t = unsafe { windows::Win32::System::SystemInformation::GetLocalTime() };
    let line = format!("{:02}.{:02} {:02}:{:02}:{:02}  {s}\n", t.wDay, t.wMonth, t.wHour, t.wMinute, t.wSecond);
    let _ = std::fs::OpenOptions::new().create(true).append(true).open(f).and_then(|mut f| std::io::Write::write_all(&mut f, line.as_bytes()));
}

#[allow(dead_code)]
pub fn pwstr_to_string(p: PWSTR) -> String {
    unsafe { p.to_string().unwrap_or_default() }
}
