//! Перенос настроек: все настройки комплекта и твики — в один текстовый файл, и обратно на другом ПК.
//! В файл не попадают история поиска, буфер обмена и место окон — только выбранные параметры.

use std::path::{Path, PathBuf};

use crate::apps::{self, APPS};
use crate::sys;
use crate::tweaks::{self, Tw};

const HEAD: &str = "MacCenter settings 1";

/// Файлы настроек программ: (подпись в файле, где лежит, какие строки не переносить)
fn files() -> Vec<(&'static str, PathBuf, &'static [&'static str])> {
    let roaming = PathBuf::from(std::env::var("APPDATA").unwrap_or_default());
    vec![
        ("MacMixer/island.txt", sys::local("MacMixer").join("island.txt"), &[]),
        ("MacSpotlight/settings.txt", sys::local("MacSpotlight").join("settings.txt"), &["wall_prev", "wall_prev_style"]),
        ("MacMirror/settings.txt", sys::local("MacMirror").join("settings.txt"), &["pos", "hinted"]),
        ("MacFinder/settings.txt", roaming.join("MacFinder").join("settings.txt"), &["size"]),
    ]
}

pub fn export(to: &Path) -> std::io::Result<usize> {
    let mut out = format!("{HEAD}\n");
    let mut n = 0;
    for (tag, path, skip) in files() {
        let Ok(text) = std::fs::read_to_string(&path) else { continue };
        out += &format!("[file {tag}]\n");
        for line in text.lines() {
            let key = line.split_once('=').map(|(k, _)| k.trim()).unwrap_or("");
            if !skip.contains(&key) && !line.trim().is_empty() {
                out += line;
                out.push('\n');
            }
        }
        out += "[end]\n";
        n += 1;
    }
    out += &format!("lyrics={}\n", sys::local("MacMixer").join("lyrics.on").exists() as u8);
    for (i, a) in APPS.iter().enumerate() {
        if a.run.is_some() {
            out += &format!("autostart {}={}\n", a.id, apps::get(apps::Opt::Autostart(i)) as u8);
        }
    }
    for tw in tweaks::ALL {
        out += &format!("tweak {}={}\n", tweaks::name(tw), tweaks::get(tw) as u8);
    }
    std::fs::write(to, out)?;
    Ok(n)
}

/// Загрузить: записать файлы, автозапуск и твики. Вернуть, что изменилось — для отчёта
pub fn import(from: &Path) -> Result<String, String> {
    let text = std::fs::read_to_string(from).map_err(|e| e.to_string())?;
    let mut lines = text.lines();
    if lines.next().map(str::trim) != Some(HEAD) {
        return Err("Это не файл настроек «Центра Mac»".into());
    }
    let targets = files();
    let mut current: Option<(PathBuf, Vec<String>)> = None;
    let (mut files_done, mut tweaks_done) = (0, 0);
    for line in lines {
        if let Some(tag) = line.strip_prefix("[file ").and_then(|s| s.strip_suffix(']')) {
            current = targets.iter().find(|t| t.0 == tag).map(|t| (t.1.clone(), Vec::new()));
            continue;
        }
        if line == "[end]" {
            if let Some((path, body)) = current.take() {
                // переносимые строки поверх местных: место окна и прочее своё остаются
                for l in body {
                    if let Some((k, v)) = l.split_once('=') {
                        sys::kv_set(&path, k.trim(), v.trim());
                    }
                }
                files_done += 1;
            }
            continue;
        }
        if let Some((_, body)) = current.as_mut() {
            body.push(line.to_string());
            continue;
        }
        if let Some(v) = line.strip_prefix("lyrics=") {
            if apps::get(apps::Opt::Lyrics) != (v.trim() == "1") {
                apps::set(apps::Opt::Lyrics, v.trim() == "1");
            }
        } else if let Some((id, v)) = line.strip_prefix("autostart ").and_then(|s| s.split_once('=')) {
            if let Some(i) = APPS.iter().position(|a| a.id == id) {
                let want = v.trim() == "1";
                if apps::installed(&APPS[i]) && apps::get(apps::Opt::Autostart(i)) != want {
                    apps::set(apps::Opt::Autostart(i), want);
                }
            }
        } else if let Some((name, v)) = line.strip_prefix("tweak ").and_then(|s| s.split_once('=')) {
            if let Some(tw) = tweaks::ALL.into_iter().find(|t| tweaks::name(*t) == name) {
                let want = v.trim() == "1";
                if (tw != Tw::ClassicMenu || sys::os().win11) && tweaks::get(tw) != want {
                    tweaks::set(tw, want);
                    tweaks_done += 1;
                }
            }
        }
    }
    // программы читают настройки при запуске — перезапускаем работающие
    let procs = sys::processes();
    for (i, a) in APPS.iter().enumerate() {
        if procs.iter().any(|p| p == a.exe) && a.id != "MacFinder" {
            apps::stop(i);
            apps::start(i, true);
        }
    }
    Ok(format!("Настройки программ: {files_done}, твиков изменено: {tweaks_done}"))
}

// ---------- окна выбора файла ----------

fn dialog(save: bool, owner: windows::Win32::Foundation::HWND) -> Option<PathBuf> {
    use windows::Win32::UI::Controls::Dialogs::*;
    let mut buf = [0u16; 520];
    if save {
        let name: Vec<u16> = "Настройки Mac.macsettings".encode_utf16().collect();
        buf[..name.len()].copy_from_slice(&name);
    }
    let filter: Vec<u16> = "Настройки Центра Mac\0*.macsettings\0Все файлы\0*.*\0\0".encode_utf16().collect();
    let ext: Vec<u16> = "macsettings\0".encode_utf16().collect();
    let mut ofn = OPENFILENAMEW {
        lStructSize: std::mem::size_of::<OPENFILENAMEW>() as u32,
        hwndOwner: owner,
        lpstrFilter: windows::core::PCWSTR(filter.as_ptr()),
        lpstrFile: windows::core::PWSTR(buf.as_mut_ptr()),
        nMaxFile: buf.len() as u32,
        lpstrDefExt: windows::core::PCWSTR(ext.as_ptr()),
        Flags: if save { OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST } else { OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST },
        ..Default::default()
    };
    let ok = unsafe { if save { GetSaveFileNameW(&mut ofn).as_bool() } else { GetOpenFileNameW(&mut ofn).as_bool() } };
    if !ok {
        return None;
    }
    let n = buf.iter().position(|c| *c == 0).unwrap_or(0);
    Some(PathBuf::from(String::from_utf16_lossy(&buf[..n])))
}

pub fn ask_save(owner: windows::Win32::Foundation::HWND) -> Option<PathBuf> {
    dialog(true, owner)
}

pub fn ask_open(owner: windows::Win32::Foundation::HWND) -> Option<PathBuf> {
    dialog(false, owner)
}
