//! Обновления без интернета: новая версия комплекта — это новый «Центр Mac.exe». Ищем его в «Загрузках»,
//! на рабочем столе и рядом с собой. Версию читаем из самого файла (метка сборки), ничего не запуская.

use std::path::{Path, PathBuf};

use crate::sys;

/// Метка сборки лежит в exe строкой: по ней другой центр узнаёт, кто из них новее
pub static STAMP: &str = concat!("MACCENTER-STAMP:", env!("BUILD_STAMP"), ";");

pub fn stamp() -> &'static str {
    &STAMP[16..STAMP.len() - 1]
}

/// «12.11.2026» из метки «202611120730»
pub fn pretty(s: &str) -> String {
    if s.len() < 12 {
        return s.to_string();
    }
    // время в метке — UTC, человеку достаточно даты
    format!("{}.{}.{}", &s[6..8], &s[4..6], &s[0..4])
}

/// Метка сборки другого exe (или None, если это не «Центр Mac»)
pub fn stamp_of(p: &Path) -> Option<String> {
    let data = std::fs::read(p).ok()?;
    let marker = b"MACCENTER-STAMP:";
    // сам образец поиска тоже лежит в exe — берём вхождение, за которым идут 12 цифр и «;»
    data.windows(marker.len()).enumerate().filter(|(_, w)| *w == marker).find_map(|(i, _)| {
        let rest = data.get(i + marker.len()..i + marker.len() + 13)?;
        (rest[12] == b';' && rest[..12].iter().all(u8::is_ascii_digit)).then(|| String::from_utf8_lossy(&rest[..12]).to_string())
    })
}

fn folders() -> Vec<PathBuf> {
    use windows::Win32::UI::Shell::*;
    let mut v = Vec::new();
    for id in [FOLDERID_Downloads, FOLDERID_Desktop] {
        unsafe {
            if let Ok(p) = SHGetKnownFolderPath(&id, KF_FLAG_DEFAULT, None) {
                v.push(PathBuf::from(p.to_string().unwrap_or_default()));
                windows::Win32::System::Com::CoTaskMemFree(Some(p.0 as *const _));
            }
        }
    }
    if let Some(d) = std::env::current_exe().ok().and_then(|e| e.parent().map(Path::to_path_buf)) {
        v.push(d);
    }
    v
}

/// Самый новый «Центр Mac» новее нашего: путь и его метка
pub fn find_newer() -> Option<(PathBuf, String)> {
    let me = std::env::current_exe().ok();
    let mine = stamp().to_string();
    let mut best: Option<(PathBuf, String)> = None;
    for dir in folders() {
        let Ok(rd) = std::fs::read_dir(&dir) else { continue };
        for e in rd.flatten() {
            let p = e.path();
            let name = p.file_name().map(|n| n.to_string_lossy().to_lowercase()).unwrap_or_default();
            let ours = name.ends_with(".exe") && (name.starts_with("mac-center") || name.starts_with("центр mac"));
            if !ours || Some(&p) == me.as_ref() || std::fs::metadata(&p).map(|m| m.len()).unwrap_or(0) > 64 << 20 {
                continue;
            }
            if let Some(s) = stamp_of(&p) {
                if s > mine && best.as_ref().is_none_or(|b| s > b.1) {
                    best = Some((p, s));
                }
            }
        }
    }
    best
}

/// Установленная копия центра (в «Программах») — и её метка
pub fn installed() -> Option<(PathBuf, String)> {
    let p = sys::local("Programs").join("MacCenter").join("mac-center.exe");
    let s = stamp_of(&p)?;
    Some((p, s))
}
