#![windows_subsystem = "windows"]
//! Центр Mac — один exe: приветствие с версией Windows, установка всех программ комплекта
//! и их настройки в одном окне, как «Параметры» Windows

mod apps;
mod backup;
mod gfx;
mod scenery;
mod sun;
mod sys;
mod tweaks;
mod ui;
mod update;
mod win;

use std::cell::RefCell;
use std::sync::atomic::Ordering;

use tiny_skia::PixmapMut;
use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Dwm::{DwmSetWindowAttribute, DWMWINDOWATTRIBUTE};
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::Com::{CoInitializeEx, COINIT_APARTMENTTHREADED};
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::System::Threading::CreateMutexW;
use windows::Win32::UI::Controls::WM_MOUSELEAVE;
use windows::Win32::UI::HiDpi::*;
use windows::Win32::UI::Input::KeyboardAndMouse::{TrackMouseEvent, TME_LEAVE, TRACKMOUSEEVENT};
use windows::Win32::UI::WindowsAndMessaging::*;

use apps::{Job, APPS};
use ui::{Act, Page, Ui};
use win::Surface;

const TIMER_STATUS: usize = 1;
const TIMER_SPIN: usize = 2;

struct App {
    hwnd: HWND,
    ui: Ui,
    frame: Option<Surface>,
}

thread_local! {
    static APP: RefCell<Option<App>> = const { RefCell::new(None) };
}

fn with<R>(f: impl FnOnce(&mut App) -> R) -> Option<R> {
    APP.with(|a| a.try_borrow_mut().ok()?.as_mut().map(f))
}

fn seen_file() -> std::path::PathBuf {
    sys::local("MacCenter").join("welcome.done")
}

fn new_ui(os: sys::Os) -> Option<Ui> {
    let fonts = ui::Fonts::load()?;
    let user = sys::user_name();
    let procs = sys::processes();
    let st = std::array::from_fn(|i| apps::status(&APPS[i], &procs));
    let finder = APPS.iter().position(|a| a.id == "MacFinder").unwrap_or(2);
    let finder_installed = apps::installed(&APPS[finder]);
    // Проводник оставляем, если Finder уже стоит без замены, а на Windows 11 — по умолчанию
    let keep_explorer = if finder_installed { !sys::finder_mod() } else { os.win11 };
    Some(Ui {
        fonts,
        user,
        page: Page::Home,
        st,
        hover: None,
        zones: Vec::new(),
        scroll: 0.0,
        content_h: 0.0,
        // отмечено то, чего нет или что устарело
        pick: std::array::from_fn(|i| apps::has_payload(&APPS[i]) && !(st[i].installed && st[i].current)),
        keep_explorer,
        tick: 0,
        icon: app_icon(176),
        pending: Vec::new(),
        scenes: None,
        explorer_dirty: false,
        found: None,
        note: None,
        os,
    })
}

/// Значок программы из ресурсов exe — для приветствия
fn app_icon(px: i32) -> Option<gfx::Img> {
    unsafe {
        let inst = GetModuleHandleW(None).ok()?;
        let h = LoadImageW(Some(inst.into()), windows::core::PCWSTR(1 as *const u16), IMAGE_ICON, px, px, LR_DEFAULTCOLOR).ok()?;
        let img = win::icon_img(HICON(h.0));
        let _ = DestroyIcon(HICON(h.0));
        img
    }
}

fn main() {
    std::panic::set_hook(Box::new(|info| sys::log(&format!("СБОЙ: {info}"))));
    unsafe {
        let _ = SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
        let _ = CoInitializeEx(None, COINIT_APARTMENTTHREADED);
    }
    gfx::load_themes();
    gfx::use_theme(true);
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.first().map(String::as_str) == Some("--preview") {
        preview(&args[1..]);
        return;
    }
    if args.first().map(String::as_str) == Some("--selftest") {
        let out = args.get(1).cloned().unwrap_or_else(|| "selftest.txt".into());
        let _ = std::fs::write(out, selftest(args.iter().any(|a| a == "--reinstall-shot")));
        return;
    }
    unsafe {
        let mutex = CreateMutexW(None, true, w!("Local\\MacCenter.Instance"));
        if let Ok(m) = &mutex {
            MUTEX.store(m.0 as isize, Ordering::Relaxed);
        }
        if GetLastError() == ERROR_ALREADY_EXISTS {
            if let Ok(h) = FindWindowW(w!("MacCenter.Main"), None) {
                let _ = ShowWindow(h, SW_RESTORE);
                let _ = SetForegroundWindow(h);
            }
            return;
        }
    }
    let os = sys::os();
    let Some(mut ui) = new_ui(os) else { return };
    if !seen_file().exists() || args.iter().any(|a| a == "--welcome") {
        ui.page = Page::Welcome;
    }
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacCenter.Main"),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            hIcon: LoadIconW(Some(inst.into()), windows::core::PCWSTR(1 as *const u16)).unwrap_or_default(),
            ..Default::default()
        };
        RegisterClassW(&wc);
        let m = win::monitor_at(win::cursor());
        let (w, h) = ((1100.0 * m.scale) as i32, (740.0 * m.scale) as i32);
        let (w, h) = (w.min(m.work.right - m.work.left), h.min(m.work.bottom - m.work.top));
        let x = (m.work.left + m.work.right - w) / 2;
        let y = (m.work.top + m.work.bottom - h) / 2;
        let Ok(hwnd) = CreateWindowExW(
            WINDOW_EX_STYLE(0),
            w!("MacCenter.Main"),
            w!("Центр Mac"),
            WS_OVERLAPPEDWINDOW,
            x,
            y,
            w,
            h,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        apps::NOTIFY.store(hwnd.0 as isize, Ordering::Relaxed);
        APP.with(|a| *a.borrow_mut() = Some(App { hwnd, ui, frame: None }));
        title_theme(hwnd);
        SetTimer(Some(hwnd), TIMER_STATUS, 1500, None);
        SetTimer(Some(hwnd), TIMER_SPIN, 90, None);
        let _ = ShowWindow(hwnd, SW_SHOW);
        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).as_bool() {
            let _ = TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
}

/// Тёмный заголовок окна в тёмной теме
fn title_theme(hwnd: HWND) {
    gfx::use_theme(true);
    let dark: u32 = gfx::theme().dark as u32;
    unsafe {
        let _ = DwmSetWindowAttribute(hwnd, DWMWINDOWATTRIBUTE(20), &dark as *const u32 as *const _, 4);
    }
}

fn scale(hwnd: HWND) -> f32 {
    unsafe { GetDpiForWindow(hwnd).max(96) as f32 / 96.0 }
}

fn invalidate(hwnd: HWND) {
    unsafe {
        let _ = InvalidateRect(Some(hwnd), None, false);
    }
}

fn refresh(a: &mut App) {
    let procs = sys::processes();
    for (i, app) in APPS.iter().enumerate() {
        a.ui.st[i] = apps::status(app, &procs);
    }
    a.ui.pending.retain(|p| apps::busy(apps::owner(p.0)));
}

fn paint(a: &mut App, hdc: HDC) {
    let mut r = RECT::default();
    unsafe {
        let _ = GetClientRect(a.hwnd, &mut r);
    }
    let (w, h) = (r.right, r.bottom);
    if w <= 0 || h <= 0 {
        return;
    }
    if a.frame.as_ref().is_none_or(|f| f.w != w || f.h != h) {
        a.frame = Surface::new(w, h);
    }
    let s = scale(a.hwnd);
    // прокрутка не дальше конца страницы
    let max = (a.ui.content_h - h as f32 / s).max(0.0);
    a.ui.scroll = a.ui.scroll.clamp(0.0, max);
    let Some(frame) = a.frame.as_ref() else { return };
    let data = unsafe { frame.pixels() };
    if let Some(mut pm) = PixmapMut::from_bytes(data, w as u32, h as u32) {
        a.ui.compose(&mut pm, w as f32, h as f32, s);
    }
    unsafe {
        let _ = BitBlt(hdc, 0, 0, w, h, Some(frame.dc), 0, 0, SRCCOPY);
    }
}

static MUTEX: std::sync::atomic::AtomicIsize = std::sync::atomic::AtomicIsize::new(0);

fn spot_file() -> std::path::PathBuf {
    sys::local("MacSpotlight").join("settings.txt")
}

/// Меню выбора под курсором (город, время); текущий вариант отмечен
fn popup(hwnd: HWND, items: &[&str], current: &str) -> Option<usize> {
    unsafe {
        let m = CreatePopupMenu().ok()?;
        for (k, t) in items.iter().enumerate() {
            let flags = if *t == current { MF_STRING | MF_CHECKED } else { MF_STRING };
            let w = win::wide(t);
            let _ = AppendMenuW(m, flags, k + 1, win::pcwstr(&w));
        }
        let p = win::cursor();
        let cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, p.x, p.y, Some(0), hwnd, None).0 as usize;
        let _ = DestroyMenu(m);
        (cmd > 0).then(|| cmd - 1)
    }
}

/// Выбор папки (окно Windows «Выбор папки»)
fn pick_folder(owner: HWND) -> Option<String> {
    use windows::Win32::System::Com::*;
    use windows::Win32::UI::Shell::*;
    unsafe {
        let d: IFileOpenDialog = CoCreateInstance(&FileOpenDialog, None, CLSCTX_INPROC_SERVER).ok()?;
        let opts = d.GetOptions().ok()?;
        d.SetOptions(opts | FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM).ok()?;
        let _ = d.SetTitle(w!("Папка с картинками для обоев"));
        d.Show(Some(owner)).ok()?;
        let item = d.GetResult().ok()?;
        let p = item.GetDisplayName(SIGDN_FILESYSPATH).ok()?;
        let s = p.to_string().ok();
        CoTaskMemFree(Some(p.0 as *const _));
        s
    }
}

fn confirm(hwnd: HWND, text: &str) -> bool {
    let t = win::wide(text);
    unsafe { MessageBoxW(Some(hwnd), win::pcwstr(&t), w!("Центр Mac"), MB_YESNO | MB_ICONQUESTION) == IDYES }
}

/// Нажатие на кнопку, переключатель или раздел
fn act(hwnd: HWND, a: Act) {
    let set_page = |p: Page| {
        with(|x| {
            x.ui.page = p;
            x.ui.scroll = 0.0;
        });
    };
    match a {
        Act::Nav(p) => {
            // миниатюры обоев рисуем при первом заходе на «Оформление»
            if p == Page::Look && with(|x| x.ui.scenes.is_none()).unwrap_or(false) {
                let thumbs = ui::scene_thumbs();
                with(|x| x.ui.scenes = Some(thumbs));
            }
            set_page(p);
        }
        Act::Toggle(o) => {
            let now = with(|x| x.ui.pending.iter().find(|p| p.0 == o).map_or_else(|| apps::get(o), |p| p.1)).unwrap_or(false);
            let i = apps::owner(o);
            if apps::busy(i) {
                return;
            }
            with(|x| x.ui.pending.push((o, !now)));
            apps::spawn(i, move || {
                apps::set(o, !now);
                true
            });
        }
        Act::Power(i) => {
            let running = with(|x| x.ui.st[i].running).unwrap_or(false);
            if let Some(o) = apps::options(i).iter().find(|o| matches!(o.opt, apps::Opt::Autostart(_))).map(|o| o.opt) {
                with(|x| x.ui.pending.push((o, !running)));
            }
            apps::spawn(i, move || {
                if running {
                    apps::stop(i);
                    apps::set(apps::Opt::Autostart(i), false);
                } else {
                    apps::set(apps::Opt::Autostart(i), true);
                    apps::start(i, true);
                    std::thread::sleep(std::time::Duration::from_millis(600));
                }
                true
            });
        }
        Act::Open(i) => apps::open(i),
        Act::Restart(i) => apps::spawn(i, move || {
            apps::stop(i);
            apps::start(i, true);
            std::thread::sleep(std::time::Duration::from_millis(600));
            true
        }),
        Act::Stop(i) => apps::spawn(i, move || {
            apps::stop(i);
            true
        }),
        Act::Install(i) => {
            let keep = if APPS[i].id == "MacFinder" && apps::installed(&APPS[i]) {
                !sys::finder_mod()
            } else {
                with(|x| x.ui.keep_explorer).unwrap_or(true)
            };
            apps::spawn(i, move || apps::install(i, keep));
        }
        Act::Remove(i) => {
            let text = format!("Удалить {} ({})?\n\nНастройки, снимки и записи останутся на диске.", APPS[i].title, APPS[i].id);
            if confirm(hwnd, &text) {
                apps::spawn(i, move || apps::uninstall(i));
            }
        }
        Act::Next => {
            if let Some(d) = seen_file().parent() {
                let _ = std::fs::create_dir_all(d);
            }
            let _ = std::fs::write(seen_file(), b"1");
            let all = with(|x| x.ui.st.iter().all(|s| s.installed && s.current)).unwrap_or(false);
            set_page(if all { Page::Home } else { Page::Setup });
        }
        Act::Pick(i) => {
            with(|x| x.ui.pick[i] = !x.ui.pick[i]);
        }
        Act::Explorer => {
            with(|x| x.ui.keep_explorer = !x.ui.keep_explorer);
        }
        Act::Go => {
            let Some((list, keep)) = with(|x| ((0..5).filter(|&i| x.ui.pick[i]).collect::<Vec<_>>(), x.ui.keep_explorer)) else { return };
            set_page(Page::Progress);
            apps::install_many(list, keep);
        }
        Act::Later => set_page(Page::Home),
        Act::Finish => {
            if let Ok(mut g) = apps::JOBS.lock() {
                for j in g.iter_mut() {
                    if matches!(j, Some(Job::Done | Job::Failed)) {
                        *j = None;
                    }
                }
            }
            set_page(Page::Home);
        }
        Act::UpdateAll => {
            let list: Vec<usize> = with(|x| (0..5).filter(|&i| apps::has_payload(&APPS[i]) && !(x.ui.st[i].installed && x.ui.st[i].current)).collect())
                .unwrap_or_default();
            if list.is_empty() {
                return;
            }
            let finder = &APPS[2];
            let keep = if apps::installed(finder) { !sys::finder_mod() } else { with(|x| x.ui.keep_explorer).unwrap_or(true) };
            set_page(Page::Progress);
            apps::install_many(list, keep);
        }
        Act::RemoveAll => {
            if !confirm(hwnd, "Удалить все программы комплекта?\n\nПроводник и смена раскладки по Win+Пробел вернутся как были.") {
                return;
            }
            let list: Vec<usize> = (0..5).filter(|&i| apps::installed(&APPS[i])).collect();
            if let Ok(mut g) = apps::JOBS.lock() {
                for &i in &list {
                    g[i] = Some(Job::Waiting);
                }
            }
            std::thread::spawn(move || {
                for i in list {
                    apps::set_job(i, Some(Job::Working));
                    let ok = apps::uninstall(i);
                    apps::set_job(i, if ok { None } else { Some(Job::Failed) });
                }
            });
        }
        Act::Url(u) => sys::open(u),
        Act::Log => {
            let f = sys::local("MacCenter").join("center.log");
            if !f.exists() {
                sys::log("журнал создан");
            }
            sys::open(&f.to_string_lossy());
        }
        Act::Programs => sys::open(&sys::local("Programs").to_string_lossy()),
        Act::Spot(key, value) => apps::spot(key, value.to_string()),
        Act::Menu(kind) => {
            let (items, current, key): (Vec<&'static str>, String, &'static str) = match kind {
                ui::Menu::City => (
                    sun::CITIES.iter().map(|c| c.name).collect(),
                    sun::city(&sys::kv_get(&spot_file(), "city").unwrap_or_default()).name.to_string(),
                    "city",
                ),
                ui::Menu::Light => (ui::LIGHT_TIMES.to_vec(), sys::kv_get(&spot_file(), "light").unwrap_or_else(|| "07:00".into()), "light"),
                ui::Menu::Dark => (ui::DARK_TIMES.to_vec(), sys::kv_get(&spot_file(), "dark").unwrap_or_else(|| "20:00".into()), "dark"),
            };
            if let Some(k) = popup(hwnd, &items, &current) {
                apps::spot(key, items[k].to_string());
            }
        }
        Act::PickFolder => {
            if let Some(dir) = pick_folder(hwnd) {
                apps::spot("wall_dir", dir);
            }
        }
        Act::Tweak(tw) => {
            let now = tweaks::get(tw);
            tweaks::set(tw, !now);
            let explorer = tweaks::list(true).iter().any(|t| t.tw == tw && t.explorer);
            if explorer {
                with(|x| x.ui.explorer_dirty = true);
            }
        }
        Act::RestartExplorer => {
            with(|x| x.ui.explorer_dirty = false);
            std::thread::spawn(tweaks::restart_explorer);
        }
        Act::Export => {
            if let Some(p) = backup::ask_save(hwnd) {
                let note = match backup::export(&p) {
                    Ok(n) => format!("Сохранено: {} (настроек программ: {n})", p.file_name().map(|f| f.to_string_lossy().to_string()).unwrap_or_default()),
                    Err(e) => format!("Не сохранилось: {e}"),
                };
                with(|x| x.ui.note = Some(note));
            }
        }
        Act::Import => {
            if let Some(p) = backup::ask_open(hwnd) {
                if confirm(hwnd, "Загрузить настройки из файла?\n\nНастройки программ и твики заменятся, работающие программы перезапустятся.") {
                    let note = match backup::import(&p) {
                        Ok(s) => format!("Загружено. {s}"),
                        Err(e) => format!("Не загрузилось: {e}"),
                    };
                    with(|x| {
                        x.ui.note = Some(note);
                        x.ui.explorer_dirty = true;
                    });
                }
            }
        }
        Act::CheckUpdate => {
            let found = match update::find_newer() {
                Some((p, s)) => ui::Found::Newer(p, s),
                None => ui::Found::Nothing,
            };
            with(|x| x.ui.found = Some(found));
        }
        Act::RunUpdate => {
            let path = with(|x| match &x.ui.found {
                Some(ui::Found::Newer(p, _)) => Some(p.clone()),
                _ => None,
            })
            .flatten();
            if let Some(p) = path {
                // новая копия откроется сама; наша блокировка «один экземпляр» ей не помешает
                let m = MUTEX.swap(0, Ordering::Relaxed);
                if m != 0 {
                    unsafe {
                        let _ = CloseHandle(HANDLE(m as *mut _));
                    }
                }
                sys::launch(&p, "");
                unsafe {
                    let _ = DestroyWindow(hwnd);
                }
                return;
            }
        }
        Act::InstallCenter => {
            apps::install_self();
            with(|x| x.ui.note = Some("«Центр Mac» в «Пуске» обновлён до этой версии".into()));
        }
    }
    with(|x| refresh(x));
    invalidate(hwnd);
}

fn point(lp: LPARAM, s: f32) -> (f32, f32) {
    (((lp.0 & 0xFFFF) as i16) as f32 / s, ((lp.0 >> 16 & 0xFFFF) as i16) as f32 / s)
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_PAINT => {
            let mut ps = PAINTSTRUCT::default();
            let hdc = BeginPaint(hwnd, &mut ps);
            let done = with(|a| paint(a, hdc)).is_some();
            let _ = EndPaint(hwnd, &ps);
            if !done {
                invalidate(hwnd);
            }
            LRESULT(0)
        }
        WM_ERASEBKGND => LRESULT(1),
        WM_SIZE => {
            invalidate(hwnd);
            LRESULT(0)
        }
        WM_GETMINMAXINFO => {
            let mm = &mut *(lp.0 as *mut MINMAXINFO);
            let s = scale(hwnd);
            mm.ptMinTrackSize = POINT { x: (900.0 * s) as i32, y: (600.0 * s) as i32 };
            LRESULT(0)
        }
        WM_MOUSEMOVE => {
            let p = point(lp, scale(hwnd));
            let changed = with(|a| {
                let h = a.ui.hit(p.0, p.1);
                std::mem::replace(&mut a.ui.hover, h) != h
            })
            .unwrap_or(false);
            let hand = with(|a| a.ui.hover.is_some()).unwrap_or(false);
            let _ = SetCursor(LoadCursorW(None, if hand { IDC_HAND } else { IDC_ARROW }).ok());
            let mut tme = TRACKMOUSEEVENT { cbSize: std::mem::size_of::<TRACKMOUSEEVENT>() as u32, dwFlags: TME_LEAVE, hwndTrack: hwnd, dwHoverTime: 0 };
            let _ = TrackMouseEvent(&mut tme);
            if changed {
                invalidate(hwnd);
            }
            LRESULT(0)
        }
        WM_SETCURSOR if (lp.0 & 0xFFFF) as u32 == HTCLIENT => LRESULT(1),
        WM_MOUSELEAVE => {
            with(|a| a.ui.hover = None);
            invalidate(hwnd);
            LRESULT(0)
        }
        WM_LBUTTONUP => {
            let p = point(lp, scale(hwnd));
            if let Some(a) = with(|a| a.ui.hit(p.0, p.1)).flatten() {
                act(hwnd, a);
            }
            LRESULT(0)
        }
        WM_MOUSEWHEEL => {
            let delta = ((wp.0 >> 16) & 0xFFFF) as i16 as f32 / 120.0;
            with(|a| a.ui.scroll -= delta * 60.0);
            invalidate(hwnd);
            LRESULT(0)
        }
        WM_TIMER => {
            match wp.0 {
                TIMER_STATUS => {
                    let changed = with(|a| {
                        let before = a.ui.st;
                        refresh(a);
                        before != a.ui.st
                    })
                    .unwrap_or(false);
                    if changed {
                        invalidate(hwnd);
                    }
                }
                TIMER_SPIN => {
                    if (0..5).any(apps::busy) {
                        with(|a| a.ui.tick = a.ui.tick.wrapping_add(1));
                        invalidate(hwnd);
                    }
                }
                _ => {}
            }
            LRESULT(0)
        }
        apps::WM_JOBS => {
            with(|a| refresh(a));
            invalidate(hwnd);
            LRESULT(0)
        }
        WM_SETTINGCHANGE => {
            gfx::load_themes();
            title_theme(hwnd);
            invalidate(hwnd);
            LRESULT(0)
        }
        WM_DPICHANGED => {
            let r = &*(lp.0 as *const RECT);
            let _ = SetWindowPos(hwnd, None, r.left, r.top, r.right - r.left, r.bottom - r.top, SWP_NOZORDER | SWP_NOACTIVATE);
            LRESULT(0)
        }
        WM_DESTROY => {
            PostQuitMessage(0);
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

/// mac-center.exe --preview welcome|setup|progress|home|app:N|system out.png [наведение]
fn preview(args: &[String]) {
    let kind = args.first().cloned().unwrap_or_else(|| "home".into());
    let out = args.get(1).cloned().unwrap_or_else(|| "preview.png".into());
    if std::env::var("MAC_DARK").is_ok() {
        gfx::force_dark();
    }
    let Some(mut ui) = new_ui(sys::os()) else { return };
    ui.page = match kind.as_str() {
        "welcome" => Page::Welcome,
        "setup" => Page::Setup,
        "progress" => Page::Progress,
        "system" => Page::System,
        "look" => Page::Look,
        "windows" => Page::Windows,
        "tweaks" => Page::Tweaks,
        k if k.starts_with("app:") => Page::App(k[4..].parse().unwrap_or(0)),
        _ => Page::Home,
    };
    if kind == "progress" {
        if let Ok(mut g) = apps::JOBS.lock() {
            *g = [Some(Job::Done), Some(Job::Done), Some(Job::Working), Some(Job::Waiting), Some(Job::Waiting)];
        }
        ui.tick = 3;
    }
    if ui.page == Page::Look {
        ui.scenes = Some(ui::scene_thumbs());
    }
    let (w, h, s) = (1100u32, 740u32, 1.0);
    let mut img = gfx::Img::new(w, h);
    // первый проход — раскладка и зоны, второй — с наведением на первую кнопку
    for pass in 0..2 {
        if let Some(mut pm) = img.pixmap_mut() {
            ui.compose(&mut pm, w as f32, h as f32, s);
        }
        if pass == 0 {
            ui.hover = args.get(2).and_then(|_| ui.zones.iter().rev().find(|z| matches!(z.1, Act::Toggle(_) | Act::Power(_))).map(|z| z.1));
        }
    }
    if let Some(png) = win::encode_png(&img) {
        let _ = std::fs::write(out, png);
    }
}

/// mac-center.exe --selftest out.txt [--reinstall-shot]: что внутри exe, состояние программ,
/// запись настроек; с ключом — настоящая переустановка MacShot (без прав администратора)
fn selftest(reinstall: bool) -> String {
    let os = sys::os();
    let mut out = format!("система: {} {} сборка {}.{}, Windows 11: {}, поддерживается: {}\n", os.name, os.version, os.build, os.ubr, os.win11, os.supported);
    out += &format!("пользователь: «{}», приветствие: {}\n", sys::user_name(), sys::greeting());
    let procs = sys::processes();
    for (i, a) in APPS.iter().enumerate() {
        let st = apps::status(a, &procs);
        let opts: Vec<String> = apps::options(i).iter().map(|o| format!("{}={}", o.title, apps::get(o.opt) as u8)).collect();
        out += &format!(
            "{}: внутри {}, стоит {}, свежая {}, работает {}, автозапуск {}\n  {}\n",
            a.id,
            apps::has_payload(a),
            st.installed,
            st.current,
            st.running,
            st.autostart,
            opts.join("; ")
        );
    }
    let tmp = std::env::temp_dir().join("MacCenter").join("kv-test.txt");
    let _ = std::fs::create_dir_all(tmp.parent().unwrap());
    let _ = std::fs::write(&tmp, "tray=1\nhinted=1\npos=1,2,3,4\n");
    sys::kv_set(&tmp, "tray", "0");
    sys::kv_set(&tmp, "muted", "1");
    out += &format!("файл настроек: {:?}\n", std::fs::read_to_string(&tmp).unwrap_or_default());
    let _ = std::fs::remove_file(&tmp);
    out += &format!("Windhawk: {}, мод Finder: {}\n", sys::windhawk_installed(), sys::finder_mod());
    out += &format!(
        "метка сборки: {} ({}), в своём exe: {:?}\n",
        update::stamp(),
        update::pretty(update::stamp()),
        std::env::current_exe().ok().and_then(|p| update::stamp_of(&p))
    );
    out += &format!("метка у чужого exe: {:?}\n", update::stamp_of(&sys::local("Programs").join("MacSpotlight").join("mac-spotlight.exe")));
    out += &format!("новее рядом: {:?}\n", update::find_newer().map(|f| f.1));
    let tw: Vec<String> = tweaks::ALL.iter().map(|t| format!("{}={}", tweaks::name(*t), tweaks::get(*t) as u8)).collect();
    out += &format!("твики: {}\n", tw.join(" "));
    let bk = std::env::temp_dir().join("MacCenter").join("backup-test.macsettings");
    match backup::export(&bk) {
        Ok(n) => {
            let text = std::fs::read_to_string(&bk).unwrap_or_default();
            out += &format!("перенос: файлов {n}, строк {}, есть место окна или прежние обои: {}\n", text.lines().count(), text.contains("pos=") || text.contains("wall_prev"));
        }
        Err(e) => out += &format!("перенос: ошибка {e}\n"),
    }
    let _ = std::fs::remove_file(&bk);
    if reinstall {
        let i = 0;
        let t = std::time::Instant::now();
        let ok = apps::install(i, true);
        std::thread::sleep(std::time::Duration::from_millis(1500));
        let st = apps::status(&APPS[i], &sys::processes());
        out += &format!("переустановка MacShot: {ok} за {:.1} с, стоит {}, свежая {}, работает {}\n", t.elapsed().as_secs_f32(), st.installed, st.current, st.running);
    }
    out
}
