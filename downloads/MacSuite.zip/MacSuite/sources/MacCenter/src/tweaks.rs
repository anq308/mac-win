//! Твики Windows: одна кнопка — улучшение, вторая — вернуть как было в Windows.
//! Всё в настройках текущего пользователя (HKCU) и системных параметрах, права администратора не нужны.

use windows::core::PCWSTR;
use windows::Win32::System::Registry::*;
use windows::Win32::UI::Accessibility::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::win::{pcwstr, wide};

#[derive(Clone, Copy, PartialEq, Debug)]
pub enum Tw {
    StickyKeys,
    MouseAccel,
    GameDvr,
    StartAds,
    BingSearch,
    Extensions,
    Hidden,
    ClassicMenu,
    FastMenus,
    Seconds,
}

pub struct Info {
    pub tw: Tw,
    pub title: &'static str,
    pub sub: &'static str,
    /// вступит в силу после перезапуска Проводника
    pub explorer: bool,
}

pub fn list(win11: bool) -> Vec<Info> {
    let i = |tw, title, sub, explorer| Info { tw, title, sub, explorer };
    let mut v = vec![
        i(Tw::StickyKeys, "Без залипания клавиш", "Окно после пяти нажатий Shift больше не выскакивает посреди игры", false),
        i(Tw::MouseAccel, "Без ускорения мыши", "«Повышенная точность указателя» выключена: прицел двигается ровно за рукой", false),
        i(Tw::GameDvr, "Без фоновой записи Xbox Game Bar", "Меньше нагрузки в играх; снимки Win+Alt+PrtSc отключатся", false),
        i(Tw::StartAds, "Без рекламы и советов в «Пуске»", "Не предлагать приложения и не ставить их без спроса", true),
        i(Tw::BingSearch, "Поиск без Bing", "Поиск Windows ищет только на компьютере", true),
        i(Tw::Extensions, "Показывать расширения файлов", "«фото.jpg» вместо «фото» — видно, что это за файл", false),
        i(Tw::Hidden, "Показывать скрытые файлы", "В Проводнике и окнах «Открыть» видны скрытые папки", false),
        i(Tw::FastMenus, "Быстрые меню и окна", "Меню открываются сразу, окна сворачиваются без анимации", false),
        i(Tw::Seconds, "Секунды в часах на панели задач", "Часы в углу показывают и секунды", true),
    ];
    if win11 {
        v.push(i(Tw::ClassicMenu, "Классическое контекстное меню", "Сразу полное меню по правому щелчку, без «Показать дополнительные параметры»", true));
    }
    v
}

// ---------- реестр ----------

fn get_dword(path: &str, name: &str) -> Option<u32> {
    let (p, n) = (wide(path), wide(name));
    let mut v = 0u32;
    let mut size = 4u32;
    unsafe { RegGetValueW(HKEY_CURRENT_USER, pcwstr(&p), pcwstr(&n), RRF_RT_REG_DWORD, None, Some(&mut v as *mut u32 as *mut _), Some(&mut size)).ok().ok()? };
    Some(v)
}

fn set_dword(path: &str, name: &str, v: u32) {
    let (p, n) = (wide(path), wide(name));
    unsafe {
        let _ = RegSetKeyValueW(HKEY_CURRENT_USER, pcwstr(&p), pcwstr(&n), REG_DWORD.0, Some(&v as *const u32 as *const _), 4);
    }
}

fn delete_value(path: &str, name: &str) {
    let (p, n) = (wide(path), wide(name));
    unsafe {
        let _ = RegDeleteKeyValueW(HKEY_CURRENT_USER, pcwstr(&p), pcwstr(&n));
    }
}

fn get_sz(path: &str, name: &str) -> Option<String> {
    let (p, n) = (wide(path), wide(name));
    let mut buf = [0u16; 128];
    let mut size = (buf.len() * 2) as u32;
    let name_ptr = if name.is_empty() { PCWSTR::null() } else { pcwstr(&n) };
    unsafe { RegGetValueW(HKEY_CURRENT_USER, pcwstr(&p), name_ptr, RRF_RT_REG_SZ, None, Some(buf.as_mut_ptr() as *mut _), Some(&mut size)).ok().ok()? };
    let len = buf.iter().position(|c| *c == 0).unwrap_or(0);
    Some(String::from_utf16_lossy(&buf[..len]))
}

fn set_sz(path: &str, name: &str, v: &str) {
    let (p, n, d) = (wide(path), wide(name), wide(v));
    let name_ptr = if name.is_empty() { PCWSTR::null() } else { pcwstr(&n) };
    unsafe {
        let _ = RegSetKeyValueW(HKEY_CURRENT_USER, pcwstr(&p), name_ptr, REG_SZ.0, Some(d.as_ptr() as *const _), (d.len() * 2) as u32);
    }
}

const ADV: &str = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced";
const CDM: &str = "Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager";
const ADS: [&str; 7] = [
    "SystemPaneSuggestionsEnabled",
    "SubscribedContent-338388Enabled",
    "SubscribedContent-338389Enabled",
    "SubscribedContent-353694Enabled",
    "SubscribedContent-353696Enabled",
    "SilentInstalledAppsEnabled",
    "SoftLandingEnabled",
];
const CLASSIC: &str = "Software\\Classes\\CLSID\\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}";

fn sticky() -> (STICKYKEYS, FILTERKEYS, TOGGLEKEYS) {
    let mut s = STICKYKEYS { cbSize: std::mem::size_of::<STICKYKEYS>() as u32, ..Default::default() };
    let mut f = FILTERKEYS { cbSize: std::mem::size_of::<FILTERKEYS>() as u32, ..Default::default() };
    let mut t = TOGGLEKEYS { cbSize: std::mem::size_of::<TOGGLEKEYS>() as u32, ..Default::default() };
    unsafe {
        let _ = SystemParametersInfoW(SPI_GETSTICKYKEYS, s.cbSize, Some(&mut s as *mut _ as *mut _), SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS(0));
        let _ = SystemParametersInfoW(SPI_GETFILTERKEYS, f.cbSize, Some(&mut f as *mut _ as *mut _), SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS(0));
        let _ = SystemParametersInfoW(SPI_GETTOGGLEKEYS, t.cbSize, Some(&mut t as *mut _ as *mut _), SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS(0));
    }
    (s, f, t)
}

/// FKF_HOTKEYACTIVE и TKF_HOTKEYACTIVE — тот же бит, что у залипания
const HOTKEY_ACTIVE: u32 = 4;

const SAVE: SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS = SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS(SPIF_UPDATEINIFILE.0 | SPIF_SENDCHANGE.0);

/// Включено ли улучшение
pub fn get(tw: Tw) -> bool {
    match tw {
        Tw::StickyKeys => {
            let (s, f, t) = sticky();
            s.dwFlags.0 & SKF_HOTKEYACTIVE.0 == 0 && f.dwFlags & HOTKEY_ACTIVE == 0 && t.dwFlags & HOTKEY_ACTIVE == 0
        }
        Tw::MouseAccel => {
            let mut m = [0i32; 3];
            unsafe {
                let _ = SystemParametersInfoW(SPI_GETMOUSE, 0, Some(m.as_mut_ptr() as *mut _), SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS(0));
            }
            m[2] == 0
        }
        Tw::GameDvr => get_dword("System\\GameConfigStore", "GameDVR_Enabled") == Some(0),
        Tw::StartAds => get_dword(CDM, ADS[0]) == Some(0) && get_dword(CDM, ADS[1]) == Some(0),
        Tw::BingSearch => get_dword("Software\\Microsoft\\Windows\\CurrentVersion\\Search", "BingSearchEnabled") == Some(0),
        Tw::Extensions => get_dword(ADV, "HideFileExt") == Some(0),
        Tw::Hidden => get_dword(ADV, "Hidden") == Some(1),
        Tw::FastMenus => get_sz("Control Panel\\Desktop", "MenuShowDelay").and_then(|v| v.parse::<u32>().ok()).is_some_and(|v| v <= 150),
        Tw::Seconds => get_dword(ADV, "ShowSecondsInSystemClock") == Some(1),
        Tw::ClassicMenu => get_sz(&format!("{CLASSIC}\\InprocServer32"), "").is_some(),
    }
}

pub fn set(tw: Tw, on: bool) {
    match tw {
        Tw::StickyKeys => {
            let (mut s, mut f, mut t) = sticky();
            let flip = |flags: &mut u32, bit: u32| if on { *flags &= !bit } else { *flags |= bit };
            flip(&mut s.dwFlags.0, SKF_HOTKEYACTIVE.0);
            flip(&mut f.dwFlags, HOTKEY_ACTIVE);
            flip(&mut t.dwFlags, HOTKEY_ACTIVE);
            unsafe {
                let _ = SystemParametersInfoW(SPI_SETSTICKYKEYS, s.cbSize, Some(&mut s as *mut _ as *mut _), SAVE);
                let _ = SystemParametersInfoW(SPI_SETFILTERKEYS, f.cbSize, Some(&mut f as *mut _ as *mut _), SAVE);
                let _ = SystemParametersInfoW(SPI_SETTOGGLEKEYS, t.cbSize, Some(&mut t as *mut _ as *mut _), SAVE);
            }
        }
        Tw::MouseAccel => {
            // в Windows по умолчанию: пороги 6 и 10, ускорение 1
            let mut m: [i32; 3] = if on { [0, 0, 0] } else { [6, 10, 1] };
            unsafe {
                let _ = SystemParametersInfoW(SPI_SETMOUSE, 0, Some(m.as_mut_ptr() as *mut _), SAVE);
            }
        }
        Tw::GameDvr => {
            set_dword("System\\GameConfigStore", "GameDVR_Enabled", !on as u32);
            set_dword("Software\\Microsoft\\Windows\\CurrentVersion\\GameDVR", "AppCaptureEnabled", !on as u32);
        }
        Tw::StartAds => {
            for a in ADS {
                set_dword(CDM, a, !on as u32);
            }
            set_dword(ADV, "Start_IrisRecommendations", !on as u32);
            set_dword(ADV, "Start_AccountNotifications", !on as u32);
        }
        Tw::BingSearch => {
            set_dword("Software\\Microsoft\\Windows\\CurrentVersion\\Search", "BingSearchEnabled", !on as u32);
            set_dword("Software\\Microsoft\\Windows\\CurrentVersion\\Search", "CortanaConsent", !on as u32);
            if on {
                set_dword("Software\\Policies\\Microsoft\\Windows\\Explorer", "DisableSearchBoxSuggestions", 1);
            } else {
                delete_value("Software\\Policies\\Microsoft\\Windows\\Explorer", "DisableSearchBoxSuggestions");
            }
        }
        Tw::Extensions => set_dword(ADV, "HideFileExt", !on as u32),
        Tw::Hidden => set_dword(ADV, "Hidden", if on { 1 } else { 2 }),
        Tw::FastMenus => {
            let delay = if on { 100 } else { 400 };
            set_sz("Control Panel\\Desktop", "MenuShowDelay", &delay.to_string());
            let mut anim = ANIMATIONINFO { cbSize: std::mem::size_of::<ANIMATIONINFO>() as u32, iMinAnimate: (!on) as i32 };
            unsafe {
                let _ = SystemParametersInfoW(SPI_SETMENUSHOWDELAY, delay, None, SAVE);
                let _ = SystemParametersInfoW(SPI_SETANIMATION, anim.cbSize, Some(&mut anim as *mut _ as *mut _), SAVE);
            }
        }
        Tw::Seconds => set_dword(ADV, "ShowSecondsInSystemClock", on as u32),
        Tw::ClassicMenu => {
            if on {
                set_sz(&format!("{CLASSIC}\\InprocServer32"), "", "");
            } else {
                let p = wide(CLASSIC);
                unsafe {
                    let _ = RegDeleteTreeW(HKEY_CURRENT_USER, pcwstr(&p));
                }
            }
        }
    }
    // Проводник и окна «Открыть» перечитывают настройки вида
    unsafe {
        windows::Win32::UI::Shell::SHChangeNotify(windows::Win32::UI::Shell::SHCNE_ASSOCCHANGED, windows::Win32::UI::Shell::SHCNF_IDLIST, None, None);
        let msg = wide("ShellState");
        let _ = SendMessageTimeoutW(HWND_BROADCAST, WM_SETTINGCHANGE, windows::Win32::Foundation::WPARAM(0), windows::Win32::Foundation::LPARAM(msg.as_ptr() as isize), SMTO_ABORTIFHUNG, 300, None);
    }
}

/// Перезапуск Проводника — чтобы применились «Пуск», поиск, часы и контекстное меню
pub fn restart_explorer() {
    crate::sys::kill("explorer.exe");
    std::thread::sleep(std::time::Duration::from_millis(800));
    if !crate::sys::processes().iter().any(|p| p == "explorer.exe") {
        crate::sys::launch(std::path::Path::new("explorer.exe"), "");
    }
}

pub const ALL: [Tw; 10] = [
    Tw::StickyKeys,
    Tw::MouseAccel,
    Tw::GameDvr,
    Tw::StartAds,
    Tw::BingSearch,
    Tw::Extensions,
    Tw::Hidden,
    Tw::FastMenus,
    Tw::Seconds,
    Tw::ClassicMenu,
];

pub fn name(tw: Tw) -> String {
    format!("{tw:?}")
}
