#![allow(dead_code)]
//! Положение солнца, восход и закат для города — без интернета, по формулам NOAA.
//! Общий файл: им пользуются MacSpotlight (смена темы и обоев) и «Центр Mac» (настройки)

use std::time::{SystemTime, UNIX_EPOCH};

pub struct City {
    pub name: &'static str,
    pub lat: f64,
    pub lon: f64,
    /// часовой пояс в минутах от UTC — по нему выбираем город по умолчанию
    pub tz: i32,
}

pub const CITIES: [City; 26] = [
    City { name: "Москва", lat: 55.75, lon: 37.62, tz: 180 },
    City { name: "Санкт-Петербург", lat: 59.94, lon: 30.31, tz: 180 },
    City { name: "Нижний Новгород", lat: 56.33, lon: 44.0, tz: 180 },
    City { name: "Казань", lat: 55.79, lon: 49.12, tz: 180 },
    City { name: "Воронеж", lat: 51.67, lon: 39.18, tz: 180 },
    City { name: "Ростов-на-Дону", lat: 47.23, lon: 39.72, tz: 180 },
    City { name: "Краснодар", lat: 45.04, lon: 38.98, tz: 180 },
    City { name: "Волгоград", lat: 48.71, lon: 44.51, tz: 180 },
    City { name: "Калининград", lat: 54.71, lon: 20.51, tz: 120 },
    City { name: "Самара", lat: 53.2, lon: 50.15, tz: 240 },
    City { name: "Уфа", lat: 54.74, lon: 55.97, tz: 300 },
    City { name: "Пермь", lat: 58.01, lon: 56.25, tz: 300 },
    City { name: "Екатеринбург", lat: 56.84, lon: 60.6, tz: 300 },
    City { name: "Челябинск", lat: 55.16, lon: 61.4, tz: 300 },
    City { name: "Омск", lat: 54.99, lon: 73.37, tz: 360 },
    City { name: "Новосибирск", lat: 55.03, lon: 82.92, tz: 420 },
    City { name: "Красноярск", lat: 56.01, lon: 92.85, tz: 420 },
    City { name: "Иркутск", lat: 52.29, lon: 104.28, tz: 480 },
    City { name: "Хабаровск", lat: 48.48, lon: 135.08, tz: 600 },
    City { name: "Владивосток", lat: 43.12, lon: 131.89, tz: 600 },
    City { name: "Минск", lat: 53.9, lon: 27.57, tz: 180 },
    City { name: "Киев", lat: 50.45, lon: 30.52, tz: 120 },
    City { name: "Алматы", lat: 43.24, lon: 76.95, tz: 300 },
    City { name: "Астана", lat: 51.17, lon: 71.45, tz: 300 },
    City { name: "Ташкент", lat: 41.3, lon: 69.24, tz: 300 },
    City { name: "Тбилиси", lat: 41.72, lon: 44.79, tz: 240 },
];

/// Смещение местного времени от UTC в минутах (с учётом летнего времени, если оно есть)
pub fn tz_minutes() -> i32 {
    use windows::Win32::System::Time::{GetTimeZoneInformation, TIME_ZONE_INFORMATION};
    let mut tzi = TIME_ZONE_INFORMATION::default();
    let r = unsafe { GetTimeZoneInformation(&mut tzi) };
    let dst = if r == 2 { tzi.DaylightBias } else { 0 };
    -(tzi.Bias + dst)
}

/// Город по названию, а без него — первый в нашем часовом поясе (или Москва)
pub fn city(name: &str) -> &'static City {
    CITIES.iter().find(|c| c.name == name).unwrap_or_else(|| {
        let tz = tz_minutes();
        CITIES.iter().find(|c| c.tz == tz).unwrap_or(&CITIES[0])
    })
}

pub fn now_unix() -> f64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs_f64()).unwrap_or(0.0)
}

/// Высота солнца над горизонтом в градусах в момент t (секунды UTC)
pub fn elevation(t: f64, lat: f64, lon: f64) -> f64 {
    let jd = t / 86400.0 + 2440587.5;
    let jc = (jd - 2451545.0) / 36525.0;
    let l0 = (280.46646 + jc * (36000.76983 + jc * 0.0003032)).rem_euclid(360.0);
    let m = 357.52911 + jc * (35999.05029 - 0.0001537 * jc);
    let e = 0.016708634 - jc * (0.000042037 + 0.0000001267 * jc);
    let mr = m.to_radians();
    let c = mr.sin() * (1.914602 - jc * (0.004817 + 0.000014 * jc)) + (2.0 * mr).sin() * (0.019993 - 0.000101 * jc) + (3.0 * mr).sin() * 0.000289;
    let true_long = l0 + c;
    let omega = 125.04 - 1934.136 * jc;
    let app_long = true_long - 0.00569 - 0.00478 * omega.to_radians().sin();
    let obliq0 = 23.0 + (26.0 + (21.448 - jc * (46.815 + jc * (0.00059 - jc * 0.001813))) / 60.0) / 60.0;
    let obliq = obliq0 + 0.00256 * omega.to_radians().cos();
    let decl = (obliq.to_radians().sin() * app_long.to_radians().sin()).asin();
    let y = (obliq.to_radians() / 2.0).tan().powi(2);
    let l0r = l0.to_radians();
    let eq_time = 4.0
        * (y * (2.0 * l0r).sin() - 2.0 * e * mr.sin() + 4.0 * e * y * mr.sin() * (2.0 * l0r).cos()
            - 0.5 * y * y * (4.0 * l0r).sin()
            - 1.25 * e * e * (2.0 * mr).sin())
        .to_degrees();
    let minutes_utc = (t / 60.0).rem_euclid(1440.0);
    let true_solar = (minutes_utc + eq_time + 4.0 * lon).rem_euclid(1440.0);
    let hour_angle = if true_solar / 4.0 < 0.0 { true_solar / 4.0 + 180.0 } else { true_solar / 4.0 - 180.0 };
    let latr = lat.to_radians();
    let cos_zen = latr.sin() * decl.sin() + latr.cos() * decl.cos() * hour_angle.to_radians().cos();
    90.0 - cos_zen.clamp(-1.0, 1.0).acos().to_degrees()
}

/// Начало местных суток (полночь) для момента t, в секундах UTC
pub fn local_midnight(t: f64) -> f64 {
    let off = tz_minutes() as f64 * 60.0;
    ((t + off) / 86400.0).floor() * 86400.0 - off
}

/// Восход и закат сегодня (секунды UTC); None — полярный день или ночь
pub fn sunrise_sunset(t: f64, lat: f64, lon: f64) -> (Option<f64>, Option<f64>) {
    let start = local_midnight(t);
    let mut rise = None;
    let mut set = None;
    let step = 120.0;
    let mut prev = elevation(start, lat, lon) + 0.833;
    let mut x = start + step;
    while x <= start + 86400.0 {
        let cur = elevation(x, lat, lon) + 0.833;
        if prev < 0.0 && cur >= 0.0 && rise.is_none() {
            rise = Some(x - step * cur / (cur - prev));
        }
        if prev >= 0.0 && cur < 0.0 && set.is_none() {
            set = Some(x - step * cur / (cur - prev));
        }
        prev = cur;
        x += step;
    }
    (rise, set)
}

/// «07:42» — местное время для момента t (секунды UTC)
pub fn clock(t: f64) -> String {
    let local = t + tz_minutes() as f64 * 60.0;
    let m = (local / 60.0).rem_euclid(1440.0) as u32;
    format!("{:02}:{:02}", m / 60, m % 60)
}

/// Минуты от местной полуночи сейчас
pub fn minutes_now() -> u32 {
    let t = now_unix() + tz_minutes() as f64 * 60.0;
    (t / 60.0).rem_euclid(1440.0) as u32
}

/// «07:30» → минуты от полуночи
pub fn parse_hm(s: &str) -> Option<u32> {
    let (h, m) = s.trim().split_once(':')?;
    let (h, m): (u32, u32) = (h.parse().ok()?, m.parse().ok()?);
    (h < 24 && m < 60).then_some(h * 60 + m)
}
