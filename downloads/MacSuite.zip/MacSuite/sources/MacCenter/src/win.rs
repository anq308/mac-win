#![allow(dead_code)]
//! Общие мелочи Win32: буфер кадра, мониторы, строки, картинки из оболочки, тёмные меню

use std::ffi::c_void;
use std::mem::size_of;
use std::path::{Path, PathBuf};

use windows::core::{GUID, PCWSTR, PWSTR};
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::Com::CoTaskMemFree;
use windows::Win32::UI::HiDpi::{GetDpiForMonitor, MDT_EFFECTIVE_DPI};
use windows::Win32::UI::Shell::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::gfx::Img;

fn bitmap_info(w: i32, h: i32) -> BITMAPINFO {
    BITMAPINFO {
        bmiHeader: BITMAPINFOHEADER {
            biSize: size_of::<BITMAPINFOHEADER>() as u32,
            biWidth: w,
            biHeight: -h,
            biPlanes: 1,
            biBitCount: 32,
            biCompression: BI_RGB.0,
            ..Default::default()
        },
        ..Default::default()
    }
}

/// Буфер кадра в памяти: DIB-секция, выбранная в совместимый DC
pub struct Surface {
    pub dc: HDC,
    bmp: HBITMAP,
    old: HGDIOBJ,
    bits: *mut u8,
    pub w: i32,
    pub h: i32,
}

impl Surface {
    pub fn new(w: i32, h: i32) -> Option<Surface> {
        unsafe {
            let screen = GetDC(None);
            let dc = CreateCompatibleDC(Some(screen));
            ReleaseDC(None, screen);
            let bi = bitmap_info(w, h);
            let mut bits: *mut c_void = std::ptr::null_mut();
            let Ok(bmp) = CreateDIBSection(Some(dc), &bi, DIB_RGB_COLORS, &mut bits, None, 0) else {
                let _ = DeleteDC(dc);
                return None;
            };
            if bits.is_null() {
                let _ = DeleteDC(dc);
                return None;
            }
            let old = SelectObject(dc, bmp.into());
            Some(Surface { dc, bmp, old, bits: bits as *mut u8, w, h })
        }
    }

    /// Пиксели без привязки к заимствованию: кадр рисуется, пока читаются соседние поля владельца
    pub unsafe fn pixels<'a>(&self) -> &'a mut [u8] {
        std::slice::from_raw_parts_mut(self.bits, (self.w * self.h * 4) as usize)
    }
}

impl Drop for Surface {
    fn drop(&mut self) {
        unsafe {
            SelectObject(self.dc, self.old);
            let _ = DeleteObject(self.bmp.into());
            let _ = DeleteDC(self.dc);
        }
    }
}

pub struct Monitor {
    pub work: RECT,
    pub scale: f32,
}

pub fn cursor() -> POINT {
    let mut p = POINT::default();
    unsafe {
        let _ = GetCursorPos(&mut p);
    }
    p
}

pub fn monitor_at(p: POINT) -> Monitor {
    unsafe {
        let m = MonitorFromPoint(p, MONITOR_DEFAULTTONEAREST);
        let mut mi = MONITORINFO { cbSize: size_of::<MONITORINFO>() as u32, ..Default::default() };
        let _ = GetMonitorInfoW(m, &mut mi);
        let (mut x, mut y) = (96u32, 96u32);
        let _ = GetDpiForMonitor(m, MDT_EFFECTIVE_DPI, &mut x, &mut y);
        Monitor { work: mi.rcWork, scale: x as f32 / 96.0 }
    }
}

pub fn wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(Some(0)).collect()
}

pub fn wide_path(p: &Path) -> Vec<u16> {
    wide(&p.to_string_lossy())
}

pub fn pcwstr(v: &[u16]) -> PCWSTR {
    PCWSTR(v.as_ptr())
}

pub fn known_folder(id: &GUID) -> Option<PathBuf> {
    unsafe {
        let p: PWSTR = SHGetKnownFolderPath(id, KF_FLAG_DEFAULT, None).ok()?;
        let s = p.to_string().ok();
        CoTaskMemFree(Some(p.0 as *const c_void));
        s.map(PathBuf::from)
    }
}

/// Картинка из оболочки: миниатюра (фото, видео, PDF) или иконка — то же, что показывает проводник
pub fn shell_image(path: &Path, px: u32, icon_only: bool) -> Option<Img> {
    let p = wide_path(path);
    unsafe {
        let f: IShellItemImageFactory = SHCreateItemFromParsingName(pcwstr(&p), None).ok()?;
        let flags = if icon_only { SIIGBF_ICONONLY } else { SIIGBF_RESIZETOFIT };
        let hbm = f.GetImage(SIZE { cx: px as i32, cy: px as i32 }, flags).ok()?;
        let img = bitmap_img(hbm);
        let _ = DeleteObject(hbm.into());
        img
    }
}

/// Мелкий значок из системного списка — как в таблице проводника (16 или 32 точки)
pub fn small_icon(path: &Path, px: u32) -> Option<Img> {
    use windows::Win32::UI::Shell::Common::ITEMIDLIST;
    let p = wide_path(path);
    unsafe {
        let mut pidl: *mut ITEMIDLIST = std::ptr::null_mut();
        SHParseDisplayName(pcwstr(&p), None, &mut pidl, 0, None).ok()?;
        let mut info = SHFILEINFOW::default();
        let size = if px <= 24 { SHGFI_SMALLICON } else { SHGFI_LARGEICON };
        let got = SHGetFileInfoW(
            PCWSTR(pidl as *const u16),
            windows::Win32::Storage::FileSystem::FILE_FLAGS_AND_ATTRIBUTES(0),
            Some(&mut info),
            size_of::<SHFILEINFOW>() as u32,
            SHGFI_PIDL | SHGFI_ICON | size,
        );
        CoTaskMemFree(Some(pidl as *const c_void));
        if got == 0 || info.hIcon.is_invalid() {
            return None;
        }
        let img = icon_img(info.hIcon);
        let _ = DestroyIcon(info.hIcon);
        img
    }
}

/// HICON → картинка; у значков альфа не премультиплицирована — умножаем сами
pub fn icon_img(icon: HICON) -> Option<Img> {
    unsafe {
        let mut ii = ICONINFO::default();
        GetIconInfo(icon, &mut ii).ok()?;
        let free = |ii: &ICONINFO| {
            let _ = DeleteObject(ii.hbmColor.into());
            let _ = DeleteObject(ii.hbmMask.into());
        };
        if ii.hbmColor.is_invalid() {
            free(&ii);
            return None;
        }
        let mut bm = BITMAP::default();
        GetObjectW(ii.hbmColor.into(), size_of::<BITMAP>() as i32, Some(&mut bm as *mut _ as *mut c_void));
        let (w, h) = (bm.bmWidth, bm.bmHeight.abs());
        let mut img = Img::new(w.max(1) as u32, h.max(1) as u32);
        let mut bi = bitmap_info(w, h);
        let dc = GetDC(None);
        let got = GetDIBits(dc, ii.hbmColor, 0, h as u32, Some(img.px.as_mut_ptr() as *mut c_void), &mut bi, DIB_RGB_COLORS);
        ReleaseDC(None, dc);
        free(&ii);
        if got == 0 {
            return None;
        }
        if img.px.chunks_exact(4).all(|p| p[3] == 0) {
            for p in img.px.chunks_exact_mut(4) {
                p[3] = 255;
            }
        }
        for p in img.px.chunks_exact_mut(4) {
            let a = p[3] as u32;
            for c in &mut p[..3] {
                *c = ((*c as u32 * a + 127) / 255) as u8;
            }
        }
        Some(img)
    }
}

fn bitmap_img(hbm: HBITMAP) -> Option<Img> {
    unsafe {
        let mut bm = BITMAP::default();
        if GetObjectW(hbm.into(), size_of::<BITMAP>() as i32, Some(&mut bm as *mut _ as *mut c_void)) == 0 {
            return None;
        }
        let (w, h) = (bm.bmWidth, bm.bmHeight.abs());
        if w <= 0 || h <= 0 {
            return None;
        }
        let mut img = Img::new(w as u32, h as u32);
        let mut bi = bitmap_info(w, h);
        let dc = GetDC(None);
        let got = GetDIBits(dc, hbm, 0, h as u32, Some(img.px.as_mut_ptr() as *mut c_void), &mut bi, DIB_RGB_COLORS);
        ReleaseDC(None, dc);
        if got == 0 {
            return None;
        }
        // у части миниатюр альфы нет вовсе — тогда картинка непрозрачная
        if img.px.chunks_exact(4).all(|p| p[3] == 0) {
            for p in img.px.chunks_exact_mut(4) {
                p[3] = 255;
            }
        } else {
            // оболочка отдаёт премультиплицированные пиксели; страхуемся от цвета ярче альфы
            for p in img.px.chunks_exact_mut(4) {
                let a = p[3];
                for c in &mut p[..3] {
                    *c = (*c).min(a);
                }
            }
        }
        Some(img)
    }
}

/// Текст в буфер обмена
pub fn set_clipboard_text(hwnd: HWND, s: &str) {
    use windows::Win32::System::DataExchange::{CloseClipboard, EmptyClipboard, OpenClipboard, SetClipboardData};
    use windows::Win32::System::Memory::{GlobalAlloc, GlobalLock, GlobalUnlock, GMEM_MOVEABLE};
    const CF_UNICODETEXT: u32 = 13;
    let w = wide(s);
    unsafe {
        if OpenClipboard(Some(hwnd)).is_err() {
            return;
        }
        let _ = EmptyClipboard();
        if let Ok(h) = GlobalAlloc(GMEM_MOVEABLE, w.len() * 2) {
            let p = GlobalLock(h) as *mut u16;
            if !p.is_null() {
                std::ptr::copy_nonoverlapping(w.as_ptr(), p, w.len());
                let _ = GlobalUnlock(h);
                let _ = SetClipboardData(CF_UNICODETEXT, Some(HANDLE(h.0)));
            }
        }
        let _ = CloseClipboard();
    }
}

pub fn encode_png(img: &Img) -> Option<Vec<u8>> {
    let mut rgba = Vec::with_capacity(img.px.len());
    for p in img.px.chunks_exact(4) {
        let a = p[3] as u32;
        let un = |c: u8| if a == 0 { 0 } else { ((c as u32 * 255 + a / 2) / a).min(255) as u8 };
        rgba.extend_from_slice(&[un(p[2]), un(p[1]), un(p[0]), p[3]]);
    }
    let mut out = Vec::new();
    {
        let mut enc = png::Encoder::new(&mut out, img.w, img.h);
        enc.set_color(png::ColorType::Rgba);
        enc.set_depth(png::BitDepth::Eight);
        let mut wr = enc.write_header().ok()?;
        wr.write_image_data(&rgba).ok()?;
    }
    Some(out)
}
