# Центр Mac — исходники

Один exe: приветствие с определением Windows 10 / 11, установка всех пяти программ комплекта
и их настройки в окне, похожем на «Параметры» Windows. Rust, чистый Win32, tiny-skia + ab_glyph.

Программы вшиты в exe при сборке: `build.rs` берёт папки `Приложение` у MacShot, MacMixer,
MacFinder (`MacFinfer2\MacFinder`), MacSpotlight и MacMirror (корень — две папки выше, или `MAC_WIND`).
Поэтому после обновления любой программы центр нужно пересобрать.

## Сборка

```
winget install BrechtSanders.WinLibs.POSIX.UCRT
.\build.ps1          # -> target\release\mac-center.exe (~10 МБ)
```

## Файлы

| Файл | Что внутри |
|---|---|
| `main.rs` | окно, мышь, прокрутка, действия кнопок, самопроверка |
| `ui.rs` | страницы: приветствие, выбор программ, установка, главная, программа, система |
| `apps.rs` | список программ, состояние, настройки (их собственные файлы), установка через их install.ps1 |
| `sys.rs` | версия Windows, имя пользователя, тема, процессы, автозапуск, файлы «ключ=значение» |
| `tweaks.rs` | твики Windows (реестр текущего пользователя и системные параметры), перезапуск Проводника |
| `backup.rs` | перенос всех настроек в один файл и обратно |
| `update.rs` | метка сборки в exe, поиск более нового «Центра Mac» в «Загрузках» |
| `sun.rs`, `scenery.rs` | общие с MacSpotlight: солнце и миниатюры «Пейзажа дня» |
| `gfx.rs`, `win.rs` | отрисовка и тема Windows (общие с другими программами) |

## Проверка

```
mac-center.exe --preview welcome|setup|progress|home|app:N|system out.png
mac-center.exe --selftest out.txt [--reinstall-shot]
mac-center.exe --welcome                       # показать приветствие ещё раз
```
`MAC_STYLE=10|11`, `MAC_FONT_DIR`, `MAC_DARK=1` — снимки в другом оформлении.
