//! Текст песни для панели музыки (показывается под кнопками). В программе текстов нет: для играющей сейчас
//! песни он запрашивается в открытой базе LRCLIB (lrclib.net), и только если текст включён

use std::collections::HashMap;
use std::sync::atomic::{AtomicU8, Ordering};
use std::sync::{Arc, Mutex};

use windows::core::{w, HSTRING, PCWSTR};
use windows::Win32::Networking::WinHttp::*;

use crate::media::TICKS;

#[derive(Clone)]
pub enum State {
    Loading,
    Missing,
    /// строки с временем начала (в единицах WinRT, 100 нс)
    Synced(Arc<Vec<(i64, String)>>),
    /// текст без времени
    Plain(Arc<Vec<String>>),
}

static CACHE: Mutex<Option<HashMap<String, State>>> = Mutex::new(None);
/// 0 — ещё не читали с диска, 1 — выкл, 2 — вкл
static ENABLED: AtomicU8 = AtomicU8::new(0);

fn flag_path() -> Option<std::path::PathBuf> {
    let d = std::path::PathBuf::from(std::env::var("LOCALAPPDATA").ok()?).join("MacMixer");
    let _ = std::fs::create_dir_all(&d);
    Some(d.join("lyrics.on"))
}

pub fn enabled() -> bool {
    match ENABLED.load(Ordering::Relaxed) {
        0 => {
            let on = flag_path().is_some_and(|p| p.exists());
            ENABLED.store(if on { 2 } else { 1 }, Ordering::Relaxed);
            on
        }
        v => v == 2,
    }
}

pub fn set_enabled(on: bool) {
    ENABLED.store(if on { 2 } else { 1 }, Ordering::Relaxed);
    if let Some(p) = flag_path() {
        if on {
            let _ = std::fs::write(p, b"1");
        } else {
            let _ = std::fs::remove_file(p);
        }
    }
}

/// Состояние текста для песни; первый вызов запускает поиск в фоне
pub fn get(title: &str, artist: &str, end: i64) -> State {
    let key = format!("{title}\n{artist}");
    let Ok(mut g) = CACHE.lock() else { return State::Missing };
    let map = g.get_or_insert_with(HashMap::new);
    if let Some(s) = map.get(&key) {
        return s.clone();
    }
    if map.len() > 200 {
        map.clear();
    }
    map.insert(key.clone(), State::Loading);
    let (title, artist) = (title.to_string(), artist.to_string());
    std::thread::spawn(move || {
        let found = find(&title, &artist, end / TICKS);
        let result = match found {
            Some(s) => s,
            None => State::Missing,
        };
        if let Ok(mut g) = CACHE.lock() {
            if let Some(m) = g.as_mut() {
                m.insert(key, result);
            }
        }
    });
    State::Loading
}

fn encode(s: &str) -> String {
    let mut out = String::new();
    for b in s.bytes() {
        match b {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => out.push(b as char),
            _ => out += &format!("%{b:02X}"),
        }
    }
    out
}

/// Убрать из названия «(Official Video)», «[Lyrics]» и подобное
fn clean(s: &str) -> String {
    let mut out = String::new();
    let mut depth = 0;
    for c in s.chars() {
        match c {
            '(' | '[' => depth += 1,
            ')' | ']' => depth = (depth - 1).max(0),
            _ if depth == 0 => out.push(c),
            _ => {}
        }
    }
    out.split_whitespace().collect::<Vec<_>>().join(" ")
}

/// Плееры в браузере иногда пишут «Исполнитель — Альбом»: для поиска нужен только исполнитель
fn artist_only(s: &str) -> String {
    s.split(" — ").next().unwrap_or(s).trim().to_string()
}

fn find(title: &str, artist: &str, secs: i64) -> Option<State> {
    let t = clean(title);
    let a = artist_only(artist);
    if let Some(s) = search(&t, &a, secs) {
        return Some(s);
    }
    // видео с YouTube: всё в названии — «Исполнитель - Песня»
    if let Some((left, right)) = t.split_once(" - ") {
        if let Some(s) = search(right.trim(), left.trim(), secs) {
            return Some(s);
        }
    }
    None
}

fn search(title: &str, artist: &str, secs: i64) -> Option<State> {
    if title.is_empty() {
        return None;
    }
    let mut q = format!("/api/search?track_name={}", encode(title));
    if !artist.is_empty() {
        q += &format!("&artist_name={}", encode(artist));
    }
    let body = http_get("lrclib.net", &q)?;
    let list: serde_json::Value = serde_json::from_slice(&body).ok()?;
    let list = list.as_array()?;
    // ближайшая по длительности, при равенстве — с привязкой ко времени
    let best = list
        .iter()
        .filter(|v| {
            let synced = v["syncedLyrics"].as_str().is_some_and(|s| !s.is_empty());
            let plain = v["plainLyrics"].as_str().is_some_and(|s| !s.is_empty());
            synced || plain
        })
        .min_by_key(|v| {
            let d = v["duration"].as_f64().unwrap_or(0.0) as i64;
            let off = if secs > 0 { (d - secs).abs() } else { 0 };
            let synced = v["syncedLyrics"].as_str().is_some_and(|s| !s.is_empty());
            (off.min(600) / 3, !synced)
        })?;
    // совсем другая длительность — скорее всего, другая песня
    if secs > 0 && (best["duration"].as_f64().unwrap_or(0.0) as i64 - secs).abs() > 15 {
        return None;
    }
    if let Some(s) = best["syncedLyrics"].as_str().filter(|s| !s.is_empty()) {
        let lines = parse_lrc(s);
        if !lines.is_empty() {
            return Some(State::Synced(Arc::new(lines)));
        }
    }
    let plain: Vec<String> = best["plainLyrics"].as_str()?.lines().map(|l| l.trim().to_string()).filter(|l| !l.is_empty()).collect();
    (!plain.is_empty()).then(|| State::Plain(Arc::new(plain)))
}

/// Формат LRC: «[мм:сс.сс] строка»
pub fn parse_lrc(text: &str) -> Vec<(i64, String)> {
    let mut out = Vec::new();
    for line in text.lines() {
        let Some(rest) = line.strip_prefix('[') else { continue };
        let Some((time, words)) = rest.split_once(']') else { continue };
        let Some((m, s)) = time.split_once(':') else { continue };
        let (Ok(m), Ok(s)) = (m.parse::<i64>(), s.parse::<f64>()) else { continue };
        let words = words.trim();
        if !words.is_empty() {
            out.push((m * 60 * TICKS + (s * TICKS as f64) as i64, words.to_string()));
        }
    }
    out.sort_by_key(|l| l.0);
    out
}

fn http_get(host: &str, path: &str) -> Option<Vec<u8>> {
    unsafe {
        let session = WinHttpOpen(w!("MacMixer/0.1"), WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY, PCWSTR::null(), PCWSTR::null(), 0);
        if session.is_null() {
            return None;
        }
        let _ = WinHttpSetTimeouts(session, 5000, 5000, 5000, 8000);
        let connect = WinHttpConnect(session, &HSTRING::from(host), 443, 0);
        let mut out = None;
        if !connect.is_null() {
            let req = WinHttpOpenRequest(connect, w!("GET"), &HSTRING::from(path), PCWSTR::null(), PCWSTR::null(), std::ptr::null(), WINHTTP_FLAG_SECURE);
            if !req.is_null() {
                if WinHttpSendRequest(req, None, None, 0, 0, 0).is_ok() && WinHttpReceiveResponse(req, std::ptr::null_mut()).is_ok() {
                    let mut body = Vec::new();
                    let mut ok = true;
                    loop {
                        let mut n = 0u32;
                        if WinHttpQueryDataAvailable(req, &mut n).is_err() {
                            ok = false;
                            break;
                        }
                        if n == 0 || body.len() > 8_000_000 {
                            break;
                        }
                        let start = body.len();
                        body.resize(start + n as usize, 0);
                        let mut read = 0u32;
                        if WinHttpReadData(req, body[start..].as_mut_ptr() as *mut _, n, &mut read).is_err() {
                            ok = false;
                            break;
                        }
                        body.truncate(start + read as usize);
                    }
                    if ok {
                        out = Some(body);
                    }
                }
                let _ = WinHttpCloseHandle(req);
            }
            let _ = WinHttpCloseHandle(connect);
        }
        let _ = WinHttpCloseHandle(session);
        out
    }
}

/// Проверка без окна: находится ли текст для песни. В отчёте только счётчики, сам текст не выводится
pub fn selftest(title: &str, artist: &str, secs: i64) -> String {
    match find(title, artist, secs) {
        Some(State::Synced(l)) => format!("найден с привязкой ко времени, строк: {}", l.len()),
        Some(State::Plain(l)) => format!("найден без времени, строк: {}", l.len()),
        _ => "не найден".into(),
    }
}
