//! Панель микшера над треем — в том же стиле, что панели MacShot:
//! выход и вход с выбором устройства, громкость каждого приложения

use std::cell::{Cell, RefCell};
use std::time::Instant;

use tiny_skia::PixmapMut;
use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Controls::WM_MOUSELEAVE;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::Shell::ShellExecuteW;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::audio::{self, Audio, Flow, Kind, Target};
use crate::gfx::{self, Fonts, Icon, Img};
use crate::win::{self, Surface};

const M: f32 = 26.0; // поле под тень
const W: f32 = 344.0;
const PAD: f32 = 12.0;
/// отступ панели от края рабочей области
const GAP: f32 = 10.0;
const TIMER: usize = 1;
const OPEN_MS: f32 = 170.0;
const WM_CLOSE_PANEL: u32 = WM_APP + 10;

const TITLE_H: f32 = 44.0;
const HEADER_H: f32 = 50.0;
const ROW_H: f32 = 34.0;
const SLIDER_H: f32 = 28.0;
const SECTION_H: f32 = 28.0;
const APP_H: f32 = 50.0;
const EMPTY_H: f32 = 44.0;
const FOOTER_H: f32 = 36.0;
const APP_ICON: f32 = 28.0;

#[derive(Clone, Copy, PartialEq, Debug)]
enum Hit {
    Header(Flow),
    Device(Flow, usize),
    Slider(Target),
    /// иконка внутри большого слайдера или иконка приложения
    Mute(Target),
    Footer,
}

#[derive(Clone, Copy)]
enum Block {
    Title,
    Card(f32),
    Header(Flow),
    Device(Flow, usize),
    Slider(Flow),
    Section,
    App(usize),
    Empty,
    Separator,
    Footer,
}

#[derive(Default)]
struct Layout {
    blocks: Vec<(Block, f32)>,
    h: f32,
}

#[derive(Clone, Copy)]
struct Press {
    hit: Hit,
    x: f32,
    dragging: bool,
}

pub struct View {
    scale: f32,
    expanded: Option<Flow>,
    hover: Option<Hit>,
    press: Option<Press>,
    /// предел высоты панели в логических пикселях
    max_h: f32,
}

#[derive(Clone, Copy, PartialEq)]
enum Edge {
    Bottom,
    Top,
    Left,
    Right,
}

struct Panel {
    hwnd: HWND,
    view: View,
    work: RECT,
    edge: Edge,
    layout: Layout,
    base: Option<Img>,
    opened: Instant,
    ticks: u32,
    sig: Vec<i32>,
    tracking: bool,
}

thread_local! {
    static PANEL: RefCell<Option<Panel>> = const { RefCell::new(None) };
    static FONTS: RefCell<Option<Fonts>> = const { RefCell::new(None) };
    static CLOSED: Cell<Option<Instant>> = const { Cell::new(None) };
}

fn with<R>(f: impl FnOnce(&mut Panel) -> R) -> Option<R> {
    PANEL.with(|s| s.try_borrow_mut().ok()?.as_mut().map(f))
}

pub fn init(fonts: Fonts) {
    FONTS.with(|f| *f.borrow_mut() = Some(fonts));
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacMixer.Panel"),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            ..Default::default()
        };
        RegisterClassW(&wc);
    }
}

/// Шрифты общие с панелью «Сейчас играет»
pub fn with_fonts<R>(f: impl FnOnce(&Fonts) -> R) -> Option<R> {
    FONTS.with(|s| s.borrow().as_ref().map(f))
}

pub fn is_open() -> bool {
    PANEL.with(|s| s.try_borrow().map(|p| p.is_some()).unwrap_or(true))
}

/// Клик по значку в трее: открыть или закрыть
pub fn toggle() {
    if is_open() {
        close();
        return;
    }
    // клик по трею сначала уводит фокус с панели и закрывает её — не открываем её тут же снова
    if CLOSED.with(|c| c.get()).is_some_and(|t| t.elapsed().as_millis() < 300) {
        return;
    }
    open();
}

pub fn open() {
    if is_open() {
        return;
    }
    let mon = win::monitor_at(win::cursor());
    let s = mon.scale;
    audio::with(|a| a.refresh(icon_px(s)));
    let (r, wk) = (mon.rect, mon.work);
    let edge = if wk.top > r.top {
        Edge::Top
    } else if wk.left > r.left {
        Edge::Left
    } else if wk.right < r.right {
        Edge::Right
    } else {
        Edge::Bottom
    };
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let Ok(hwnd) = CreateWindowExW(
            WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
            w!("MacMixer.Panel"),
            w!("Громкость"),
            WS_POPUP,
            wk.right,
            wk.bottom,
            1,
            1,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        let view = View {
            scale: s,
            expanded: None,
            hover: None,
            press: None,
            max_h: (wk.bottom - wk.top) as f32 / s - GAP * 2.0,
        };
        let p = Panel {
            hwnd,
            view,
            work: wk,
            edge,
            layout: Layout::default(),
            base: None,
            opened: Instant::now(),
            ticks: 0,
            sig: Vec::new(),
            tracking: false,
        };
        PANEL.with(|cell| *cell.borrow_mut() = Some(p));
        frame(true);
        let _ = ShowWindow(hwnd, SW_SHOW);
        let _ = SetForegroundWindow(hwnd);
        SetTimer(Some(hwnd), TIMER, 16, None);
    }
}

pub fn close() {
    let p = PANEL.with(|s| s.try_borrow_mut().ok().and_then(|mut p| p.take()));
    if let Some(p) = p {
        CLOSED.with(|c| c.set(Some(Instant::now())));
        unsafe {
            let _ = DestroyWindow(p.hwnd);
        }
    }
}

fn icon_px(scale: f32) -> u32 {
    (APP_ICON * scale).round() as u32
}

// ---------- вёрстка ----------

fn layout(v: &View, a: &Audio) -> Layout {
    let mut b = Vec::new();
    let mut y = 0.0;
    b.push((Block::Title, y));
    y += TITLE_H;
    for flow in [Flow::Out, Flow::In] {
        let (list, has) = match flow {
            Flow::Out => (&a.outputs, a.output().is_some()),
            Flow::In => (&a.inputs, a.input().is_some()),
        };
        let start = y;
        let card = b.len();
        b.push((Block::Card(0.0), y));
        y += 4.0;
        b.push((Block::Header(flow), y));
        y += HEADER_H;
        if v.expanded == Some(flow) {
            for i in 0..list.len() {
                b.push((Block::Device(flow, i), y));
                y += ROW_H;
            }
            y += 6.0;
        }
        if has {
            b.push((Block::Slider(flow), y));
            y += SLIDER_H + 14.0;
        } else {
            y += 4.0;
        }
        b[card].0 = Block::Card(y - start);
        y += 8.0;
    }
    b.push((Block::Section, y));
    y += SECTION_H;
    let tail = 6.0 + 1.0 + 6.0 + FOOTER_H + 8.0;
    if a.apps.is_empty() {
        b.push((Block::Empty, y));
        y += EMPTY_H;
    }
    for i in 0..a.apps.len() {
        // приложений больше, чем влезает по высоте экрана, — показываем сколько поместится
        if i > 0 && y + APP_H + tail > v.max_h {
            break;
        }
        b.push((Block::App(i), y));
        y += APP_H;
    }
    y += 6.0;
    b.push((Block::Separator, y));
    y += 1.0 + 6.0;
    b.push((Block::Footer, y));
    y += FOOTER_H + 8.0;
    Layout { blocks: b, h: y }
}

/// внутренняя ширина карточек
const IX: f32 = PAD + 6.0;
const IW: f32 = W - PAD * 2.0 - 12.0;

fn main_track() -> (f32, f32) {
    let tx = PAD + 14.0;
    (tx, W - PAD - 14.0 - 46.0 - tx)
}

/// Дорожка большого ползунка: справа от значка
fn main_range() -> (f32, f32) {
    let (tx, tw) = main_track();
    (tx + SLIDER_H + 12.0, tx + tw - 4.0)
}

fn app_track() -> (f32, f32) {
    let tx = PAD + 54.0;
    (tx, W - PAD - 14.0 - tx)
}

fn target(flow: Flow) -> Target {
    match flow {
        Flow::Out => Target::Out,
        Flow::In => Target::In,
    }
}

fn inside(x: f32, y: f32, rx: f32, ry: f32, rw: f32, rh: f32) -> bool {
    x >= rx && x < rx + rw && y >= ry && y < ry + rh
}

fn hit(l: &Layout, x: f32, y: f32) -> Option<Hit> {
    for &(b, by) in &l.blocks {
        match b {
            Block::Header(flow) if inside(x, y, IX, by, IW, HEADER_H) => return Some(Hit::Header(flow)),
            Block::Device(flow, i) if inside(x, y, IX, by, IW, ROW_H) => return Some(Hit::Device(flow, i)),
            Block::Slider(flow) => {
                let (tx, tw) = main_track();
                if inside(x, y, tx - 6.0, by - 6.0, tw + 12.0, SLIDER_H + 12.0) {
                    let t = target(flow);
                    return Some(if x < tx + SLIDER_H { Hit::Mute(t) } else { Hit::Slider(t) });
                }
            }
            Block::App(i) => {
                if inside(x, y, PAD + 6.0, by + 5.0, 40.0, 40.0) {
                    return Some(Hit::Mute(Target::App(i)));
                }
                let (tx, tw) = app_track();
                if inside(x, y, tx - 8.0, by + 22.0, tw + 16.0, 24.0) {
                    return Some(Hit::Slider(Target::App(i)));
                }
            }
            Block::Footer if inside(x, y, PAD + 2.0, by, W - PAD * 2.0 - 4.0, FOOTER_H) => return Some(Hit::Footer),
            _ => {}
        }
    }
    None
}

/// Положение на слайдере → громкость
fn value_at(t: Target, x: f32) -> f32 {
    let v = match t {
        Target::Out | Target::In => {
            let (x0, x1) = main_range();
            (x - x0) / (x1 - x0)
        }
        Target::App(_) => {
            let (tx, tw) = app_track();
            (x - tx - 7.0) / (tw - 14.0)
        }
    };
    v.clamp(0.0, 1.0)
}

/// Сколько из шести точек индикатора уровня горит
fn dots(peak: f32, muted: bool) -> usize {
    if muted || peak < 0.003 {
        0
    } else {
        ((peak.sqrt() * 6.0).ceil() as usize).min(6)
    }
}

/// Высоты трёх столбиков «эквалайзера» у играющего приложения
fn bars(peak: f32, muted: bool) -> Option<[f32; 3]> {
    if muted || peak < 0.01 {
        return None;
    }
    let k = peak.sqrt();
    Some([0.7, 1.0, 0.55].map(|m: f32| (3.0 + 7.0 * (k * m).min(1.0)).round()))
}

fn waves(vol: f32) -> u8 {
    match vol {
        v if v < 0.01 => 0,
        v if v < 0.34 => 1,
        v if v < 0.67 => 2,
        _ => 3,
    }
}

fn device_icon(kind: Kind, muted: bool) -> Icon {
    match (kind, muted) {
        (Kind::Mic, true) => Icon::MicMuted,
        (Kind::Mic, false) => Icon::Mic,
        (Kind::Headphones, _) => Icon::Headphones,
        (Kind::Display, _) => Icon::Display,
        (Kind::Speakers, true) => Icon::SpeakerMuted,
        (Kind::Speakers, false) => Icon::Speaker(3),
    }
}

// ---------- отрисовка ----------

struct Ctx {
    s: f32,
    o: f32,
}

impl Ctx {
    fn x(&self, v: f32) -> f32 {
        self.o + v * self.s
    }
    fn d(&self, v: f32) -> f32 {
        v * self.s
    }
}

fn background(w: u32, h: u32, s: f32, ph: f32) -> Img {
    let mut img = Img::new(w, h);
    if let Some(mut pm) = img.pixmap_mut() {
        let (x, y, pw, ph) = (M * s, M * s, W * s, ph * s);
        gfx::shadow(&mut pm, x, y + 6.0 * s, pw, ph, 24.0 * s, 0.32);
        gfx::fill_rrect(&mut pm, x, y, pw, ph, 16.0 * s, gfx::panel(0.97));
        gfx::stroke_rrect(&mut pm, x + 0.5, y + 0.5, pw - 1.0, ph - 1.0, 16.0 * s, 1.0, gfx::white(0.10));
    }
    img
}

fn render(v: &View, a: &Audio, f: &Fonts, l: &Layout, base: &mut Option<Img>) -> Img {
    let s = v.scale;
    let (iw, ih) = (((W + 2.0 * M) * s).ceil() as u32, ((l.h + 2.0 * M) * s).ceil() as u32);
    let mut img = match base {
        Some(b) if b.w == iw && b.h == ih => b.clone(),
        _ => {
            let b = background(iw, ih, s, l.h);
            *base = Some(b.clone());
            b
        }
    };
    if let Some(mut pm) = img.pixmap_mut() {
        let c = Ctx { s, o: M * s };
        for &(b, y) in &l.blocks {
            draw(&mut pm, &c, v, a, f, b, y);
        }
    }
    img
}

fn draw(pm: &mut PixmapMut, c: &Ctx, v: &View, a: &Audio, f: &Fonts, b: Block, y: f32) {
    let s = c.s;
    let hover = |h: Hit| v.hover == Some(h) && v.press.is_none_or(|p| p.hit == h);
    match b {
        Block::Title => {
            gfx::text(pm, &f.semibold, "Звук", c.x(PAD + 10.0), c.x(29.0), 16.0 * s, gfx::white(0.95));
        }
        Block::Card(h) => {
            gfx::fill_rrect(pm, c.x(PAD), c.x(y), c.d(W - PAD * 2.0), c.d(h), c.d(13.0), gfx::white(0.05));
        }
        Block::Header(flow) => {
            let dev = if flow == Flow::Out { a.output() } else { a.input() };
            if hover(Hit::Header(flow)) {
                gfx::fill_rrect(pm, c.x(IX), c.x(y), c.d(IW), c.d(HEADER_H), c.d(10.0), gfx::white(0.07));
            }
            let (cx, cy) = (IX + 8.0 + 16.0, y + HEADER_H / 2.0);
            let muted = dev.is_none_or(|d| d.muted);
            let tile = if muted { gfx::white(0.12) } else { gfx::accent(1.0) };
            gfx::fill_rrect(pm, c.x(cx - 16.0), c.x(cy - 16.0), c.d(32.0), c.d(32.0), 0.0, tile);
            let kind = dev.map(|d| d.kind).unwrap_or(if flow == Flow::Out { Kind::Speakers } else { Kind::Mic });
            let ic = if muted { gfx::white(0.85) } else { gfx::on_accent(1.0) };
            gfx::icon(pm, device_icon(kind, muted), c.x(cx - 9.0), c.x(cy - 9.0), c.d(18.0), ic);
            let chev = if v.expanded == Some(flow) { Icon::ChevronUp } else { Icon::ChevronDown };
            let chx = IX + IW - 10.0 - 16.0;
            gfx::icon(pm, chev, c.x(chx), c.x(cy - 8.0), c.d(16.0), gfx::white(0.5));
            let tx = IX + 48.0;
            let mut right = chx - 8.0;
            if let Some(d) = dev {
                // индикатор уровня: шесть точек перед стрелкой
                let lit = dots(d.peak, d.muted);
                for i in 0..6 {
                    let dx = right - 3.0 - (5 - i) as f32 * 7.0;
                    let col = if i < lit { gfx::accent(1.0) } else { gfx::white(0.13) };
                    gfx::fill_rrect(pm, c.x(dx - 2.0), c.x(cy - 2.0), c.d(4.0), c.d(4.0), 0.0, col);
                }
                right -= 6.0 * 7.0 + 6.0;
            }
            let (name, detail) = match dev {
                Some(d) => (d.name.as_str(), d.detail.as_str()),
                None if flow == Flow::Out => ("Нет устройств вывода", ""),
                None => ("Нет микрофона", ""),
            };
            let max = c.d(right - tx);
            let nb = if detail.is_empty() { cy + 5.0 } else { y + 22.0 };
            let name = gfx::fit(&f.semibold, name, 13.5 * s, max);
            gfx::text(pm, &f.semibold, &name, c.x(tx), c.x(nb), 13.5 * s, gfx::white(0.95));
            if !detail.is_empty() {
                let detail = gfx::fit(&f.regular, detail, 11.5 * s, max);
                gfx::text(pm, &f.regular, &detail, c.x(tx), c.x(y + 38.0), 11.5 * s, gfx::white(0.5));
            }
        }
        Block::Device(flow, i) => {
            let (list, def) = match flow {
                Flow::Out => (&a.outputs, a.out_default),
                Flow::In => (&a.inputs, a.in_default),
            };
            let Some(d) = list.get(i) else { return };
            if hover(Hit::Device(flow, i)) {
                gfx::fill_rrect(pm, c.x(IX), c.x(y), c.d(IW), c.d(ROW_H), c.d(9.0), gfx::white(0.07));
            }
            let cy = y + ROW_H / 2.0;
            gfx::icon(pm, device_icon(d.kind, false), c.x(IX + 16.0), c.x(cy - 8.0), c.d(16.0), gfx::white(0.65));
            let tx = IX + 44.0;
            let label = if d.detail.is_empty() { d.name.clone() } else { format!("{} · {}", d.name, d.detail) };
            let label = gfx::fit(&f.regular, &label, 13.0 * s, c.d(IW - 44.0 - 36.0));
            gfx::text(pm, &f.regular, &label, c.x(tx), c.x(cy + 4.6), 13.0 * s, gfx::white(0.9));
            if def == Some(i) {
                gfx::icon(pm, Icon::Check, c.x(IX + IW - 14.0 - 16.0), c.x(cy - 8.0), c.d(16.0), gfx::accent(1.0));
            }
        }
        Block::Slider(flow) => {
            let t = target(flow);
            let Some((vol, muted, _)) = a.level(t) else { return };
            let (tx, _) = main_track();
            let h = SLIDER_H;
            let cy = y + h / 2.0;
            if hover(Hit::Mute(t)) {
                gfx::fill_rrect(pm, c.x(tx), c.x(y), c.d(h), c.d(h), 0.0, gfx::white(0.10));
            }
            let (x0, x1) = main_range();
            gfx::fill_rrect(pm, c.x(x0), c.x(cy - 1.0), c.d(x1 - x0), c.d(2.0), 0.0, gfx::white(0.45));
            let kx = x0 + vol * (x1 - x0);
            let fill = if muted { gfx::white(0.45) } else { gfx::accent(1.0) };
            gfx::fill_rrect(pm, c.x(x0), c.x(cy - 1.0), c.d(kx - x0), c.d(2.0), 0.0, fill);
            gfx::pill(pm, c.x(kx - 4.0), c.x(cy - 11.0), c.d(8.0), c.d(22.0), fill);
            let kind = match (flow, muted) {
                (Flow::Out, true) => Icon::SpeakerMuted,
                (Flow::Out, false) => Icon::Speaker(waves(vol)),
                (Flow::In, true) => Icon::MicMuted,
                (Flow::In, false) => Icon::Mic,
            };
            gfx::icon(pm, kind, c.x(tx + 4.0), c.x(cy - 10.0), c.d(20.0), gfx::white(if muted { 0.6 } else { 0.95 }));
            let pct = format!("{}%", (vol * 100.0).round() as i32);
            let px = 13.0 * s;
            let pw = gfx::measure(&f.regular, &pct, px);
            let col = if muted { gfx::white(0.35) } else { gfx::white(0.7) };
            gfx::text(pm, &f.regular, &pct, c.x(W - PAD - 14.0) - pw, c.x(y + h / 2.0 + 4.7), px, col);
        }
        Block::Section => {
            gfx::text(pm, &f.semibold, "Приложения", c.x(PAD + 10.0), c.x(y + 19.0), 12.0 * s, gfx::white(0.45));
        }
        Block::Empty => {
            let msg = "Сейчас ничего не играет";
            let px = 13.0 * s;
            let mw = gfx::measure(&f.regular, msg, px);
            gfx::text(pm, &f.regular, msg, c.x(W / 2.0) - mw / 2.0, c.x(y + 24.0), px, gfx::white(0.38));
        }
        Block::App(i) => {
            let Some(app) = a.apps.get(i) else { return };
            let t = Target::App(i);
            let (ix, iy) = (PAD + 12.0, y + (APP_H - APP_ICON) / 2.0);
            let (icx, icy) = (ix + APP_ICON / 2.0, iy + APP_ICON / 2.0);
            if hover(Hit::Mute(t)) {
                gfx::fill_rrect(pm, c.x(ix - 6.0), c.x(iy - 6.0), c.d(APP_ICON + 12.0), c.d(APP_ICON + 12.0), c.d(10.0), gfx::white(0.08));
            }
            let op = if app.muted { 0.35 } else { 1.0 };
            if app.system {
                gfx::fill_rrect(pm, c.x(ix), c.x(iy), c.d(APP_ICON), c.d(APP_ICON), 0.0, gfx::white(0.10 * op + 0.02));
                gfx::icon(pm, Icon::Bell, c.x(icx - 9.0), c.x(icy - 9.0), c.d(18.0), gfx::white(0.85 * op));
            } else if let Some(img) = &app.icon {
                gfx::image(pm, img, c.x(ix), c.x(iy), c.d(APP_ICON), op);
            } else {
                gfx::icon(pm, Icon::Window, c.x(icx - 11.0), c.x(icy - 11.0), c.d(22.0), gfx::white(0.7 * op));
            }
            if app.muted {
                let (bx, by) = (ix + APP_ICON - 1.0, iy + APP_ICON - 1.0);
                gfx::fill_rrect(pm, c.x(bx - 8.0), c.x(by - 8.0), c.d(16.0), c.d(16.0), 0.0, gfx::panel(1.0));
                gfx::icon(pm, Icon::SpeakerMuted, c.x(bx - 6.0), c.x(by - 6.0), c.d(12.0), gfx::white(0.9));
            }
            let tx = PAD + 54.0;
            let right = W - PAD - 14.0;
            let pct = format!("{}%", (app.volume * 100.0).round() as i32);
            let pp = 12.0 * s;
            let pw = gfx::measure(&f.regular, &pct, pp);
            gfx::text(pm, &f.regular, &pct, c.x(right) - pw, c.x(y + 20.0), pp, gfx::white(if app.muted { 0.3 } else { 0.45 }));
            let eq = bars(app.peak, app.muted);
            let room = c.d(right - tx) - pw - c.d(if eq.is_some() { 30.0 } else { 10.0 });
            let px = 13.0 * s;
            let name = gfx::fit(&f.regular, &app.name, px, room);
            gfx::text(pm, &f.regular, &name, c.x(tx), c.x(y + 20.0), px, gfx::white(if app.muted { 0.5 } else { 0.92 }));
            if let Some(hs) = eq {
                let ex = c.x(tx) + gfx::measure(&f.regular, &name, px) + c.d(8.0);
                for (k, h) in hs.iter().enumerate() {
                    let bx = ex + c.d(k as f32 * 4.4);
                    gfx::fill_rrect(pm, bx, c.x(y + 19.0 - h), c.d(2.4), c.d(*h), c.d(1.2), gfx::accent(1.0));
                }
            }
            let (sx, sw) = app_track();
            let ty = y + 32.0;
            let ky = ty + 2.5;
            gfx::fill_rrect(pm, c.x(sx + 7.0), c.x(ky - 1.0), c.d(sw - 14.0), c.d(2.0), 0.0, gfx::white(0.45));
            let kx = sx + 7.0 + app.volume * (sw - 14.0);
            let fill = if app.muted { gfx::white(0.45) } else { gfx::accent(1.0) };
            gfx::fill_rrect(pm, c.x(sx + 7.0), c.x(ky - 1.0), c.d(kx - sx - 7.0), c.d(2.0), 0.0, fill);
            gfx::pill(pm, c.x(kx - 3.0), c.x(ky - 8.0), c.d(6.0), c.d(16.0), fill);
        }
        Block::Separator => {
            let h = (1.0f32).max(s.floor());
            gfx::fill_rrect(pm, c.x(PAD + 8.0), c.x(y), c.d(W - PAD * 2.0 - 16.0), h, 0.0, gfx::white(0.08));
        }
        Block::Footer => {
            if hover(Hit::Footer) {
                gfx::fill_rrect(pm, c.x(PAD + 2.0), c.x(y), c.d(W - PAD * 2.0 - 4.0), c.d(FOOTER_H), c.d(10.0), gfx::white(0.07));
            }
            let cy = y + FOOTER_H / 2.0;
            gfx::text(pm, &f.regular, "Параметры звука…", c.x(PAD + 14.0), c.x(cy + 4.6), 13.0 * s, gfx::white(0.85));
            gfx::icon(pm, Icon::ChevronRight, c.x(W - PAD - 12.0 - 16.0), c.x(cy - 8.0), c.d(16.0), gfx::white(0.4));
        }
    }
}

/// Отпечаток всего, что видно на панели: перерисовываем только когда он меняется
fn signature(v: &View, a: &Audio) -> Vec<i32> {
    let q = |x: f32| (x * 1000.0).round() as i32;
    let mut sig = vec![
        v.expanded.map_or(0, |f| f as i32 + 1),
        v.hover.map_or(-1, |h| hit_code(h)),
        v.press.map_or(-1, |p| hit_code(p.hit)),
        a.out_default.map_or(-1, |i| i as i32),
        a.in_default.map_or(-1, |i| i as i32),
        a.outputs.len() as i32,
        a.inputs.len() as i32,
        a.apps.len() as i32,
    ];
    for d in a.outputs.iter().chain(a.inputs.iter()) {
        sig.extend([q(d.volume), d.muted as i32, dots(d.peak, d.muted) as i32]);
    }
    for app in &a.apps {
        sig.extend([q(app.volume), app.muted as i32]);
        sig.extend(bars(app.peak, app.muted).map_or([0.0; 3], |b| b).map(|h| h as i32));
    }
    sig
}

fn hit_code(h: Hit) -> i32 {
    let t = |t: Target| match t {
        Target::Out => 0,
        Target::In => 1,
        Target::App(i) => 2 + i as i32,
    };
    match h {
        Hit::Header(f) => 1_000 + f as i32,
        Hit::Device(f, i) => 2_000 + f as i32 * 500 + i as i32,
        Hit::Slider(x) => 3_000 + t(x),
        Hit::Mute(x) => 4_000 + t(x),
        Hit::Footer => 5_000,
    }
}

fn ease(k: f32) -> f32 {
    1.0 - (1.0 - k.clamp(0.0, 1.0)).powi(3)
}

/// Перерисовать панель, если что-то изменилось (или force)
fn frame(force: bool) {
    with(|p| {
        audio::with(|a| {
            FONTS.with(|f| {
                let f = f.borrow();
                let Some(f) = f.as_ref() else { return };
                let anim = p.opened.elapsed().as_millis() as f32 <= OPEN_MS + 20.0;
                let sig = signature(&p.view, a);
                if !force && !anim && sig == p.sig {
                    return;
                }
                p.sig = sig;
                p.layout = layout(&p.view, a);
                let img = render(&p.view, a, f, &p.layout, &mut p.base);
                present(p, &img);
            })
        })
    });
}

fn present(p: &Panel, img: &Img) {
    let s = p.view.scale;
    let (m, gap) = (M * s, GAP * s);
    let (pw, ph) = (W * s, p.layout.h * s);
    let wk = p.work;
    let px = if p.edge == Edge::Left { wk.left as f32 + gap } else { wk.right as f32 - gap - pw };
    let py = if p.edge == Edge::Top { wk.top as f32 + gap } else { wk.bottom as f32 - gap - ph };
    // появление: панель всплывает на 10 px от панели задач и проявляется
    let k = ease(p.opened.elapsed().as_millis() as f32 / OPEN_MS);
    let dir = if p.edge == Edge::Top { -1.0 } else { 1.0 };
    let dy = (1.0 - k) * 10.0 * s * dir;
    let Some(mut surf) = Surface::new(img.w as i32, img.h as i32) else { return };
    surf.data().copy_from_slice(&img.px);
    unsafe {
        let screen = GetDC(None);
        let pos = POINT { x: (px - m).round() as i32, y: (py - m + dy).round() as i32 };
        let size = SIZE { cx: img.w as i32, cy: img.h as i32 };
        let src = POINT::default();
        let blend = BLENDFUNCTION {
            BlendOp: AC_SRC_OVER as u8,
            SourceConstantAlpha: (k * 255.0).round() as u8,
            AlphaFormat: AC_SRC_ALPHA as u8,
            ..Default::default()
        };
        let _ = UpdateLayeredWindow(p.hwnd, Some(screen), Some(&pos), Some(&size), Some(surf.dc), Some(&src), COLORREF(0), Some(&blend), ULW_ALPHA);
        ReleaseDC(None, screen);
    }
}

/// Только картинка панели — для проверки вёрстки (--preview)
pub fn preview(expanded: Option<Flow>) -> Option<Img> {
    let mon = win::monitor_at(win::cursor());
    let s = mon.scale;
    let fonts = Fonts::load()?;
    audio::with(|a| {
        a.refresh(icon_px(s));
        let v = View { scale: s, expanded, hover: None, press: None, max_h: (mon.work.bottom - mon.work.top) as f32 / s };
        let l = layout(&v, a);
        render(&v, a, &fonts, &l, &mut None)
    })
}

// ---------- мышь и клавиатура ----------

fn open_settings() {
    unsafe {
        ShellExecuteW(None, w!("open"), w!("ms-settings:sound"), None, None, SW_SHOWNORMAL);
    }
}

/// Логические координаты внутри панели
fn to_panel(s: f32, x: i32, y: i32) -> (f32, f32) {
    (x as f32 / s - M, y as f32 / s - M)
}

fn set_from_x(t: Target, x: f32) {
    audio::with(|a| {
        a.set_volume(t, value_at(t, x));
        if a.level(t).is_some_and(|l| l.1) {
            a.set_muted(t, false);
        }
    });
}

fn nudge(t: Target, delta: f32) {
    audio::with(|a| {
        let Some((vol, muted, _)) = a.level(t) else { return };
        a.set_volume(t, vol + delta);
        if muted && delta > 0.0 {
            a.set_muted(t, false);
        }
    });
}

enum Action {
    None,
    Toggle(Flow),
    Default(Flow, usize),
    Mute(Target),
    Settings,
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    let pt = || ((lp.0 & 0xFFFF) as i16 as i32, ((lp.0 >> 16) & 0xFFFF) as i16 as i32);
    match msg {
        WM_TIMER => {
            let refresh = with(|p| {
                p.ticks += 1;
                if p.ticks == 12 {
                    // после анимации появления хватает 30 кадров в секунду
                    SetTimer(Some(hwnd), TIMER, 33, None);
                }
                let dragging = p.view.press.is_some();
                (p.ticks % 30 == 0 && !dragging).then_some(icon_px(p.view.scale))
            })
            .flatten();
            audio::with(|a| match refresh {
                Some(px) => a.refresh(px),
                None => a.poll(),
            });
            frame(false);
            LRESULT(0)
        }
        WM_MOUSEMOVE => {
            let (x, y) = pt();
            let drag = with(|p| {
                if !p.tracking {
                    p.tracking = true;
                    let mut tme = TRACKMOUSEEVENT {
                        cbSize: std::mem::size_of::<TRACKMOUSEEVENT>() as u32,
                        dwFlags: TME_LEAVE,
                        hwndTrack: hwnd,
                        dwHoverTime: 0,
                    };
                    let _ = TrackMouseEvent(&mut tme);
                }
                let (lx, ly) = to_panel(p.view.scale, x, y);
                p.view.hover = hit(&p.layout, lx, ly);
                let press = p.view.press.as_mut()?;
                match press.hit {
                    // тянуть можно и начав с иконки большого слайдера
                    Hit::Mute(t @ (Target::Out | Target::In)) if (lx - press.x).abs() > 3.0 => {
                        press.hit = Hit::Slider(t);
                        press.dragging = true;
                        Some((t, lx))
                    }
                    Hit::Slider(t) => Some((t, lx)),
                    _ => None,
                }
            })
            .flatten();
            if let Some((t, lx)) = drag {
                set_from_x(t, lx);
            }
            frame(false);
            LRESULT(0)
        }
        WM_MOUSELEAVE => {
            with(|p| {
                p.tracking = false;
                p.view.hover = None;
            });
            frame(false);
            LRESULT(0)
        }
        WM_LBUTTONDOWN => {
            let (x, y) = pt();
            let start = with(|p| {
                let (lx, ly) = to_panel(p.view.scale, x, y);
                let h = hit(&p.layout, lx, ly)?;
                p.view.press = Some(Press { hit: h, x: lx, dragging: matches!(h, Hit::Slider(_)) });
                Some((h, lx))
            })
            .flatten();
            if let Some((h, lx)) = start {
                SetCapture(hwnd);
                if let Hit::Slider(t) = h {
                    set_from_x(t, lx);
                }
            }
            frame(false);
            LRESULT(0)
        }
        WM_LBUTTONUP => {
            let _ = ReleaseCapture();
            let (x, y) = pt();
            let action = with(|p| {
                let press = p.view.press.take()?;
                let (lx, ly) = to_panel(p.view.scale, x, y);
                if press.dragging || hit(&p.layout, lx, ly) != Some(press.hit) {
                    return None;
                }
                Some(match press.hit {
                    Hit::Header(f) => Action::Toggle(f),
                    Hit::Device(f, i) => Action::Default(f, i),
                    Hit::Mute(t) => Action::Mute(t),
                    Hit::Footer => Action::Settings,
                    Hit::Slider(_) => Action::None,
                })
            })
            .flatten()
            .unwrap_or(Action::None);
            match action {
                Action::Toggle(f) => {
                    with(|p| p.view.expanded = if p.view.expanded == Some(f) { None } else { Some(f) });
                }
                Action::Default(f, i) => {
                    audio::with(|a| a.set_default(f, i));
                    with(|p| p.view.expanded = None);
                }
                Action::Mute(t) => {
                    audio::with(|a| {
                        if let Some((_, muted, _)) = a.level(t) {
                            a.set_muted(t, !muted);
                        }
                    });
                }
                Action::Settings => {
                    close();
                    open_settings();
                    return LRESULT(0);
                }
                Action::None => {}
            }
            frame(false);
            LRESULT(0)
        }
        WM_MOUSEWHEEL => {
            let delta = ((wp.0 >> 16) & 0xFFFF) as i16 as f32 / WHEEL_DELTA as f32;
            let (sx, sy) = pt();
            let mut p0 = POINT { x: sx, y: sy };
            let _ = ScreenToClient(hwnd, &mut p0);
            let t = with(|p| {
                let (lx, ly) = to_panel(p.view.scale, p0.x, p0.y);
                match hit(&p.layout, lx, ly) {
                    Some(Hit::Slider(t) | Hit::Mute(t)) => t,
                    Some(Hit::Header(f)) => target(f),
                    _ => Target::Out,
                }
            });
            if let Some(t) = t {
                nudge(t, delta * 0.02);
            }
            frame(false);
            LRESULT(0)
        }
        WM_KEYDOWN => {
            match VIRTUAL_KEY(wp.0 as u16) {
                VK_ESCAPE => close(),
                VK_UP | VK_RIGHT => nudge(Target::Out, 0.02),
                VK_DOWN | VK_LEFT => nudge(Target::Out, -0.02),
                _ => {}
            }
            frame(false);
            LRESULT(0)
        }
        WM_ACTIVATE => {
            if (wp.0 & 0xFFFF) as u32 == WA_INACTIVE {
                // закрываем после выхода из обработчика активации
                let _ = PostMessageW(Some(hwnd), WM_CLOSE_PANEL, WPARAM(0), LPARAM(0));
            }
            LRESULT(0)
        }
        WM_CLOSE_PANEL | WM_CLOSE => {
            close();
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}
