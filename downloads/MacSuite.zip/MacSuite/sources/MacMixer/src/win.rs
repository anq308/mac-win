//! Общие мелочи Win32: буфер кадра, мониторы, строки, иконки

use std::ffi::c_void;
use std::mem::size_of;

use windows::core::PCWSTR;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::UI::HiDpi::{GetDpiForMonitor, MDT_EFFECTIVE_DPI};
use windows::Win32::UI::Shell::SHDefExtractIconW;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::gfx::Img;

fn dib(dc: HDC, w: i32, h: i32) -> Option<(HBITMAP, *mut u8)> {
    let bi = bitmap_info(w, h);
    let mut bits: *mut c_void = std::ptr::null_mut();
    let bmp = unsafe { CreateDIBSection(Some(dc), &bi, DIB_RGB_COLORS, &mut bits, None, 0).ok()? };
    (!bits.is_null()).then_some((bmp, bits as *mut u8))
}

fn bitmap_info(w: i32, h: i32) -> BITMAPINFO {
    BITMAPINFO {
        bmiHeader: BITMAPINFOHEADER {
            biSize: size_of::<BITMAPINFOHEADER>() as u32,
            biWidth: w,
            biHeight: -h,
            biPlanes: 1,
            biBitCount: 32,
            biCompression: BI_RGB.0,
            ..Default::default()
        },
        ..Default::default()
    }
}

/// Буфер кадра в памяти: DIB-секция, выбранная в совместимый DC
pub struct Surface {
    pub dc: HDC,
    bmp: HBITMAP,
    old: HGDIOBJ,
    bits: *mut u8,
    pub w: i32,
    pub h: i32,
}

impl Surface {
    pub fn new(w: i32, h: i32) -> Option<Surface> {
        unsafe {
            let screen = GetDC(None);
            let dc = CreateCompatibleDC(Some(screen));
            ReleaseDC(None, screen);
            let Some((bmp, bits)) = dib(dc, w, h) else {
                let _ = DeleteDC(dc);
                return None;
            };
            let old = SelectObject(dc, bmp.into());
            Some(Surface { dc, bmp, old, bits, w, h })
        }
    }

    pub fn data(&mut self) -> &mut [u8] {
        unsafe { std::slice::from_raw_parts_mut(self.bits, (self.w * self.h * 4) as usize) }
    }
}

impl Drop for Surface {
    fn drop(&mut self) {
        unsafe {
            SelectObject(self.dc, self.old);
            let _ = DeleteObject(self.bmp.into());
            let _ = DeleteDC(self.dc);
        }
    }
}

pub struct Monitor {
    pub rect: RECT,
    pub work: RECT,
    pub scale: f32,
}

fn monitor_scale(m: HMONITOR) -> f32 {
    let (mut x, mut y) = (96u32, 96u32);
    unsafe {
        let _ = GetDpiForMonitor(m, MDT_EFFECTIVE_DPI, &mut x, &mut y);
    }
    x as f32 / 96.0
}

pub fn cursor() -> POINT {
    let mut p = POINT::default();
    unsafe {
        let _ = GetCursorPos(&mut p);
    }
    p
}

pub fn monitor_at(p: POINT) -> Monitor {
    unsafe {
        let m = MonitorFromPoint(p, MONITOR_DEFAULTTONEAREST);
        let mut mi = MONITORINFO { cbSize: size_of::<MONITORINFO>() as u32, ..Default::default() };
        let _ = GetMonitorInfoW(m, &mut mi);
        Monitor { rect: mi.rcMonitor, work: mi.rcWork, scale: monitor_scale(m) }
    }
}

pub fn wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(Some(0)).collect()
}

pub fn pcwstr(v: &[u16]) -> PCWSTR {
    PCWSTR(v.as_ptr())
}

/// Иконка exe нужного размера в виде картинки
pub fn exe_icon(path: &str, px: u32) -> Option<Img> {
    let p = wide(path);
    let mut big = HICON::default();
    unsafe {
        SHDefExtractIconW(pcwstr(&p), 0, 0, Some(&mut big), None, px).ok().ok()?;
        if big.is_invalid() {
            return None;
        }
        let img = icon_img(big);
        let _ = DestroyIcon(big);
        img
    }
}

fn icon_img(icon: HICON) -> Option<Img> {
    unsafe {
        let mut ii = ICONINFO::default();
        GetIconInfo(icon, &mut ii).ok()?;
        let free = |ii: &ICONINFO| {
            let _ = DeleteObject(ii.hbmColor.into());
            let _ = DeleteObject(ii.hbmMask.into());
        };
        if ii.hbmColor.is_invalid() {
            free(&ii);
            return None;
        }
        let mut bm = BITMAP::default();
        GetObjectW(ii.hbmColor.into(), size_of::<BITMAP>() as i32, Some(&mut bm as *mut _ as *mut c_void));
        let (w, h) = (bm.bmWidth, bm.bmHeight);
        let mut img = Img::new(w.max(1) as u32, h.max(1) as u32);
        let mut bi = bitmap_info(w, h);
        let dc = GetDC(None);
        let got = GetDIBits(dc, ii.hbmColor, 0, h as u32, Some(img.px.as_mut_ptr() as *mut c_void), &mut bi, DIB_RGB_COLORS);
        ReleaseDC(None, dc);
        free(&ii);
        if got == 0 {
            return None;
        }
        // у старых иконок без альфа-канала прозрачность только в маске — считаем их непрозрачными
        if img.px.chunks_exact(4).all(|p| p[3] == 0) {
            for p in img.px.chunks_exact_mut(4) {
                p[3] = 255;
            }
        }
        for p in img.px.chunks_exact_mut(4) {
            let a = p[3] as u32;
            for c in &mut p[..3] {
                *c = ((*c as u32 * a + 127) / 255) as u8;
            }
        }
        Some(img)
    }
}

/// Картинка → иконка для трея (иконкам нужна непремультиплицированная альфа)
pub fn hicon(img: &Img) -> HICON {
    let mut px = img.px.clone();
    for p in px.chunks_exact_mut(4) {
        let a = p[3] as u32;
        if a > 0 {
            for c in &mut p[..3] {
                *c = ((*c as u32 * 255 + a / 2) / a).min(255) as u8;
            }
        }
    }
    unsafe {
        let color = CreateBitmap(img.w as i32, img.h as i32, 1, 32, Some(px.as_ptr() as *const c_void));
        let mask = CreateBitmap(img.w as i32, img.h as i32, 1, 1, None);
        let info = ICONINFO { fIcon: true.into(), hbmColor: color, hbmMask: mask, ..Default::default() };
        let icon = CreateIconIndirect(&info).unwrap_or_default();
        let _ = DeleteObject(color.into());
        let _ = DeleteObject(mask.into());
        icon
    }
}

pub fn encode_png(img: &Img) -> Option<Vec<u8>> {
    let mut rgba = Vec::with_capacity(img.px.len());
    for p in img.px.chunks_exact(4) {
        let a = p[3] as u32;
        let un = |c: u8| if a == 0 { 0 } else { ((c as u32 * 255 + a / 2) / a).min(255) as u8 };
        rgba.extend_from_slice(&[un(p[2]), un(p[1]), un(p[0]), p[3]]);
    }
    let mut out = Vec::new();
    {
        let mut enc = png::Encoder::new(&mut out, img.w, img.h);
        enc.set_color(png::ColorType::Rgba);
        enc.set_depth(png::BitDepth::Eight);
        let mut wr = enc.write_header().ok()?;
        wr.write_image_data(&rgba).ok()?;
    }
    Some(out)
}
