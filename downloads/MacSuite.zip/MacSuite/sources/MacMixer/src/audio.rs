//! Core Audio: устройства вывода и ввода, их громкость и уровень, громкость приложений

use std::cell::RefCell;
use std::collections::HashMap;
use std::ffi::c_void;

use windows::core::{Interface, GUID, HRESULT, IUnknown, PCWSTR, PWSTR};
use windows::Win32::Foundation::*;
use windows::Win32::Media::Audio::Endpoints::{IAudioEndpointVolume, IAudioMeterInformation};
use windows::Win32::Media::Audio::*;
use windows::Win32::Storage::FileSystem::{GetFileVersionInfoSizeW, GetFileVersionInfoW, VerQueryValueW};
use windows::Win32::System::Com::*;
use windows::Win32::System::Threading::{OpenProcess, QueryFullProcessImageNameW, PROCESS_NAME_WIN32, PROCESS_QUERY_LIMITED_INFORMATION};
use windows::Win32::UI::Shell::PropertiesSystem::IPropertyStore;

use crate::gfx::Img;
use crate::win::{self, pcwstr, wide};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Flow {
    Out,
    In,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Target {
    Out,
    In,
    App(usize),
}

#[derive(Clone, Copy, PartialEq)]
pub enum Kind {
    Speakers,
    Headphones,
    Display,
    Mic,
}

pub struct Device {
    pub id: String,
    pub name: String,
    pub detail: String,
    pub kind: Kind,
    vol: Option<IAudioEndpointVolume>,
    meter: Option<IAudioMeterInformation>,
    pub volume: f32,
    pub muted: bool,
    pub peak: f32,
}

pub struct App {
    pub key: String,
    pub name: String,
    pub icon: Option<Img>,
    pub system: bool,
    /// у одной программы бывает несколько сессий (вкладки браузера и т. п.) — управляем ими вместе
    sessions: Vec<(ISimpleAudioVolume, Option<IAudioMeterInformation>)>,
    pub volume: f32,
    pub muted: bool,
    pub peak: f32,
}

pub struct Audio {
    en: IMMDeviceEnumerator,
    pub outputs: Vec<Device>,
    pub inputs: Vec<Device>,
    pub out_default: Option<usize>,
    pub in_default: Option<usize>,
    pub apps: Vec<App>,
    /// путь exe → имя и иконка, чтобы не читать их заново каждую секунду
    known: HashMap<String, (String, Option<Img>)>,
    icon_px: u32,
}

thread_local! {
    static AUDIO: RefCell<Option<Audio>> = const { RefCell::new(None) };
}

pub fn init() -> bool {
    let a = Audio::new();
    let ok = a.is_some();
    AUDIO.with(|s| *s.borrow_mut() = a);
    ok
}

pub fn with<R>(f: impl FnOnce(&mut Audio) -> R) -> Option<R> {
    AUDIO.with(|s| s.try_borrow_mut().ok()?.as_mut().map(f))
}

// ключи свойств устройства (functiondiscoverykeys_devpkey.h, mmdeviceapi.h)
const PKEY_DEVICE_FRIENDLY_NAME: PROPERTYKEY = key(0xa45c254e_df1c_4efd_8020_67d146a850e0, 14);
const PKEY_DEVICE_DESC: PROPERTYKEY = key(0xa45c254e_df1c_4efd_8020_67d146a850e0, 2);
const PKEY_INTERFACE_FRIENDLY_NAME: PROPERTYKEY = key(0x026e516e_b814_414b_83cd_856d6fef4822, 2);
const PKEY_FORM_FACTOR: PROPERTYKEY = key(0x1da5d803_d492_4edd_8c23_e0c0ffee7f0e, 0);

const fn key(g: u128, pid: u32) -> PROPERTYKEY {
    PROPERTYKEY { fmtid: GUID::from_u128(g), pid }
}

fn take(p: PWSTR) -> String {
    if p.is_null() {
        return String::new();
    }
    unsafe {
        let s = p.to_string().unwrap_or_default();
        CoTaskMemFree(Some(p.0 as *const c_void));
        s
    }
}

fn prop_str(store: &IPropertyStore, k: &PROPERTYKEY) -> String {
    unsafe { store.GetValue(k).map(|v| v.to_string()).unwrap_or_default() }
}

fn prop_u32(store: &IPropertyStore, k: &PROPERTYKEY) -> Option<u32> {
    unsafe { store.GetValue(k).ok().and_then(|v| u32::try_from(&v).ok()) }
}

impl Audio {
    fn new() -> Option<Audio> {
        let en: IMMDeviceEnumerator = unsafe { CoCreateInstance(&MMDeviceEnumerator, None, CLSCTX_ALL).ok()? };
        let mut a = Audio {
            en,
            outputs: Vec::new(),
            inputs: Vec::new(),
            out_default: None,
            in_default: None,
            apps: Vec::new(),
            known: HashMap::new(),
            icon_px: 32,
        };
        a.refresh_devices();
        Some(a)
    }

    /// Полное перечитывание: устройства и приложения; icon_px — размер иконок программ
    pub fn refresh(&mut self, icon_px: u32) {
        if icon_px != self.icon_px {
            self.icon_px = icon_px;
            self.known.clear();
        }
        self.refresh_devices();
        self.apps = self.sessions();
        self.poll();
    }

    pub fn refresh_devices(&mut self) {
        self.outputs = self.devices(eRender);
        self.inputs = self.devices(eCapture);
        self.out_default = self.default_index(eRender);
        self.in_default = self.default_index(eCapture);
        self.poll_devices();
    }

    fn default_id(&self, flow: EDataFlow) -> Option<String> {
        unsafe { self.en.GetDefaultAudioEndpoint(flow, eConsole).ok().and_then(|d| d.GetId().ok()).map(take) }
    }

    fn default_index(&self, flow: EDataFlow) -> Option<usize> {
        let id = self.default_id(flow)?;
        let list = if flow == eRender { &self.outputs } else { &self.inputs };
        list.iter().position(|d| d.id == id)
    }

    /// Дешёвая проверка для трея: не сменилось ли устройство по умолчанию
    pub fn check_default(&mut self) {
        let id = self.default_id(eRender);
        let cur = self.out_default.and_then(|i| self.outputs.get(i)).map(|d| d.id.clone());
        if id != cur {
            self.refresh_devices();
        } else if let Some(i) = self.out_default {
            poll_device(&mut self.outputs[i]);
        }
    }

    fn devices(&self, flow: EDataFlow) -> Vec<Device> {
        let mut out = Vec::new();
        unsafe {
            let Ok(col) = self.en.EnumAudioEndpoints(flow, DEVICE_STATE_ACTIVE) else { return out };
            for i in 0..col.GetCount().unwrap_or(0) {
                if let Ok(d) = col.Item(i) {
                    out.push(device(&d, flow));
                }
            }
        }
        out
    }

    fn sessions(&mut self) -> Vec<App> {
        let mut apps: Vec<App> = Vec::new();
        unsafe {
            let Ok(dev) = self.en.GetDefaultAudioEndpoint(eRender, eConsole) else { return apps };
            let Ok(mgr) = dev.Activate::<IAudioSessionManager2>(CLSCTX_ALL, None) else { return apps };
            let Ok(list) = mgr.GetSessionEnumerator() else { return apps };
            for i in 0..list.GetCount().unwrap_or(0) {
                let Ok(ctl) = list.GetSession(i) else { continue };
                if ctl.GetState() == Ok(AudioSessionStateExpired) {
                    continue;
                }
                let Ok(ctl2) = ctl.cast::<IAudioSessionControl2>() else { continue };
                let Ok(vol) = ctl.cast::<ISimpleAudioVolume>() else { continue };
                let meter = ctl.cast::<IAudioMeterInformation>().ok();
                let system = ctl2.IsSystemSoundsSession() == S_OK;
                let pid = ctl2.GetProcessId().unwrap_or(0);
                let path = if system { None } else { process_path(pid) };
                let key = match (&path, system) {
                    (_, true) => "system".to_string(),
                    (Some(p), _) => p.to_lowercase(),
                    (None, _) => format!("pid:{pid}"),
                };
                if let Some(app) = apps.iter_mut().find(|a| a.key == key) {
                    app.sessions.push((vol, meter));
                    continue;
                }
                let shown = take(ctl.GetDisplayName().unwrap_or(PWSTR::null()));
                let (name, icon) = if system {
                    ("Системные звуки".to_string(), None)
                } else if let Some(p) = &path {
                    let px = self.icon_px;
                    self.known.entry(key.clone()).or_insert_with(|| (app_name(p), win::exe_icon(p, px))).clone()
                } else {
                    (String::new(), None)
                };
                // своё имя сессии есть у немногих программ, и часто это ссылка на ресурс вида «@%SystemRoot%…»
                let name = if !shown.is_empty() && !shown.starts_with('@') && !system { shown } else { name };
                let name = if name.is_empty() { format!("Процесс {pid}") } else { name };
                apps.push(App { key, name, icon, system, sessions: vec![(vol, meter)], volume: 1.0, muted: false, peak: 0.0 });
            }
        }
        apps.sort_by(|a, b| a.system.cmp(&b.system).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase())));
        apps
    }

    /// Свежие громкость, mute и уровень для всего, что уже найдено
    pub fn poll(&mut self) {
        self.poll_devices();
        for app in &mut self.apps {
            let (mut vol, mut muted, mut peak) = (0f32, true, 0f32);
            for (v, m) in &app.sessions {
                unsafe {
                    vol = vol.max(v.GetMasterVolume().unwrap_or(0.0));
                    muted &= v.GetMute().map(|b| b.as_bool()).unwrap_or(false);
                    if let Some(m) = m {
                        peak = peak.max(m.GetPeakValue().unwrap_or(0.0));
                    }
                }
            }
            (app.volume, app.muted, app.peak) = (vol, muted, peak);
        }
    }

    fn poll_devices(&mut self) {
        for d in self.outputs.iter_mut().chain(self.inputs.iter_mut()) {
            poll_device(d);
        }
    }

    pub fn output(&self) -> Option<&Device> {
        self.out_default.and_then(|i| self.outputs.get(i))
    }

    pub fn input(&self) -> Option<&Device> {
        self.in_default.and_then(|i| self.inputs.get(i))
    }

    /// (громкость, выключен ли звук, текущий уровень)
    pub fn level(&self, t: Target) -> Option<(f32, bool, f32)> {
        match t {
            Target::Out => self.output().map(|d| (d.volume, d.muted, d.peak)),
            Target::In => self.input().map(|d| (d.volume, d.muted, d.peak)),
            Target::App(i) => self.apps.get(i).map(|a| (a.volume, a.muted, a.peak)),
        }
    }

    pub fn set_volume(&mut self, t: Target, v: f32) {
        let v = v.clamp(0.0, 1.0);
        unsafe {
            match t {
                Target::Out | Target::In => {
                    let i = if t == Target::Out { self.out_default } else { self.in_default };
                    let list = if t == Target::Out { &mut self.outputs } else { &mut self.inputs };
                    let Some(d) = i.and_then(|i| list.get_mut(i)) else { return };
                    if let Some(vol) = &d.vol {
                        let _ = vol.SetMasterVolumeLevelScalar(v, std::ptr::null());
                    }
                    d.volume = v;
                }
                Target::App(i) => {
                    let Some(app) = self.apps.get_mut(i) else { return };
                    for (s, _) in &app.sessions {
                        let _ = s.SetMasterVolume(v, std::ptr::null());
                    }
                    app.volume = v;
                }
            }
        }
    }

    pub fn set_muted(&mut self, t: Target, on: bool) {
        unsafe {
            match t {
                Target::Out | Target::In => {
                    let i = if t == Target::Out { self.out_default } else { self.in_default };
                    let list = if t == Target::Out { &mut self.outputs } else { &mut self.inputs };
                    let Some(d) = i.and_then(|i| list.get_mut(i)) else { return };
                    if let Some(vol) = &d.vol {
                        let _ = vol.SetMute(on, std::ptr::null());
                    }
                    d.muted = on;
                }
                Target::App(i) => {
                    let Some(app) = self.apps.get_mut(i) else { return };
                    for (s, _) in &app.sessions {
                        let _ = s.SetMute(on, std::ptr::null());
                    }
                    app.muted = on;
                }
            }
        }
    }

    /// Сделать устройство основным для всех ролей — как выбор в «Параметрах звука»
    pub fn set_default(&mut self, flow: Flow, i: usize) {
        let list = if flow == Flow::Out { &self.outputs } else { &self.inputs };
        let Some(d) = list.get(i) else { return };
        set_default_endpoint(&d.id);
        self.refresh(self.icon_px);
    }
}

fn device(d: &IMMDevice, flow: EDataFlow) -> Device {
    unsafe {
        let id = d.GetId().map(take).unwrap_or_default();
        let (mut name, mut detail, mut ff) = (String::new(), String::new(), None);
        if let Ok(store) = d.OpenPropertyStore(STGM_READ) {
            // «Динамики» + «Realtek(R) Audio» вместо слитного «Динамики (Realtek(R) Audio)»
            name = prop_str(&store, &PKEY_DEVICE_DESC);
            detail = prop_str(&store, &PKEY_INTERFACE_FRIENDLY_NAME);
            if name.is_empty() {
                name = prop_str(&store, &PKEY_DEVICE_FRIENDLY_NAME);
            }
            ff = prop_u32(&store, &PKEY_FORM_FACTOR);
        }
        let kind = if flow == eCapture {
            Kind::Mic
        } else {
            match ff {
                Some(3) | Some(5) => Kind::Headphones,
                Some(9) => Kind::Display,
                _ => Kind::Speakers,
            }
        };
        Device {
            id,
            name,
            detail,
            kind,
            vol: d.Activate::<IAudioEndpointVolume>(CLSCTX_ALL, None).ok(),
            meter: d.Activate::<IAudioMeterInformation>(CLSCTX_ALL, None).ok(),
            volume: 0.0,
            muted: false,
            peak: 0.0,
        }
    }
}

fn poll_device(d: &mut Device) {
    unsafe {
        if let Some(v) = &d.vol {
            d.volume = v.GetMasterVolumeLevelScalar().unwrap_or(d.volume);
            d.muted = v.GetMute().map(|b| b.as_bool()).unwrap_or(d.muted);
        }
        d.peak = d.meter.as_ref().and_then(|m| m.GetPeakValue().ok()).unwrap_or(0.0);
    }
}

fn process_path(pid: u32) -> Option<String> {
    if pid == 0 {
        return None;
    }
    unsafe {
        let h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid).ok()?;
        let mut buf = vec![0u16; 1024];
        let mut len = buf.len() as u32;
        let ok = QueryFullProcessImageNameW(h, PROCESS_NAME_WIN32, PWSTR(buf.as_mut_ptr()), &mut len).is_ok();
        let _ = CloseHandle(h);
        ok.then(|| String::from_utf16_lossy(&buf[..len as usize]))
    }
}

/// Человеческое имя программы: «Описание файла» из ресурсов exe, иначе имя файла
fn app_name(path: &str) -> String {
    let stem = std::path::Path::new(path).file_stem().map(|s| s.to_string_lossy().to_string()).unwrap_or_default();
    let desc = file_description(path).unwrap_or_default();
    let desc = desc.trim();
    if desc.is_empty() {
        let mut c = stem.chars();
        c.next().map(|f| f.to_uppercase().collect::<String>() + c.as_str()).unwrap_or_default()
    } else {
        desc.to_string()
    }
}

fn file_description(path: &str) -> Option<String> {
    let p = wide(path);
    unsafe {
        let size = GetFileVersionInfoSizeW(pcwstr(&p), None);
        if size == 0 {
            return None;
        }
        let mut data = vec![0u8; size as usize];
        GetFileVersionInfoW(pcwstr(&p), None, size, data.as_mut_ptr() as *mut c_void).ok()?;
        let mut ptr: *mut c_void = std::ptr::null_mut();
        let mut len = 0u32;
        let tr = wide("\\VarFileInfo\\Translation");
        let mut langs = Vec::new();
        if VerQueryValueW(data.as_ptr() as *const c_void, pcwstr(&tr), &mut ptr, &mut len).as_bool() && len >= 4 {
            let pairs = std::slice::from_raw_parts(ptr as *const u16, len as usize / 2);
            for c in pairs.chunks_exact(2) {
                langs.push(format!("{:04x}{:04x}", c[0], c[1]));
            }
        }
        langs.extend(["040904b0".to_string(), "040904e4".to_string(), "041904b0".to_string()]);
        for l in langs {
            let q = wide(&format!("\\StringFileInfo\\{l}\\FileDescription"));
            if VerQueryValueW(data.as_ptr() as *const c_void, pcwstr(&q), &mut ptr, &mut len).as_bool() && len > 1 {
                let s = std::slice::from_raw_parts(ptr as *const u16, len as usize - 1);
                let s = String::from_utf16_lossy(s).trim_end_matches('\0').trim().to_string();
                if !s.is_empty() {
                    return Some(s);
                }
            }
        }
        None
    }
}

/// IPolicyConfig не документирован, но именно им пользуется сама Windows; вызываем метод по номеру в таблице
fn set_default_endpoint(id: &str) {
    const CLSID_POLICY_CONFIG: GUID = GUID::from_u128(0x870af99c_171d_4f9e_af0d_e63df40c2bc9);
    const IID_POLICY_CONFIG: GUID = GUID::from_u128(0xf8679f50_850a_41cf_9c72_430f290290c8);
    // IUnknown (3) + 10 методов до SetDefaultEndpoint
    const SET_DEFAULT_ENDPOINT: usize = 13;
    type SetDefault = unsafe extern "system" fn(*mut c_void, PCWSTR, ERole) -> HRESULT;
    type Release = unsafe extern "system" fn(*mut c_void) -> u32;
    unsafe {
        let Ok(unk) = CoCreateInstance::<_, IUnknown>(&CLSID_POLICY_CONFIG, None, CLSCTX_ALL) else { return };
        let mut p: *mut c_void = std::ptr::null_mut();
        if unk.query(&IID_POLICY_CONFIG, &mut p).is_err() || p.is_null() {
            return;
        }
        let vtbl = *(p as *const *const usize);
        let set: SetDefault = std::mem::transmute(*vtbl.add(SET_DEFAULT_ENDPOINT));
        let w = wide(id);
        for role in [eConsole, eMultimedia, eCommunications] {
            let _ = set(p, pcwstr(&w), role);
        }
        let release: Release = std::mem::transmute(*vtbl.add(2));
        release(p);
    }
}
