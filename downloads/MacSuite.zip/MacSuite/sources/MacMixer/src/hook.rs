//! Клавиши громкости и музыки. Плашку Windows показывает сама система, отключить её настройкой нельзя,
//! поэтому низкоуровневый хук забирает нажатия раньше неё — дальше звуком управляет наша панель

use std::sync::atomic::{AtomicIsize, AtomicU32, Ordering};

use windows::Win32::Foundation::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::media;

/// wParam — код клавиши
pub const WM_MEDIA_KEY: u32 = WM_APP + 4;

static TARGET: AtomicIsize = AtomicIsize::new(0);
/// клавиши, нажатие которых мы забрали: их автоповтор и отпускание тоже не пропускаем в систему
static HELD: AtomicU32 = AtomicU32::new(0);

pub fn start(target: HWND) {
    TARGET.store(target.0 as isize, Ordering::SeqCst);
    // отдельный поток: если окно задумается, Windows не снимет хук по таймауту
    std::thread::spawn(|| unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let set = || SetWindowsHookExW(WH_KEYBOARD_LL, Some(proc), Some(inst.into()), 0).ok();
        let mut hook = set();
        // Windows молча снимает хук, если хоть раз не дождалась ответа (сон, нагрузка), — ставим заново
        SetTimer(None, 0, 5000, None);
        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).as_bool() {
            if msg.message == WM_TIMER && HELD.load(Ordering::SeqCst) == 0 {
                if let Some(fresh) = set() {
                    if let Some(old) = hook.replace(fresh) {
                        let _ = UnhookWindowsHookEx(old);
                    }
                }
            }
            DispatchMessageW(&msg);
        }
        if let Some(h) = hook {
            let _ = UnhookWindowsHookEx(h);
        }
    });
}

fn post(vk: u32) {
    let target = HWND(TARGET.load(Ordering::SeqCst) as *mut _);
    unsafe {
        let _ = PostMessageW(Some(target), WM_MEDIA_KEY, WPARAM(vk as usize), LPARAM(0));
    }
}

/// Бит клавиши в HELD, если у неё не должно быть автоповтора
fn single_shot(vk: u16) -> Option<u32> {
    match VIRTUAL_KEY(vk) {
        VK_VOLUME_MUTE => Some(1),
        VK_MEDIA_PLAY_PAUSE => Some(2),
        VK_MEDIA_NEXT_TRACK => Some(4),
        VK_MEDIA_PREV_TRACK => Some(8),
        VK_MEDIA_STOP => Some(16),
        _ => None,
    }
}

unsafe extern "system" fn proc(code: i32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    if code == HC_ACTION as i32 {
        let k = &*(lp.0 as *const KBDLLHOOKSTRUCT);
        let down = wp.0 as u32 == WM_KEYDOWN || wp.0 as u32 == WM_SYSKEYDOWN;
        let vk = k.vkCode as u16;
        // громкость держат зажатой — повторы как раз нужны
        if vk == VK_VOLUME_UP.0 || vk == VK_VOLUME_DOWN.0 {
            if down {
                post(k.vkCode);
            }
            return LRESULT(1);
        }
        if let Some(bit) = single_shot(vk) {
            let held = HELD.load(Ordering::SeqCst);
            if !down {
                if held & bit != 0 {
                    HELD.fetch_and(!bit, Ordering::SeqCst);
                    return LRESULT(1);
                }
            } else if held & bit != 0 {
                return LRESULT(1);
            } else if vk == VK_VOLUME_MUTE.0 || media::has_session() {
                // плеера нет в системном списке — клавишу пропускаем: старые плееры ловят её сами
                HELD.fetch_or(bit, Ordering::SeqCst);
                post(k.vkCode);
                return LRESULT(1);
            }
        }
    }
    CallNextHookEx(None, code, wp, lp)
}
