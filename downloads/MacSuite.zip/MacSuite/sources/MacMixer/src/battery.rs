//! Заряд Bluetooth-наушников и других устройств — то же число, что показывает «Параметры → Bluetooth».
//! Карточка в «островке», когда устройство подключилось, и когда заряд стал меньше 20%.

use std::collections::HashMap;
use std::time::Duration;

use windows::core::{GUID, PCWSTR};
use windows::Win32::Devices::DeviceAndDriverInstallation::*;
use windows::Win32::Devices::Properties::*;
use windows::Win32::Foundation::DEVPROPKEY;

use crate::island::{self, Action, Art, Item};
use crate::notify;

/// Уровень заряда, который Windows хранит у устройства (байт, проценты)
const BATTERY: DEVPROPKEY = DEVPROPKEY { fmtid: GUID::from_u128(0x104ea319_6ee2_4701_bd47_8ddbf425bbe5), pid: 2 };

/// Подключённые устройства с известным зарядом: имя и проценты
pub fn devices() -> Vec<(String, u8)> {
    let mut out: Vec<(String, u8)> = Vec::new();
    unsafe {
        let Ok(set) = SetupDiGetClassDevsW(None, PCWSTR::null(), None, DIGCF_ALLCLASSES | DIGCF_PRESENT) else { return out };
        let mut i = 0;
        loop {
            let mut data = SP_DEVINFO_DATA { cbSize: std::mem::size_of::<SP_DEVINFO_DATA>() as u32, ..Default::default() };
            if SetupDiEnumDeviceInfo(set, i, &mut data).is_err() {
                break;
            }
            i += 1;
            let mut ty = DEVPROPTYPE(0);
            let mut level = [0u8; 1];
            if SetupDiGetDevicePropertyW(set, &data, &BATTERY, &mut ty, Some(&mut level), None, 0).is_err() || ty != DEVPROP_TYPE_BYTE {
                continue;
            }
            let mut name = [0u8; 512];
            let mut nty = DEVPROPTYPE(0);
            let mut size = 0u32;
            let got = SetupDiGetDevicePropertyW(set, &data, &DEVPKEY_NAME, &mut nty, Some(&mut name), Some(&mut size), 0).is_ok();
            let name = if got {
                let u: Vec<u16> = name[..size as usize].chunks_exact(2).map(|c| u16::from_le_bytes([c[0], c[1]])).take_while(|c| *c != 0).collect();
                String::from_utf16_lossy(&u)
            } else {
                "Наушники".into()
            };
            // у наушников несколько узлов (звук, гарнитура, кнопки) с одним и тем же зарядом
            if !out.iter().any(|(n, _)| *n == name) && level[0] <= 100 {
                out.push((name, level[0]));
            }
        }
        let _ = SetupDiDestroyDeviceInfoList(set);
    }
    out
}

fn card(title: String, body: String) {
    island::send(Item { art: Art::Glyph('\u{E7F6}'), title, body, source: "Bluetooth".into(), action: Action::None, hold_ms: 3500 });
}

/// Раз в минуту: кто подключился и у кого садится заряд
pub fn start() {
    std::thread::spawn(|| {
        // устройства, подключённые до запуска, без карточек — только новые
        let mut seen: HashMap<String, u8> = devices().into_iter().collect();
        let mut warned: HashMap<String, bool> = HashMap::new();
        loop {
            std::thread::sleep(Duration::from_secs(60));
            let now = devices();
            let on = notify::options().battery;
            for (name, level) in &now {
                if on && !seen.contains_key(name) {
                    card(name.clone(), format!("Подключено · заряд {level}%"));
                }
                let low = *level <= 20;
                if low && on && !warned.get(name).copied().unwrap_or(false) {
                    card("Низкий заряд".into(), format!("{name} · {level}%"));
                    warned.insert(name.clone(), true);
                } else if *level > 30 {
                    warned.insert(name.clone(), false);
                }
            }
            seen = now.into_iter().collect();
        }
    });
}

/// --preview battery out.txt: сколько устройств сообщают заряд (без имён)
pub fn check() -> String {
    let list = devices();
    let levels: Vec<String> = list.iter().map(|(_, l)| format!("{l}%")).collect();
    format!("устройств с зарядом: {} {:?}", list.len(), levels)
}
