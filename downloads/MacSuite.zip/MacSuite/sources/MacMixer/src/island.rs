//! «Островок» сверху по центру: короткие события — сообщения, загрузки, смена трека и устройства.
//! Как и панель музыки, фокус не забирает; если панель открыта, островок встаёт под ней

use std::cell::RefCell;
use std::collections::VecDeque;
use std::path::PathBuf;
use std::sync::atomic::{AtomicIsize, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use windows::core::{w, HSTRING, PCWSTR};
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Shell::{SHQueryUserNotificationState, ShellExecuteW, QUNS_ACCEPTS_NOTIFICATIONS};
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::gfx::{self, Fonts, Img};
use crate::win::{self, Surface};
use crate::{music, panel};

pub const WM_ISLAND: u32 = WM_APP + 5;

const M: f32 = 28.0;
const TOP: f32 = 12.0;
const W: f32 = 440.0;
const H1: f32 = 66.0;
const H2: f32 = 86.0;
const ICON: f32 = 40.0;
const TIMER: usize = 1;
const OPEN_MS: f32 = 240.0;
const CLOSE_MS: f32 = 140.0;

pub enum Art {
    Glyph(char),
    Image(Arc<Img>),
}

pub enum Action {
    None,
    /// открыть приложение по его идентификатору
    App(String),
    /// показать файл в папке
    Reveal(PathBuf),
}

pub struct Item {
    pub art: Art,
    pub title: String,
    pub body: String,
    /// подпись справа: от кого уведомление
    pub source: String,
    pub action: Action,
    pub hold_ms: u64,
}

static QUEUE: Mutex<VecDeque<Item>> = Mutex::new(VecDeque::new());
static MAIN: AtomicIsize = AtomicIsize::new(0);

/// Положить событие в очередь (из любого потока)
pub fn send(item: Item) {
    if let Ok(mut q) = QUEUE.lock() {
        if q.len() >= 8 {
            q.pop_front();
        }
        q.push_back(item);
    }
    let h = HWND(MAIN.load(Ordering::SeqCst) as *mut _);
    if !h.is_invalid() {
        unsafe {
            let _ = PostMessageW(Some(h), WM_ISLAND, WPARAM(0), LPARAM(0));
        }
    }
}

struct Island {
    hwnd: HWND,
    item: Item,
    lines: Vec<String>,
    scale: f32,
    work: RECT,
    opened: Instant,
    closing: Option<Instant>,
    hide_at: Instant,
    rect: RECT,
    hover: bool,
    base: Option<Img>,
}

thread_local! {
    static ISLAND: RefCell<Option<Island>> = const { RefCell::new(None) };
}

fn with<R>(f: impl FnOnce(&mut Island) -> R) -> Option<R> {
    ISLAND.with(|s| s.try_borrow_mut().ok()?.as_mut().map(f))
}

pub fn init(main: HWND) {
    MAIN.store(main.0 as isize, Ordering::SeqCst);
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacMixer.Island"),
            hCursor: LoadCursorW(None, IDC_HAND).unwrap_or_default(),
            ..Default::default()
        };
        RegisterClassW(&wc);
    }
}

/// В игре или полноэкранном видео не мешаем. Состояние системы общее на все мониторы, поэтому
/// дополнительно смотрим, занят ли полным экраном именно тот монитор, где появится карточка
fn quiet() -> bool {
    unsafe {
        if SHQueryUserNotificationState().is_ok_and(|s| s == QUNS_ACCEPTS_NOTIFICATIONS) {
            return false;
        }
        let fg = GetForegroundWindow();
        if fg.is_invalid() {
            return false;
        }
        // рабочий стол тоже занимает весь экран, но это не игра
        let mut class = [0u16; 32];
        let n = GetClassNameW(fg, &mut class).max(0) as usize;
        let class = String::from_utf16_lossy(&class[..n]);
        if class == "Progman" || class == "WorkerW" {
            return false;
        }
        let mut r = RECT::default();
        if GetWindowRect(fg, &mut r).is_err() {
            return false;
        }
        let m = win::monitor_at(win::cursor()).rect;
        r.left <= m.left && r.top <= m.top && r.right >= m.right && r.bottom >= m.bottom
    }
}

/// Показать следующее событие, если сейчас ничего не показано
pub fn pump() {
    if ISLAND.with(|s| s.try_borrow().map(|i| i.is_some()).unwrap_or(true)) {
        return;
    }
    if quiet() {
        if let Ok(mut q) = QUEUE.lock() {
            q.clear();
        }
        return;
    }
    let Some(item) = QUEUE.lock().ok().and_then(|mut q| q.pop_front()) else { return };
    let mon = win::monitor_at(win::cursor());
    let s = mon.scale;
    let lines = panel::with_fonts(|f| body_lines(f, &item, s)).unwrap_or_default();
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let Ok(hwnd) = CreateWindowExW(
            WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
            w!("MacMixer.Island"),
            w!("Уведомление"),
            WS_POPUP,
            mon.work.left,
            mon.work.top,
            1,
            1,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        let now = Instant::now();
        let hide_at = now + Duration::from_millis(item.hold_ms);
        let i = Island {
            hwnd,
            item,
            lines,
            scale: s,
            work: mon.work,
            opened: now,
            closing: None,
            hide_at,
            rect: RECT::default(),
            hover: false,
            base: None,
        };
        ISLAND.with(|c| *c.borrow_mut() = Some(i));
        frame();
        let _ = ShowWindow(hwnd, SW_SHOWNOACTIVATE);
        SetTimer(Some(hwnd), TIMER, 16, None);
    }
}

fn close() {
    let i = ISLAND.with(|s| s.try_borrow_mut().ok().and_then(|mut i| i.take()));
    if let Some(i) = i {
        unsafe {
            let _ = DestroyWindow(i.hwnd);
        }
    }
    pump();
}

fn body_lines(f: &Fonts, item: &Item, s: f32) -> Vec<String> {
    let max = (W - 88.0) * s;
    let px = 13.0 * s;
    let mut out: Vec<String> = Vec::new();
    let mut cur = String::new();
    let mut words = item.body.split_whitespace().peekable();
    while let Some(word) = words.next() {
        let t = if cur.is_empty() { word.to_string() } else { format!("{cur} {word}") };
        if gfx::measure(&f.regular, &t, px) <= max || cur.is_empty() {
            cur = t;
            continue;
        }
        if out.len() == 1 {
            // вторая строка последняя: остальное под многоточие
            let rest = std::iter::once(cur.as_str()).chain(std::iter::once(word)).chain(words).collect::<Vec<_>>().join(" ");
            out.push(gfx::fit(&f.regular, &rest, px, max));
            return out;
        }
        out.push(std::mem::take(&mut cur));
        cur = word.to_string();
    }
    if !cur.is_empty() {
        out.push(gfx::fit(&f.regular, &cur, px, max));
    }
    out
}

fn ease(k: f32) -> f32 {
    let k = k.clamp(0.0, 1.0);
    1.0 - (1.0 - k).powi(3)
}

fn height(lines: usize) -> f32 {
    if lines > 1 {
        H2
    } else {
        H1
    }
}

fn card(iw: u32, ih: u32, s: f32, width: f32, ph: f32) -> Img {
    let mut img = Img::new(iw, ih);
    if let Some(mut pm) = img.pixmap_mut() {
        let o = M * s;
        let (pw, x, r) = (width * s, o + (W - width) / 2.0 * s, gfx::window_radius() * s);
        gfx::shadow(&mut pm, x, o + 4.0 * s, pw, ph * s, 22.0 * s, 0.5);
        gfx::fill_rrect(&mut pm, x, o, pw, ph * s, r, gfx::panel(1.0));
        gfx::stroke_rrect(&mut pm, x + 0.5, o + 0.5, pw - 1.0, ph * s - 1.0, r, 1.0, gfx::white(0.12));
    }
    img
}

/// Содержимое: значок, заголовок, источник и текст. a — прозрачность содержимого при раскрытии
fn render(item: &Item, lines: &[String], f: &Fonts, s: f32, k: f32, hover: bool, base: &mut Option<Img>) -> Img {
    let ph = height(lines.len());
    let (iw, ih) = (((W + 2.0 * M) * s).ceil() as u32, ((ph + 2.0 * M) * s).ceil() as u32);
    // пока раскрывается, карточка становится шире; потом подложка не меняется
    let width = W * (0.62 + 0.38 * k);
    let mut img = match base {
        Some(b) if k >= 1.0 && b.w == iw && b.h == ih => b.clone(),
        _ => {
            let b = card(iw, ih, s, width, ph);
            if k >= 1.0 {
                *base = Some(b.clone());
            }
            b
        }
    };
    let a = ((k - 0.55) / 0.45).clamp(0.0, 1.0);
    if a <= 0.0 {
        return img;
    }
    if let Some(mut pm) = img.pixmap_mut() {
        let o = M * s;
        let x = |v: f32| o + v * s;
        let d = |v: f32| v * s;
        let iy = (ph - ICON) / 2.0;
        match &item.art {
            Art::Image(art) => gfx::image_round(&mut pm, art, x(14.0), x(iy), d(ICON), d(gfx::window_radius() / 2.0)),
            Art::Glyph(ch) => {
                gfx::fill_rrect(&mut pm, x(14.0), x(iy), d(ICON), d(ICON), 0.0, gfx::accent(a));
                gfx::glyph(&mut pm, *ch, x(14.0 + ICON / 2.0), x(iy + ICON / 2.0), d(20.0), gfx::on_accent(a));
            }
        }
        let tx = 68.0;
        let right = W - 14.0;
        let sw = gfx::measure(&f.regular, &item.source, 12.0 * s) / s;
        if hover {
            gfx::glyph(&mut pm, '\u{E8BB}', x(right - 6.0), x(16.0), d(11.0), gfx::white(0.7 * a));
        } else if !item.source.is_empty() {
            gfx::text(&mut pm, &f.regular, &item.source, x(right - sw), x(24.0), 12.0 * s, gfx::white(0.5 * a));
        }
        let room = right - tx - if item.source.is_empty() { 16.0 } else { sw + 10.0 };
        let title = gfx::fit(&f.semibold, &item.title, 15.0 * s, d(room));
        let top = if lines.is_empty() { (ph + 10.0) / 2.0 } else { 25.0 };
        gfx::text(&mut pm, &f.semibold, &title, x(tx), x(top), 15.0 * s, gfx::white(0.96 * a));
        for (i, l) in lines.iter().enumerate() {
            gfx::text(&mut pm, &f.regular, l, x(tx), x(45.0 + i as f32 * 19.0), 13.0 * s, gfx::white(0.68 * a));
        }
    }
    img
}

fn frame() {
    let bottom = music::bottom();
    with(|i| {
        panel::with_fonts(|f| {
            let s = i.scale;
            let k = match i.closing {
                Some(c) => 1.0 - ease(c.elapsed().as_millis() as f32 / CLOSE_MS),
                None => ease(i.opened.elapsed().as_millis() as f32 / OPEN_MS),
            };
            let img = render(&i.item, &i.lines, f, s, if i.closing.is_some() { 1.0 } else { k }, i.hover, &mut i.base);
            let ph = height(i.lines.len());
            let o = M * s;
            let x = (i.work.left + i.work.right) as f32 / 2.0 - W * s / 2.0;
            let y = bottom.map_or(i.work.top as f32 + TOP * s, |b| b as f32 + 8.0 * s);
            let dy = -(1.0 - k) * 14.0 * s;
            i.rect = RECT { left: x as i32, top: y as i32, right: (x + W * s) as i32, bottom: (y + ph * s) as i32 };
            let Some(mut surf) = Surface::new(img.w as i32, img.h as i32) else { return };
            surf.data().copy_from_slice(&img.px);
            unsafe {
                let screen = GetDC(None);
                let pos = POINT { x: (x - o).round() as i32, y: (y - o + dy).round() as i32 };
                let size = SIZE { cx: img.w as i32, cy: img.h as i32 };
                let src = POINT::default();
                let blend = BLENDFUNCTION {
                    BlendOp: AC_SRC_OVER as u8,
                    SourceConstantAlpha: (k.clamp(0.0, 1.0) * 255.0) as u8,
                    AlphaFormat: AC_SRC_ALPHA as u8,
                    ..Default::default()
                };
                let _ = UpdateLayeredWindow(i.hwnd, Some(screen), Some(&pos), Some(&size), Some(surf.dc), Some(&src), COLORREF(0), Some(&blend), ULW_ALPHA);
                ReleaseDC(None, screen);
            }
        });
    });
}

fn run(action: &Action) {
    unsafe {
        match action {
            Action::None => {}
            Action::App(id) => {
                let target = HSTRING::from(format!("shell:AppsFolder\\{id}"));
                ShellExecuteW(None, w!("open"), &target, PCWSTR::null(), PCWSTR::null(), SW_SHOWNORMAL);
            }
            Action::Reveal(p) => {
                let args = HSTRING::from(format!("/select,\"{}\"", p.display()));
                ShellExecuteW(None, w!("open"), w!("explorer.exe"), &args, PCWSTR::null(), SW_SHOWNORMAL);
            }
        }
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_MOUSEACTIVATE => LRESULT(MA_NOACTIVATE as isize),
        WM_TIMER => {
            let done = with(|i| {
                let now = Instant::now();
                let p = win::cursor();
                let r = i.rect;
                let over = p.x >= r.left && p.x < r.right && p.y >= r.top && p.y < r.bottom;
                i.hover = over;
                if i.closing.is_none() {
                    if over {
                        i.hide_at = i.hide_at.max(now + Duration::from_millis(1200));
                    } else if now >= i.hide_at {
                        i.closing = Some(now);
                    }
                }
                i.closing.is_some_and(|c| c.elapsed().as_millis() as f32 >= CLOSE_MS)
            })
            .unwrap_or(false);
            if done {
                close();
            } else {
                frame();
            }
            LRESULT(0)
        }
        WM_LBUTTONUP => {
            // крестик в правом верхнем углу только закрывает, остальная карточка открывает источник
            let x = (lp.0 & 0xFFFF) as i16 as f32;
            let y = ((lp.0 >> 16) & 0xFFFF) as i16 as f32;
            with(|i| {
                let (lx, ly) = (x / i.scale - M, y / i.scale - M);
                if !(lx > W - 34.0 && ly < 32.0) {
                    run(&i.item.action);
                }
                i.closing = Some(Instant::now());
            });
            LRESULT(0)
        }
        WM_RBUTTONUP => {
            with(|i| i.closing = Some(Instant::now()));
            LRESULT(0)
        }
        WM_CLOSE => {
            close();
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

/// Картинка для проверки вёрстки
pub fn preview(item: &Item) -> Option<Img> {
    let f = Fonts::load()?;
    let lines = body_lines(&f, item, 1.0);
    let mut base = None;
    Some(render(item, &lines, &f, 1.0, 1.0, false, &mut base))
}
