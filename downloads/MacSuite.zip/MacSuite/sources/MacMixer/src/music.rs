//! Панель «Сейчас играет» по центру сверху экрана — замена плашки Windows, что появляется слева
//! при нажатии клавиш громкости и музыки. Фокус не забирает: окно, в котором работаете, остаётся активным

use std::cell::RefCell;
use std::collections::hash_map::DefaultHasher;
use std::hash::{Hash, Hasher};
use std::sync::Arc;
use std::time::{Duration, Instant};

use tiny_skia::PixmapMut;
use windows::core::w;
use windows::Win32::Foundation::*;
use windows::Win32::Graphics::Gdi::*;
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::UI::Controls::WM_MOUSELEAVE;
use windows::Win32::UI::Input::KeyboardAndMouse::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use crate::audio::{self, Target};
use crate::gfx::{self, Fonts, Icon, Img};
use crate::lyrics;
use crate::media::{self, Cmd, Track, TICKS};
use crate::panel;
use crate::win::{self, Surface};

const M: f32 = 28.0; // поле под тень
const TOP: f32 = 12.0; // отступ от верхнего края экрана
const TIMER: usize = 1;
const OPEN_MS: f32 = 170.0;
const CLOSE_MS: f32 = 130.0;
/// сколько панель висит после нажатия клавиши и после сочетания
const HOLD_KEY: u64 = 2800;
const HOLD_HOTKEY: u64 = 6000;
/// сколько ещё висит после того, как мышь ушла
const HOLD_HOVER: u64 = 1500;

// полная панель
const W: f32 = 520.0;
const H: f32 = 128.0;
const PAD: f32 = 12.0;
const ART: f32 = 104.0;
const TX: f32 = PAD + ART + 14.0;
const RIGHT: f32 = W - 16.0;
const BAR_Y: f32 = 70.0;
const BAR_X0: f32 = TX + 40.0;
const BAR_X1: f32 = RIGHT - 40.0;
const ROW: f32 = 84.0;
const VOL_W: f32 = 118.0;
const VOL_X1: f32 = RIGHT - 42.0;
const VOL_X0: f32 = VOL_X1 - VOL_W;

// текст песни — в той же панели, под кнопками
const LH: f32 = 172.0;
/// размер и шаг строк текста, отступ слева
const LPX: f32 = 18.0;
const LSTEP: f32 = 25.0;
const LGAP: f32 = 11.0;
const LX: f32 = 20.0;
/// где на высоте текста держится середина текущей строки
const LANCHOR: f32 = 62.0;
/// опережение подсветки: звук доходит до ушей чуть позже, чем плеер сообщает позицию
const LLEAD: i64 = TICKS / 6;
/// после ручной прокрутки текст ещё столько ждёт, прежде чем вернуться к текущей строке
const LMANUAL: Duration = Duration::from_millis(3500);

// только громкость: нажали клавишу, а музыка не играет
const CW: f32 = 380.0;
const CH: f32 = 60.0;
const CX0: f32 = 54.0;
const CX1: f32 = CW - 58.0;

#[derive(Clone, Copy, PartialEq, Hash)]
enum Hit {
    Prev,
    Toggle,
    Next,
    Seek,
    Volume,
    Mute,
    App,
    Lyrics,
}

#[derive(Clone, Copy)]
struct Press {
    hit: Hit,
    /// доля полоски перемотки, пока её тянут
    seek: f32,
}

/// Строка текста, разбитая под ширину панели
struct Row {
    /// пустой список — точки в проигрыше перед первой строкой
    lines: Vec<String>,
    y: f32,
    h: f32,
    /// начало строки; меньше нуля — времени нет
    t: i64,
    /// текущая яркость: меняется плавно
    a: f32,
}

/// Состояние текста песни: разбивка на строки и плавная прокрутка
#[derive(Default)]
struct Lyr {
    rows: Vec<Row>,
    id: usize,
    width: f32,
    total: f32,
    scroll: f32,
    /// до этого момента прокруткой управляет пользователь
    manual: Option<Instant>,
    hover: Option<usize>,
    /// 0…1: насколько раскрыта область текста
    reveal: f32,
    last: Option<Instant>,
}

#[derive(Default)]
struct View {
    lyr: Lyr,
    scale: f32,
    hover: Option<Hit>,
    press: Option<Press>,
    /// ширина подписи с названием плеера — её считает отрисовка
    chip: f32,
}

/// Всё, что нужно одному кадру
struct Scene {
    compact: bool,
    track: Option<Track>,
    volume: f32,
    muted: bool,
    peak: f32,
    device: String,
    /// секунды для анимации индикатора
    time: f32,
    /// текст песни, если плашка включена
    lyrics: Option<lyrics::State>,
}

struct Music {
    hwnd: HWND,
    view: View,
    work: RECT,
    base: Option<Img>,
    opened: Instant,
    closing: Option<Instant>,
    hide_at: Instant,
    /// можно показать короткий вид, если музыка не играет (открыли клавишей громкости)
    compact_ok: bool,
    /// закреплена кнопкой или Ctrl+Win+M, пока включён текст: не скрывается сама
    pinned: bool,
    /// где панель на экране
    rect: RECT,
    ticks: u32,
    sig: u64,
}

thread_local! {
    static MUSIC: RefCell<Option<Music>> = const { RefCell::new(None) };
}

fn with<R>(f: impl FnOnce(&mut Music) -> R) -> Option<R> {
    MUSIC.with(|s| s.try_borrow_mut().ok()?.as_mut().map(f))
}

pub fn init() {
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacMixer.Music"),
            hCursor: LoadCursorW(None, IDC_ARROW).unwrap_or_default(),
            ..Default::default()
        };
        RegisterClassW(&wc);
    }
}

/// Клавиша, которую забрал хук
pub fn key(vk: u16) {
    let k = VIRTUAL_KEY(vk);
    match k {
        VK_VOLUME_UP => nudge(1.0),
        VK_VOLUME_DOWN => nudge(-1.0),
        VK_VOLUME_MUTE => toggle_mute(),
        VK_MEDIA_PLAY_PAUSE => media::send(Cmd::Toggle),
        VK_MEDIA_NEXT_TRACK => media::send(Cmd::Next),
        VK_MEDIA_PREV_TRACK => media::send(Cmd::Prev),
        VK_MEDIA_STOP => media::send(Cmd::Stop),
        _ => return,
    }
    show(HOLD_KEY, matches!(k, VK_VOLUME_UP | VK_VOLUME_DOWN | VK_VOLUME_MUTE));
}

/// Сочетание клавиш и пункт меню: открыть или закрыть
pub fn toggle() {
    let open = with(|m| m.closing.is_none()).unwrap_or(false);
    if open {
        with(|m| m.closing = Some(Instant::now()));
    } else {
        show(HOLD_HOTKEY, false);
        // открыли сами и текст включён — читаем, панель не прячется
        if lyrics::enabled() {
            with(|m| m.pinned = true);
        }
    }
}

fn show(hold: u64, compact_ok: bool) {
    let now = Instant::now();
    let hide_at = now + Duration::from_millis(hold);
    let reused = with(|m| {
        m.hide_at = hide_at;
        m.compact_ok &= compact_ok;
        // начала закрываться — возвращаем сразу, без повторной анимации
        if m.closing.take().is_some() {
            m.opened = now.checked_sub(Duration::from_millis(OPEN_MS as u64 + 50)).unwrap_or(now);
        }
    })
    .is_some();
    if reused {
        frame();
        return;
    }
    media::send(Cmd::Watch(true));
    let mon = win::monitor_at(win::cursor());
    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let Ok(hwnd) = CreateWindowExW(
            WS_EX_LAYERED | WS_EX_TOPMOST | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
            w!("MacMixer.Music"),
            w!("Сейчас играет"),
            WS_POPUP,
            mon.work.left,
            mon.work.top,
            1,
            1,
            None,
            None,
            Some(inst.into()),
            None,
        ) else {
            return;
        };
        let m = Music {
            hwnd,
            view: View { scale: mon.scale, ..Default::default() },
            work: mon.work,
            base: None,
            opened: now,
            closing: None,
            hide_at,
            compact_ok,
            pinned: false,
            rect: RECT::default(),
            ticks: 0,
            sig: 0,
        };
        MUSIC.with(|c| *c.borrow_mut() = Some(m));
        frame();
        let _ = ShowWindow(hwnd, SW_SHOWNOACTIVATE);
        SetTimer(Some(hwnd), TIMER, 16, None);
    }
}

/// Нижний край панели на экране, пока она открыта: островок встанет под ней
pub fn bottom() -> Option<i32> {
    with(|m| m.closing.is_none().then_some(m.rect.bottom)).flatten()
}

/// Панель открыта и не закрывается
pub fn is_open() -> bool {
    bottom().is_some()
}

fn close() {
    let m = MUSIC.with(|s| s.try_borrow_mut().ok().and_then(|mut m| m.take()));
    if let Some(m) = m {
        media::send(Cmd::Watch(false));
        unsafe {
            let _ = DestroyWindow(m.hwnd);
        }
    }
}

fn nudge(dir: f32) {
    audio::with(|a| {
        a.poll();
        let Some((v, muted, _)) = a.level(Target::Out) else { return };
        // как у Windows: шаг 2 %, а любая из клавиш возвращает выключенный звук
        if muted {
            a.set_muted(Target::Out, false);
        }
        a.set_volume(Target::Out, ((v * 50.0).round() + dir) / 50.0);
    });
}

fn toggle_mute() {
    audio::with(|a| {
        a.poll();
        if let Some((_, muted, _)) = a.level(Target::Out) {
            a.set_muted(Target::Out, !muted);
        }
    });
}

// ---------- вёрстка ----------

fn inside(x: f32, y: f32, r: (f32, f32, f32, f32)) -> bool {
    x >= r.0 && x < r.0 + r.2 && y >= r.1 && y < r.1 + r.3
}

fn rect_of(h: Hit, compact: bool, chip: f32) -> (f32, f32, f32, f32) {
    if compact {
        return match h {
            Hit::Mute => (12.0, 14.0, 32.0, 32.0),
            Hit::Volume => (CX0 - 6.0, 26.0, CX1 - CX0 + 12.0, 26.0),
            _ => (0.0, 0.0, 0.0, 0.0),
        };
    }
    match h {
        Hit::Prev => (TX, ROW, 36.0, 32.0),
        Hit::Toggle => (TX + 40.0, ROW, 44.0, 32.0),
        Hit::Next => (TX + 88.0, ROW, 36.0, 32.0),
        Hit::Mute => (VOL_X0 - 40.0, ROW, 32.0, 32.0),
        Hit::Volume => (VOL_X0 - 6.0, ROW, VOL_W + 12.0, 32.0),
        Hit::Seek => (BAR_X0 - 6.0, BAR_Y - 8.0, BAR_X1 - BAR_X0 + 12.0, 16.0),
        Hit::App => (RIGHT - chip - 4.0, 10.0, chip + 8.0, 24.0),
        Hit::Lyrics => (TX + 130.0, ROW, 32.0, 32.0),
    }
}

fn hit(compact: bool, t: Option<&Track>, chip: f32, x: f32, y: f32) -> Option<Hit> {
    let allowed = |h: Hit| match h {
        Hit::Mute | Hit::Volume => true,
        Hit::Prev => t.is_some_and(|t| t.can_prev),
        Hit::Next => t.is_some_and(|t| t.can_next),
        Hit::Toggle => t.is_some_and(|t| t.can_toggle),
        Hit::Seek => t.is_some_and(|t| t.can_seek),
        Hit::App => t.is_some_and(|t| t.players > 1),
        Hit::Lyrics => t.is_some(),
    };
    [Hit::Prev, Hit::Toggle, Hit::Next, Hit::Lyrics, Hit::Mute, Hit::Volume, Hit::Seek, Hit::App]
        .into_iter()
        .find(|&h| allowed(h) && inside(x, y, rect_of(h, compact, chip)))
}

fn clock(ticks: i64) -> String {
    let s = ticks / TICKS;
    if s >= 3600 {
        format!("{}:{:02}:{:02}", s / 3600, s / 60 % 60, s % 60)
    } else {
        format!("{}:{:02}", s / 60, s % 60)
    }
}

fn speaker(volume: f32, muted: bool) -> Icon {
    match volume {
        _ if muted => Icon::SpeakerMuted,
        v if v < 0.01 => Icon::Speaker(0),
        v if v < 0.34 => Icon::Speaker(1),
        v if v < 0.67 => Icon::Speaker(2),
        _ => Icon::Speaker(3),
    }
}

// ---------- отрисовка ----------

struct Ctx {
    s: f32,
    o: f32,
}

impl Ctx {
    fn x(&self, v: f32) -> f32 {
        self.o + v * self.s
    }
    fn d(&self, v: f32) -> f32 {
        v * self.s
    }
}

fn card(pm: &mut PixmapMut, x: f32, y: f32, w: f32, h: f32, s: f32) {
    let r = gfx::window_radius() * s;
    gfx::shadow(pm, x, y + 4.0 * s, w, h, 22.0 * s, 0.5);
    gfx::fill_rrect(pm, x, y, w, h, r, gfx::panel(1.0));
    gfx::stroke_rrect(pm, x + 0.5, y + 0.5, w - 1.0, h - 1.0, r, 1.0, gfx::white(0.12));
}

fn background(iw: u32, ih: u32, s: f32, pw: f32, ph: f32, text: bool) -> Img {
    let mut img = Img::new(iw, ih);
    if let Some(mut pm) = img.pixmap_mut() {
        let o = M * s;
        card(&mut pm, o, o, pw * s, ph * s, s);
        if text {
            // разделитель между кнопками и текстом
            gfx::fill_rrect(&mut pm, o + PAD * s, o + H * s, (pw - PAD * 2.0) * s, s.max(1.0), 0.0, gfx::white(0.1));
        }
    }
    img
}

/// Разбить текст на строки под ширину панели и расставить их по высоте
fn lay_out(l: &mut Lyr, f: &Fonts, s: f32, items: Vec<(i64, &str)>) {
    let max = (W - LX * 2.0) * s;
    l.rows.clear();
    let mut y = 8.0;
    // до первой строки — точки, как в проигрыше
    if let Some(first) = items.first().filter(|i| i.0 > 3 * TICKS) {
        let _ = first;
        l.rows.push(Row { lines: Vec::new(), y, h: 34.0, t: 0, a: 0.3 });
        y += 34.0;
    }
    for (time, text) in items {
        let lines = wrap(&f.semibold, text, LPX * s, max);
        let h = lines.len() as f32 * LSTEP + LGAP;
        l.rows.push(Row { lines, y, h, t: time, a: 0.3 });
        y += h;
    }
    l.total = y + 8.0;
}

/// Анимация текста: раскрытие области, прокрутка к текущей строке и яркость строк
fn update_lyrics(v: &mut View, f: &Fonts, sc: &Scene, dt: f32) {
    let s = v.scale;
    let l = &mut v.lyr;
    let goal = if sc.lyrics.is_some() && !sc.compact { 1.0 } else { 0.0 };
    l.reveal += (goal - l.reveal) * (1.0 - (-dt * 13.0).exp());
    if (goal - l.reveal).abs() < 0.004 {
        l.reveal = goal;
    }
    let id = match sc.lyrics.as_ref() {
        Some(lyrics::State::Synced(a)) => Arc::as_ptr(a) as usize,
        Some(lyrics::State::Plain(a)) => Arc::as_ptr(a) as usize,
        _ => 0,
    };
    let fresh = id != l.id || l.width != s;
    if fresh {
        (l.id, l.width, l.manual, l.hover) = (id, s, None, None);
        match sc.lyrics.as_ref() {
            Some(lyrics::State::Synced(a)) => lay_out(l, f, s, a.iter().map(|(t, x)| (*t, x.as_str())).collect()),
            Some(lyrics::State::Plain(a)) => lay_out(l, f, s, a.iter().map(|x| (-1, x.as_str())).collect()),
            _ => l.rows.clear(),
        }
    }
    let track = sc.track.as_ref();
    let pos = track.map_or(0, |t| t.position()) + LLEAD;
    let synced = matches!(sc.lyrics, Some(lyrics::State::Synced(_)));
    let cur = if synced { l.rows.iter().rposition(|r| r.t >= 0 && r.t <= pos) } else { None };
    // куда прокрутить: к текущей строке, а в тексте без времени — по доле песни
    let focus = cur.or_else(|| {
        let k = track.filter(|t| t.end > 0 && !synced).map(|t| t.position() as f32 / t.end as f32)?;
        Some(((l.rows.len() as f32 * k) as usize).min(l.rows.len().checked_sub(1)?))
    });
    let limit = (l.total - LH).max(0.0);
    let target = focus.and_then(|i| l.rows.get(i)).map_or(0.0, |r| (r.y + r.h / 2.0 - LANCHOR).clamp(0.0, limit));
    if l.manual.is_some_and(|u| Instant::now() >= u) {
        l.manual = None;
    }
    if fresh {
        l.scroll = target;
    } else if l.manual.is_none() {
        l.scroll += (target - l.scroll) * (1.0 - (-dt * 8.0).exp());
        if (target - l.scroll).abs() < 0.25 {
            l.scroll = target;
        }
    }
    l.scroll = l.scroll.clamp(0.0, limit);
    let (manual, hover) = (l.manual.is_some(), l.hover);
    for (i, r) in l.rows.iter_mut().enumerate() {
        let want = if cur == Some(i) || !synced && focus == Some(i) {
            0.98
        } else if hover == Some(i) {
            0.78
        } else if manual {
            0.5
        } else if cur.is_some_and(|c| i < c) {
            0.24
        } else {
            0.36
        };
        r.a += (want - r.a) * (1.0 - (-dt * 11.0).exp());
        if fresh {
            r.a = want;
        }
    }
}

/// Строка под курсором (координаты панели)
fn line_at(v: &View, x: f32, y: f32) -> Option<usize> {
    if v.lyr.reveal < 0.9 || y < H + 2.0 || !(0.0..W).contains(&x) {
        return None;
    }
    let inner = y - H + v.lyr.scroll;
    v.lyr.rows.iter().position(|r| inner >= r.y && inner < r.y + r.h && r.t >= 0)
}

/// Текст под кнопками: рисуем отдельным слоем, чтобы строки плавно гасли у краёв области
fn draw_lyrics(pm: &mut PixmapMut, c: &Ctx, v: &View, f: &Fonts, sc: &Scene) {
    let s = c.s;
    let l = &v.lyr;
    let area = LH * l.reveal;
    let (aw, ah) = ((W * s).ceil() as u32, (area * s).ceil() as u32);
    if ah == 0 {
        return;
    }
    let mut layer = Img::new(aw, ah);
    if let Some(mut lp) = layer.pixmap_mut() {
        let message = match sc.lyrics.as_ref() {
            Some(lyrics::State::Loading) => Some("Ищу текст песни…"),
            Some(lyrics::State::Missing) => Some("Текста этой песни нет в базе"),
            _ => None,
        };
        if let Some(text) = message {
            let tw = gfx::measure(&f.regular, text, 13.0 * s);
            gfx::text(&mut lp, &f.regular, text, (aw as f32 - tw) / 2.0, (LH / 2.0 + 5.0) * s, 13.0 * s, gfx::white(0.55));
        }
        let pos = sc.track.as_ref().map_or(0, |t| t.position()) + LLEAD;
        let first = l.rows.iter().find(|r| !r.lines.is_empty()).map_or(1, |r| r.t.max(1));
        for (i, r) in l.rows.iter().enumerate() {
            let top = r.y - l.scroll;
            if top + r.h < 0.0 || top > area {
                continue;
            }
            if l.hover == Some(i) {
                gfx::fill_rrect(&mut lp, (LX - 8.0) * s, top * s - 3.0 * s, (W - (LX - 8.0) * 2.0) * s, (r.h - LGAP + 6.0) * s, 6.0 * s, gfx::white(0.07));
            }
            if r.lines.is_empty() {
                // три точки наполняются по мере приближения первой строки
                let k = pos as f32 / first as f32 * 3.0;
                for d in 0..3 {
                    let fill = (k - d as f32).clamp(0.0, 1.0);
                    let cx = LX + 5.0 + d as f32 * 17.0;
                    gfx::pill(&mut lp, (cx - 5.0) * s, (top + 10.0) * s, 10.0 * s, 10.0 * s, gfx::white(0.25 + 0.7 * fill * r.a.max(0.5)));
                }
                continue;
            }
            for (n, text) in r.lines.iter().enumerate() {
                gfx::text(&mut lp, &f.semibold, text, LX * s, (top + 19.0 + n as f32 * LSTEP) * s, LPX * s, gfx::white(r.a));
            }
        }
    }
    // у верхнего и нижнего края строки растворяются
    let (fade_top, fade_bottom) = (16.0 * s, 26.0 * s);
    for (row, line) in layer.px.chunks_exact_mut(aw as usize * 4).enumerate() {
        let y = row as f32;
        let k = (y / fade_top).min((ah as f32 - y) / fade_bottom).clamp(0.0, 1.0);
        if k < 1.0 {
            for b in line.iter_mut() {
                *b = (*b as f32 * k) as u8;
            }
        }
    }
    if let Some(src) = layer.pixmap() {
        pm.draw_pixmap(c.x(0.0) as i32, c.x(H) as i32, src, &tiny_skia::PixmapPaint::default(), tiny_skia::Transform::identity(), None);
    }
}

fn wrap(f: &ab_glyph::FontVec, s: &str, px: f32, max: f32) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    for w in s.split(' ') {
        let t = if cur.is_empty() { w.to_string() } else { format!("{cur} {w}") };
        if gfx::measure(f, &t, px) <= max || cur.is_empty() {
            cur = t;
        } else {
            out.push(std::mem::take(&mut cur));
            cur = w.to_string();
        }
    }
    if !cur.is_empty() {
        out.push(cur);
    }
    out
}

/// Полоска с заполнением и бегунком
fn slider(pm: &mut PixmapMut, c: &Ctx, x0: f32, x1: f32, cy: f32, k: f32, on: bool, thumb: bool) {
    let k = k.clamp(0.0, 1.0);
    let (s, w) = (c.s, x1 - x0);
    let th = (if gfx::win11() { 4.0 } else { 2.0 } * s).round().max(1.0);
    let top = c.x(cy) - th / 2.0;
    gfx::fill_rrect(pm, c.x(x0), top, c.d(w), th, 0.0, gfx::white(0.22));
    let fill = if on { gfx::accent(1.0) } else { gfx::white(0.45) };
    gfx::fill_rrect(pm, c.x(x0), top, c.d(w * k), th, 0.0, fill);
    if thumb {
        let (tw, tl) = (8.0, 20.0);
        let tx = x0 + (w * k - tw / 2.0).clamp(-tw / 2.0, w - tw / 2.0);
        gfx::pill(pm, c.x(tx), c.x(cy - tl / 2.0), c.d(tw), c.d(tl), if on { gfx::accent(1.0) } else { gfx::white(0.7) });
    }
}

fn button(pm: &mut PixmapMut, c: &Ctx, v: &View, h: Hit, r: (f32, f32, f32, f32), ch: char, px: f32, on: bool) {
    let hovered = on && v.hover == Some(h) && v.press.is_none_or(|p| p.hit == h);
    let pressed = hovered && v.press.is_some();
    if hovered {
        let a = if pressed { 0.06 } else { 0.11 };
        gfx::fill_rrect(pm, c.x(r.0), c.x(r.1), c.d(r.2), c.d(r.3), 0.0, gfx::white(a));
    }
    let col = if on { gfx::white(0.92) } else { gfx::white(0.28) };
    gfx::glyph(pm, ch, c.x(r.0 + r.2 / 2.0), c.x(r.1 + r.3 / 2.0), c.d(px), col);
}

fn mute_button(pm: &mut PixmapMut, c: &Ctx, v: &View, r: (f32, f32, f32, f32), volume: f32, muted: bool) {
    let hovered = v.hover == Some(Hit::Mute) && v.press.is_none_or(|p| p.hit == Hit::Mute);
    if hovered {
        gfx::fill_rrect(pm, c.x(r.0), c.x(r.1), c.d(r.2), c.d(r.3), 0.0, gfx::white(0.11));
    }
    let col = if muted { gfx::white(0.55) } else { gfx::white(0.92) };
    let sz = 18.0;
    gfx::icon(pm, speaker(volume, muted), c.x(r.0 + (r.2 - sz) / 2.0), c.x(r.1 + (r.3 - sz) / 2.0), c.d(sz), col);
}

/// Индикатор звука рядом с названием плеера: столбики следуют за уровнем на выходе
fn equalizer(pm: &mut PixmapMut, c: &Ctx, right: f32, base: f32, sc: &Scene) {
    let active = sc.track.as_ref().is_some_and(|t| t.playing) && !sc.muted;
    let level = if active { sc.peak.clamp(0.0, 1.0).sqrt() } else { 0.0 };
    for i in 0..3 {
        let wave = 0.62 + 0.38 * (sc.time * 7.0 + i as f32 * 1.9).sin();
        let h = (2.0 + 10.0 * level * wave).max(2.0);
        let x = right - 13.0 + i as f32 * 5.0;
        let col = if level > 0.01 { gfx::accent(1.0) } else { gfx::white(0.3) };
        gfx::fill_rrect(pm, c.x(x), c.x(base - h), c.d(3.0), c.d(h), 0.0, col);
    }
}

fn draw_compact(pm: &mut PixmapMut, c: &Ctx, v: &View, f: &Fonts, sc: &Scene) {
    let s = c.s;
    mute_button(pm, c, v, rect_of(Hit::Mute, true, 0.0), sc.volume, sc.muted);
    let name = gfx::fit(&f.regular, &sc.device, 12.0 * s, c.d(CX1 - CX0));
    gfx::text(pm, &f.regular, &name, c.x(CX0), c.x(24.0), 12.0 * s, gfx::white(0.65));
    slider(pm, c, CX0, CX1, 39.0, sc.volume, !sc.muted, true);
    let pct = format!("{}", (sc.volume * 100.0).round() as i32);
    let tw = gfx::measure(&f.semibold, &pct, 16.0 * s);
    gfx::text(pm, &f.semibold, &pct, c.x(CW - 16.0) - tw, c.x(36.0), 16.0 * s, gfx::white(if sc.muted { 0.5 } else { 0.95 }));
}

fn draw_full(pm: &mut PixmapMut, c: &Ctx, v: &View, f: &Fonts, sc: &Scene) {
    let s = c.s;
    let t = sc.track.as_ref();

    // обложка
    match t.and_then(|t| t.art.as_ref()) {
        Some(art) => gfx::image_round(pm, art, c.x(PAD), c.x(PAD), c.d(ART), c.d(gfx::window_radius() / 2.0)),
        None => {
            gfx::fill_rrect(pm, c.x(PAD), c.x(PAD), c.d(ART), c.d(ART), 0.0, gfx::white(0.07));
            gfx::glyph(pm, '\u{EC4F}', c.x(PAD + ART / 2.0), c.x(PAD + ART / 2.0), c.d(38.0), gfx::white(0.4));
        }
    }

    // плеер и индикатор справа сверху
    let mut title_right = RIGHT;
    if let Some(t) = t {
        let many = t.players > 1;
        let tw = gfx::measure(&f.regular, &t.app, 12.0 * s) / s;
        let chip = tw + if many { 14.0 } else { 0.0 };
        let hovered = v.hover == Some(Hit::App);
        if hovered {
            let r = rect_of(Hit::App, false, chip);
            gfx::fill_rrect(pm, c.x(r.0), c.x(r.1), c.d(r.2), c.d(r.3), 0.0, gfx::white(0.11));
        }
        gfx::text(pm, &f.regular, &t.app, c.x(RIGHT - chip), c.x(27.0), 12.0 * s, gfx::white(0.6));
        if many {
            gfx::icon(pm, Icon::ChevronDown, c.x(RIGHT - 12.0), c.x(17.0), c.d(12.0), gfx::white(0.6));
        }
        equalizer(pm, c, RIGHT - chip - 8.0, 27.0, sc);
        title_right = RIGHT - chip - 8.0 - 13.0 - 10.0;
    }

    // название и исполнитель; если плеер не даёт позицию, полоски нет — текст опускаем к кнопкам
    let timeline = t.is_some_and(|t| t.end > 0);
    let shift = if timeline { 0.0 } else { 10.0 };
    let (title, sub) = match t {
        Some(t) => (t.title.as_str(), t.artist.as_str()),
        None => ("Ничего не играет", "Запустите музыку в любом плеере"),
    };
    let tmax = c.d(title_right - TX);
    let line = gfx::fit(&f.semibold, title, 16.0 * s, tmax);
    gfx::text(pm, &f.semibold, &line, c.x(TX), c.x(29.0 + shift), 16.0 * s, gfx::white(0.96));
    let line = gfx::fit(&f.regular, sub, 13.0 * s, c.d(RIGHT - TX));
    gfx::text(pm, &f.regular, &line, c.x(TX), c.x(48.0 + shift), 13.0 * s, gfx::white(0.65));

    // перемотка
    if let Some(t) = t.filter(|t| t.end > 0) {
        let seeking = v.press.filter(|p| p.hit == Hit::Seek).map(|p| p.seek);
        let k = seeking.unwrap_or(t.position() as f32 / t.end as f32);
        let pos = seeking.map_or(t.position(), |k| (k as f64 * t.end as f64) as i64);
        let thumb = t.can_seek && (v.hover == Some(Hit::Seek) || seeking.is_some());
        slider(pm, c, BAR_X0, BAR_X1, BAR_Y, k, true, thumb);
        let col = gfx::white(0.65);
        gfx::text(pm, &f.regular, &clock(pos), c.x(TX), c.x(BAR_Y + 4.0), 11.0 * s, col);
        let end = clock(t.end);
        let ew = gfx::measure(&f.regular, &end, 11.0 * s);
        gfx::text(pm, &f.regular, &end, c.x(RIGHT) - ew, c.x(BAR_Y + 4.0), 11.0 * s, col);
    }

    // кнопки
    let (can_prev, can_next, can_toggle) = t.map_or((false, false, false), |t| (t.can_prev, t.can_next, t.can_toggle));
    button(pm, c, v, Hit::Prev, rect_of(Hit::Prev, false, 0.0), '\u{E892}', 14.0, can_prev);
    button(pm, c, v, Hit::Next, rect_of(Hit::Next, false, 0.0), '\u{E893}', 14.0, can_next);
    {
        let on = lyrics::enabled();
        let r = rect_of(Hit::Lyrics, false, 0.0);
        if on {
            gfx::fill_rrect(pm, c.x(r.0), c.x(r.1), c.d(r.2), c.d(r.3), 0.0, gfx::accent(0.25));
        }
        button(pm, c, v, Hit::Lyrics, r, '\u{E8FD}', 15.0, t.is_some());
    }
    let r = rect_of(Hit::Toggle, false, 0.0);
    let fill = if can_toggle { gfx::accent(1.0) } else { gfx::white(0.08) };
    gfx::fill_rrect(pm, c.x(r.0), c.x(r.1), c.d(r.2), c.d(r.3), 0.0, fill);
    if can_toggle && v.hover == Some(Hit::Toggle) {
        let over = if v.press.is_some() { gfx::rgb(0, 0, 0, 0.15) } else { gfx::pure(0.14) };
        gfx::fill_rrect(pm, c.x(r.0), c.x(r.1), c.d(r.2), c.d(r.3), 0.0, over);
    }
    let playing = t.is_some_and(|t| t.playing);
    let ch = if playing { '\u{E769}' } else { '\u{E768}' };
    let col = if can_toggle { gfx::on_accent(1.0) } else { gfx::white(0.28) };
    gfx::glyph(pm, ch, c.x(r.0 + r.2 / 2.0), c.x(r.1 + r.3 / 2.0), c.d(15.0), col);

    // громкость
    mute_button(pm, c, v, rect_of(Hit::Mute, false, 0.0), sc.volume, sc.muted);
    slider(pm, c, VOL_X0, VOL_X1, ROW + 16.0, sc.volume, !sc.muted, true);
    let pct = format!("{}", (sc.volume * 100.0).round() as i32);
    let tw = gfx::measure(&f.regular, &pct, 13.0 * s);
    gfx::text(pm, &f.regular, &pct, c.x(RIGHT) - tw, c.x(ROW + 21.0), 13.0 * s, gfx::white(if sc.muted { 0.5 } else { 0.9 }));
}

fn size_of(compact: bool) -> (f32, f32) {
    if compact {
        (CW, CH)
    } else {
        (W, H)
    }
}

/// Размер панели: с текстом песни она выше
fn full_size(sc: &Scene, v: &View) -> (f32, f32) {
    let (w, h) = size_of(sc.compact);
    (w, h + LH * v.lyr.reveal)
}

fn render(v: &View, f: &Fonts, sc: &Scene, base: &mut Option<Img>) -> Img {
    let s = v.scale;
    let side = v.lyr.reveal > 0.004;
    let (pw, ph) = full_size(sc, v);
    let (iw, ih) = (((pw + 2.0 * M) * s).ceil() as u32, ((ph + 2.0 * M) * s).ceil() as u32);
    let mut img = match base {
        Some(b) if b.w == iw && b.h == ih => b.clone(),
        _ => {
            let b = background(iw, ih, s, pw, ph, side);
            *base = Some(b.clone());
            b
        }
    };
    if let Some(mut pm) = img.pixmap_mut() {
        let c = Ctx { s, o: M * s };
        if sc.compact {
            draw_compact(&mut pm, &c, v, f, sc);
        } else {
            draw_full(&mut pm, &c, v, f, sc);
            if side {
                draw_lyrics(&mut pm, &c, v, f, sc);
            }
        }
    }
    img
}

fn ease(k: f32) -> f32 {
    let k = k.clamp(0.0, 1.0);
    1.0 - (1.0 - k).powi(3)
}

/// Сцена из текущего состояния плеера и звука
fn scene(compact_ok: bool, started: Instant) -> Scene {
    let track = media::track();
    let (volume, muted, peak, device) = audio::with(|a| {
        let (v, m, p) = a.level(Target::Out).unwrap_or((0.0, true, 0.0));
        (v, m, p, a.output().map_or_else(|| "Нет устройств вывода".to_string(), |d| d.name.clone()))
    })
    .unwrap_or((0.0, true, 0.0, String::new()));
    let compact = compact_ok && track.is_none();
    let lyrics = track.as_ref().filter(|_| !compact && lyrics::enabled()).map(|t| lyrics::get(&t.title, &t.artist, t.end));
    Scene { compact, track, volume, muted, peak, device, time: started.elapsed().as_secs_f32(), lyrics }
}

/// Отпечаток кадра: пока он прежний, окно не перерисовываем
fn signature(v: &View, sc: &Scene) -> u64 {
    let mut h = DefaultHasher::new();
    sc.compact.hash(&mut h);
    ((sc.volume * 200.0) as i32, sc.muted).hash(&mut h);
    v.hover.hash(&mut h);
    v.press.map(|p| (p.hit, (p.seek * 1000.0) as i32)).hash(&mut h);
    lyrics::enabled().hash(&mut h);
    ((v.lyr.scroll * 2.0) as i32, (v.lyr.reveal * 100.0) as i32, v.lyr.hover).hash(&mut h);
    v.lyr.rows.iter().map(|r| (r.a * 60.0) as i32).sum::<i32>().hash(&mut h);
    match &sc.lyrics {
        None => 0u8.hash(&mut h),
        Some(lyrics::State::Loading) => 1u8.hash(&mut h),
        Some(lyrics::State::Missing) => 2u8.hash(&mut h),
        Some(lyrics::State::Plain(l)) => (3u8, Arc::as_ptr(l) as usize).hash(&mut h),
        Some(lyrics::State::Synced(l)) => {
            let pos = sc.track.as_ref().map_or(0, |t| t.position());
            (4u8, Arc::as_ptr(l) as usize, l.iter().rposition(|(t, _)| *t <= pos)).hash(&mut h);
        }
    }
    if let Some(t) = &sc.track {
        (&t.title, &t.artist, &t.app, t.players, t.playing).hash(&mut h);
        (t.can_prev, t.can_next, t.can_toggle, t.can_seek, t.end).hash(&mut h);
        t.art.as_ref().map(|a| Arc::as_ptr(a) as usize).hash(&mut h);
        // секунды для подписи, доли — для плавной полоски
        (t.position() / (TICKS / 4)).hash(&mut h);
        if t.playing && !sc.muted && sc.peak > 0.001 {
            ((sc.time * 30.0) as i32).hash(&mut h);
        }
    }
    h.finish()
}

fn frame() {
    with(|m| {
        let sc = scene(m.compact_ok, m.opened);
        let closing = m.closing.is_some();
        let opening = m.opened.elapsed().as_millis() as f32 <= OPEN_MS + 20.0;
        let dt = m.view.lyr.last.map_or(0.033, |l| l.elapsed().as_secs_f32()).min(0.1);
        m.view.lyr.last = Some(Instant::now());
        panel::with_fonts(|f| update_lyrics(&mut m.view, f, &sc, dt));
        let sig = signature(&m.view, &sc);
        if !closing && !opening && sig == m.sig {
            return;
        }
        m.sig = sig;
        panel::with_fonts(|f| {
            if let Some(t) = &sc.track {
                let tw = gfx::measure(&f.regular, &t.app, 12.0 * m.view.scale) / m.view.scale;
                m.view.chip = tw + if t.players > 1 { 14.0 } else { 0.0 };
            }
            let img = render(&m.view, f, &sc, &mut m.base);
            let size = full_size(&sc, &m.view);
            present(m, &img, size);
        });
    });
}

fn present(m: &mut Music, img: &Img, (pw, ph): (f32, f32)) {
    let s = m.view.scale;
    let o = M * s;
    let wk = m.work;
    let x = (wk.left + wk.right) as f32 / 2.0 - pw * s / 2.0;
    let y = wk.top as f32 + TOP * s;
    // появление: выезжает сверху и проявляется; закрытие — обратно
    let k = match m.closing {
        Some(c) => 1.0 - ease(c.elapsed().as_millis() as f32 / CLOSE_MS),
        None => ease(m.opened.elapsed().as_millis() as f32 / OPEN_MS),
    };
    let dy = -(1.0 - k) * 14.0 * s;
    m.rect = RECT {
        left: x.round() as i32,
        top: y.round() as i32,
        right: (x + pw * s).round() as i32,
        bottom: (y + ph * s).round() as i32,
    };
    let Some(mut surf) = Surface::new(img.w as i32, img.h as i32) else { return };
    surf.data().copy_from_slice(&img.px);
    unsafe {
        let screen = GetDC(None);
        let pos = POINT { x: (x - o).round() as i32, y: (y - o + dy).round() as i32 };
        let size = SIZE { cx: img.w as i32, cy: img.h as i32 };
        let src = POINT::default();
        let blend = BLENDFUNCTION {
            BlendOp: AC_SRC_OVER as u8,
            SourceConstantAlpha: (k * 255.0).round() as u8,
            AlphaFormat: AC_SRC_ALPHA as u8,
            ..Default::default()
        };
        let _ = UpdateLayeredWindow(m.hwnd, Some(screen), Some(&pos), Some(&size), Some(surf.dc), Some(&src), COLORREF(0), Some(&blend), ULW_ALPHA);
        ReleaseDC(None, screen);
    }
}

// ---------- мышь ----------

fn to_panel(s: f32, x: i32, y: i32) -> (f32, f32) {
    (x as f32 / s - M, y as f32 / s - M)
}

fn is_compact(m: &Music) -> bool {
    m.compact_ok && media::track().is_none()
}

fn set_volume(compact: bool, x: f32) {
    let (x0, x1) = if compact { (CX0, CX1) } else { (VOL_X0, VOL_X1) };
    let v = ((x - x0) / (x1 - x0)).clamp(0.0, 1.0);
    audio::with(|a| {
        if a.level(Target::Out).is_some_and(|l| l.1) {
            a.set_muted(Target::Out, false);
        }
        a.set_volume(Target::Out, v);
    });
}

fn seek_at(x: f32) -> f32 {
    ((x - BAR_X0) / (BAR_X1 - BAR_X0)).clamp(0.0, 1.0)
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    let pt = || ((lp.0 & 0xFFFF) as i16 as i32, ((lp.0 >> 16) & 0xFFFF) as i16 as i32);
    match msg {
        // клик по панели не должен забирать фокус у окна, в котором работают
        WM_MOUSEACTIVATE => LRESULT(MA_NOACTIVATE as isize),
        WM_TIMER => {
            audio::with(|a| a.poll());
            let done = with(|m| {
                m.ticks += 1;
                if m.ticks == 12 {
                    // после анимации появления хватает 30 кадров в секунду
                    let _ = SetTimer(Some(hwnd), TIMER, 33, None);
                }
                let now = Instant::now();
                let p = win::cursor();
                let r = m.rect;
                let over = p.x >= r.left && p.x < r.right && p.y >= r.top && p.y < r.bottom;
                if m.closing.is_none() {
                    if over || m.view.press.is_some() || m.pinned {
                        // панель висит, пока на ней мышь
                        m.hide_at = m.hide_at.max(now + Duration::from_millis(HOLD_HOVER));
                    } else if now >= m.hide_at {
                        m.closing = Some(now);
                        // закрытие пойдёт плавно — снова нужны частые кадры
                        let _ = SetTimer(Some(hwnd), TIMER, 16, None);
                    }
                }
                m.closing.is_some_and(|c| c.elapsed().as_millis() as f32 >= CLOSE_MS)
            })
            .unwrap_or(false);
            if done {
                close();
            } else {
                frame();
            }
            LRESULT(0)
        }
        WM_MOUSEMOVE => {
            let (x, y) = pt();
            let t = media::track();
            let vol = with(|m| {
                let compact = is_compact(m);
                let (lx, ly) = to_panel(m.view.scale, x, y);
                m.view.hover = hit(compact, t.as_ref(), m.view.chip, lx, ly);
                let seekable = t.as_ref().is_some_and(|t| t.can_seek);
                m.view.lyr.hover = if seekable && m.view.hover.is_none() { line_at(&m.view, lx, ly) } else { None };
                match m.view.press.as_mut() {
                    Some(p) if p.hit == Hit::Seek => {
                        p.seek = seek_at(lx);
                        None
                    }
                    Some(p) if p.hit == Hit::Volume => Some((compact, lx)),
                    _ => None,
                }
            })
            .flatten();
            if let Some((compact, lx)) = vol {
                set_volume(compact, lx);
            }
            with(|m| {
                let mut tme = TRACKMOUSEEVENT {
                    cbSize: std::mem::size_of::<TRACKMOUSEEVENT>() as u32,
                    dwFlags: TME_LEAVE,
                    hwndTrack: m.hwnd,
                    dwHoverTime: 0,
                };
                let _ = TrackMouseEvent(&mut tme);
            });
            frame();
            LRESULT(0)
        }
        WM_MOUSELEAVE => {
            with(|m| {
                m.view.hover = None;
                m.view.lyr.hover = None;
            });
            frame();
            LRESULT(0)
        }
        // над строкой текста курсор-рука: по ней можно нажать
        WM_SETCURSOR if with(|m| m.view.lyr.hover.is_some()).unwrap_or(false) => {
            SetCursor(LoadCursorW(None, IDC_HAND).ok());
            LRESULT(1)
        }
        WM_LBUTTONDOWN => {
            let (x, y) = pt();
            let t = media::track();
            // клик по строке — перемотка к ней
            let line = with(|m| {
                let (lx, ly) = to_panel(m.view.scale, x, y);
                if hit(is_compact(m), t.as_ref(), m.view.chip, lx, ly).is_some() || !t.as_ref().is_some_and(|t| t.can_seek) {
                    return None;
                }
                let i = line_at(&m.view, lx, ly)?;
                m.view.lyr.manual = None;
                Some(m.view.lyr.rows[i].t)
            })
            .flatten();
            if let Some(at) = line {
                media::send(Cmd::Seek(at));
                frame();
                return LRESULT(0);
            }
            let start = with(|m| {
                let compact = is_compact(m);
                let (lx, ly) = to_panel(m.view.scale, x, y);
                let h = hit(compact, t.as_ref(), m.view.chip, lx, ly)?;
                m.view.press = Some(Press { hit: h, seek: seek_at(lx) });
                Some((h, compact, lx))
            })
            .flatten();
            if let Some((h, compact, lx)) = start {
                SetCapture(hwnd);
                if h == Hit::Volume {
                    set_volume(compact, lx);
                }
            }
            frame();
            LRESULT(0)
        }
        WM_LBUTTONUP => {
            let (x, y) = pt();
            let t = media::track();
            let done = with(|m| {
                let compact = is_compact(m);
                let (lx, ly) = to_panel(m.view.scale, x, y);
                let over = hit(compact, t.as_ref(), m.view.chip, lx, ly);
                m.view.press.take().map(|p| (p, over))
            })
            .flatten();
            let _ = ReleaseCapture();
            if let Some((p, over)) = done {
                match p.hit {
                    // перемотку отдаём плееру, только когда кнопку отпустили
                    Hit::Seek => {
                        if let Some(t) = &t {
                            media::send(Cmd::Seek((p.seek as f64 * t.end as f64) as i64));
                        }
                    }
                    Hit::Volume => {}
                    h if over == Some(h) => match h {
                        Hit::Prev => media::send(Cmd::Prev),
                        Hit::Next => media::send(Cmd::Next),
                        Hit::Toggle => media::send(Cmd::Toggle),
                        Hit::App => media::send(Cmd::Cycle),
                        Hit::Lyrics => {
                            let on = !lyrics::enabled();
                            lyrics::set_enabled(on);
                            with(|m| m.pinned = on);
                        }
                        Hit::Mute => toggle_mute(),
                        _ => {}
                    },
                    _ => {}
                }
            }
            frame();
            LRESULT(0)
        }
        // захват мыши отняли (например, Alt+Tab во время перетаскивания): иначе панель считала бы,
        // что кнопка всё ещё зажата, и больше не скрылась
        WM_CAPTURECHANGED => {
            with(|m| m.view.press = None);
            LRESULT(0)
        }
        WM_MOUSEWHEEL => {
            let delta = ((wp.0 >> 16) & 0xFFFF) as i16;
            // над текстом колёсико листает строки, над кнопками — громкость
            let (_, sy) = pt();
            let scrolled = with(|m| {
                let l = &mut m.view.lyr;
                if (sy - m.rect.top) as f32 / m.view.scale <= H || l.reveal < 0.5 || l.rows.is_empty() {
                    return false;
                }
                let limit = (l.total - LH).max(0.0);
                l.scroll = (l.scroll - delta as f32 / 120.0 * 48.0).clamp(0.0, limit);
                l.manual = Some(Instant::now() + LMANUAL);
                true
            })
            .unwrap_or(false);
            if !scrolled {
                nudge(if delta > 0 { 1.0 } else { -1.0 });
            }
            frame();
            LRESULT(0)
        }
        WM_CLOSE => {
            close();
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

// ---------- превью для проверки вёрстки ----------

/// Обложка-заглушка для превью: диагональный градиент
fn sample_art() -> Img {
    let n = 256u32;
    let mut img = Img::new(n, n);
    for y in 0..n {
        for x in 0..n {
            let k = (x + y) as f32 / (2 * n) as f32;
            let i = ((y * n + x) * 4) as usize;
            img.px[i] = (200.0 - 120.0 * k) as u8;
            img.px[i + 1] = (60.0 + 40.0 * k) as u8;
            img.px[i + 2] = (70.0 + 170.0 * k) as u8;
            img.px[i + 3] = 255;
        }
    }
    img
}

fn sample_track() -> Track {
    Track {
        title: "Название трека для проверки вёрстки".into(),
        artist: "Исполнитель — Альбом".into(),
        app: "Spotify".into(),
        players: 2,
        playing: true,
        pos: 95 * TICKS,
        end: 214 * TICKS,
        at: Some(Instant::now()),
        can_prev: true,
        can_next: true,
        can_toggle: true,
        can_seek: true,
        art: Some(Arc::new(sample_art())),
    }
}

/// kind: full | hover | paused | nosek | empty | volume | live
pub fn preview(kind: &str) -> Option<Img> {
    let fonts = Fonts::load()?;
    let mut v = View { scale: 1.0, ..Default::default() };
    let track = match kind {
        "empty" | "volume" => None,
        // ошибку показываем прямо в картинке, иначе её не отличить от «ничего не играет»
        "live" => media::once().unwrap_or_else(|e| Some(Track { title: format!("Ошибка: {e}"), ..Track::default() })),
        "paused" => Some(Track { playing: false, players: 1, art: None, ..sample_track() }),
        "nosek" => Some(Track { end: 0, pos: 0, can_seek: false, can_prev: false, ..sample_track() }),
        _ => Some(sample_track()),
    };
    if kind == "hover" {
        v.hover = Some(Hit::Seek);
    }
    // строки-заглушки: только для проверки вёрстки
    let sample: Vec<(i64, String)> = [
        (62, "Первая придуманная строка"),
        (70, "Строка, которая уже прошла"),
        (90, "Текущая строка песни: она яркая, а длинная занимает две строки по ширине панели"),
        (101, "Следующая строка"),
        (108, "И ещё одна строка после неё"),
        (116, "Эта уже растворяется у края"),
        (124, "А эта пока не видна"),
    ]
    .iter()
    .map(|(t, s)| (*t as i64 * TICKS, s.to_string()))
    .collect();
    let lyr = match kind {
        "lyrics" | "lyrics-hover" => Some(lyrics::State::Synced(Arc::new(sample))),
        "lyrics-loading" => Some(lyrics::State::Loading),
        "lyrics-missing" => Some(lyrics::State::Missing),
        _ => None,
    };
    if let Some(t) = &track {
        let tw = gfx::measure(&fonts.regular, &t.app, 12.0);
        v.chip = tw + if t.players > 1 { 14.0 } else { 0.0 };
    }
    audio::with(|a| a.poll());
    let (volume, muted, device) = audio::with(|a| {
        let (vol, m, _) = a.level(Target::Out).unwrap_or((0.0, true, 0.0));
        (vol, m, a.output().map_or(String::new(), |d| d.name.clone()))
    })?;
    let sc = Scene { compact: kind == "volume", track, volume, muted, peak: 0.5, device, time: 0.4, lyrics: lyr };
    let mut base = None;
    for _ in 0..40 {
        update_lyrics(&mut v, &fonts, &sc, 0.1);
    }
    if kind == "lyrics-hover" {
        v.lyr.hover = Some(3);
    }
    Some(render(&v, &fonts, &sc, &mut base))
}
