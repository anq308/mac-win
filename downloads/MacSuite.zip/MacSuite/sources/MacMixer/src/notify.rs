//! Откуда «островок» узнаёт о событиях: уведомления программ, новые файлы в «Загрузках»,
//! смена трека и устройства вывода. Текст уведомлений никуда не отправляется и не сохраняется

use std::collections::{HashMap, HashSet};
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use windows::core::{Interface, Result};
use windows::Foundation::Size;
use windows::Storage::Streams::IRandomAccessStreamReference;
use windows::UI::Notifications::Management::{UserNotificationListener, UserNotificationListenerAccessStatus as Access};
use windows::UI::Notifications::{KnownNotificationBindings, NotificationKinds, UserNotification};
use windows::Win32::System::Com::{CoInitializeEx, CoTaskMemFree, COINIT_MULTITHREADED};
use windows::Win32::System::Registry::*;
use windows::Win32::UI::Shell::{FOLDERID_Downloads, SHGetKnownFolderPath, KF_FLAG_DEFAULT};

use crate::gfx::Img;
use crate::island::{self, Action, Art, Item};
use crate::media;

#[derive(Clone, Copy, PartialEq)]
pub struct Options {
    pub messages: bool,
    pub tracks: bool,
    pub downloads: bool,
    pub devices: bool,
    /// прятать стандартные баннеры Windows у программ, чьи уведомления показывает островок
    pub hide_banners: bool,
    /// заряд Bluetooth-наушников: подключились, садится
    pub battery: bool,
}

static OPTIONS: Mutex<Option<Options>> = Mutex::new(None);

fn dir() -> Option<PathBuf> {
    let d = PathBuf::from(std::env::var("LOCALAPPDATA").ok()?).join("MacMixer");
    let _ = std::fs::create_dir_all(&d);
    Some(d)
}

pub fn options() -> Options {
    let mut g = match OPTIONS.lock() {
        Ok(g) => g,
        Err(_) => return Options { messages: true, tracks: true, downloads: true, devices: true, hide_banners: false, battery: true },
    };
    *g.get_or_insert_with(|| {
        let text = dir().and_then(|d| std::fs::read_to_string(d.join("island.txt")).ok()).unwrap_or_default();
        let get = |k: &str, def: bool| text.lines().find_map(|l| l.strip_prefix(k)?.strip_prefix('=').map(|v| v.trim() == "1")).unwrap_or(def);
        Options {
            messages: get("messages", true),
            tracks: get("tracks", true),
            downloads: get("downloads", true),
            devices: get("devices", true),
            hide_banners: get("hide_banners", false),
            battery: get("battery", true),
        }
    })
}

pub fn set_options(o: Options) {
    if let Ok(mut g) = OPTIONS.lock() {
        *g = Some(o);
    }
    let b = |v: bool| if v { 1 } else { 0 };
    if let Some(d) = dir() {
        let _ = std::fs::write(
            d.join("island.txt"),
            format!(
                "messages={}\ntracks={}\ndownloads={}\ndevices={}\nhide_banners={}\nbattery={}\n",
                b(o.messages),
                b(o.tracks),
                b(o.downloads),
                b(o.devices),
                b(o.hide_banners),
                b(o.battery)
            ),
        );
    }
}

pub fn start() {
    std::thread::spawn(messages);
    std::thread::spawn(downloads);
}

// ---------- уведомления программ ----------

/// Системные сообщения (защитник, обновления) остаются в обычном виде: на них бывают кнопки
fn system(id: &str) -> bool {
    id.starts_with("Windows.") || id.starts_with("Microsoft.Windows")
}

fn read_item(n: &UserNotification) -> Result<Option<Item>> {
    let info = n.AppInfo()?;
    let id = info.AppUserModelId()?.to_string();
    if system(&id) {
        return Ok(None);
    }
    let display = info.DisplayInfo()?;
    let source = display.DisplayName()?.to_string();
    let binding = n.Notification()?.Visual()?.GetBinding(&KnownNotificationBindings::ToastGeneric()?)?;
    let texts = binding.GetTextElements()?;
    let mut parts = Vec::new();
    for i in 0..texts.Size()? {
        let t = texts.GetAt(i)?.Text()?.to_string();
        if !t.trim().is_empty() {
            parts.push(t);
        }
    }
    let Some(title) = parts.first().cloned() else { return Ok(None) };
    let body = parts[1..].join(" ");
    let logo = display
        .GetLogo(Size { Width: 64.0, Height: 64.0 })
        .ok()
        .and_then(|r| r.cast::<IRandomAccessStreamReference>().ok())
        .and_then(|r| media::decode_image(&r, 80).ok());
    if system(&id) {
        return Ok(None);
    }
    if options().hide_banners {
        hide_banner(&id);
    }
    Ok(Some(Item {
        art: logo.map_or(Art::Glyph('\u{E7E7}'), |l| Art::Image(Arc::new(l))),
        title,
        body,
        source,
        action: Action::App(id),
        hold_ms: 5000,
    }))
}

fn messages() {
    unsafe {
        let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
    }
    let Ok(listener) = UserNotificationListener::Current() else { return };
    if listener.GetAccessStatus().is_ok_and(|s| s != Access::Allowed) {
        if let Ok(op) = listener.RequestAccessAsync() {
            let _ = media::wait(op, 60_000);
        }
    }
    let mut seen: HashSet<u32> = HashSet::new();
    let mut first = true;
    loop {
        std::thread::sleep(Duration::from_millis(if first { 200 } else { 1200 }));
        if !options().messages && !first {
            continue;
        }
        let Ok(op) = listener.GetNotificationsAsync(NotificationKinds::Toast) else { continue };
        let Ok(list) = media::wait(op, 4000) else { continue };
        let mut now = HashSet::new();
        for i in 0..list.Size().unwrap_or(0) {
            let Ok(n) = list.GetAt(i) else { continue };
            let Ok(id) = n.Id() else { continue };
            now.insert(id);
            // то, что уже лежало в центре уведомлений при запуске, не показываем
            if first || seen.contains(&id) {
                continue;
            }
            if let Ok(Some(item)) = read_item(&n) {
                island::send(item);
            }
        }
        seen = now;
        first = false;
    }
}

/// Проверка разбора уведомлений без показа. Содержимое чужих уведомлений в отчёт не попадает:
/// для них только счётчики, текст виден лишь у тестового с заголовком «Test»
pub fn check() -> String {
    std::thread::spawn(|| {
        unsafe {
            let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
        }
        let inner = || -> Result<String> {
            let l = UserNotificationListener::Current()?;
            let status = l.GetAccessStatus()?;
            let list = media::wait(l.GetNotificationsAsync(NotificationKinds::Toast)?, 5000)?;
            let (mut parsed, mut skipped, mut failed) = (0, 0, 0);
            let mut test = String::from("тестовое не найдено");
            for i in 0..list.Size()? {
                match read_item(&list.GetAt(i)?) {
                    Ok(Some(item)) => {
                        parsed += 1;
                        if item.title == "Test" {
                            let art = matches!(item.art, Art::Image(_));
                            test = format!("тестовое: заголовок «{}», текст «{}», значок программы: {art}", item.title, item.body);
                        }
                    }
                    Ok(None) => skipped += 1,
                    Err(_) => failed += 1,
                }
            }
            Ok(format!("доступ: {}\nразобрано: {parsed}, системных пропущено: {skipped}, ошибок: {failed}\n{test}", status.0))
        };
        inner().unwrap_or_else(|e| format!("ошибка: {e}"))
    })
    .join()
    .unwrap_or_default()
}

// ---------- загрузки ----------

fn downloads_dir() -> Option<PathBuf> {
    unsafe {
        let p = SHGetKnownFolderPath(&FOLDERID_Downloads, KF_FLAG_DEFAULT, None).ok()?;
        let s = p.to_string().ok();
        CoTaskMemFree(Some(p.0 as *const _));
        s.map(PathBuf::from)
    }
}

fn unfinished(name: &str) -> bool {
    let low = name.to_lowercase();
    [".crdownload", ".part", ".partial", ".tmp", ".opdownload", ".download", ".!ut", ".temp"].iter().any(|e| low.ends_with(e))
        || low.starts_with('.')
        || low.starts_with("~$")
        || low == "desktop.ini"
}

fn snapshot(d: &PathBuf) -> HashMap<String, u64> {
    let mut out = HashMap::new();
    if let Ok(rd) = std::fs::read_dir(d) {
        for e in rd.flatten() {
            if let Ok(m) = e.metadata() {
                if m.is_file() {
                    out.insert(e.file_name().to_string_lossy().to_string(), m.len());
                }
            }
        }
    }
    out
}

fn size_text(b: u64) -> String {
    match b {
        b if b >= 1 << 30 => format!("{:.1} ГБ", b as f64 / (1u64 << 30) as f64),
        b if b >= 1 << 20 => format!("{:.1} МБ", b as f64 / (1u64 << 20) as f64),
        b => format!("{} КБ", (b / 1024).max(1)),
    }
}

fn downloads() {
    let Some(d) = downloads_dir() else { return };
    let mut known = snapshot(&d);
    // новые файлы, которые ждут, пока размер перестанет меняться
    let mut pending: HashMap<String, u64> = HashMap::new();
    loop {
        std::thread::sleep(Duration::from_secs(2));
        let now = snapshot(&d);
        let mut done = Vec::new();
        for (name, size) in &now {
            if known.contains_key(name) || unfinished(name) || *size == 0 {
                continue;
            }
            match pending.get(name) {
                Some(prev) if prev == size => done.push((name.clone(), *size)),
                _ => {
                    pending.insert(name.clone(), *size);
                }
            }
        }
        // большая пачка файлов — это копирование или распаковка, а не загрузка
        if done.len() <= 3 && options().downloads {
            for (name, size) in &done {
                island::send(Item {
                    art: Art::Glyph('\u{E896}'),
                    title: "Загрузка завершена".into(),
                    body: format!("{name} · {}", size_text(*size)),
                    source: String::new(),
                    action: Action::Reveal(d.join(name)),
                    hold_ms: 5000,
                });
            }
        }
        for (name, _) in &done {
            pending.remove(name);
        }
        pending.retain(|n, _| now.contains_key(n));
        known = now.iter().filter(|(n, _)| !pending.contains_key(*n)).map(|(n, s)| (n.clone(), *s)).collect();
    }
}

// ---------- смена трека и устройства (вызывается из таймера окна) ----------

struct Watch {
    track: Option<String>,
    /// новый трек ждёт обложку, но не дольше пары секунд
    pending: Option<(String, Instant)>,
    device: Option<String>,
}

static WATCH: Mutex<Watch> = Mutex::new(Watch { track: None, pending: None, device: None });

/// Панель музыки открыта — о смене трека и так видно
pub fn tick(music_open: bool, device: Option<String>) {
    let Ok(mut w) = WATCH.lock() else { return };
    let o = options();
    if let Some(d) = device {
        if w.device.as_ref().is_some_and(|old| *old != d) && o.devices {
            island::send(Item {
                art: Art::Glyph('\u{E767}'),
                title: "Звук переключён".into(),
                body: d.clone(),
                source: String::new(),
                action: Action::None,
                hold_ms: 2800,
            });
        }
        w.device = Some(d);
    }
    let Some(t) = media::track().filter(|t| t.playing) else {
        w.pending = None;
        return;
    };
    let key = format!("{}\n{}", t.title, t.artist);
    if w.track.as_ref() != Some(&key) {
        let had = w.track.is_some();
        w.track = Some(key.clone());
        w.pending = had.then(|| (key.clone(), Instant::now()));
    }
    let ready = w.pending.as_ref().is_some_and(|(k, at)| *k == key && (t.art.is_some() || at.elapsed() > Duration::from_secs(2)));
    if ready {
        w.pending = None;
        if o.tracks && !music_open {
            island::send(track_item(&t.title, &t.artist, t.art.clone()));
        }
    }
}

fn track_item(title: &str, artist: &str, art: Option<Arc<Img>>) -> Item {
    Item {
        art: art.map_or(Art::Glyph('\u{EC4F}'), Art::Image),
        title: title.to_string(),
        body: artist.to_string(),
        source: "Сейчас играет".into(),
        action: Action::None,
        hold_ms: 2800,
    }
}

// ---------- стандартные баннеры Windows ----------

const SETTINGS: &str = "Software\\Microsoft\\Windows\\CurrentVersion\\Notifications\\Settings";

fn wide(s: &str) -> Vec<u16> {
    s.encode_utf16().chain(Some(0)).collect()
}

fn banners_file() -> Option<PathBuf> {
    Some(dir()?.join("banners.txt"))
}

/// Выключить баннер у программы; список запоминаем, чтобы потом вернуть как было
fn hide_banner(id: &str) {
    let Some(f) = banners_file() else { return };
    let text = std::fs::read_to_string(&f).unwrap_or_default();
    if text.lines().any(|l| l == id) {
        return;
    }
    let (key, name, v) = (wide(&format!("{SETTINGS}\\{id}")), wide("ShowBanner"), 0u32);
    unsafe {
        let _ = RegSetKeyValueW(
            HKEY_CURRENT_USER,
            windows::core::PCWSTR(key.as_ptr()),
            windows::core::PCWSTR(name.as_ptr()),
            REG_DWORD.0,
            Some(&v as *const u32 as *const _),
            4,
        );
    }
    let _ = std::fs::write(f, text + id + "\n");
}

/// Вернуть баннеры всем программам, у которых мы их выключали
pub fn restore_banners() {
    let Some(f) = banners_file() else { return };
    let text = std::fs::read_to_string(&f).unwrap_or_default();
    for id in text.lines().filter(|l| !l.is_empty()) {
        let (key, name) = (wide(&format!("{SETTINGS}\\{id}")), wide("ShowBanner"));
        unsafe {
            let _ = RegDeleteKeyValueW(HKEY_CURRENT_USER, windows::core::PCWSTR(key.as_ptr()), windows::core::PCWSTR(name.as_ptr()));
        }
    }
    let _ = std::fs::remove_file(f);
}

/// Тестовые карточки для проверки вёрстки — текст придуман
pub fn sample(kind: &str) -> Item {
    match kind {
        "download" => Item { art: Art::Glyph('\u{E896}'), title: "Загрузка завершена".into(), body: "setup-programmy.exe · 84.2 МБ".into(), source: String::new(), action: Action::None, hold_ms: 5000 },
        "device" => Item { art: Art::Glyph('\u{E767}'), title: "Звук переключён".into(), body: "Динамики · Realtek(R) Audio".into(), source: String::new(), action: Action::None, hold_ms: 2800 },
        "long" => Item { art: Art::Glyph('\u{E7E7}'), title: "Имя отправителя".into(), body: "Длинное сообщение для проверки: оно должно занять две строки и аккуратно закончиться многоточием, если не поместилось в карточку целиком".into(), source: "Telegram".into(), action: Action::None, hold_ms: 5000 },
        _ => Item { art: Art::Glyph('\u{E7E7}'), title: "Имя отправителя".into(), body: "Короткое сообщение".into(), source: "Discord".into(), action: Action::None, hold_ms: 5000 },
    }
}
