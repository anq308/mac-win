//! Что сейчас играет: системные элементы управления медиа (SMTC), как у плашки Windows.
//! Вызовы WinRT здесь блокирующие, поэтому живут в своём потоке, а окну достаётся готовый снимок

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{channel, Receiver, RecvTimeoutError, Sender};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use windows::core::{Result, RuntimeType};
use windows_future::{AsyncStatus, IAsyncOperation};
use windows::Graphics::Imaging::{
    BitmapAlphaMode, BitmapBounds, BitmapDecoder, BitmapInterpolationMode, BitmapPixelFormat, BitmapTransform,
    ColorManagementMode, ExifOrientationMode,
};
use windows::Media::Control::{
    GlobalSystemMediaTransportControlsSession as Session,
    GlobalSystemMediaTransportControlsSessionManager as Manager,
    GlobalSystemMediaTransportControlsSessionPlaybackStatus as Status,
};
use windows::Storage::Streams::IRandomAccessStreamReference;
use windows::Win32::System::Com::{CoInitializeEx, COINIT_MULTITHREADED};

use crate::gfx::Img;

/// сторона обложки в памяти: с запасом под масштаб экрана 200 %
const ART: u32 = 256;
/// единицы WinRT — 100 нс
pub const TICKS: i64 = 10_000_000;
/// столько времени после команды верим своему состоянию, а не плееру: он отвечает с задержкой
const HOLD: Duration = Duration::from_millis(900);

#[derive(Clone, Default)]
pub struct Track {
    pub title: String,
    pub artist: String,
    pub app: String,
    /// сколько плееров сейчас в системе
    pub players: usize,
    pub playing: bool,
    pub pos: i64,
    pub end: i64,
    /// когда была верна позиция pos
    pub at: Option<Instant>,
    pub can_prev: bool,
    pub can_next: bool,
    pub can_toggle: bool,
    pub can_seek: bool,
    pub art: Option<Arc<Img>>,
}

impl Track {
    /// Позиция прямо сейчас: между обновлениями от плеера считаем сами
    pub fn position(&self) -> i64 {
        let run = match (self.playing, self.at) {
            (true, Some(at)) => (at.elapsed().as_secs_f64() * TICKS as f64) as i64,
            _ => 0,
        };
        let p = self.pos + run;
        if self.end > 0 {
            p.clamp(0, self.end)
        } else {
            p.max(0)
        }
    }
}

#[derive(Clone, Copy)]
pub enum Cmd {
    Toggle,
    Next,
    Prev,
    Stop,
    Seek(i64),
    /// следующий плеер из списка
    Cycle,
    /// панель открыта — обновляемся чаще; закрыта — выбор плеера забываем
    Watch(bool),
}

static TRACK: Mutex<Option<Track>> = Mutex::new(None);
static TX: Mutex<Option<Sender<Cmd>>> = Mutex::new(None);
static HAS_SESSION: AtomicBool = AtomicBool::new(false);

/// Дождаться ответа WinRT, но не вечно: зависший плеер не должен останавливать всю панель
pub fn wait<T: RuntimeType + 'static>(op: IAsyncOperation<T>, ms: u64) -> Result<T> {
    let start = Instant::now();
    loop {
        let st = op.Status()?;
        if st != AsyncStatus::Started {
            return op.GetResults();
        }
        if start.elapsed() > Duration::from_millis(ms) {
            let _ = op.Cancel();
            return Err(windows::core::Error::from_hresult(windows::Win32::Foundation::E_ABORT));
        }
        std::thread::sleep(Duration::from_millis(4));
    }
}

pub fn start() {
    let (tx, rx) = channel();
    if let Ok(mut s) = TX.lock() {
        *s = Some(tx);
    }
    std::thread::spawn(move || worker(rx));
}

/// Есть ли кому отдать клавиши музыки (спрашивает хук клавиатуры — ответ должен быть мгновенным)
pub fn has_session() -> bool {
    HAS_SESSION.load(Ordering::Relaxed)
}

pub fn track() -> Option<Track> {
    TRACK.lock().ok()?.clone()
}

pub fn send(cmd: Cmd) {
    // сразу показываем результат, не дожидаясь плеера
    if let Ok(mut s) = TRACK.lock() {
        if let Some(t) = s.as_mut() {
            match cmd {
                Cmd::Toggle if t.can_toggle => {
                    t.pos = t.position();
                    t.at = Some(Instant::now());
                    t.playing = !t.playing;
                }
                Cmd::Seek(p) => {
                    t.pos = p;
                    t.at = Some(Instant::now());
                }
                _ => {}
            }
        }
    }
    if let Ok(s) = TX.lock() {
        if let Some(tx) = s.as_ref() {
            let _ = tx.send(cmd);
        }
    }
}

/// Один опрос без фонового потока — для проверки (--preview music-live)
pub fn once() -> std::result::Result<Option<Track>, String> {
    std::thread::spawn(|| {
        unsafe {
            let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
        }
        Worker::new().read().map_err(|e| e.to_string())
    })
    .join()
    .unwrap_or_else(|_| Err("поток упал".into()))
}

struct Worker {
    manager: Option<Manager>,
    /// плеер, выбранный вручную, пока панель открыта
    chosen: Option<String>,
    watch: bool,
    /// сколько частых опросов ещё сделать после команды
    burst: u32,
    hold: Option<Instant>,
    art_key: String,
    /// плееры отдают обложку позже названия — после смены трека читаем её ещё пару раз
    art_tries: u32,
    art: Option<Arc<Img>>,
    /// сколько опросов подряд не удалось / подтвердили, что плееров нет
    fails: u32,
    empty: u32,
}

fn worker(rx: Receiver<Cmd>) {
    unsafe {
        let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
    }
    let mut w = Worker::new();
    loop {
        w.update();
        let wait = if w.burst > 0 {
            250
        } else if w.watch {
            1000
        } else {
            3000
        };
        match rx.recv_timeout(Duration::from_millis(wait)) {
            Ok(cmd) => {
                w.apply(cmd);
                while let Ok(cmd) = rx.try_recv() {
                    w.apply(cmd);
                }
            }
            Err(RecvTimeoutError::Timeout) => w.burst = w.burst.saturating_sub(1),
            Err(RecvTimeoutError::Disconnected) => return,
        }
    }
}

fn source(s: &Session) -> String {
    s.SourceAppUserModelId().map(|h| h.to_string()).unwrap_or_default()
}

fn is_playing(s: &Session) -> bool {
    s.GetPlaybackInfo().and_then(|i| i.PlaybackStatus()).is_ok_and(|st| st == Status::Playing)
}

impl Worker {
    fn new() -> Worker {
        Worker { manager: None, chosen: None, watch: false, burst: 0, hold: None, art_key: String::new(), art_tries: 0, art: None, fails: 0, empty: 0 }
    }

    fn manager(&mut self) -> Result<Manager> {
        if let Some(m) = &self.manager {
            return Ok(m.clone());
        }
        let m = wait(Manager::RequestAsync()?, 5000)?;
        self.manager = Some(m.clone());
        Ok(m)
    }

    /// Все плееры и номер того, что показываем: выбранный вручную, потом играющий, потом текущий системный
    fn sessions(&mut self) -> Result<(Vec<Session>, usize)> {
        let mgr = self.manager()?;
        let list = mgr.GetSessions()?;
        let mut all = Vec::new();
        for i in 0..list.Size()? {
            all.push(list.GetAt(i)?);
        }
        let current = mgr.GetCurrentSession().map(|s| source(&s)).unwrap_or_default();
        let by_id = |id: &str| all.iter().position(|s| source(s) == id);
        let idx = self
            .chosen
            .as_deref()
            .and_then(by_id)
            .or_else(|| by_id(&current).filter(|&i| is_playing(&all[i])))
            .or_else(|| all.iter().position(is_playing))
            .or_else(|| by_id(&current))
            .unwrap_or(0);
        Ok((all, idx))
    }

    fn apply(&mut self, cmd: Cmd) {
        match cmd {
            Cmd::Watch(on) => {
                self.watch = on;
                if on {
                    self.burst = self.burst.max(1);
                } else {
                    self.chosen = None;
                }
                return;
            }
            Cmd::Toggle | Cmd::Seek(_) => self.hold = Some(Instant::now() + HOLD),
            _ => {}
        }
        self.burst = 4;
        let Ok((all, idx)) = self.sessions() else { return };
        if all.is_empty() {
            return;
        }
        if let Cmd::Cycle = cmd {
            self.chosen = Some(source(&all[(idx + 1) % all.len()]));
            return;
        }
        let s = &all[idx];
        // ответа не ждём: зависший плеер не должен останавливать панель, итог покажет следующий опрос
        let _ = match cmd {
            Cmd::Toggle => s.TryTogglePlayPauseAsync().map(drop),
            Cmd::Next => s.TrySkipNextAsync().map(drop),
            Cmd::Prev => s.TrySkipPreviousAsync().map(drop),
            Cmd::Stop => s.TryStopAsync().map(drop),
            Cmd::Seek(p) => s.TryChangePlaybackPositionAsync(p).map(drop),
            _ => Ok(()),
        };
    }

    fn update(&mut self) {
        let mut t = match self.read() {
            Ok(Some(t)) => {
                (self.fails, self.empty) = (0, 0);
                Some(t)
            }
            Ok(None) => {
                self.fails = 0;
                self.empty += 1;
                // плеер мог на миг пропасть при смене трека: «ничего нет» — только если это подтвердилось
                if self.empty < 3 {
                    return;
                }
                None
            }
            Err(_) => {
                // при смене трека браузер часто отвечает ошибкой — показываем прежнее и не отдаём клавиши Windows
                self.fails += 1;
                if self.fails < 8 {
                    return;
                }
                // служба могла перезапуститься — попросим менеджер заново
                self.manager = None;
                self.fails = 0;
                return;
            }
        };
        HAS_SESSION.store(t.is_some(), Ordering::Relaxed);
        let Ok(mut cur) = TRACK.lock() else { return };
        if let (Some(t), Some(old), Some(until)) = (t.as_mut(), cur.as_ref(), self.hold) {
            if Instant::now() < until && t.title == old.title {
                t.playing = old.playing;
                t.pos = old.position();
                t.at = Some(Instant::now());
            }
        }
        *cur = t;
    }

    fn read(&mut self) -> Result<Option<Track>> {
        let (all, idx) = self.sessions()?;
        let Some(s) = all.get(idx) else {
            self.art = None;
            self.art_key.clear();
            return Ok(None);
        };
        let info = s.GetPlaybackInfo()?;
        let controls = info.Controls()?;
        let props = wait(s.TryGetMediaPropertiesAsync()?, 2500)?;
        let timeline = s.GetTimelineProperties()?;
        let playing = info.PlaybackStatus()? == Status::Playing;
        let id = source(s);
        let title = props.Title()?.to_string();
        let mut artist = props.Artist()?.to_string();
        if artist.is_empty() {
            artist = props.AlbumTitle()?.to_string();
        }

        let key = format!("{id}\n{title}\n{artist}");
        if key != self.art_key {
            self.art_key = key;
            self.art = None;
            self.art_tries = 3;
        }
        if self.art_tries > 0 {
            self.art_tries -= 1;
            let fresh = props.Thumbnail().ok().and_then(|th| decode_image(&th, ART).ok());
            if fresh.is_some() {
                self.art = fresh.map(Arc::new);
            }
        }

        let end = timeline.EndTime()?.Duration.max(0);
        let mut pos = timeline.Position()?.Duration;
        if playing {
            // плеер сообщает позицию редко и вместе с моментом, когда она была верна
            let updated = timeline.LastUpdatedTime()?.UniversalTime;
            if updated > 0 {
                pos += (filetime_now() - updated).max(0);
            }
        }
        Ok(Some(Track {
            title: if title.is_empty() { "Без названия".into() } else { title },
            artist,
            app: app_name(&id),
            players: all.len(),
            playing,
            pos,
            end,
            at: Some(Instant::now()),
            can_prev: controls.IsPreviousEnabled().unwrap_or(false),
            can_next: controls.IsNextEnabled().unwrap_or(false),
            can_toggle: controls.IsPauseEnabled().unwrap_or(false) || controls.IsPlayEnabled().unwrap_or(false),
            can_seek: controls.IsPlaybackPositionEnabled().unwrap_or(false) && end > 0,
            art: self.art.clone(),
        }))
    }
}

/// Текущее время в единицах DateTime: 100 нс с 1601 года
fn filetime_now() -> i64 {
    let unix = SystemTime::now().duration_since(UNIX_EPOCH).map_or(0, |d| d.as_nanos() as i64 / 100);
    unix + 116_444_736_000_000_000
}

/// Обложка квадратом: широкие кадры (например, с YouTube) обрезаем по центру
pub fn decode_image(th: &IRandomAccessStreamReference, side: u32) -> Result<Img> {
    let stream = wait(th.OpenReadAsync()?, 2500)?;
    let dec = wait(BitmapDecoder::CreateAsync(&stream)?, 2500)?;
    let (w, h) = (dec.PixelWidth()?.max(1), dec.PixelHeight()?.max(1));
    let k = side as f32 / w.min(h) as f32;
    let (sw, sh) = (((w as f32 * k).round() as u32).max(side), ((h as f32 * k).round() as u32).max(side));
    let tr = BitmapTransform::new()?;
    tr.SetScaledWidth(sw)?;
    tr.SetScaledHeight(sh)?;
    tr.SetInterpolationMode(BitmapInterpolationMode::Fant)?;
    tr.SetBounds(BitmapBounds { X: (sw - side) / 2, Y: (sh - side) / 2, Width: side, Height: side })?;
    let data = wait(
        dec.GetPixelDataTransformedAsync(
            BitmapPixelFormat::Bgra8,
            BitmapAlphaMode::Premultiplied,
            &tr,
            ExifOrientationMode::RespectExifOrientation,
            ColorManagementMode::ColorManageToSRgb,
        )?,
        2500,
    )?;
    let px = data.DetachPixelData()?.to_vec();
    if px.len() != (side * side * 4) as usize {
        return Err(windows::core::Error::from_hresult(windows::Win32::Foundation::E_FAIL));
    }
    Ok(Img { w: side, h: side, px })
}

/// Понятное имя плеера из идентификатора приложения
fn app_name(id: &str) -> String {
    const KNOWN: [(&str, &str); 19] = [
        ("spotify", "Spotify"),
        ("yandex", "Яндекс"),
        ("msedge", "Edge"),
        ("chrome", "Chrome"),
        ("308046b0af4a39cb", "Firefox"),
        ("firefox", "Firefox"),
        ("opera", "Opera"),
        ("brave", "Brave"),
        ("vivaldi", "Vivaldi"),
        ("telegram", "Telegram"),
        ("discord", "Discord"),
        ("steam", "Steam"),
        ("vlc", "VLC"),
        ("aimp", "AIMP"),
        ("foobar", "foobar2000"),
        ("applemusic", "Apple Music"),
        ("itunes", "iTunes"),
        ("zunemusic", "Музыка Groove"),
        ("zunevideo", "Кино и ТВ"),
    ];
    let low = id.to_lowercase();
    if let Some((_, name)) = KNOWN.iter().find(|(k, _)| low.contains(k)) {
        return (*name).to_string();
    }
    let s = id.rsplit(['\\', '/']).next().unwrap_or(id);
    let s = s.split('!').next().unwrap_or(s);
    let s = s.split('_').next().unwrap_or(s);
    let s = s.strip_suffix(".exe").or_else(|| s.strip_suffix(".EXE")).unwrap_or(s);
    let s = s.rsplit('.').next().unwrap_or(s);
    let mut c = s.chars();
    c.next().map_or(String::new(), |f| f.to_uppercase().chain(c).collect())
}
