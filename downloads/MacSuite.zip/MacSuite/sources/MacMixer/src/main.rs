#![windows_subsystem = "windows"]

mod audio;
mod gfx;
mod battery;
mod hook;
mod island;
mod lyrics;
mod media;
mod music;
mod notify;
mod panel;
mod win;

use std::ffi::c_void;
use std::mem::size_of;

use windows::core::{w, PCWSTR};
use windows::Win32::Foundation::*;
use windows::Win32::System::Com::{CoInitializeEx, COINIT_APARTMENTTHREADED};
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::System::Registry::*;
use windows::Win32::System::Threading::CreateMutexW;
use windows::Win32::UI::HiDpi::{SetProcessDpiAwarenessContext, DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2};
use windows::Win32::UI::Input::KeyboardAndMouse::{RegisterHotKey, MOD_CONTROL, MOD_NOREPEAT, MOD_WIN};
use windows::Win32::UI::Shell::*;
use windows::Win32::UI::WindowsAndMessaging::*;

use audio::{Flow, Target};
use gfx::{Icon, Img};
use win::{pcwstr, wide};

const WM_TRAY: u32 = WM_APP + 2;
/// повторный запуск exe просит уже работающую копию открыть панель
const WM_OPEN: u32 = WM_APP + 3;
const TIMER_TRAY: usize = 1;
/// Ctrl+Win+M — панель «Сейчас играет»
const HOTKEY_MUSIC: i32 = 1;

const MENU_MIXER: usize = 1;
const MENU_SETTINGS: usize = 2;
const MENU_DEVICES: usize = 3;
const MENU_CLASSIC: usize = 4;
const MENU_AUTOSTART: usize = 5;
const MENU_EXIT: usize = 6;
const MENU_MUSIC: usize = 7;
const MENU_ISLAND: usize = 20;

static mut TASKBAR_CREATED: u32 = 0;
/// что сейчас нарисовано в трее: (волны или 255 = выключен, подсказка)
static mut TRAY_STATE: Option<(u8, String)> = None;

fn main() {
    // panic = "abort" не оставляет следов — пишем причину в лог рядом с exe
    std::panic::set_hook(Box::new(|info| {
        if let Ok(exe) = std::env::current_exe() {
            let log = exe.with_file_name("crash.log");
            let line = format!("{:?}: {info}\n", std::time::SystemTime::now());
            let _ = std::fs::OpenOptions::new().create(true).append(true).open(log)
                .and_then(|mut f| std::io::Write::write_all(&mut f, line.as_bytes()));
        }
    }));
    unsafe {
        let _ = SetProcessDpiAwarenessContext(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);
        let _ = CoInitializeEx(None, COINIT_APARTMENTTHREADED);
    }
    let args: Vec<String> = std::env::args().skip(1).collect();
    // при удалении программы вернуть стандартные баннеры уведомлений
    if args.first().map(String::as_str) == Some("--restore-banners") {
        notify::restore_banners();
        return;
    }
    if args.first().map(String::as_str) == Some("--preview") {
        preview(&args[1..]);
        return;
    }
    unsafe {
        let _ = CreateMutexW(None, true, w!("Local\\MacMixer.Instance"));
        if GetLastError() == ERROR_ALREADY_EXISTS {
            if let Ok(main) = FindWindowW(w!("MacMixer.Main"), None) {
                let _ = AllowSetForegroundWindow(ASFW_ANY);
                let _ = PostMessageW(Some(main), WM_OPEN, WPARAM(0), LPARAM(0));
            }
            return;
        }
    }
    let Some(fonts) = gfx::Fonts::load() else { return };
    if !audio::init() {
        return;
    }
    // панель громкости — всплывающее окно, поэтому тема как у панели задач
    gfx::load_themes();
    gfx::use_theme(false);
    panel::init(fonts);
    music::init();
    media::start();

    unsafe {
        let inst = GetModuleHandleW(None).unwrap_or_default();
        let wc = WNDCLASSW {
            lpfnWndProc: Some(wndproc),
            hInstance: inst.into(),
            lpszClassName: w!("MacMixer.Main"),
            ..Default::default()
        };
        RegisterClassW(&wc);
        let Ok(hwnd) =
            CreateWindowExW(WS_EX_TOOLWINDOW, w!("MacMixer.Main"), w!("MacMixer"), WS_POPUP, 0, 0, 0, 0, None, None, Some(inst.into()), None)
        else {
            return;
        };
        TASKBAR_CREATED = RegisterWindowMessageW(w!("TaskbarCreated"));
        update_tray(hwnd, true);
        SetTimer(Some(hwnd), TIMER_TRAY, 500, None);
        hook::start(hwnd);
        island::init(hwnd);
        notify::start();
        battery::start();
        let _ = RegisterHotKey(Some(hwnd), HOTKEY_MUSIC, MOD_WIN | MOD_CONTROL | MOD_NOREPEAT, u32::from(b'M'));

        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).as_bool() {
            let _ = TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        remove_tray(hwnd);
    }
    // программы больше нет — уведомления снова показывает сама Windows
    notify::restore_banners();
}

// ---------- трей ----------

fn tray_image(state: u8) -> Img {
    let size = unsafe { GetSystemMetrics(SM_CXSMICON) }.max(16) as u32 * 2;
    let mut img = Img::new(size, size);
    if let Some(mut pm) = img.pixmap_mut() {
        let kind = if state == 255 { Icon::SpeakerMuted } else { Icon::Speaker(state) };
        gfx::icon(&mut pm, kind, 0.0, 0.0, size as f32, gfx::white(1.0));
    }
    img
}

/// Значок и подсказка в трее следуют за громкостью основного устройства
fn update_tray(hwnd: HWND, add: bool) {
    let Some(st) = audio::with(|a| {
        if !panel::is_open() {
            a.check_default();
        }
        let d = a.output();
        let (vol, muted) = a.level(Target::Out).map_or((0.0, true), |l| (l.0, l.1));
        let state = if muted || d.is_none() {
            255
        } else {
            match vol {
                v if v < 0.01 => 0,
                v if v < 0.34 => 1,
                v if v < 0.67 => 2,
                _ => 3,
            }
        };
        let tip = match d {
            None => "Нет устройств вывода".to_string(),
            Some(d) if muted => format!("Звук выключен — {}", d.name),
            Some(d) => format!("Громкость {}% — {}", (vol * 100.0).round() as i32, d.name),
        };
        (state, tip)
    }) else {
        return;
    };
    unsafe {
        let cur = &raw mut TRAY_STATE;
        if !add && (*cur).as_ref() == Some(&st) {
            return;
        }
        let mut nid = NOTIFYICONDATAW {
            cbSize: size_of::<NOTIFYICONDATAW>() as u32,
            hWnd: hwnd,
            uID: 1,
            uFlags: NIF_ICON | NIF_MESSAGE | NIF_TIP,
            uCallbackMessage: WM_TRAY,
            hIcon: win::hicon(&tray_image(st.0)),
            ..Default::default()
        };
        let tip = wide(&st.1);
        let n = tip.len().min(nid.szTip.len() - 1);
        nid.szTip[..n].copy_from_slice(&tip[..n]);
        let _ = Shell_NotifyIconW(if add { NIM_ADD } else { NIM_MODIFY }, &nid);
        let _ = DestroyIcon(nid.hIcon);
        *cur = Some(st);
    }
}

fn remove_tray(hwnd: HWND) {
    unsafe {
        let nid = NOTIFYICONDATAW { cbSize: size_of::<NOTIFYICONDATAW>() as u32, hWnd: hwnd, uID: 1, ..Default::default() };
        let _ = Shell_NotifyIconW(NIM_DELETE, &nid);
    }
}

fn run(file: PCWSTR, args: Option<&str>) {
    let a = args.map(wide);
    unsafe {
        ShellExecuteW(None, w!("open"), file, a.as_ref().map_or(PCWSTR::null(), |a| pcwstr(a)), None, SW_SHOWNORMAL);
    }
}

fn tray_menu(hwnd: HWND) {
    unsafe {
        let Ok(m) = CreatePopupMenu() else { return };
        let _ = AppendMenuW(m, MF_STRING, MENU_MIXER, w!("Микшер громкости"));
        let _ = SetMenuDefaultItem(m, MENU_MIXER as u32, 0);
        let _ = AppendMenuW(m, MF_STRING, MENU_MUSIC, w!("Сейчас играет\tCtrl+Win+M"));
        let o = notify::options();
        let sub = CreatePopupMenu().unwrap_or_default();
        let check = |on: bool| if on { MF_STRING | MF_CHECKED } else { MF_STRING };
        let _ = AppendMenuW(sub, check(o.messages), MENU_ISLAND, w!("Сообщения и уведомления"));
        let _ = AppendMenuW(sub, check(o.tracks), MENU_ISLAND + 1, w!("Смена трека"));
        let _ = AppendMenuW(sub, check(o.downloads), MENU_ISLAND + 2, w!("Завершённые загрузки"));
        let _ = AppendMenuW(sub, check(o.devices), MENU_ISLAND + 3, w!("Смена устройства звука"));
        let _ = AppendMenuW(sub, check(o.battery), MENU_ISLAND + 5, w!("Заряд наушников"));
        let _ = AppendMenuW(sub, MF_SEPARATOR, 0, None);
        let _ = AppendMenuW(sub, check(o.hide_banners), MENU_ISLAND + 4, w!("Скрывать стандартные уведомления"));
        let _ = AppendMenuW(m, MF_POPUP, sub.0 as usize, w!("Островок сверху"));
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        let _ = AppendMenuW(m, MF_STRING, MENU_SETTINGS, w!("Параметры звука"));
        let _ = AppendMenuW(m, MF_STRING, MENU_DEVICES, w!("Устройства воспроизведения"));
        let _ = AppendMenuW(m, MF_STRING, MENU_CLASSIC, w!("Классический микшер Windows"));
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        let flags = if autostart_enabled() { MF_STRING | MF_CHECKED } else { MF_STRING };
        let _ = AppendMenuW(m, flags, MENU_AUTOSTART, w!("Запускать вместе с Windows"));
        let _ = AppendMenuW(m, MF_SEPARATOR, 0, None);
        let _ = AppendMenuW(m, MF_STRING, MENU_EXIT, w!("Выход"));
        let p = win::cursor();
        let _ = SetForegroundWindow(hwnd);
        let cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_RIGHTBUTTON, p.x, p.y, Some(0), hwnd, None).0 as usize;
        let _ = DestroyMenu(m);
        match cmd {
            MENU_MIXER => panel::open(),
            MENU_MUSIC => music::toggle(),
            c if (MENU_ISLAND..MENU_ISLAND + 6).contains(&c) => {
                let mut o = notify::options();
                match c - MENU_ISLAND {
                    0 => o.messages = !o.messages,
                    1 => o.tracks = !o.tracks,
                    2 => o.downloads = !o.downloads,
                    3 => o.devices = !o.devices,
                    5 => o.battery = !o.battery,
                    _ => {
                        o.hide_banners = !o.hide_banners;
                        if !o.hide_banners {
                            notify::restore_banners();
                        }
                    }
                }
                notify::set_options(o);
            }
            MENU_SETTINGS => run(w!("ms-settings:sound"), None),
            MENU_DEVICES => run(w!("control.exe"), Some("mmsys.cpl,,0")),
            MENU_CLASSIC => run(w!("sndvol.exe"), None),
            MENU_AUTOSTART => set_autostart(!autostart_enabled()),
            MENU_EXIT => PostQuitMessage(0),
            _ => {}
        }
    }
}

const RUN_KEY: PCWSTR = w!("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
const RUN_VALUE: PCWSTR = w!("MacMixer");

fn autostart_enabled() -> bool {
    let mut size = 0u32;
    let r = unsafe { RegGetValueW(HKEY_CURRENT_USER, RUN_KEY, RUN_VALUE, RRF_RT_REG_SZ, None, None, Some(&mut size)) };
    r == ERROR_SUCCESS
}

fn set_autostart(on: bool) {
    unsafe {
        if on {
            let Ok(exe) = std::env::current_exe() else { return };
            let cmd = wide(&format!("\"{}\"", exe.display()));
            let _ = RegSetKeyValueW(
                HKEY_CURRENT_USER,
                RUN_KEY,
                RUN_VALUE,
                REG_SZ.0,
                Some(cmd.as_ptr() as *const c_void),
                (cmd.len() * 2) as u32,
            );
        } else {
            let _ = RegDeleteKeyValueW(HKEY_CURRENT_USER, RUN_KEY, RUN_VALUE);
        }
    }
}

unsafe extern "system" fn wndproc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_TIMER if wp.0 == TIMER_TRAY => {
            update_tray(hwnd, false);
            let device = audio::with(|a| a.output().map(|d| d.name.clone())).flatten();
            notify::tick(music::is_open(), device);
            LRESULT(0)
        }
        WM_TRAY => {
            match (lp.0 & 0xFFFF) as u32 {
                WM_LBUTTONUP => panel::toggle(),
                WM_RBUTTONUP => tray_menu(hwnd),
                _ => {}
            }
            LRESULT(0)
        }
        WM_OPEN => {
            panel::open();
            LRESULT(0)
        }
        island::WM_ISLAND => {
            island::pump();
            LRESULT(0)
        }
        // сообщение от других программ комплекта, например «Текст скопирован» из MacShot
        WM_COPYDATA => {
            let cd = &*(lp.0 as *const windows::Win32::System::DataExchange::COPYDATASTRUCT);
            if cd.dwData != 0x4D49 || cd.lpData.is_null() {
                return LRESULT(0);
            }
            let data = std::slice::from_raw_parts(cd.lpData as *const u16, cd.cbData as usize / 2);
            let text = String::from_utf16_lossy(data);
            // «заголовок\0текст» и необязательно «\0путь» — тогда щелчок покажет файл в папке
            let mut parts = text.split('\0');
            let title = parts.next().unwrap_or_default();
            let body = parts.next().unwrap_or_default();
            let path = parts.next().filter(|p| !p.is_empty()).map(std::path::PathBuf::from);
            island::send(island::Item {
                art: island::Art::Glyph(if path.is_some() { '\u{E896}' } else { '\u{E8C8}' }),
                title: title.to_string(),
                body: body.to_string(),
                source: String::new(),
                action: path.map_or(island::Action::None, island::Action::Reveal),
                hold_ms: 2800,
            });
            LRESULT(1)
        }
        hook::WM_MEDIA_KEY => {
            music::key(wp.0 as u16);
            update_tray(hwnd, false);
            LRESULT(0)
        }
        WM_HOTKEY if wp.0 as i32 == HOTKEY_MUSIC => {
            music::toggle();
            LRESULT(0)
        }
        m if m == TASKBAR_CREATED && m != 0 => {
            update_tray(hwnd, true);
            LRESULT(0)
        }
        WM_SETTINGCHANGE => {
            // сменили тему или цвет акцента — перерисуем значок в трее
            gfx::load_themes();
            gfx::use_theme(false);
            TRAY_STATE = None;
            update_tray(hwnd, false);
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

// ---------- превью для проверки вёрстки ----------

/// mac-mixer.exe --preview [out|in|tray|music|music-paused|music-hover|music-nosek|music-empty|music-volume|music-live] файл.png
fn preview(args: &[String]) {
    let (kind, out) = match args {
        [k, o, ..] => (k.as_str(), o.clone()),
        [o] => ("", o.clone()),
        [] => ("", "preview.png".into()),
    };
    if !audio::init() {
        return;
    }
    gfx::load_themes();
    gfx::use_theme(false);
    let img = match kind {
        "tray" => {
            // все состояния значка в ряд на тёмном фоне
            let parts: Vec<Img> = [0u8, 1, 2, 3, 255].iter().map(|s| tray_image(*s)).collect();
            let sz = parts[0].w;
            let mut row = Img::new(sz * 5 + 40, sz + 8);
            if let Some(mut pm) = row.pixmap_mut() {
                pm.fill(gfx::rgb(0x10, 0x10, 0x10, 1.0));
                for (i, p) in parts.iter().enumerate() {
                    gfx::image(&mut pm, p, 4.0 + i as f32 * (sz as f32 + 8.0), 4.0, sz as f32, 1.0);
                }
            }
            Some(row)
        }
        k if k.starts_with("lyrics:") => {
            // mac-mixer.exe --preview lyrics:название|исполнитель|секунды отчёт.txt
            let parts: Vec<&str> = k[7..].split('|').collect();
            let r = lyrics::selftest(parts.first().unwrap_or(&""), parts.get(1).unwrap_or(&""), parts.get(2).and_then(|s| s.parse().ok()).unwrap_or(0));
            let _ = std::fs::write(&out, r);
            return;
        }
        "battery" => {
            let _ = std::fs::write(&out, battery::check());
            return;
        }
        "notif-check" => {
            let _ = std::fs::write(&out, notify::check());
            return;
        }
        k if k.starts_with("island") => island::preview(&notify::sample(k.strip_prefix("island-").unwrap_or(""))),
        k if k.starts_with("music") => music::preview(k.strip_prefix("music-").unwrap_or("full")),
        "out" => panel::preview(Some(Flow::Out)),
        "in" => panel::preview(Some(Flow::In)),
        _ => panel::preview(None),
    };
    if let Some(png) = img.as_ref().and_then(win::encode_png) {
        let _ = std::fs::write(out, png);
    }
}
