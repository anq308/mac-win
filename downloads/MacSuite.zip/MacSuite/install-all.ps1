﻿# Установка всего комплекта разом: MacShot, MacMixer, MacFinder, MacSpotlight, MacMirror.
# Программы сами определяют Windows 10 или 11 и подстраивают оформление.
# .\install-all.ps1             — установить или обновить всё
# .\install-all.ps1 -Uninstall  — удалить всё
# .\install-all.ps1 -Check      — только проверить, что все файлы на месте
param([switch]$Uninstall, [switch]$Check)

$root = $PSScriptRoot
$apps = @(
    @{ Name = "MacShot";     Title = "Снимки экрана";       Exe = "mac-shot.exe" },
    @{ Name = "MacMixer";    Title = "Микшер и панель музыки"; Exe = "mac-mixer.exe" },
    @{ Name = "MacFinder";   Title = "Файловый менеджер";   Exe = "mac-finder.exe" },
    @{ Name = "MacSpotlight"; Title = "Поиск по Win+Пробел"; Exe = "mac-spotlight.exe" },
    @{ Name = "MacMirror";   Title = "Экран iPhone на ПК";  Exe = "mac-mirror.exe" }
)

$missing = @()
foreach ($a in $apps) {
    foreach ($f in "install.ps1", $a.Exe) {
        $p = Join-Path $root "apps\$($a.Name)\$f"
        if (-not (Test-Path $p)) { $missing += $p }
    }
}
if ($missing.Count) {
    Write-Host "Не хватает файлов — распакуйте архив целиком:" -ForegroundColor Red
    $missing | ForEach-Object { Write-Host "  $_" }
    exit 1
}
if ($Check) {
    Write-Host "Все файлы на месте."
    return
}

$build = [int](Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").CurrentBuildNumber
$win11 = $build -ge 22000
if (-not [Environment]::Is64BitOperatingSystem -or $build -lt 17763) {
    Write-Host "Нужна 64-битная Windows 10 (версия 1809 или новее) или Windows 11." -ForegroundColor Red
    exit 1
}

if ($Uninstall) {
    foreach ($a in $apps) {
        Write-Host "--- $($a.Name)"
        & (Join-Path $root "apps\$($a.Name)\install.ps1") -Uninstall
    }
    Write-Host ""
    Write-Host "Комплект удалён. Windhawk, если ставился, можно удалить в «Приложения и возможности»."
    return
}

Write-Host "Устанавливаю комплект для Windows $(if ($win11) { '11' } else { '10' }) (сборка $build)."
Write-Host "Windows спросит разрешение администратора один-два раза: брандмауэр для экрана iPhone и замена Проводника."
Write-Host ""

# Замена Проводника — самое заметное изменение системы, поэтому спрашиваем отдельно
$keepExplorer = $true
if ($win11) {
    Write-Host "Открывать папки в Finder вместо Проводника? Ставит Windhawk. На Windows 11 эта замена" -ForegroundColor Yellow
    Write-Host "ещё не проверялась, поэтому по умолчанию «нет» — Finder всё равно будет доступен с ярлыка." -ForegroundColor Yellow
    $keepExplorer = (Read-Host "Заменить Проводник? [y/N]") -notmatch '^[yYдД]'
} else {
    Write-Host "Открывать папки в Finder вместо Проводника? Ставит Windhawk. Вернуть можно в любой момент." -ForegroundColor Yellow
    $keepExplorer = (Read-Host "Заменить Проводник? [Y/n]") -match '^[nNнН]'
}

if (-not $keepExplorer -and -not (Test-Path (Join-Path $env:ProgramFiles "Windhawk\windhawk.ini"))) {
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "Ставлю Windhawk..."
        winget install --id RamenSoftware.Windhawk -e --silent --accept-package-agreements --accept-source-agreements
    } else {
        Write-Host "Нет winget — Windhawk не поставить автоматически. Finder откроется по Win+E, а папки останутся в Проводнике."
    }
}

$failed = @()
foreach ($a in $apps) {
    Write-Host ""
    Write-Host "--- $($a.Name): $($a.Title)" -ForegroundColor Cyan
    try {
        $script = Join-Path $root "apps\$($a.Name)\install.ps1"
        if ($a.Name -eq "MacFinder" -and $keepExplorer) { & $script -KeepExplorer } else { & $script }
    } catch {
        Write-Host $_ -ForegroundColor Red
        $failed += $a.Name
    }
}

Write-Host ""
if ($failed.Count) {
    Write-Host "Не установились: $($failed -join ', '). Запустите установщик ещё раз." -ForegroundColor Red
} else {
    Write-Host "Готово, всё установлено!" -ForegroundColor Green
}
Write-Host ""
Write-Host "  Win+Пробел     — поиск"
Write-Host "  Win+Shift+S    — снимок экрана"
Write-Host "  Клавиши музыки и громкости, Ctrl+Win+M — панель музыки сверху"
Write-Host "  Клик по динамику в трее — микшер громкости"
Write-Host "  «Экран iPhone» на рабочем столе, на iPhone: Пункт управления → «Повтор экрана»"
